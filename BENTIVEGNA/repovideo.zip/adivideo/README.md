# EventFlow - Plataforma de Eventos y Reservas

EventFlow es una plataforma completa para gestión de eventos con sistema de reservas, desarrollada con PocketBase como backend y React como frontend.

## 🎯 Características

- **Sistema de autenticación** completo con roles (admin, organizer, user)
- **Gestión de eventos** con cupo, imágenes, localización y fechas
- **Sistema de reservas** con lista de espera automática
- **Panel de organizador** para crear y gestionar eventos
- **Panel de administración** con métricas y auditoría
- **Actualizaciones en tiempo real** usando PocketBase subscriptions
- **Subida de imágenes** a PocketBase
- **Validaciones de negocio** en backend (hooks)
- **Comentarios** en eventos
- **Logs de auditoría** de todas las acciones importantes

## 🛠️ Stack Tecnológico

### Backend
- **PocketBase**: Backend como servicio con base de datos SQLite embebida
- **Hooks JavaScript**: Lógica de negocio en el servidor
- **Reglas de acceso**: Control de permisos a nivel de colección

### Frontend
- **React 18**: Biblioteca de UI
- **TypeScript**: Tipado estático
- **Vite**: Build tool y dev server
- **Tailwind CSS**: Framework de estilos
- **React Router**: Navegación
- **PocketBase JS SDK**: Cliente para comunicarse con el backend
- **date-fns**: Manejo de fechas

### DevOps
- **Docker Compose**: Orquestación de servicios
- **Node.js**: Runtime para scripts de seed

## 📋 Requisitos Previos

- Docker y Docker Compose instalados
- Node.js 20+ (para ejecutar el script de seed)
- Navegador web moderno

## 🚀 Instalación y Configuración

### 1. Clonar el repositorio

```bash
git clone <repository-url>
cd adivideo
```

### 2. Configurar variables de entorno

Crea un archivo `.env` en la raíz del proyecto (opcional):

```env
PB_ENCRYPTION_KEY=your-32-char-encryption-key-here-change-it
VITE_POCKETBASE_URL=http://localhost:8090
```

### 3. Levantar los servicios con Docker Compose

```bash
docker-compose up -d
```

Esto levantará:
- PocketBase en `http://localhost:8090`
- Frontend en `http://localhost:5173`

### 4. Configurar PocketBase

#### 4.1. Acceder a la interfaz admin

1. Abre `http://localhost:8090/_/` en tu navegador
2. Crea la cuenta de administrador inicial
3. Guarda las credenciales

#### 4.2. Crear las colecciones

Debes crear las siguientes colecciones en PocketBase. Puedes hacerlo manualmente desde la interfaz o usar la API.

**Colección: users** (extender la colección auth por defecto)
- Campos adicionales:
  - `role` (select): ["admin", "organizer", "user"] - default: "user"
  - `name` (text)
  - `avatar` (file)

**Colección: events**
- `title` (text)
- `description` (editor)
- `startAt` (date)
- `endAt` (date)
- `location` (text)
- `capacity` (number)
- `coverImage` (file)
- `organizer` (relation) -> users
- `status` (select): ["draft", "published", "cancelled"] - default: "draft"

**Colección: reservations**
- `event` (relation) -> events
- `user` (relation) -> users
- `status` (select): ["active", "cancelled", "waitlist"] - default: "active"
- `createdAt` (date) - auto

**Colección: comments**
- `event` (relation) -> events
- `user` (relation) -> users
- `content` (text)
- `createdAt` (date) - auto

**Colección: audit_logs**
- `actor` (relation) -> users
- `action` (text)
- `entityType` (text)
- `entityId` (text)
- `payload` (json)
- `createdAt` (date) - auto

#### 4.3. Configurar reglas de acceso

Consulta el archivo `backend/setup_collections.md` para las reglas de acceso detalladas.

**Reglas resumidas:**

- **users**: Cualquiera puede ver, solo admin puede cambiar roles
- **events**: Cualquiera puede ver publicados, solo organizer/admin puede crear/editar
- **reservations**: Usuarios pueden ver sus propias reservas, organizadores pueden ver las de sus eventos
- **comments**: Autenticados pueden crear, solo autor o admin puede borrar
- **audit_logs**: Solo admin puede ver

#### 4.4. Copiar hooks

Los hooks ya están en `backend/pb_hooks/`. Asegúrate de que PocketBase los detecte. Si usas Docker, los hooks se montan automáticamente.

### 5. Ejecutar seed de datos

```bash
cd backend
npm install
npm run seed
```

Esto creará:
- 1 usuario admin
- 3 organizadores
- 10 usuarios normales
- 15 eventos variados
- Reservas y comentarios de ejemplo

**Credenciales de prueba:**
- Admin: `admin@eventflow.com` / `admin123`
- Organizador: `organizer1@eventflow.com` / `org123`
- Usuario: `user1@eventflow.com` / `user123`

### 6. Acceder a la aplicación

Abre `http://localhost:5173` en tu navegador.

## 📁 Estructura del Proyecto

```
adivideo/
├── backend/
│   ├── pb_data/              # Datos de PocketBase (generado)
│   ├── pb_migrations/        # Migraciones (vacío por ahora)
│   ├── pb_hooks/             # Hooks de PocketBase
│   │   ├── onBeforeCreate_reservations.js
│   │   ├── onAfterCreate_reservations.js
│   │   ├── onBeforeUpdate_reservations.js
│   │   ├── onBeforeUpdate_events.js
│   │   └── onBeforeDelete_comments.js
│   ├── seed.js               # Script de seed
│   ├── package.json
│   └── setup_collections.md  # Documentación de colecciones
├── frontend/
│   ├── src/
│   │   ├── components/       # Componentes reutilizables
│   │   ├── contexts/         # Contextos de React
│   │   ├── lib/              # Utilidades
│   │   ├── pages/            # Páginas de la aplicación
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   └── Dockerfile
├── docker-compose.yml
└── README.md
```

## 🔧 Comandos Útiles

### Desarrollo

```bash
# Levantar servicios
docker-compose up -d

# Ver logs
docker-compose logs -f

# Detener servicios
docker-compose down

# Reconstruir contenedores
docker-compose up -d --build
```

### Frontend

```bash
cd frontend

# Instalar dependencias
npm install

# Desarrollo
npm run dev

# Build para producción
npm run build

# Tests
npm test
```

### Backend

```bash
cd backend

# Instalar dependencias
npm install

# Ejecutar seed
npm run seed
```

## 🎨 Funcionalidades por Rol

### Usuario (user)
- Ver eventos publicados
- Reservar plazas en eventos
- Ver y cancelar sus reservas
- Comentar en eventos
- Editar su perfil

### Organizador (organizer)
- Todas las funcionalidades de usuario
- Crear, editar y eliminar eventos
- Ver reservas de sus eventos
- Cambiar estado de eventos (draft/published/cancelled)

### Administrador (admin)
- Todas las funcionalidades anteriores
- Ver todos los usuarios
- Cambiar roles de usuarios
- Ver logs de auditoría
- Ver métricas del sistema

## 🔄 Lógica de Negocio (Hooks)

### Crear Reserva
1. Valida que el usuario esté autenticado
2. Verifica que el evento esté publicado
3. Previene reservas duplicadas
4. Asigna `status = "active"` si hay cupo, `"waitlist"` si está lleno
5. Registra en `audit_logs`

### Cancelar Reserva Activa
1. Si se cancela una reserva activa y hay lista de espera, promueve la más antigua a `active`
2. Registra en `audit_logs`

### Cancelar Evento
1. Cancela automáticamente todas las reservas activas y en waitlist
2. Registra en `audit_logs`

### Borrar Comentario
1. Solo el autor o admin puede borrar
2. Registra en `audit_logs`

## 🔔 Realtime

La aplicación usa suscripciones de PocketBase para actualizar la UI en tiempo real:

- **Eventos**: Se actualizan cuando cambian (crear, editar, cancelar)
- **Reservas**: Se actualizan cuando se crean o cancelan (afecta cupo disponible)
- **Comentarios**: Se actualizan cuando se crean o borran

## 📧 Verificación de Email

PocketBase soporta verificación de email, pero en este proyecto está deshabilitada para facilitar el desarrollo. Para activarla:

1. Configura SMTP en PocketBase admin (`Settings > Mail settings`)
2. Habilita `Email verification` en la colección `users`
3. Los usuarios recibirán un email de verificación al registrarse

## 🧪 Tests

### Tests Backend (Hooks)

```bash
cd backend
node __tests__/hooks.test.js
```

Los tests verifican la lógica conceptual de los hooks.

### Tests Frontend

```bash
cd frontend
npm test
```

Tests unitarios para componentes y contextos.

## 🐛 Troubleshooting

### PocketBase no inicia
- Verifica que el puerto 8090 no esté en uso
- Revisa los logs: `docker-compose logs pocketbase`
- Asegúrate de que `pb_data` tenga permisos de escritura

### Frontend no se conecta a PocketBase
- Verifica que `VITE_POCKETBASE_URL` esté configurado correctamente
- Asegúrate de que PocketBase esté corriendo
- Revisa la consola del navegador para errores CORS

### Hooks no se ejecutan
- Verifica que los archivos estén en `backend/pb_hooks/`
- Asegúrate de que el volumen esté montado correctamente en Docker
- Revisa los logs de PocketBase para errores en los hooks

### Seed falla
- Asegúrate de que PocketBase esté corriendo
- Verifica que las colecciones estén creadas
- Revisa que las reglas de acceso permitan crear registros

## 📝 Checklist de Verificación Manual

Antes de considerar la demo lista, verifica:

1. ✅ **Autenticación**
   - [ ] Registro de nuevo usuario funciona
   - [ ] Login con credenciales correctas funciona
   - [ ] Logout funciona correctamente

2. ✅ **Eventos**
   - [ ] Se listan eventos publicados en la home
   - [ ] Los filtros (ubicación, fecha) funcionan
   - [ ] El detalle del evento muestra toda la información
   - [ ] El cupo disponible se actualiza en tiempo real

3. ✅ **Reservas**
   - [ ] Un usuario puede reservar un evento con cupo disponible
   - [ ] Si el cupo está lleno, la reserva va a lista de espera
   - [ ] No se puede reservar dos veces el mismo evento
   - [ ] Al cancelar una reserva activa, se promueve una de waitlist
   - [ ] "Mis Reservas" muestra todas las reservas del usuario

4. ✅ **Panel Organizador**
   - [ ] Se pueden crear nuevos eventos
   - [ ] Se pueden editar eventos existentes
   - [ ] Se pueden eliminar eventos
   - [ ] Se ven las reservas de cada evento

5. ✅ **Panel Admin**
   - [ ] Se listan todos los usuarios
   - [ ] Se puede cambiar el rol de un usuario
   - [ ] Se ven los audit logs
   - [ ] Se muestran las métricas (reservas por día, top eventos)

6. ✅ **Comentarios**
   - [ ] Se pueden crear comentarios en eventos
   - [ ] Solo el autor o admin puede borrar comentarios
   - [ ] Los comentarios se actualizan en tiempo real

7. ✅ **Realtime**
   - [ ] Al crear una reserva, el cupo se actualiza sin refrescar
   - [ ] Al cancelar una reserva, el cupo se actualiza sin refrescar
   - [ ] Los nuevos comentarios aparecen sin refrescar

8. ✅ **Validaciones Backend**
   - [ ] No se puede reservar un evento no publicado
   - [ ] No se puede reservar dos veces el mismo evento
   - [ ] Solo el organizador o admin puede editar eventos
   - [ ] Solo el autor o admin puede borrar comentarios

9. ✅ **Perfil**
   - [ ] Se puede editar el nombre
   - [ ] Se puede subir un avatar (opcional, si está configurado)

10. ✅ **Datos de Seed**
    - [ ] Existen eventos de ejemplo
    - [ ] Existen reservas variadas (activas, waitlist, canceladas)
    - [ ] Existen comentarios en algunos eventos

## 📄 Licencia

Este proyecto es un ejemplo educativo. Úsalo como base para tus propios proyectos.

## 🤝 Contribuciones

Este es un proyecto de demostración. Siéntete libre de usarlo como base y adaptarlo a tus necesidades.

---

**Desarrollado con ❤️ usando PocketBase y React**
