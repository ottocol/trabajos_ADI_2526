import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import pb, { type User } from '../lib/pocketbase';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, name: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const updateProfile = async () => {
    try {
      if (pb.authStore.isValid) {
        const authData = pb.authStore.model;
        if (authData) {
          // Cargar el usuario completo con relaciones si es necesario
          const record = await pb.collection('users').getOne(authData.id);
          setUser(record as any as User);
        }
      } else {
        setUser(null);
      }
      } catch (err) {
        console.error('Error updating profile:', err);
      setUser(null);
    } finally {
    setLoading(false);
    }
  };

  useEffect(() => {
    // Obtener sesión inicial
    if (pb.authStore.isValid) {
        updateProfile();
      } else {
        setLoading(false);
      }

    // Escuchar cambios de autenticación
    pb.authStore.onChange((token, model) => {
      if (model) {
        setUser(model as any as User);
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    // Cleanup
    return () => {
      // No hay unsubscribe directo, pero podemos limpiar el listener si es necesario
    };
  }, []);

  const login = async (email: string, password: string) => {
    const authData = await pb.collection('users').authWithPassword(email, password);
    // Recargar el usuario completo para obtener todos los campos
    const fullUser = await pb.collection('users').getOne(authData.record.id);
    setUser(fullUser as any as User);
  };

  const register = async (email: string, password: string, name: string) => {
    const data = {
      email,
      password,
      passwordConfirm: password,
          name,
      role: 'user',
    };
    await pb.collection('users').create(data);
    // Iniciar sesión automáticamente después del registro
    await login(email, password);
  };

  const logout = async () => {
    pb.authStore.clear();
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{ user, loading, login, register, logout, updateProfile }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}