import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import pb, { type Reservation } from '../lib/pocketbase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function MyReservations() {
  const { user } = useAuth();
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadReservations();

    // Suscripción realtime
    let subscription: any = null;
    let isMounted = true;

    pb.collection('reservations')
      .subscribe('*', () => {
        if (isMounted) {
          loadReservations();
        }
      })
      .then((sub) => {
        if (isMounted) {
          subscription = sub;
        } else if (sub && typeof sub.unsubscribe === 'function') {
          // Si el componente ya se desmontó, limpia la suscripción inmediatamente
          sub.unsubscribe().catch(() => {});
        }
      })
      .catch((err) => {
        console.error('Error subscribing to reservations:', err);
      });

    return () => {
      isMounted = false;
      if (subscription && typeof subscription.unsubscribe === 'function') {
        subscription.unsubscribe().catch(() => {});
      }
    };
  }, [user]);

  const loadReservations = async () => {
    if (!user) return;
    try {
      const records = await pb.collection('reservations').getList<Reservation>(1, 100, {
        filter: `user = "${user.id}"`,
        expand: 'event',
        sort: '-created',
      });

      setReservations(records.items || []);
    } catch (err: any) {
      // Ignorar errores de autocancelación (normal en React 18 StrictMode)
      if (err?.status === 0 || err?.message?.includes('autocancelled')) {
        return;
      }
      console.error('Error loading reservations:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async (reservationId: string) => {
    if (!confirm('¿Estás seguro de cancelar esta reserva?')) return;

    try {
      await pb.collection('reservations').update(reservationId, {
        status: 'cancelled',
      });
      await loadReservations();
    } catch (err: any) {
      alert(err.message || 'Error al cancelar la reserva');
    }
  };

  if (loading) {
    return <div className="text-center py-12">Cargando reservas...</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Mis Reservas</h1>

      {reservations.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          No tienes reservas aún.
        </div>
      ) : (
        <div className="space-y-4">
          {reservations.map((reservation) => {
            const event = reservation.expand?.event;
            const coverUrl = event?.coverImage
              ? pb.files.getUrl(event, event.coverImage)
              : 'https://via.placeholder.com/150';

            return (
              <div
                key={reservation.id}
                className="bg-white rounded-lg shadow-md p-6 flex items-center gap-6"
              >
                <img
                  src={coverUrl}
                  alt={event?.title || 'Evento'}
                  className="w-24 h-24 object-cover rounded"
                />
                <div className="flex-1">
                  <Link
                    to={`/event/${reservation.event}`}
                    className="text-xl font-semibold text-indigo-600 hover:underline"
                  >
                    {event?.title || 'Evento'}
                  </Link>
                  {event?.startAt && (
                    <p className="text-gray-600 mt-1">
                      📅 {format(new Date(event.startAt), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
                    </p>
                  )}
                  {event?.location && (
                    <p className="text-gray-600">📍 {event.location}</p>
                  )}
                  <p className="mt-2">
                    Estado:{' '}
                    <span
                      className={`font-semibold ${
                        reservation.status === 'active'
                          ? 'text-green-600'
                          : reservation.status === 'waitlist'
                          ? 'text-yellow-600'
                          : 'text-red-600'
                      }`}
                    >
                      {reservation.status === 'active'
                        ? '✅ Activa'
                        : reservation.status === 'waitlist'
                        ? '⏳ Lista de espera'
                        : '❌ Cancelada'}
                    </span>
                  </p>
                </div>
                {reservation.status !== 'cancelled' && (
                  <button
                    onClick={() => handleCancel(reservation.id)}
                    className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                  >
                    Cancelar
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}