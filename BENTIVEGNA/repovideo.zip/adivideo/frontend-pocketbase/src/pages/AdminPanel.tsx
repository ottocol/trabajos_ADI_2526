import { useEffect, useState } from 'react';
import pb, { type User, type AuditLog, type Event } from '../lib/pocketbase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function AdminPanel() {
  const { user } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [metrics, setMetrics] = useState({
    totalUsers: 0,
    totalEvents: 0,
    totalReservations: 0,
    reservationsByDay: [] as { date: string; count: number }[],
    topEvents: [] as { event: Event; count: number }[],
  });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'users' | 'logs' | 'metrics'>('users');

  useEffect(() => {
    if (!user || user.role !== 'admin') return;
    loadUsers();
    loadAuditLogs();
    loadMetrics();

    // Suscripciones realtime
    let usersSubscription: any = null;
    let logsSubscription: any = null;

    pb.collection('users')
      .subscribe('*', () => {
          loadUsers();
          loadMetrics();
      })
      .then((sub) => {
        usersSubscription = sub;
      })
      .catch((err) => {
        console.error('Error subscribing to users:', err);
      });

    pb.collection('audit_logs')
      .subscribe('*', () => {
          loadAuditLogs();
      })
      .then((sub) => {
        logsSubscription = sub;
      })
      .catch((err) => {
        console.error('Error subscribing to audit_logs:', err);
      });

    return () => {
      if (usersSubscription) {
        usersSubscription.unsubscribe().catch(() => {});
      }
      if (logsSubscription) {
        logsSubscription.unsubscribe().catch(() => {});
      }
    };
  }, [user]);

  const loadUsers = async () => {
    try {
      const records = await pb.collection('users').getList<User>(1, 100, {
        sort: '-created',
      });
      setUsers(records.items || []);
    } catch (err) {
      console.error('Error loading users:', err);
    }
  };

  const loadAuditLogs = async () => {
    try {
      const records = await pb.collection('audit_logs').getList<AuditLog>(1, 100, {
        expand: 'actor',
        sort: '-created',
      });
      setAuditLogs(records.items || []);
    } catch (err) {
      console.error('Error loading audit logs:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadMetrics = async () => {
    try {
      // Totales
      const usersList = await pb.collection('users').getList(1, 1);
      const usersCount = usersList.totalItems || 0;

      const eventsList = await pb.collection('events').getList(1, 1);
      const eventsCount = eventsList.totalItems || 0;

      const reservationsList = await pb.collection('reservations').getList(1, 1);
      const reservationsCount = reservationsList.totalItems || 0;

      // Reservas por día (últimos 7 días)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const reservationsRecords = await pb.collection('reservations').getList(1, 10000, {
        filter: `created >= "${sevenDaysAgo.toISOString()}"`,
      });

      const byDay: { [key: string]: number } = {};
      reservationsRecords.items.forEach((r) => {
        const date = format(new Date(r.created), 'yyyy-MM-dd');
        byDay[date] = (byDay[date] || 0) + 1;
      });

      const reservationsByDay = Object.entries(byDay).map(([date, count]) => ({
        date,
        count,
      }));

      // Top eventos por reservas
      const allReservations = await pb.collection('reservations').getList(1, 10000, {
        expand: 'event',
      });

      const eventCounts: { [key: string]: { event: Event; count: number } } = {};
      allReservations.items.forEach((r) => {
        const eventId = typeof r.event === 'string' ? r.event : r.event?.id;
        if (eventId) {
          const eventData = typeof r.event === 'object' ? (r.event as any) : null;
          if (!eventCounts[eventId]) {
            eventCounts[eventId] = {
              event: eventData || ({ id: eventId } as Event),
              count: 0,
            };
          }
          eventCounts[eventId].count++;
        }
      });

      const topEvents = Object.values(eventCounts)
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

      setMetrics({
        totalUsers: usersCount,
        totalEvents: eventsCount,
        totalReservations: reservationsCount,
        reservationsByDay,
        topEvents,
      });
    } catch (err) {
      console.error('Error loading metrics:', err);
    }
  };

  const handleChangeRole = async (userId: string, newRole: string) => {
    if (!confirm(`¿Cambiar el rol de este usuario a ${newRole}?`)) return;

    try {
      await pb.collection('users').update(userId, {
        role: newRole,
      });
      loadUsers();
    } catch (err: any) {
      alert(err.message || 'Error al cambiar el rol');
    }
  };

  if (loading) {
    return <div className="text-center py-12">Cargando...</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Panel de Administración</h1>

      <div className="flex gap-2 mb-6 border-b">
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 ${
            activeTab === 'users' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-600'
          }`}
        >
          Usuarios
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`px-4 py-2 ${
            activeTab === 'logs' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-600'
          }`}
        >
          Audit Logs
        </button>
        <button
          onClick={() => setActiveTab('metrics')}
          className={`px-4 py-2 ${
            activeTab === 'metrics' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-600'
          }`}
        >
          Métricas
        </button>
      </div>

      {activeTab === 'users' && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Email
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Nombre
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rol</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {users.map((u) => (
                <tr key={u.id}>
                  <td className="px-6 py-4 whitespace-nowrap">{u.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{u.name || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 text-xs rounded ${
                        u.role === 'admin'
                          ? 'bg-red-100 text-red-800'
                          : u.role === 'organizer'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {u.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={u.role}
                      onChange={(e) => handleChangeRole(u.id, e.target.value)}
                      className="px-2 py-1 border rounded text-sm"
                    >
                      <option value="user">Usuario</option>
                      <option value="organizer">Organizador</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'logs' && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-4 max-h-96 overflow-y-auto">
            <div className="space-y-4">
              {auditLogs.map((log) => {
                const actor = log.expand?.actor;
                return (
                  <div key={log.id} className="border-b pb-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold">{log.action}</p>
                        <p className="text-sm text-gray-600">
                          {log.entityType} - {log.entityId || 'N/A'}
                        </p>
                        <p className="text-xs text-gray-500">
                          Por: {actor?.name || actor?.email || log.actor || 'Sistema'}
                        </p>
                        {log.payload && (
                          <pre className="text-xs bg-gray-50 p-2 rounded mt-2 overflow-x-auto">
                            {JSON.stringify(log.payload, null, 2)}
                          </pre>
                        )}
                      </div>
                      <p className="text-xs text-gray-500">
                        {format(new Date(log.created), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
            {auditLogs.length === 0 && (
              <p className="text-center text-gray-500 py-8">No hay logs de auditoría</p>
            )}
          </div>
        </div>
      )}

      {activeTab === 'metrics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-2">Total Usuarios</h3>
              <p className="text-3xl font-bold text-indigo-600">{metrics.totalUsers}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-2">Total Eventos</h3>
              <p className="text-3xl font-bold text-indigo-600">{metrics.totalEvents}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-2">Total Reservas</h3>
              <p className="text-3xl font-bold text-indigo-600">{metrics.totalReservations}</p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4">Reservas por Día (Últimos 7 días)</h3>
            <div className="space-y-2">
              {metrics.reservationsByDay.map((item) => (
                <div key={item.date} className="flex items-center gap-4">
                  <span className="w-32 text-sm">
                    {format(new Date(item.date), "d 'de' MMMM", { locale: es })}
                  </span>
                  <div className="flex-1 bg-gray-200 rounded-full h-6">
                    <div
                      className="bg-indigo-600 h-6 rounded-full flex items-center justify-end pr-2"
                      style={{
                        width: `${
                          (item.count /
                            Math.max(...metrics.reservationsByDay.map((i) => i.count), 1)) *
                          100
                        }%`,
                      }}
                    >
                      <span className="text-white text-xs">{item.count}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4">Top 5 Eventos por Reservas</h3>
            <div className="space-y-2">
              {metrics.topEvents.map((item, index) => (
                <div key={item.event.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <span className="font-semibold">
                    {index + 1}. {item.event.title || 'Evento sin título'}
                  </span>
                  <span className="text-indigo-600 font-bold">{item.count} reservas</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}