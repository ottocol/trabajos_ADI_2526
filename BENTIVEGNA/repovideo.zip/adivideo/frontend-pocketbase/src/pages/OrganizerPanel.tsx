import { useEffect, useState } from 'react';
import pb, { type Event, type Reservation } from '../lib/pocketbase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function OrganizerPanel() {
  const { user } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    startAt: '',
    endAt: '',
    location: '',
    capacity: 10,
    status: 'draft',
  });

  useEffect(() => {
    if (!user) return;
    loadEvents();

    // Suscripción realtime
    let subscription: any = null;
    pb.collection('events')
      .subscribe('*', () => {
          loadEvents();
      })
      .then((sub) => {
        subscription = sub;
      })
      .catch((err) => {
        console.error('Error subscribing to events:', err);
      });

    return () => {
      if (subscription) {
        subscription.unsubscribe().catch(() => {});
      }
    };
  }, [user]);

  const loadEvents = async () => {
    if (!user) return;
    try {
      const records = await pb.collection('events').getList<Event>(1, 100, {
        filter: `organizer = "${user.id}"`,
        sort: '-created',
      });
      setEvents(records.items || []);
    } catch (err) {
      console.error('Error loading events:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadReservations = async (eventId: string) => {
    try {
      const records = await pb.collection('reservations').getList<Reservation>(1, 100, {
        filter: `event = "${eventId}"`,
        expand: 'user',
        sort: '-created',
      });
      setReservations(records.items || []);
    } catch (err) {
      console.error('Error loading reservations:', err);
    }
  };

  const handleSelectEvent = (event: Event) => {
    setSelectedEvent(event);
    loadReservations(event.id);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const eventData = {
        title: formData.title,
        description: formData.description,
        startAt: formData.startAt,
        endAt: formData.endAt,
        location: formData.location,
        capacity: formData.capacity,
        status: formData.status,
        organizer: user.id,
      };

      if (editingEvent) {
        await pb.collection('events').update(editingEvent.id, eventData);
      } else {
        await pb.collection('events').create(eventData);
      }

      setShowForm(false);
      setEditingEvent(null);
      setFormData({
        title: '',
        description: '',
        startAt: '',
        endAt: '',
        location: '',
        capacity: 10,
        status: 'draft',
      });
      loadEvents();
    } catch (err: any) {
      alert(err.message || 'Error al guardar el evento');
    }
  };

  const handleEdit = (event: Event) => {
    setEditingEvent(event);
    setFormData({
      title: event.title,
      description: event.description || '',
      startAt: new Date(event.startAt).toISOString().slice(0, 16),
      endAt: new Date(event.endAt).toISOString().slice(0, 16),
      location: event.location,
      capacity: event.capacity,
      status: event.status,
    });
    setShowForm(true);
  };

  const handleDelete = async (eventId: string) => {
    if (!confirm('¿Estás seguro de eliminar este evento?')) return;

    try {
      await pb.collection('events').delete(eventId);
      loadEvents();
      if (selectedEvent?.id === eventId) {
        setSelectedEvent(null);
        setReservations([]);
      }
    } catch (err: any) {
      alert(err.message || 'Error al eliminar el evento');
    }
  };

  if (loading) {
    return <div className="text-center py-12">Cargando...</div>;
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Panel de Organizador</h1>
        <button
          onClick={() => {
            setShowForm(true);
            setEditingEvent(null);
            setFormData({
              title: '',
              description: '',
              startAt: '',
              endAt: '',
              location: '',
              capacity: 10,
              status: 'draft',
            });
          }}
          className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
        >
          + Nuevo Evento
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h2 className="text-2xl font-bold mb-4">
            {editingEvent ? 'Editar Evento' : 'Nuevo Evento'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Título</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
                className="w-full px-3 py-2 border rounded"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Descripción</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                required
                rows={4}
                className="w-full px-3 py-2 border rounded"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Fecha Inicio</label>
                <input
                  type="datetime-local"
                  value={formData.startAt}
                  onChange={(e) => setFormData({ ...formData, startAt: e.target.value })}
                  required
                  className="w-full px-3 py-2 border rounded"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Fecha Fin</label>
                <input
                  type="datetime-local"
                  value={formData.endAt}
                  onChange={(e) => setFormData({ ...formData, endAt: e.target.value })}
                  required
                  className="w-full px-3 py-2 border rounded"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Ubicación</label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                required
                className="w-full px-3 py-2 border rounded"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Capacidad</label>
                <input
                  type="number"
                  value={formData.capacity}
                  onChange={(e) => setFormData({ ...formData, capacity: parseInt(e.target.value) })}
                  required
                  min="1"
                  className="w-full px-3 py-2 border rounded"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Estado</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="w-full px-3 py-2 border rounded"
                >
                  <option value="draft">Borrador</option>
                  <option value="published">Publicado</option>
                  <option value="cancelled">Cancelado</option>
                </select>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
              >
                {editingEvent ? 'Actualizar' : 'Crear'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingEvent(null);
                }}
                className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
              >
                Cancelar
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <h2 className="text-2xl font-bold mb-4">Mis Eventos</h2>
          <div className="space-y-4">
            {events.map((event) => (
              <div
                key={event.id}
                className={`bg-white p-4 rounded-lg shadow cursor-pointer ${
                  selectedEvent?.id === event.id ? 'ring-2 ring-indigo-600' : ''
                }`}
                onClick={() => handleSelectEvent(event)}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="font-semibold">{event.title}</h3>
                    <p className="text-sm text-gray-600">
                      {format(new Date(event.startAt), "d 'de' MMMM", { locale: es })}
                    </p>
                    <p className="text-sm text-gray-500">
                      Estado:{' '}
                      {event.status === 'published'
                        ? '✅ Publicado'
                        : event.status === 'draft'
                        ? '📝 Borrador'
                        : '❌ Cancelado'}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEdit(event);
                      }}
                      className="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600"
                    >
                      Editar
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(event.id);
                      }}
                      className="px-3 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          {selectedEvent ? (
            <>
              <h2 className="text-2xl font-bold mb-4">Reservas: {selectedEvent.title}</h2>
              <div className="bg-white p-4 rounded-lg shadow">
                <div className="space-y-2">
                  {reservations.map((reservation) => {
                    const reservationUser = reservation.expand?.user;
                    return (
                      <div key={reservation.id} className="border-b pb-2">
                        <p className="font-semibold">
                          {reservationUser?.name || reservationUser?.email || 'Usuario'}
                        </p>
                        <p className="text-sm text-gray-600">
                          Estado:{' '}
                          {reservation.status === 'active'
                            ? '✅ Activa'
                            : reservation.status === 'waitlist'
                            ? '⏳ Lista de espera'
                            : '❌ Cancelada'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {format(new Date(reservation.created), "d 'de' MMMM 'a las' HH:mm", {
                            locale: es,
                          })}
                        </p>
                      </div>
                    );
                  })}
                </div>
                {reservations.length === 0 && (
                  <p className="text-gray-500 text-center py-4">No hay reservas para este evento</p>
                )}
              </div>
            </>
          ) : (
            <div className="bg-white p-8 rounded-lg shadow text-center text-gray-500">
              Selecciona un evento para ver sus reservas
            </div>
          )}
        </div>
      </div>
    </div>
  );
}