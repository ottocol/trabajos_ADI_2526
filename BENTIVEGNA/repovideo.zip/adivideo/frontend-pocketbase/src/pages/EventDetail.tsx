import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import pb, { type Event, type Reservation, type Comment } from '../lib/pocketbase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function EventDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [event, setEvent] = useState<Event | null>(null);
  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [activeReservations, setActiveReservations] = useState(0);
  const [loading, setLoading] = useState(true);
  const [reserving, setReserving] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);

  useEffect(() => {
    if (!id) return;
    loadEvent();
    loadReservation();
    loadComments();
    loadReservationsCount();

    // Suscripciones realtime
    let eventSubscription: any = null;
    let reservationsSubscription: any = null;
    let commentsSubscription: any = null;
    let isMounted = true;

    pb.collection('events')
      .subscribe(id || '', () => {
        if (isMounted) {
          loadEvent();
        }
      })
      .then((sub) => {
        if (isMounted) {
          eventSubscription = sub;
        } else if (sub && typeof sub.unsubscribe === 'function') {
          sub.unsubscribe().catch(() => {});
        }
      })
      .catch((err) => {
        console.error('Error subscribing to event:', err);
      });

    pb.collection('reservations')
      .subscribe('*', () => {
        if (isMounted) {
          loadReservation();
          loadReservationsCount();
        }
      })
      .then((sub) => {
        if (isMounted) {
          reservationsSubscription = sub;
        } else if (sub && typeof sub.unsubscribe === 'function') {
          sub.unsubscribe().catch(() => {});
        }
      })
      .catch((err) => {
        console.error('Error subscribing to reservations:', err);
      });

    pb.collection('comments')
      .subscribe('*', () => {
        if (isMounted) {
          loadComments();
        }
      })
      .then((sub) => {
        if (isMounted) {
          commentsSubscription = sub;
        } else if (sub && typeof sub.unsubscribe === 'function') {
          sub.unsubscribe().catch(() => {});
        }
      })
      .catch((err) => {
        console.error('Error subscribing to comments:', err);
      });

    return () => {
      isMounted = false;
      if (eventSubscription && typeof eventSubscription.unsubscribe === 'function') {
        eventSubscription.unsubscribe().catch(() => {});
      }
      if (reservationsSubscription && typeof reservationsSubscription.unsubscribe === 'function') {
        reservationsSubscription.unsubscribe().catch(() => {});
      }
      if (commentsSubscription && typeof commentsSubscription.unsubscribe === 'function') {
        commentsSubscription.unsubscribe().catch(() => {});
      }
    };
  }, [id, user]);

  const loadEvent = async () => {
    if (!id) return;
    try {
      const record = await pb.collection('events').getOne<Event>(id, {
        expand: 'organizer',
      });
      setEvent(record);
    } catch (err: any) {
      // Ignorar errores de autocancelación (normal en React 18 StrictMode)
      if (err?.status === 0 || err?.message?.includes('autocancelled')) {
        return;
      }
      console.error('Error loading event:', err);
      navigate('/');
    } finally {
      setLoading(false);
    }
  };

  const loadReservation = async () => {
    if (!id || !user) return;
    try {
      const records = await pb.collection('reservations').getList<Reservation>(1, 1, {
        filter: `event = "${id}" && user = "${user.id}" && (status = "active" || status = "waitlist")`,
        expand: 'event,user',
      });
      setReservation(records.items[0] || null);
    } catch (err) {
      console.error('Error loading reservation:', err);
    }
  };

  const loadComments = async () => {
    if (!id) return;
    try {
      const records = await pb.collection('comments').getList<Comment>(1, 100, {
        filter: `event = "${id}"`,
        expand: 'user',
        sort: '-created',
      });
      setComments(records.items || []);
    } catch (err: any) {
      // Ignorar errores de autocancelación (normal en React 18 StrictMode)
      if (err?.status === 0 || err?.message?.includes('autocancelled')) {
        return;
      }
      console.error('Error loading comments:', err);
    }
  };

  const loadReservationsCount = async () => {
    if (!id) return;
    try {
      const records = await pb.collection('reservations').getList(1, 10000, {
        filter: `event = "${id}" && status = "active"`,
      });
      setActiveReservations(records.items.length || 0);
    } catch (err: any) {
      // Ignorar errores de autocancelación (normal en React 18 StrictMode)
      if (err?.status === 0 || err?.message?.includes('autocancelled')) {
        return;
      }
      console.error('Error loading reservations count:', err);
    }
  };

  const handleReserve = async () => {
    if (!id || !user) {
      navigate('/login');
      return;
    }

    setReserving(true);
    try {
      // En PocketBase, la lógica de reserva se maneja en hooks
      // Simplemente creamos la reserva y el hook determinará si es activa o waitlist
      await pb.collection('reservations').create({
        event: id,
        user: user.id,
        status: 'active', // El hook lo cambiará si es necesario
      });

        await loadReservation();
        await loadReservationsCount();
    } catch (err: any) {
      alert(err.message || 'Error al crear la reserva');
    } finally {
      setReserving(false);
    }
  };

  const handleCancelReservation = async () => {
    if (!reservation) return;

    if (!confirm('¿Estás seguro de cancelar tu reserva?')) return;

    try {
      await pb.collection('reservations').update(reservation.id, {
        status: 'cancelled',
      });
      setReservation(null);
      await loadReservationsCount();
    } catch (err: any) {
      alert(err.message || 'Error al cancelar la reserva');
    }
  };

  const handleSubmitComment = async () => {
    if (!id || !user || !commentText.trim()) return;

    setSubmittingComment(true);
    try {
      await pb.collection('comments').create({
        event: id,
        user: user.id,
        content: commentText.trim(),
      });
      setCommentText('');
    } catch (err: any) {
      alert(err.message || 'Error al crear el comentario');
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!confirm('¿Estás seguro de borrar este comentario?')) return;

    try {
      await pb.collection('comments').delete(commentId);
    } catch (err: any) {
      alert(err.message || 'Error al borrar el comentario');
    }
  };

  if (loading) {
    return <div className="text-center py-12">Cargando evento...</div>;
  }

  if (!event) {
    return <div className="text-center py-12">Evento no encontrado</div>;
  }

  const availableSpots = event.capacity - activeReservations;
  const isFull = availableSpots <= 0;

  const coverUrl = event.coverImage
    ? pb.files.getUrl(event, event.coverImage)
    : 'https://via.placeholder.com/800x400';

  const organizer = event.expand?.organizer;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <img
          src={coverUrl}
          alt={event.title}
          className="w-full h-64 object-cover"
        />
        <div className="p-6">
          <h1 className="text-3xl font-bold mb-4">{event.title}</h1>
          <div className="prose mb-6" dangerouslySetInnerHTML={{ __html: event.description || '' }} />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <p className="text-sm text-gray-500">Fecha de inicio</p>
              <p className="font-semibold">
                {event.startAt
                  ? format(new Date(event.startAt), "d 'de' MMMM 'a las' HH:mm", { locale: es })
                  : 'Fecha no disponible'}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Fecha de fin</p>
              <p className="font-semibold">
                {event.endAt
                  ? format(new Date(event.endAt), "d 'de' MMMM 'a las' HH:mm", { locale: es })
                  : 'Fecha no disponible'}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Ubicación</p>
              <p className="font-semibold">{event.location}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Organizador</p>
              <p className="font-semibold">{organizer?.name || organizer?.email || 'N/A'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Capacidad</p>
              <p className="font-semibold">
                {activeReservations} / {event.capacity} reservas
              </p>
              <p className={`text-sm ${isFull ? 'text-red-600' : 'text-green-600'}`}>
                {isFull ? 'Sin plazas disponibles' : `${availableSpots} plazas disponibles`}
              </p>
            </div>
          </div>

          {/* Botones de reserva */}
          {user ? (
            <div className="mb-6">
              {reservation ? (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="font-semibold mb-2">
                    Tu reserva está: {reservation.status === 'active' ? '✅ Activa' : '⏳ En lista de espera'}
                  </p>
                  <button
                    onClick={handleCancelReservation}
                    className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                  >
                    Cancelar Reserva
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleReserve}
                  disabled={reserving || isFull}
                  className={`px-6 py-3 rounded font-semibold ${
                    isFull
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                  }`}
                >
                  {reserving ? 'Reservando...' : isFull ? 'Sin plazas disponibles' : 'Reservar Plaza'}
                </button>
              )}
            </div>
          ) : (
            <div className="mb-6">
              <p className="text-gray-600 mb-2">Debes iniciar sesión para reservar</p>
              <button
                onClick={() => navigate('/login')}
                className="px-6 py-3 bg-indigo-600 text-white rounded hover:bg-indigo-700"
              >
                Iniciar Sesión
              </button>
            </div>
          )}

          {/* Comentarios */}
          <div className="border-t pt-6">
            <h2 className="text-2xl font-bold mb-4">Comentarios</h2>

            {user && (
              <div className="mb-6">
                <textarea
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Escribe un comentario..."
                  className="w-full px-4 py-2 border rounded mb-2"
                  rows={3}
                />
                <button
                  onClick={handleSubmitComment}
                  disabled={submittingComment || !commentText.trim()}
                  className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 disabled:bg-gray-400"
                >
                  {submittingComment ? 'Enviando...' : 'Enviar Comentario'}
                </button>
              </div>
            )}

            <div className="space-y-4">
              {comments.map((comment) => {
                const commentUser = comment.expand?.user;
                return (
                <div key={comment.id} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-semibold">
                          {commentUser?.name || commentUser?.email || 'Usuario'}
                      </p>
                      <p className="text-sm text-gray-500">
                          {comment.created
                            ? format(new Date(comment.created), "d 'de' MMMM 'a las' HH:mm", { locale: es })
                            : 'Fecha no disponible'}
                      </p>
                    </div>
                      {(user?.id === comment.user || user?.role === 'admin') && (
                      <button
                        onClick={() => handleDeleteComment(comment.id)}
                        className="text-red-600 hover:text-red-800 text-sm"
                      >
                        Borrar
                      </button>
                    )}
                  </div>
                  <p className="text-gray-700">{comment.content}</p>
                </div>
                );
              })}
            </div>

            {comments.length === 0 && (
              <p className="text-gray-500 text-center py-4">No hay comentarios aún</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}