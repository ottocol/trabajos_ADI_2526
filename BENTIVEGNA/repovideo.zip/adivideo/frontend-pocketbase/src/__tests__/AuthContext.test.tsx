import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, waitFor } from '@testing-library/react';
import { AuthProvider, useAuth } from '../contexts/AuthContext';
import pb from '../lib/pocketbase';
import React, { ReactNode } from 'react';

// Mock PocketBase
vi.mock('../lib/pocketbase', () => {
  const mockAuthStore = {
    isValid: false,
    model: null,
    clear: vi.fn(),
    onChange: vi.fn((callback) => {
      return () => {}; // Return unsubscribe function
    }),
  };

  return {
    default: {
      authStore: mockAuthStore,
      collection: vi.fn(() => ({
        getOne: vi.fn(),
        authWithPassword: vi.fn(),
        create: vi.fn(),
      })),
    },
  };
});

const wrapper = ({ children }: { children: ReactNode }) => (
  <AuthProvider>{children}</AuthProvider>
);

describe('AuthContext', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should initialize with no user', async () => {
    const { result } = renderHook(() => useAuth(), { wrapper });

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.user).toBeNull();
  });

  it('should login successfully', async () => {
    const mockUser = {
      id: '1',
      email: 'test@example.com',
      name: 'Test User',
      role: 'user',
    };

    (pb.collection('users').authWithPassword as any).mockResolvedValue({
      record: mockUser,
    });

    (pb.collection('users').getOne as any).mockResolvedValue(mockUser);

    const { result } = renderHook(() => useAuth(), { wrapper });

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    await result.current.login('test@example.com', 'password123');

    await waitFor(() => {
      expect(pb.collection('users').authWithPassword).toHaveBeenCalledWith(
        'test@example.com',
        'password123'
      );
    });
  });

  it('should logout successfully', async () => {
    const { result } = renderHook(() => useAuth(), { wrapper });

    result.current.logout();

    expect(pb.authStore.clear).toHaveBeenCalled();
  });
});
