import PocketBase from 'pocketbase';

const pb = new PocketBase(import.meta.env.VITE_POCKETBASE_URL || 'http://localhost:8090');

export default pb;

// Tipos de base de datos
export interface User {
  id: string;
  email: string;
  username: string;
  name?: string;
  avatar?: string;
  role: 'admin' | 'organizer' | 'user';
  created: string;
  updated: string;
}

export interface Event {
  id: string;
  organizer: string;
  title: string;
  description?: string;
  startAt: string;
  endAt: string;
  location: string;
  capacity: number;
  coverImage?: string;
  status: 'draft' | 'published' | 'cancelled';
  created: string;
  updated: string;
  expand?: {
    organizer?: User;
  };
}

export interface Reservation {
  id: string;
  event: string;
  user: string;
  status: 'active' | 'cancelled' | 'waitlist';
  created: string;
  updated: string;
  expand?: {
    event?: Event;
    user?: User;
  };
}

export interface Comment {
  id: string;
  event: string;
  user: string;
  content: string;
  created: string;
  updated: string;
  expand?: {
    user?: User;
  };
}

export interface AuditLog {
  id: string;
  actor?: string;
  action: string;
  entityType: string;
  entityId?: string;
  payload?: any;
  created: string;
  expand?: {
    actor?: User;
  };
}