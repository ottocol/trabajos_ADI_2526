/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1687431684")

  // update collection data
  unmarshal({
    "createRule": "@request.auth.id != \"\" && (@request.auth.role = \"organizer\" || @request.auth.role = \"admin\")",
    "deleteRule": "organizer = @request.auth.id || @request.auth.role = \"admin\"",
    "listRule": "status = \"published\" || organizer = @request.auth.id || @request.auth.role = \"admin\"",
    "updateRule": "organizer = @request.auth.id || @request.auth.role = \"admin\"",
    "viewRule": "status = \"published\" || organizer = @request.auth.id || @request.auth.role = \"admin\""
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1687431684")

  // update collection data
  unmarshal({
    "createRule": null,
    "deleteRule": null,
    "listRule": null,
    "updateRule": null,
    "viewRule": null
  }, collection)

  return app.save(collection)
})
