/**
 * Script de seed para PocketBase
 * Ejecutar con: node seed.js
 * Requiere que PocketBase esté corriendo en http://localhost:8090
 */

const PocketBase = require('pocketbase/cjs');

const pb = new PocketBase('http://localhost:8090');

// Helper para subir imágenes
async function uploadImage(pb, collection, recordId, field, imagePath) {
  // En producción, usarías archivos reales. Aquí simulamos con un placeholder
  // Para demo, usaremos URLs de placeholder
  return `https://via.placeholder.com/800x400/4F46E5/FFFFFF?text=Event+Image`;
}

async function seed() {
  try {
    console.log('🌱 Iniciando seed de datos...');

    // 1. Crear usuarios admin
    console.log('📝 Creando usuarios admin...');
    const adminData = {
      email: 'admin@eventflow.com',
      password: 'admin123',
      passwordConfirm: 'admin123',
      role: 'admin',
      name: 'Admin User',
      emailVisibility: true,
    };
    let admin;
    try {
      admin = await pb.collection('users').create(adminData);
      console.log('✅ Admin creado:', admin.email);
      // Autenticarse después de crear el admin
      await pb.collection('users').authWithPassword(adminData.email, adminData.password);
      admin = pb.authStore.model;
      console.log('✅ Admin autenticado');
    } catch (err) {
      if (err.status === 400) {
        // Ya existe, intentar autenticarse
        try {
          await pb.collection('users').authWithPassword(adminData.email, adminData.password);
          admin = pb.authStore.model;
          console.log('✅ Admin ya existe, autenticado');
        } catch (authErr) {
          console.log('⚠️ No se pudo autenticar con admin existente, continuando sin autenticación...');
          pb.authStore.clear();
        }
      } else {
        throw err;
      }
    }

    // Asegurarse de que estamos autenticados como admin para crear otros usuarios (si es necesario)
    // Para usuarios, normalmente se crean sin autenticación (registro público)
    // Pero verificamos que el admin esté autenticado por si acaso
    
    // 2. Crear organizadores
    console.log('📝 Creando organizadores...');
    const organizers = [
      {
        email: 'organizer1@eventflow.com',
        password: 'org123',
        passwordConfirm: 'org123',
        role: 'organizer',
        name: 'María González',
        emailVisibility: true,
      },
      {
        email: 'organizer2@eventflow.com',
        password: 'org123',
        passwordConfirm: 'org123',
        role: 'organizer',
        name: 'Carlos Rodríguez',
        emailVisibility: true,
      },
      {
        email: 'organizer3@eventflow.com',
        password: 'org123',
        passwordConfirm: 'org123',
        role: 'organizer',
        name: 'Ana Martínez',
        emailVisibility: true,
      },
    ];

    const createdOrganizers = [];
    for (const orgData of organizers) {
      // Limpiar sesión antes de crear/autenticar otro usuario
      pb.authStore.clear();
      try {
        const org = await pb.collection('users').create(orgData);
        createdOrganizers.push(org);
        console.log('✅ Organizador creado:', org.email);
      } catch (err) {
        // Error 400 puede ser validación o usuario existente
        // Intentar autenticarse para verificar si existe
        if (err.status === 400) {
          try {
            await pb.collection('users').authWithPassword(orgData.email, orgData.password);
            createdOrganizers.push(pb.authStore.model);
            console.log('✅ Organizador ya existe:', orgData.email);
            pb.authStore.clear(); // Limpiar para el siguiente
          } catch (authErr) {
            // No se pudo autenticar, probablemente no existe o password diferente
            // Intentar obtener usuario si tenemos admin autenticado
            if (admin) {
              try {
                pb.authStore.clear();
                await pb.collection('users').authWithPassword(adminData.email, adminData.password);
                const existingUsers = await pb.collection('users').getList(1, 100, {
                  filter: `email = "${orgData.email}"`,
                });
                if (existingUsers.items.length > 0) {
                  createdOrganizers.push(existingUsers.items[0]);
                  console.log('✅ Organizador encontrado (sin autenticar):', orgData.email);
                  pb.authStore.clear();
                } else {
                  console.log('⚠️ Error creando organizador:', orgData.email, '-', err.message);
                  pb.authStore.clear();
                }
              } catch (fetchErr) {
                console.log('⚠️ No se pudo obtener organizador:', orgData.email);
                pb.authStore.clear();
              }
            } else {
              console.log('⚠️ No se pudo crear/autenticar organizador:', orgData.email);
              pb.authStore.clear();
            }
          }
        } else {
          console.log('⚠️ Error inesperado creando organizador:', orgData.email, '-', err.message);
        }
      }
    }
    
    // Si no hay organizadores creados, usar el admin como organizador
    if (createdOrganizers.length === 0 && admin) {
      console.log('⚠️ No se pudieron crear organizadores, usando admin como organizador');
      createdOrganizers.push(admin);
    }

    // 3. Crear usuarios normales
    console.log('📝 Creando usuarios...');
    const users = [];
    for (let i = 1; i <= 10; i++) {
      // Limpiar sesión antes de crear otro usuario
      pb.authStore.clear();
      const userData = {
        email: `user${i}@eventflow.com`,
        password: 'user123',
        passwordConfirm: 'user123',
        role: 'user',
        name: `Usuario ${i}`,
        emailVisibility: true,
      };
      try {
        const user = await pb.collection('users').create(userData);
        users.push(user);
      } catch (err) {
        if (err.status === 400) {
          // Usuario ya existe, intentar autenticarse
          try {
            await pb.collection('users').authWithPassword(userData.email, userData.password);
            users.push(pb.authStore.model);
          } catch (authErr) {
            // Ignorar errores de autenticación para usuarios existentes
            console.log(`⚠️ Usuario ${userData.email} ya existe pero no se pudo autenticar`);
          }
        } else {
          // Ignorar otros errores y continuar
          console.log(`⚠️ Error creando usuario ${userData.email}:`, err.message);
        }
      }
    }
    console.log(`✅ ${users.length} usuarios procesados`);

    // 4. Crear eventos
    console.log('📝 Creando eventos...');
    const events = [];
    
    // Verificar que tenemos al menos un organizador
    if (createdOrganizers.length === 0) {
      console.log('❌ No hay organizadores disponibles. No se pueden crear eventos.');
      console.log('💡 SOLUCIÓN: Necesitas configurar las colecciones en PocketBase primero.');
      console.log('   1. Ve a http://localhost:8090/_/');
      console.log('   2. Crea las colecciones: users, events, reservations, comments, audit_logs');
      console.log('   3. Configura las reglas de acceso (ve backend/setup_collections.md)');
      console.log('   4. Ejecuta npm run seed nuevamente');
      console.log('');
      console.log('📊 Resumen actual:');
      console.log(`   - 1 admin (✅ creado)`);
      console.log(`   - ${createdOrganizers.length} organizadores`);
      console.log(`   - ${users.length} usuarios`);
      console.log(`   - 0 eventos (no se pudieron crear sin organizadores)`);
      return;
    }
    const eventTemplates = [
      {
        title: 'Conferencia de Tecnología 2024',
        description: 'Únete a nuestra conferencia anual sobre las últimas tendencias en tecnología, IA y desarrollo de software.',
        location: 'Centro de Convenciones, Madrid',
        capacity: 100,
        status: 'published',
      },
      {
        title: 'Workshop de React Avanzado',
        description: 'Aprende técnicas avanzadas de React, hooks personalizados, optimización y mejores prácticas.',
        location: 'Campus Tech, Barcelona',
        capacity: 30,
        status: 'published',
      },
      {
        title: 'Networking para Desarrolladores',
        description: 'Evento de networking donde podrás conocer a otros desarrolladores y compartir experiencias.',
        location: 'Café Tech, Valencia',
        capacity: 50,
        status: 'published',
      },
      {
        title: 'Hackathon de Fintech',
        description: '48 horas para desarrollar soluciones innovadoras en el sector financiero.',
        location: 'Innovation Hub, Sevilla',
        capacity: 80,
        status: 'published',
      },
      {
        title: 'Charla sobre DevOps',
        description: 'Introducción a DevOps, CI/CD, Docker y Kubernetes para principiantes.',
        location: 'Online',
        capacity: 200,
        status: 'published',
      },
      {
        title: 'Curso de TypeScript',
        description: 'Curso intensivo de TypeScript desde cero hasta nivel avanzado.',
        location: 'Academia Code, Bilbao',
        capacity: 25,
        status: 'published',
      },
      {
        title: 'Meetup de Python',
        description: 'Reunión mensual de la comunidad Python local.',
        location: 'Espacio Coworking, Málaga',
        capacity: 40,
        status: 'published',
      },
      {
        title: 'Seminario de Seguridad Web',
        description: 'Aprende sobre vulnerabilidades comunes y cómo proteger tus aplicaciones.',
        location: 'Universidad Tech, Zaragoza',
        capacity: 60,
        status: 'published',
      },
      {
        title: 'Taller de Diseño UX/UI',
        description: 'Workshop práctico sobre diseño de interfaces y experiencia de usuario.',
        location: 'Design Studio, Granada',
        capacity: 35,
        status: 'published',
      },
      {
        title: 'Conferencia de Blockchain',
        description: 'Explora el futuro de blockchain, criptomonedas y Web3.',
        location: 'Convention Center, Madrid',
        capacity: 150,
        status: 'published',
      },
      {
        title: 'Bootcamp Full Stack',
        description: 'Bootcamp intensivo de 3 meses para convertirte en desarrollador full stack.',
        location: 'Coding Academy, Barcelona',
        capacity: 20,
        status: 'draft',
      },
      {
        title: 'Evento Cancelado de Prueba',
        description: 'Este evento está cancelado para probar la funcionalidad.',
        location: 'Test Location',
        capacity: 10,
        status: 'cancelled',
      },
      {
        title: 'Webinar de Cloud Computing',
        description: 'Introducción a AWS, Azure y Google Cloud Platform.',
        location: 'Online',
        capacity: 300,
        status: 'published',
      },
      {
        title: 'Charla sobre Startups',
        description: 'Cómo lanzar tu startup tecnológica: desde la idea hasta el MVP.',
        location: 'Startup Hub, Madrid',
        capacity: 70,
        status: 'published',
      },
      {
        title: 'Workshop de Testing',
        description: 'Aprende a escribir tests efectivos: unit, integration y e2e.',
        location: 'Tech Lab, Valencia',
        capacity: 45,
        status: 'published',
      },
    ];

    // Asegurar que tenemos al menos un organizador para cada evento
    // Si no hay suficientes organizadores, usar el primero disponible
    const getOrganizerId = (index) => {
      if (index < createdOrganizers.length) {
        return createdOrganizers[index].id;
      }
      return createdOrganizers[0].id; // Usar el primer organizador si no hay más
    };

    // Generar fechas variadas
    const now = new Date();
    for (let i = 0; i < eventTemplates.length; i++) {
      const template = eventTemplates[i];
      
      // Asegurar que el organizer existe
      const organizerIndex = i % Math.max(1, createdOrganizers.length);
      const organizerId = getOrganizerId(organizerIndex);
      
      const startAt = new Date(now);
      startAt.setDate(startAt.getDate() + i + 1);
      startAt.setHours(10 + (i % 8), 0, 0, 0);

      const endAt = new Date(startAt);
      endAt.setHours(startAt.getHours() + 3);

      const eventData = {
        ...template,
        organizer: organizerId, // Usar el organizador disponible
        startAt: startAt.toISOString(),
        endAt: endAt.toISOString(),
        // No incluir coverImage como URL, solo como campo file si es necesario
      };

      try {
        // Asegurarse de que estamos autenticados como admin antes de crear eventos
        if (!pb.authStore.isValid || !pb.authStore.model) {
          await pb.collection('users').authWithPassword(adminData.email, adminData.password);
        }
        
        // Verificar autenticación antes de crear
        if (!pb.authStore.isValid || !pb.authStore.model) {
          console.error(`❌ No se pudo autenticar como admin antes de crear evento`);
          continue;
        }
        
        // Mostrar datos que se van a enviar (para debugging)
        console.log(`   Intentando crear evento: ${template.title}`);
        console.log(`   Organizer ID: ${organizerId}`);
        console.log(`   Auth status: ${pb.authStore.isValid ? 'Autenticado' : 'No autenticado'}`);
        
        const event = await pb.collection('events').create(eventData);
        events.push(event);
        console.log(`✅ Evento creado: ${event.title}`);
      } catch (err) {
        console.error(`❌ Error creando evento ${template.title}:`, err.message);
        // Mostrar más detalles del error para debugging
        if (err.response) {
          console.error('   Response:', JSON.stringify(err.response, null, 2));
        }
        if (err.data) {
          console.error('   Data:', JSON.stringify(err.data, null, 2));
        }
        if (err.status) {
          console.error(`   Status: ${err.status}`);
        }
      }
    }

    // 5. Crear reservas
    console.log('📝 Creando reservas...');
    let reservationCount = 0;
    for (const event of events.filter(e => e.status === 'published')) {
      const numReservations = Math.floor(Math.random() * Math.min(event.capacity + 10, users.length)) + 1;
      const shuffledUsers = [...users].sort(() => Math.random() - 0.5);

      for (let i = 0; i < Math.min(numReservations, shuffledUsers.length); i++) {
        const user = shuffledUsers[i];
        const isActive = i < event.capacity;
        const status = isActive ? 'active' : 'waitlist';

        try {
          // Autenticarse como el usuario para crear la reserva
          await pb.collection('users').authWithPassword(user.email, 'user123');
          const reservation = await pb.collection('reservations').create({
            event: event.id,
            user: user.id,
            status: status,
          });
          reservationCount++;
        } catch (err) {
          // Ignorar errores de duplicados
          if (err.status !== 409) {
            console.error(`Error creando reserva:`, err.message);
          }
        }
      }
    }
    console.log(`✅ ${reservationCount} reservas creadas`);

    // 6. Crear comentarios
    console.log('📝 Creando comentarios...');
    let commentCount = 0;
    for (const event of events.filter(e => e.status === 'published').slice(0, 5)) {
      const numComments = Math.floor(Math.random() * 5) + 1;
      const shuffledUsers = [...users].sort(() => Math.random() - 0.5);

      for (let i = 0; i < Math.min(numComments, shuffledUsers.length); i++) {
        const user = shuffledUsers[i];
        const comments = [
          '¡Excelente evento! Muy bien organizado.',
          'Espero aprender mucho en este evento.',
          '¿Habrá certificado de asistencia?',
          'Perfecto para mi nivel de experiencia.',
          'Me encanta la temática, definitivamente asistiré.',
        ];

        try {
          await pb.collection('users').authWithPassword(user.email, 'user123');
          await pb.collection('comments').create({
            event: event.id,
            user: user.id,
            content: comments[Math.floor(Math.random() * comments.length)],
          });
          commentCount++;
        } catch (err) {
          // Ignorar errores
        }
      }
    }
    console.log(`✅ ${commentCount} comentarios creados`);

    // Autenticarse como admin para finalizar
    await pb.collection('users').authWithPassword(adminData.email, adminData.password);

    console.log('\n✅ Seed completado exitosamente!');
    console.log('\n📊 Resumen:');
    console.log(`   - 1 admin`);
    console.log(`   - ${createdOrganizers.length} organizadores`);
    console.log(`   - ${users.length} usuarios`);
    console.log(`   - ${events.length} eventos`);
    console.log(`   - ${reservationCount} reservas`);
    console.log(`   - ${commentCount} comentarios`);
    console.log('\n🔑 Credenciales:');
    console.log('   Admin: admin@eventflow.com / admin123');
    console.log('   Organizador: organizer1@eventflow.com / org123');
    console.log('   Usuario: user1@eventflow.com / user123');

  } catch (error) {
    console.error('❌ Error en seed:', error);
    process.exit(1);
  }
}

seed();
