# Configuración de Colecciones PocketBase

Este documento describe cómo configurar las colecciones en PocketBase. 
Debes hacerlo manualmente desde la interfaz admin de PocketBase o usando la API.

## Colecciones a crear:

### 1. users (extender la colección auth por defecto)
- Campos adicionales:
  - `role` (select): ["admin", "organizer", "user"] - default: "user"
  - `name` (text)
  - `avatar` (file)

### 2. events
- `title` (text)
- `description` (editor)
- `startAt` (date)
- `endAt` (date)
- `location` (text)
- `capacity` (number)
- `coverImage` (file)
- `organizer` (relation) -> users
- `status` (select): ["draft", "published", "cancelled"] - default: "draft"

### 3. reservations
- `event` (relation) -> events
- `user` (relation) -> users
- `status` (select): ["active", "cancelled", "waitlist"] - default: "active"
- `createdAt` (date) - auto

### 4. comments
- `event` (relation) -> events
- `user` (relation) -> users
- `content` (text)
- `createdAt` (date) - auto

### 5. audit_logs
- `actor` (relation) -> users
- `action` (text)
- `entityType` (text)
- `entityId` (text)
- `payload` (json)
- `createdAt` (date) - auto

## Reglas de Acceso (Rules)

### users
- List: `@request.auth.id != ""`
- View: `@request.auth.id != "" || id = @request.auth.id`
- Create: `@request.auth.id = ""`
- Update: `id = @request.auth.id || @request.auth.role = "admin"`
- Delete: `@request.auth.role = "admin"`

### events
- List: `status = "published" || organizer = @request.auth.id || @request.auth.role = "admin"`
- View: `status = "published" || organizer = @request.auth.id || @request.auth.role = "admin"`
- Create: `@request.auth.id != "" && (@request.auth.role = "organizer" || @request.auth.role = "admin")`
- Update: `organizer = @request.auth.id || @request.auth.role = "admin"`
- Delete: `organizer = @request.auth.id || @request.auth.role = "admin"`

### reservations
- List: `user = @request.auth.id || event.organizer = @request.auth.id || @request.auth.role = "admin"`
- View: `user = @request.auth.id || event.organizer = @request.auth.id || @request.auth.role = "admin"`
- Create: `@request.auth.id != "" && user = @request.auth.id`
- Update: `user = @request.auth.id || @request.auth.role = "admin"`
- Delete: `user = @request.auth.id || @request.auth.role = "admin"`

### comments
- List: `@request.auth.id != ""`
- View: `@request.auth.id != ""`
- Create: `@request.auth.id != "" && user = @request.auth.id`
- Update: `user = @request.auth.id || @request.auth.role = "admin"`
- Delete: `user = @request.auth.id || @request.auth.role = "admin"`

### audit_logs
- List: `@request.auth.role = "admin"`
- View: `@request.auth.role = "admin"`
- Create: `false` (solo hooks)
- Update: `false`
- Delete: `false`
