/**
 * Hook: Antes de borrar un comentario
 * - Solo el autor o admin puede borrar
 */
async (e) => {
  const record = e.record;
  const userId = record.get("user");

  // Verificar permisos: solo el autor o admin puede borrar
  if (e.authRecord?.id !== userId && e.authRecord?.role !== "admin") {
    throw new $e.HttpError(403, "Solo el autor o un administrador puede borrar este comentario");
  }

  // Registrar en audit_log
  const auditLog = new Record($app.dao(), "audit_logs");
  auditLog.set("actor", e.authRecord?.id || "system");
  auditLog.set("action", "comment_deleted");
  auditLog.set("entityType", "comment");
  auditLog.set("entityId", record.getId());
  auditLog.set("payload", JSON.stringify({
    event: record.get("event"),
    user: userId
  }));
  await $app.dao().saveRecord(auditLog);
};
