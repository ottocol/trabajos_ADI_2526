/**
 * Hook: Antes de actualizar un evento
 * - Si se cancela un evento, cancelar todas las reservas activas
 * - Registrar en audit_log
 */
async (e) => {
  const record = e.record;
  const oldRecord = e.originalRecord;

  // Solo procesar si el status cambió a "cancelled"
  if (record.get("status") === "cancelled" && oldRecord.get("status") !== "cancelled") {
    const eventId = record.getId();

    // Cancelar todas las reservas activas y en waitlist
    const activeReservations = await $app.dao().findRecordsByFilter(
      "reservations",
      `event = "${eventId}" && (status = "active" || status = "waitlist")`,
      1,
      1000
    );

    for (const reservation of activeReservations) {
      reservation.set("status", "cancelled");
      await $app.dao().saveRecord(reservation);
    }

    // Registrar cancelación del evento en audit_log
    const auditLog = new Record($app.dao(), "audit_logs");
    auditLog.set("actor", e.authRecord?.id || "system");
    auditLog.set("action", "event_cancelled");
    auditLog.set("entityType", "event");
    auditLog.set("entityId", eventId);
    auditLog.set("payload", JSON.stringify({
      cancelledReservations: activeReservations.length
    }));
    await $app.dao().saveRecord(auditLog);
  }
};
