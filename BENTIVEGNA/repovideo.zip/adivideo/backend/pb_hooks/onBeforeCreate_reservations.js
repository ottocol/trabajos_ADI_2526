/**
 * Hook: Antes de crear una reserva
 * - Valida que no exista una reserva activa del mismo usuario para el mismo evento
 * - Asigna status según capacidad disponible
 * - Registra en audit_log
 */
async (e) => {
  const event = e.data.event;
  const user = e.data.user;

  // Verificar que el usuario esté autenticado
  if (!e.authRecord) {
    throw new $e.HttpError(401, "Debes estar autenticado para crear una reserva");
  }

  // Verificar que el usuario de la reserva sea el autenticado (o admin)
  if (e.authRecord.id !== user && e.authRecord.role !== "admin") {
    throw new $e.HttpError(403, "Solo puedes crear reservas para tu propia cuenta");
  }

  // Verificar que el evento exista y esté publicado
  const eventRecord = await $app.dao().findRecordById("events", event);
  if (!eventRecord) {
    throw new $e.HttpError(404, "El evento no existe");
  }

  if (eventRecord.get("status") !== "published") {
    throw new $e.HttpError(400, "Solo se pueden reservar eventos publicados");
  }

  // Verificar que no exista una reserva activa o en waitlist del mismo usuario
  const existingReservation = await $app.dao().findFirstRecordByFilter(
    "reservations",
    `event = "${event}" && user = "${user}" && (status = "active" || status = "waitlist")`
  );

  if (existingReservation) {
    throw new $e.HttpError(409, "Ya tienes una reserva activa o en lista de espera para este evento");
  }

  // Obtener número de reservas activas del evento
  const activeReservations = await $app.dao().findRecordsByFilter(
    "reservations",
    `event = "${event}" && status = "active"`,
    1,
    1000
  );

  const capacity = eventRecord.get("capacity");
  const currentActive = activeReservations.length;

  // Asignar status según capacidad
  if (currentActive < capacity) {
    e.data.status = "active";
  } else {
    e.data.status = "waitlist";
  }

  // Registrar en audit_log
  const auditLog = new Record($app.dao(), "audit_logs");
  auditLog.set("actor", e.authRecord.id);
  auditLog.set("action", "reservation_created");
  auditLog.set("entityType", "reservation");
  auditLog.set("entityId", "");
  auditLog.set("payload", JSON.stringify({
    event: event,
    user: user,
    status: e.data.status,
    capacity: capacity,
    currentActive: currentActive
  }));
  await $app.dao().saveRecord(auditLog);
};
