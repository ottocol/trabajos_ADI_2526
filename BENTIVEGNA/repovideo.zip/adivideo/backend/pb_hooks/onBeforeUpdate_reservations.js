/**
 * Hook: Antes de actualizar una reserva
 * - Manejar cancelación: si se cancela una reserva activa, promover la más antigua de waitlist
 * - Registrar en audit_log
 */
async (e) => {
  const record = e.record;
  const oldRecord = e.originalRecord;

  // Solo procesar si el status cambió a "cancelled"
  if (record.get("status") === "cancelled" && oldRecord.get("status") !== "cancelled") {
    const oldStatus = oldRecord.get("status");
    const eventId = record.get("event");

    // Si se cancela una reserva activa, promover la más antigua de waitlist
    if (oldStatus === "active") {
      const oldestWaitlist = await $app.dao().findFirstRecordByFilter(
        "reservations",
        `event = "${eventId}" && status = "waitlist"`,
        1,
        1,
        "created"
      );

      if (oldestWaitlist) {
        oldestWaitlist.set("status", "active");
        await $app.dao().saveRecord(oldestWaitlist);

        // Registrar promoción en audit_log
        const auditLog = new Record($app.dao(), "audit_logs");
        auditLog.set("actor", e.authRecord?.id || "system");
        auditLog.set("action", "reservation_promoted");
        auditLog.set("entityType", "reservation");
        auditLog.set("entityId", oldestWaitlist.getId());
        auditLog.set("payload", JSON.stringify({
          event: eventId,
          user: oldestWaitlist.get("user"),
          reason: "promoted_from_waitlist"
        }));
        await $app.dao().saveRecord(auditLog);
      }
    }

    // Registrar cancelación en audit_log
    const auditLog = new Record($app.dao(), "audit_logs");
    auditLog.set("actor", e.authRecord?.id || "system");
    auditLog.set("action", "reservation_cancelled");
    auditLog.set("entityType", "reservation");
    auditLog.set("entityId", record.getId());
    auditLog.set("payload", JSON.stringify({
      event: eventId,
      user: record.get("user"),
      previousStatus: oldStatus
    }));
    await $app.dao().saveRecord(auditLog);
  }
};
