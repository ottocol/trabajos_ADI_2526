/**
 * Hook: Después de crear una reserva
 * - Actualizar el entityId del audit_log con el ID de la reserva creada
 */
async (e) => {
  const record = e.record;
  const reservationId = record.getId();

  // Actualizar el último audit_log con el ID de la reserva
  const lastAuditLog = await $app.dao().findFirstRecordByFilter(
    "audit_logs",
    `action = "reservation_created" && entityId = ""`,
    1,
    1,
    "-created"
  );

  if (lastAuditLog) {
    lastAuditLog.set("entityId", reservationId);
    await $app.dao().saveRecord(lastAuditLog);
  }
};
