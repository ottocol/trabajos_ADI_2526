import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

const getProjectRefFromUrl = (url: string) => {
  try {
    return new URL(url).hostname.split('.')[0] || null;
  } catch {
    return null;
  }
};

const getProjectRefFromAnonKey = (key: string) => {
  try {
    const payload = JSON.parse(globalThis.atob(key.split('.')[1] || ''));
    return payload?.ref || null;
  } catch {
    return null;
  }
};

const urlRef = getProjectRefFromUrl(supabaseUrl);
const keyRef = getProjectRefFromAnonKey(supabaseAnonKey);

if (import.meta.env.DEV) {
  console.info('Supabase config', { supabaseUrl, urlRef, keyRef });
}

if (urlRef && keyRef && urlRef !== keyRef) {
  console.warn(
    'Supabase config mismatch: VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are from different projects.',
    { urlRef, keyRef },
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

// Tipos de base de datos
export interface Profile {
  id: string;
  role: 'admin' | 'organizer' | 'user';
  display_name: string | null;
  avatar_url: string | null;
  created_at: string;
}

export interface Event {
  id: string;
  organizer_id: string;
  title: string;
  description: string | null;
  start_at: string;
  end_at: string;
  location: string;
  capacity: number;
  cover_path: string | null;
  status: 'draft' | 'published' | 'cancelled';
  created_at: string;
  organizer?: Profile;
}

export interface Reservation {
  id: string;
  event_id: string;
  user_id: string;
  status: 'active' | 'cancelled' | 'waitlist';
  created_at: string;
  event?: Event;
  user?: Profile;
}

export interface Comment {
  id: string;
  event_id: string;
  user_id: string;
  content: string;
  created_at: string;
  user?: Profile;
}

export interface AuditLog {
  id: number;
  actor_id: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  payload: any;
  created_at: string;
  actor?: Profile;
}
