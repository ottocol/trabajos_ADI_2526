import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase, type Event, type Reservation, type Comment } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function EventDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [event, setEvent] = useState<Event | null>(null);
  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [activeReservations, setActiveReservations] = useState(0);
  const [loading, setLoading] = useState(true);
  const [reserving, setReserving] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);

  useEffect(() => {
    if (!id) return;
    loadEvent();
    loadReservation();
    loadComments();
    loadReservationsCount();

    // Suscripciones realtime
    const eventChannel = supabase
      .channel(`event_${id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'events',
          filter: `id=eq.${id}`,
        },
        () => {
          loadEvent();
        }
      )
      .subscribe();

    const reservationsChannel = supabase
      .channel(`reservations_${id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'reservations',
          filter: `event_id=eq.${id}`,
        },
        () => {
          loadReservation();
          loadReservationsCount();
        }
      )
      .subscribe();

    const commentsChannel = supabase
      .channel(`comments_${id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'comments',
          filter: `event_id=eq.${id}`,
        },
        () => {
          loadComments();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(eventChannel);
      supabase.removeChannel(reservationsChannel);
      supabase.removeChannel(commentsChannel);
    };
  }, [id, user]);

  const loadEvent = async () => {
    if (!id) return;
    try {
      const { data, error } = await supabase
        .from('events')
        .select('*, organizer:profiles!events_organizer_id_fkey(*)')
        .eq('id', id)
        .single();

      if (error) throw error;
      setEvent(data);
    } catch (err) {
      console.error('Error loading event:', err);
      navigate('/');
    } finally {
      setLoading(false);
    }
  };

  const loadReservation = async () => {
    if (!id || !user) return;
    try {
      const { data, error } = await supabase
        .from('reservations')
        .select('*')
        .eq('event_id', id)
        .eq('user_id', user.id)
        .in('status', ['active', 'waitlist'])
        .maybeSingle();

      if (error) throw error;
      setReservation(data || null);
    } catch (err) {
      console.error('Error loading reservation:', err);
    }
  };

  const loadComments = async () => {
    if (!id) return;
    try {
      const { data, error } = await supabase
        .from('comments')
        .select('*, user:profiles!comments_user_id_fkey(*)')
        .eq('event_id', id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setComments(data || []);
    } catch (err) {
      console.error('Error loading comments:', err);
    }
  };

  const loadReservationsCount = async () => {
    if (!id) return;
    try {
      const { count, error } = await supabase
        .from('reservations')
        .select('*', { count: 'exact', head: true })
        .eq('event_id', id)
        .eq('status', 'active');

      if (error) throw error;
      setActiveReservations(count || 0);
    } catch (err) {
      console.error('Error loading reservations count:', err);
    }
  };

  const handleReserve = async () => {
    if (!id || !user) {
      navigate('/login');
      return;
    }

    setReserving(true);
    try {
      const { data, error } = await supabase.rpc('reserve_event', {
        p_event_id: id,
      });

      if (error) throw error;

      if (data.success) {
        await loadReservation();
        await loadReservationsCount();
      }
    } catch (err: any) {
      alert(err.message || 'Error al crear la reserva');
    } finally {
      setReserving(false);
    }
  };

  const handleCancelReservation = async () => {
    if (!reservation) return;

    if (!confirm('¿Estás seguro de cancelar tu reserva?')) return;

    try {
      const { error } = await supabase.rpc('cancel_reservation', {
        p_reservation_id: reservation.id,
      });

      if (error) throw error;
      setReservation(null);
      await loadReservationsCount();
    } catch (err: any) {
      alert(err.message || 'Error al cancelar la reserva');
    }
  };

  const handleSubmitComment = async () => {
    if (!id || !user || !commentText.trim()) return;

    setSubmittingComment(true);
    try {
      const { error } = await supabase.from('comments').insert({
        event_id: id,
        user_id: user.id,
        content: commentText.trim(),
      });

      if (error) throw error;
      setCommentText('');
    } catch (err: any) {
      alert(err.message || 'Error al crear el comentario');
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!confirm('¿Estás seguro de borrar este comentario?')) return;

    try {
      const { error } = await supabase.from('comments').delete().eq('id', commentId);

      if (error) throw error;
    } catch (err: any) {
      alert(err.message || 'Error al borrar el comentario');
    }
  };

  if (loading) {
    return <div className="text-center py-12">Cargando evento...</div>;
  }

  if (!event) {
    return <div className="text-center py-12">Evento no encontrado</div>;
  }

  const availableSpots = event.capacity - activeReservations;
  const isFull = availableSpots <= 0;

  const coverUrl = event.cover_path
    ? supabase.storage.from('event-covers').getPublicUrl(event.cover_path).data.publicUrl
    : 'https://via.placeholder.com/800x400';

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <img
          src={coverUrl}
          alt={event.title}
          className="w-full h-64 object-cover"
        />
        <div className="p-6">
          <h1 className="text-3xl font-bold mb-4">{event.title}</h1>
          <div className="prose mb-6" dangerouslySetInnerHTML={{ __html: event.description || '' }} />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <p className="text-sm text-gray-500">Fecha de inicio</p>
              <p className="font-semibold">
                {format(new Date(event.start_at), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Fecha de fin</p>
              <p className="font-semibold">
                {format(new Date(event.end_at), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Ubicación</p>
              <p className="font-semibold">{event.location}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Organizador</p>
              <p className="font-semibold">{event.organizer?.display_name || 'N/A'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Capacidad</p>
              <p className="font-semibold">
                {activeReservations} / {event.capacity} reservas
              </p>
              <p className={`text-sm ${isFull ? 'text-red-600' : 'text-green-600'}`}>
                {isFull ? 'Sin plazas disponibles' : `${availableSpots} plazas disponibles`}
              </p>
            </div>
          </div>

          {/* Botones de reserva */}
          {user ? (
            <div className="mb-6">
              {reservation ? (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="font-semibold mb-2">
                    Tu reserva está: {reservation.status === 'active' ? '✅ Activa' : '⏳ En lista de espera'}
                  </p>
                  <button
                    onClick={handleCancelReservation}
                    className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                  >
                    Cancelar Reserva
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleReserve}
                  disabled={reserving || isFull}
                  className={`px-6 py-3 rounded font-semibold ${
                    isFull
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                  }`}
                >
                  {reserving ? 'Reservando...' : isFull ? 'Sin plazas disponibles' : 'Reservar Plaza'}
                </button>
              )}
            </div>
          ) : (
            <div className="mb-6">
              <p className="text-gray-600 mb-2">Debes iniciar sesión para reservar</p>
              <button
                onClick={() => navigate('/login')}
                className="px-6 py-3 bg-indigo-600 text-white rounded hover:bg-indigo-700"
              >
                Iniciar Sesión
              </button>
            </div>
          )}

          {/* Comentarios */}
          <div className="border-t pt-6">
            <h2 className="text-2xl font-bold mb-4">Comentarios</h2>

            {user && (
              <div className="mb-6">
                <textarea
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Escribe un comentario..."
                  className="w-full px-4 py-2 border rounded mb-2"
                  rows={3}
                />
                <button
                  onClick={handleSubmitComment}
                  disabled={submittingComment || !commentText.trim()}
                  className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 disabled:bg-gray-400"
                >
                  {submittingComment ? 'Enviando...' : 'Enviar Comentario'}
                </button>
              </div>
            )}

            <div className="space-y-4">
              {comments.map((comment) => (
                <div key={comment.id} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-semibold">
                        {comment.user?.display_name || comment.user?.id || 'Usuario'}
                      </p>
                      <p className="text-sm text-gray-500">
                        {format(new Date(comment.created_at), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
                      </p>
                    </div>
                    {(user?.id === comment.user_id || profile?.role === 'admin') && (
                      <button
                        onClick={() => handleDeleteComment(comment.id)}
                        className="text-red-600 hover:text-red-800 text-sm"
                      >
                        Borrar
                      </button>
                    )}
                  </div>
                  <p className="text-gray-700">{comment.content}</p>
                </div>
              ))}
            </div>

            {comments.length === 0 && (
              <p className="text-gray-500 text-center py-4">No hay comentarios aún</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
