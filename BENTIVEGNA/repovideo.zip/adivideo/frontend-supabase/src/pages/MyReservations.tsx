import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase, type Reservation } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function MyReservations() {
  const { user } = useAuth();
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadReservations();

    // Suscripción realtime
    const channel = supabase
      .channel('my_reservations')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'reservations',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          loadReservations();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const loadReservations = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('reservations')
        .select('*, event:events(*)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setReservations(data || []);
    } catch (err) {
      console.error('Error loading reservations:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async (reservationId: string) => {
    if (!confirm('¿Estás seguro de cancelar esta reserva?')) return;

    try {
      const { error } = await supabase.rpc('cancel_reservation', {
        p_reservation_id: reservationId,
      });

      if (error) throw error;
    } catch (err: any) {
      alert(err.message || 'Error al cancelar la reserva');
    }
  };

  if (loading) {
    return <div className="text-center py-12">Cargando reservas...</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Mis Reservas</h1>

      {reservations.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          No tienes reservas aún.
        </div>
      ) : (
        <div className="space-y-4">
          {reservations.map((reservation) => {
            const event = reservation.event as any;
            const coverUrl = event?.cover_path
              ? supabase.storage.from('event-covers').getPublicUrl(event.cover_path).data.publicUrl
              : 'https://via.placeholder.com/150';

            return (
              <div
                key={reservation.id}
                className="bg-white rounded-lg shadow-md p-6 flex items-center gap-6"
              >
                <img
                  src={coverUrl}
                  alt={event?.title || 'Evento'}
                  className="w-24 h-24 object-cover rounded"
                />
                <div className="flex-1">
                  <Link
                    to={`/event/${reservation.event_id}`}
                    className="text-xl font-semibold text-indigo-600 hover:underline"
                  >
                    {event?.title || 'Evento'}
                  </Link>
                  {event?.start_at && (
                    <p className="text-gray-600 mt-1">
                      📅 {format(new Date(event.start_at), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
                    </p>
                  )}
                  {event?.location && (
                    <p className="text-gray-600">📍 {event.location}</p>
                  )}
                  <p className="mt-2">
                    Estado:{' '}
                    <span
                      className={`font-semibold ${
                        reservation.status === 'active'
                          ? 'text-green-600'
                          : reservation.status === 'waitlist'
                          ? 'text-yellow-600'
                          : 'text-red-600'
                      }`}
                    >
                      {reservation.status === 'active'
                        ? '✅ Activa'
                        : reservation.status === 'waitlist'
                        ? '⏳ Lista de espera'
                        : '❌ Cancelada'}
                    </span>
                  </p>
                </div>
                {reservation.status !== 'cancelled' && (
                  <button
                    onClick={() => handleCancel(reservation.id)}
                    className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                  >
                    Cancelar
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
