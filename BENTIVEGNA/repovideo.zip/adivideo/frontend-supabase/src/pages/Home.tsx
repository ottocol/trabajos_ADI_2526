import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase, type Event } from '../lib/supabase';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function Home() {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    location: '',
    dateFrom: '',
  });

  useEffect(() => {
    loadEvents();

    // Suscripción realtime a eventos
    const channel = supabase
      .channel('events_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'events',
        },
        () => {
          loadEvents();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [filters]);

  const loadEvents = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('events')
        .select('*, organizer:profiles!events_organizer_id_fkey(*)')
        .eq('status', 'published')
        .order('start_at', { ascending: false });

      if (filters.location) {
        query = query.ilike('location', `%${filters.location}%`);
      }

      if (filters.dateFrom) {
        query = query.gte('start_at', filters.dateFrom);
      }

      const { data, error } = await query;

      if (error) throw error;
      setEvents(data || []);
    } catch (err) {
      console.error('Error loading events:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center py-12">Cargando eventos...</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Eventos Disponibles</h1>

      {/* Filtros */}
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Ubicación</label>
            <input
              type="text"
              value={filters.location}
              onChange={(e) => setFilters({ ...filters, location: e.target.value })}
              placeholder="Buscar por ubicación..."
              className="w-full px-3 py-2 border rounded"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Desde</label>
            <input
              type="date"
              value={filters.dateFrom}
              onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
              className="w-full px-3 py-2 border rounded"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={() => setFilters({ location: '', dateFrom: '' })}
              className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
            >
              Limpiar
            </button>
          </div>
        </div>
      </div>

      {/* Lista de eventos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {events.map((event) => (
          <EventCard key={event.id} event={event} />
        ))}
      </div>

      {events.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          No hay eventos disponibles con estos filtros.
        </div>
      )}
    </div>
  );
}

function EventCard({ event }: { event: Event }) {
  const [availableSpots, setAvailableSpots] = useState<number | null>(null);
  const [loadingSpots, setLoadingSpots] = useState(true);

  useEffect(() => {
    loadSpots();

    // Suscripción realtime para reservas
    const channel = supabase
      .channel(`reservations_${event.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'reservations',
          filter: `event_id=eq.${event.id}`,
        },
        () => {
          loadSpots();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [event.id]);

  const loadSpots = async () => {
    try {
      setLoadingSpots(true);
      const { count, error } = await supabase
        .from('reservations')
        .select('*', { count: 'exact', head: true })
        .eq('event_id', event.id)
        .eq('status', 'active');

      if (error) throw error;
      setAvailableSpots(event.capacity - (count || 0));
    } catch {
      setAvailableSpots(event.capacity);
    } finally {
      setLoadingSpots(false);
    }
  };

  const coverUrl = event.cover_path
    ? supabase.storage.from('event-covers').getPublicUrl(event.cover_path).data.publicUrl
    : 'https://via.placeholder.com/400x200';

  return (
    <Link to={`/event/${event.id}`}>
      <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
        <img
          src={coverUrl}
          alt={event.title}
          className="w-full h-48 object-cover"
        />
        <div className="p-4">
          <h3 className="text-xl font-semibold mb-2">{event.title}</h3>
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">{event.description}</p>
          <div className="text-sm text-gray-500 space-y-1">
            <p>
              📅 {format(new Date(event.start_at), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
            </p>
            <p>📍 {event.location}</p>
            <p>
              👤 {event.organizer?.display_name || 'Organizador'}
            </p>
            {loadingSpots ? (
              <p className="text-indigo-600">Cargando cupo...</p>
            ) : (
              <p className={`font-semibold ${availableSpots! > 0 ? 'text-green-600' : 'text-red-600'}`}>
                {availableSpots! > 0 ? `✅ ${availableSpots} plazas disponibles` : '❌ Sin plazas disponibles'}
              </p>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
