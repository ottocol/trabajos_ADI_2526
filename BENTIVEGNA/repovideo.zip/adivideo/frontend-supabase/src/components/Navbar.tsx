import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function Navbar() {
  const { user, profile, logout } = useAuth();

  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="text-2xl font-bold text-indigo-600">
            EventFlow
          </Link>
          <div className="flex items-center gap-4">
            {user ? (
              <>
                <Link to="/" className="text-gray-700 hover:text-indigo-600">
                  Eventos
                </Link>
                <Link to="/my-reservations" className="text-gray-700 hover:text-indigo-600">
                  Mis Reservas
                </Link>
                {(profile?.role === 'organizer' || profile?.role === 'admin') && (
                  <Link to="/organizer" className="text-gray-700 hover:text-indigo-600">
                    Panel Organizador
                  </Link>
                )}
                {profile?.role === 'admin' && (
                  <Link to="/admin" className="text-gray-700 hover:text-indigo-600">
                    Admin
                  </Link>
                )}
                <Link to="/profile" className="text-gray-700 hover:text-indigo-600">
                  {profile?.display_name || user.email}
                </Link>
                <button
                  onClick={logout}
                  className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                >
                  Salir
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-gray-700 hover:text-indigo-600">
                  Iniciar Sesión
                </Link>
                <Link
                  to="/register"
                  className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
                >
                  Registrarse
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
