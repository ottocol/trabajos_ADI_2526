-- Script de seed para datos de prueba (Supabase)
-- IMPORTANTE: Ejecutar con service_role o desde el SQL Editor de Supabase.
-- Este script crea usuarios, perfiles, eventos, reservas, comentarios y audit_logs.
-- Password por defecto para todos: Eventflow123!

-- Helper: obtener user_id por email
CREATE OR REPLACE FUNCTION get_user_id_by_email(p_email TEXT)
RETURNS UUID AS $$
  SELECT id FROM auth.users WHERE email = p_email LIMIT 1;
$$ LANGUAGE sql SECURITY DEFINER;

-- Helper: crear usuario en auth.users + auth.identities si no existe
CREATE OR REPLACE FUNCTION seed_create_user(
  p_email TEXT,
  p_password TEXT,
  p_name TEXT
)
RETURNS UUID AS $$
DECLARE
  v_user_id UUID;
  v_instance_id UUID;
BEGIN
  SELECT id INTO v_user_id FROM auth.users WHERE email = p_email;

  IF v_user_id IS NULL THEN
    SELECT id INTO v_instance_id FROM auth.instances LIMIT 1;
    v_user_id := gen_random_uuid();

    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_user_meta_data,
      aud,
      role,
      created_at,
      updated_at
    )
    VALUES (
      v_user_id,
      v_instance_id,
      p_email,
      crypt(p_password, gen_salt('bf')),
      NOW(),
      jsonb_build_object('name', p_name),
      'authenticated',
      'authenticated',
      NOW(),
      NOW()
    );

    INSERT INTO auth.identities (
      id,
      user_id,
      provider,
      provider_id,
      identity_data,
      created_at,
      updated_at
    )
    VALUES (
      gen_random_uuid(),
      v_user_id,
      'email',
      v_user_id::text,
      jsonb_build_object('sub', v_user_id::text, 'email', p_email),
      NOW(),
      NOW()
    )
    ON CONFLICT (provider_id, provider) DO NOTHING;
  END IF;

  RETURN COALESCE(v_user_id, (SELECT id FROM auth.users WHERE email = p_email));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DO $$
DECLARE
  v_admin_id UUID;
  v_org1_id UUID;
  v_org2_id UUID;
  v_org3_id UUID;
  v_user1_id UUID;
  v_user2_id UUID;
  v_user3_id UUID;
  v_user4_id UUID;
  v_user5_id UUID;
  v_event1_id UUID;
  v_event2_id UUID;
  v_event3_id UUID;
  v_event4_id UUID;
  v_event5_id UUID;
BEGIN
  -- Crear usuarios base
  v_admin_id := seed_create_user('admin@eventflow.com', 'Eventflow123!', 'Admin EventFlow');
  v_org1_id := seed_create_user('organizer1@eventflow.com', 'Eventflow123!', 'Organizador Uno');
  v_org2_id := seed_create_user('organizer2@eventflow.com', 'Eventflow123!', 'Organizador Dos');
  v_org3_id := seed_create_user('organizer3@eventflow.com', 'Eventflow123!', 'Organizador Tres');
  v_user1_id := seed_create_user('user1@eventflow.com', 'Eventflow123!', 'Usuario Uno');
  v_user2_id := seed_create_user('user2@eventflow.com', 'Eventflow123!', 'Usuario Dos');
  v_user3_id := seed_create_user('user3@eventflow.com', 'Eventflow123!', 'Usuario Tres');
  v_user4_id := seed_create_user('user4@eventflow.com', 'Eventflow123!', 'Usuario Cuatro');
  v_user5_id := seed_create_user('user5@eventflow.com', 'Eventflow123!', 'Usuario Cinco');

  -- Asignar roles en profiles
  UPDATE public.profiles SET role = 'admin', display_name = 'Admin EventFlow'
  WHERE id = v_admin_id;
  UPDATE public.profiles SET role = 'organizer' WHERE id IN (v_org1_id, v_org2_id, v_org3_id);

  -- Insertar eventos
  INSERT INTO public.events (organizer_id, title, description, start_at, end_at, location, capacity, status, cover_path)
  VALUES (
    v_org1_id,
    'Conferencia de Tecnología 2024',
    'Únete a nuestra conferencia anual sobre las últimas tendencias en tecnología, IA y desarrollo de software.',
    NOW() + INTERVAL '1 day' + INTERVAL '10 hours',
    NOW() + INTERVAL '1 day' + INTERVAL '13 hours',
    'Centro de Convenciones, Madrid',
    100,
    'published',
    'events/tech-conf-2024.jpg'
  ) RETURNING id INTO v_event1_id;

  INSERT INTO public.events (organizer_id, title, description, start_at, end_at, location, capacity, status, cover_path)
  VALUES (
    v_org1_id,
    'Workshop de React Avanzado',
    'Aprende técnicas avanzadas de React, hooks personalizados, optimización y mejores prácticas.',
    NOW() + INTERVAL '2 days' + INTERVAL '14 hours',
    NOW() + INTERVAL '2 days' + INTERVAL '17 hours',
    'Campus Tech, Barcelona',
    30,
    'published',
    'events/react-workshop.jpg'
  ) RETURNING id INTO v_event2_id;

  INSERT INTO public.events (organizer_id, title, description, start_at, end_at, location, capacity, status, cover_path)
  VALUES (
    v_org2_id,
    'Networking para Desarrolladores',
    'Evento de networking donde podrás conocer a otros desarrolladores y compartir experiencias.',
    NOW() + INTERVAL '3 days' + INTERVAL '18 hours',
    NOW() + INTERVAL '3 days' + INTERVAL '21 hours',
    'Café Tech, Valencia',
    50,
    'published',
    'events/networking.jpg'
  ) RETURNING id INTO v_event3_id;

  INSERT INTO public.events (organizer_id, title, description, start_at, end_at, location, capacity, status, cover_path)
  VALUES (
    v_org2_id,
    'Hackathon de Fintech',
    '48 horas para desarrollar soluciones innovadoras en el sector financiero.',
    NOW() + INTERVAL '5 days',
    NOW() + INTERVAL '7 days',
    'Innovation Hub, Sevilla',
    80,
    'published',
    'events/hackathon.jpg'
  ) RETURNING id INTO v_event4_id;

  INSERT INTO public.events (organizer_id, title, description, start_at, end_at, location, capacity, status, cover_path)
  VALUES (
    v_org3_id,
    'Charla sobre DevOps',
    'Introducción a DevOps, CI/CD, Docker y Kubernetes para principiantes.',
    NOW() + INTERVAL '6 days' + INTERVAL '10 hours',
    NOW() + INTERVAL '6 days' + INTERVAL '12 hours',
    'Online',
    200,
    'published',
    'events/devops.jpg'
  ) RETURNING id INTO v_event5_id;

  -- Reservas (activas y waitlist)
  INSERT INTO public.reservations (event_id, user_id, status)
  VALUES
    (v_event1_id, v_user1_id, 'active'),
    (v_event1_id, v_user2_id, 'active'),
    (v_event1_id, v_user3_id, 'active'),
    (v_event1_id, v_user4_id, 'waitlist'),
    (v_event2_id, v_user1_id, 'active'),
    (v_event2_id, v_user2_id, 'active'),
    (v_event3_id, v_user3_id, 'active'),
    (v_event3_id, v_user4_id, 'active'),
    (v_event3_id, v_user5_id, 'waitlist'),
    (v_event4_id, v_user5_id, 'active');

  -- Comentarios
  INSERT INTO public.comments (event_id, user_id, content)
  VALUES
    (v_event1_id, v_user1_id, '¡Evento increíble! Gracias por la organización.'),
    (v_event1_id, v_user2_id, 'Muy buenas charlas y networking.'),
    (v_event2_id, v_user3_id, 'El workshop fue súper práctico.'),
    (v_event3_id, v_user4_id, 'Gran ambiente y gente muy copada.'),
    (v_event5_id, v_user5_id, 'Me encantó el enfoque introductorio.');

  -- Audit logs (acciones simuladas)
  INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, payload)
  VALUES
    (v_admin_id, 'seed_completed', 'system', NULL, jsonb_build_object('source', '011_seed_data.sql')),
    (v_org1_id, 'event_created', 'event', v_event1_id, jsonb_build_object('title', 'Conferencia de Tecnología 2024')),
    (v_org1_id, 'event_created', 'event', v_event2_id, jsonb_build_object('title', 'Workshop de React Avanzado')),
    (v_org2_id, 'event_created', 'event', v_event3_id, jsonb_build_object('title', 'Networking para Desarrolladores')),
    (v_org2_id, 'event_created', 'event', v_event4_id, jsonb_build_object('title', 'Hackathon de Fintech')),
    (v_org3_id, 'event_created', 'event', v_event5_id, jsonb_build_object('title', 'Charla sobre DevOps'));
END $$;

COMMENT ON FUNCTION get_user_id_by_email IS 'Helper para obtener user_id por email (solo para seed)';
COMMENT ON FUNCTION seed_create_user IS 'Crea usuarios de seed en auth.users/auth.identities si no existen';
