// Base de datos
export const users = [
  {
    id: "1",
    name: "Ana García",
    email: "ana@example.com",
    age: 28,
    city: "Madrid"
  },
  {
    id: "2",
    name: "Carlos Ruiz",
    email: "carlos@example.com",
    age: 35,
    city: "Barcelona"
  },
  {
    id: "3",
    name: "María López",
    email: "maria@example.com",
    age: 24,
    city: "Valencia"
  }
];

export const posts = [
  {
    id: "1",
    title: "Introducción a GraphQL",
    content: "GraphQL es un lenguaje de consulta para APIs...",
    authorId: "1",
    likes: 42
  },
  {
    id: "2",
    title: "REST vs GraphQL",
    content: "Comparando dos paradigmas de desarrollo de APIs...",
    authorId: "1",
    likes: 28
  },
  {
    id: "3",
    title: "Arquitectura de Microservicios",
    content: "Los microservicios permiten escalar aplicaciones...",
    authorId: "2",
    likes: 55
  },
  {
    id: "4",
    title: "TypeScript para Principiantes",
    content: "TypeScript añade tipado estático a JavaScript...",
    authorId: "3",
    likes: 38
  }
];
