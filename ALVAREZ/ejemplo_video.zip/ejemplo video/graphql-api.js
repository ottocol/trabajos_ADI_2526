import { ApolloServer } from '@apollo/server';
import { startStandaloneServer } from '@apollo/server/standalone';
import { users, posts } from './data.js';


// ESQUEMA GraphQL
const typeDefs = `#graphql
  type User {
    id: ID!
    name: String!
    email: String!
    age: Int!
    city: String!
    posts: [Post!]!
  }

  type Post {
    id: ID!
    title: String!
    content: String!
    authorId: ID!
    author: User!
    likes: Int!
  }

  type Query {
    # Obtener todos los usuarios
    users: [User!]!
    
    # Obtener un usuario por ID
    user(id: ID!): User
    
    # Obtener todos los posts
    posts: [Post!]!
    
    # Obtener un post por ID
    post(id: ID!): Post
    
    # Obtener posts de un usuario específico
    userPosts(userId: ID!): [Post!]!
  }

  type Mutation {
    # Crear un nuevo usuario
    createUser(name: String!, email: String!, age: Int!, city: String!): User!
    
    # Crear un nuevo post
    createPost(title: String!, content: String!, authorId: ID!): Post!
  }
`;


// RESOLVERS
const resolvers = {
  Query: {
    users: () => users,
    
    user: (_, { id }) => users.find(user => user.id === id),
    
    posts: () => posts,
    
    post: (_, { id }) => posts.find(post => post.id === id),
    
    userPosts: (_, { userId }) => posts.filter(post => post.authorId === userId),
  },
  
  Mutation: {
    createUser: (_, { name, email, age, city }) => {
      const newUser = {
        id: String(users.length + 1),
        name,
        email,
        age,
        city
      };
      users.push(newUser);
      return newUser;
    },
    
    createPost: (_, { title, content, authorId }) => {
      const newPost = {
        id: String(posts.length + 1),
        title,
        content,
        authorId,
        likes: 0
      };
      posts.push(newPost);
      return newPost;
    }
  },
  
  // Resolvers de campos relacionados
  User: {
    posts: (user) => posts.filter(post => post.authorId === user.id)
  },
  
  Post: {
    author: (post) => users.find(user => user.id === post.authorId)
  }
};


// CREAR Y ARRANCAR SERVIDOR GraphQL
const server = new ApolloServer({
  typeDefs,
  resolvers,
});

const { url } = await startStandaloneServer(server, {
  listen: { port: 4000 },
});

console.log(`GraphQL Server corriendo en ${url}`);