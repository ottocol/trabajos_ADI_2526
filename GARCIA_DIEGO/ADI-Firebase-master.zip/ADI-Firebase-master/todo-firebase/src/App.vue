<script setup>
import { ref, onMounted } from "vue"
import { onAuthStateChanged } from "firebase/auth"
import { auth } from "./firebase"

import AuthView from "./components/AuthView.vue"
import TodoView from "./components/TodoView.vue"

const user = ref(null)

onMounted(() => {
  onAuthStateChanged(auth, u => {
    user.value = u
  })
})
</script>

<template>
  <AuthView v-if="!user" />
  <TodoView v-else :user="user" />
</template>
