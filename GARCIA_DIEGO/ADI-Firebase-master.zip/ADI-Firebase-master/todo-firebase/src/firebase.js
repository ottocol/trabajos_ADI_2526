// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD94cbm_woXj8wIBa0sOv-T_xKZakwe2Mw",
  authDomain: "adi-firebase-0126.firebaseapp.com",
  projectId: "adi-firebase-0126",
  storageBucket: "adi-firebase-0126.firebasestorage.app",
  messagingSenderId: "268822357928",
  appId: "1:268822357928:web:f98ed76bd11d2184089f9d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app)
export const db = getFirestore(app)