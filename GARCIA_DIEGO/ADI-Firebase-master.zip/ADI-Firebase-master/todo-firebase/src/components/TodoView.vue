<script setup>
    import { ref, onMounted } from "vue"
    import { auth, db } from "../firebase"
    import { signOut } from "firebase/auth"
    import { collection, addDoc, query, where, onSnapshot , doc, updateDoc, deleteDoc } from "firebase/firestore"

    const props = defineProps(["user"])

    const tasks = ref([])
    const newTask = ref("")

    onMounted(() => {
        const q = query(
            collection(db, "tasks"),
            where("userId", "==", props.user.uid)
        )

        onSnapshot(q, snap => {
            tasks.value = snap.docs.map(d => ({
                id: d.id,
                ...d.data()
            }))
        })
    })

    const addTask = async () => {
        if (!newTask.value) return

        await addDoc(collection(db, "tasks"), {
            userId: props.user.uid,
            text: newTask.value,
            done: false
        })
        newTask.value = ""
    }

    const toggleDone = async (task) => {
        const ref = doc(db, "tasks", task.id)

        await updateDoc(ref, {
            done: !task.done
        })
    }

    const removeTask = async (task) => {
        const ref = doc(db, "tasks", task.id)
        await deleteDoc(ref)
    }
</script>

<template>
    <h2>My Tasks</h2>
    <button @click="signOut(auth)">Logout</button>

    <br /><br />

    <input v-model="newTask" placeholder="New task" />
    <button @click="addTask">Add</button>

    <ul>
        <li v-for="t in tasks" :key="t.id" style="margin-bottom:8px">
            <input type="checkbox" :checked="t.done" @change="toggleDone(t)" />
            <span :style="{ textDecoration: t.done ? 'line-through' : 'none' }"> {{ t.text }} </span>
            <button @click="removeTask(t)" style="margin-left:10px"> Eliminar </button>
        </li>
    </ul>
</template>
