<script setup>
    import { ref } from "vue"
    import { auth } from "../firebase"
    import {
        createUserWithEmailAndPassword,
        signInWithEmailAndPassword
    } from "firebase/auth"

    const email = ref("")
    const password = ref("")
    const error = ref("")

    const login = async () => {
        try {
            await signInWithEmailAndPassword(auth, email.value, password.value)
        } catch (e) {
            error.value = e.message
        }
    }

    const register = async () => {
        try {
            await createUserWithEmailAndPassword(auth, email.value, password.value)
        } catch (e) {
            error.value = e.message
        }
    }
</script>

<template>
    <h2>Login</h2>

    <input v-model="email" placeholder="Email" />
    <input v-model="password" type="password" placeholder="Password" />

    <div style="color:red">{{ error }}</div>

    <button @click="login">Login</button>
    <button @click="register">Register</button>
</template>
