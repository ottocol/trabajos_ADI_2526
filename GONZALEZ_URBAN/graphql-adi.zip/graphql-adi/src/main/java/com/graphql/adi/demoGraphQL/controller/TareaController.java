package com.graphql.adi.demoGraphQL.controller;

import com.graphql.adi.demoGraphQL.model.Tarea;
import com.graphql.adi.demoGraphQL.model.Tarea;
import com.graphql.adi.demoGraphQL.graphql.inputTarea;
import com.graphql.adi.demoGraphQL.graphql.inputTarea;
import com.graphql.adi.demoGraphQL.service.TareaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class TareaController {
    @Autowired
    TareaService tareaService;

    @QueryMapping(name="findAllTareas")
    public List<Tarea> findAllTareas(){
        return tareaService.findAllTareas();
    }

    @QueryMapping(name = "findTareaById")
    public Tarea findById(@Argument(name = "TareaId") Integer id) {
        return tareaService.findById(id);
    }

    @QueryMapping(name = "findTareasByUsuario")
    public List<Tarea> findTareasByUsuario(@Argument(name = "UsuarioId") Integer usuarioId) {
        return tareaService.findTareaByUsuarioId(usuarioId);
    }

    @MutationMapping(name = "createTarea")
    public Tarea createTarea(@Argument(name = "input") inputTarea input) {
        return tareaService.crear(input);
    }

    @MutationMapping(name = "updateTarea")
    public Tarea updateTarea(@Argument(name = "id") Integer id,@Argument(name = "input") inputTarea inputTarea) {
        return tareaService.actualizarTarea(id, inputTarea);
    }

    @MutationMapping(name = "deleteTarea")
    public String deleteTarea(@Argument(name = "id") Integer id) {
        if  (tareaService.eliminarTarea(id)) {
            return "Tarea con id:" + id + " eliminado";
        }
        return "Tarea con id:" + id + " no ha podido ser eliminado";
    }
}
