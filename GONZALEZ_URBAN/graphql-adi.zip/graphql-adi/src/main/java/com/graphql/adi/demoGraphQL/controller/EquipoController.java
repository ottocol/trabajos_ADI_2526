package com.graphql.adi.demoGraphQL.controller;

import com.graphql.adi.demoGraphQL.graphql.inputEquipo;
import com.graphql.adi.demoGraphQL.model.Equipo;
import com.graphql.adi.demoGraphQL.service.EquipoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class EquipoController {
    @Autowired
    private EquipoService equipoService;

    @QueryMapping(name = "findAllEquipos")
    public List<Equipo> listAllEquipos() {
        return equipoService.findAllEquipos();
    }

    @QueryMapping(name = "findEquipoById")
    public Equipo findEquipoById(@Argument(name = "EquipoId") Integer id) {
        return equipoService.findEquipoById(id);
    }

    @QueryMapping(name = "findEquiposByUsuario")
    public List<Equipo> findEquiposByUsuario(@Argument(name = "UsuarioId") Integer usuarioId) {
        return equipoService.findEquiposByUsuarioId(usuarioId);
    }

    @MutationMapping(name = "createEquipo")
    public Equipo createEquipo(@Argument(name = "input") inputEquipo input) {
        return equipoService.crear(input);
    }

    @MutationMapping(name = "updateEquipo")
    public Equipo updateEquipo(@Argument(name = "id") Integer id,@Argument(name = "input") inputEquipo inputEquipo) {
        return equipoService.actualizarEquipo(id, inputEquipo);
    }

    @MutationMapping(name = "deleteEquipo")
    public String deleteEquipo(@Argument(name = "id") Integer id) {
        if  (equipoService.eliminarEquipo(id)) {
            return "Equipo con id:" + id + " eliminado";
        }
        return "Equipo con id:" + id + " no ha podido ser eliminado";
    }

}
