package com.graphql.adi.demoGraphQL.repository;
import org.jetbrains.annotations.NotNull;
import org.springframework.data.repository.CrudRepository;
import com.graphql.adi.demoGraphQL.model.Usuario;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends CrudRepository<Usuario, Integer>{
    Optional<Usuario> findUsuarioById(Integer id);
    Optional<Usuario> findByEmail(String email);
    List<Usuario> findUsuariosByEquiposId(Integer equipoId);
    List<Usuario> findAll();
}
