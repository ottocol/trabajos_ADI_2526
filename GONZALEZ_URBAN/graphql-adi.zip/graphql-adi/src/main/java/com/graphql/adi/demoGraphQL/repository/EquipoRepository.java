package com.graphql.adi.demoGraphQL.repository;
import com.graphql.adi.demoGraphQL.model.Equipo;
import com.graphql.adi.demoGraphQL.model.Usuario;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface EquipoRepository extends CrudRepository<Equipo, Integer>{
    Optional<Equipo> findEquipoById(Integer equipoId);
    List<Equipo> findByUsuariosId(Integer usuario);
    List<Equipo> findAll();
}
