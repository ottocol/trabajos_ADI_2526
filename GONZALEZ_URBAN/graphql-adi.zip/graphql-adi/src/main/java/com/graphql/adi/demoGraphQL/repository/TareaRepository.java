package com.graphql.adi.demoGraphQL.repository;
import com.graphql.adi.demoGraphQL.model.Tarea;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface TareaRepository extends CrudRepository<Tarea, Integer>{
    Optional<Tarea> findTareaById(Integer id);
    List<Tarea> findTareaByUsuarioId(Integer id);
    List<Tarea> findAll();
}
