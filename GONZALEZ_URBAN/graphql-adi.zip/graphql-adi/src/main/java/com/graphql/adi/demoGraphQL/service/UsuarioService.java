package com.graphql.adi.demoGraphQL.service;

import com.graphql.adi.demoGraphQL.graphql.inputUsuario;
import com.graphql.adi.demoGraphQL.model.Usuario;
import com.graphql.adi.demoGraphQL.repository.UsuarioRepository;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    private Usuario toUsuario(inputUsuario usuario){
        Usuario u = new Usuario();
        u.setNombre(usuario.getNombre());
        u.setEmail(usuario.getEmail());
        u.setPassword(usuario.getPassword());
        return u;
    }

    @Transactional(readOnly = true)
    public List<Usuario> findAll() {
        return usuarioRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Usuario findById(Integer id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    @Transactional(readOnly = true)
    public Usuario findByEmail(String email) {
        return usuarioRepository.findByEmail(email).orElse(null);
    }

    @Transactional(readOnly = true)
    public List<Usuario> findByEquipoId(Integer equipoId) {
        return usuarioRepository.findUsuariosByEquiposId(equipoId);
    }

    @Transactional
    public Usuario registrar(inputUsuario usuario) {
        Usuario usuarioBD = usuarioRepository.findByEmail(usuario.getEmail()).orElse(null);
        if (usuarioBD != null) {
            return null;
        }
        Usuario u = toUsuario(usuario);
        return usuarioRepository.save(u);
    }

    @Transactional
    public Usuario actualizarUsuario(Integer id,inputUsuario usuario) {
        Usuario usuarioBD = usuarioRepository.findById(id).orElse(null);
        if (usuarioBD != null) {
            Usuario u = toUsuario(usuario);
            u.setId(id);
            return usuarioRepository.save(u);
        }
        return null;
    }

    @Transactional
    public boolean eliminarUsuario(Integer id) {
        Usuario usuarioBD = usuarioRepository.findById(id).orElse(null);
        if (usuarioBD != null) {
            usuarioRepository.deleteById(id);
            return true;
        }
        return false;
    }

}
