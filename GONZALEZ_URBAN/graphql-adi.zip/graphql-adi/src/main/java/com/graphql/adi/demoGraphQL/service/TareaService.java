package com.graphql.adi.demoGraphQL.service;

import com.graphql.adi.demoGraphQL.graphql.inputEquipo;
import com.graphql.adi.demoGraphQL.graphql.inputTarea;
import com.graphql.adi.demoGraphQL.graphql.inputUsuario;
import com.graphql.adi.demoGraphQL.model.Equipo;
import com.graphql.adi.demoGraphQL.model.Tarea;
import com.graphql.adi.demoGraphQL.model.Usuario;
import com.graphql.adi.demoGraphQL.repository.TareaRepository;
import com.graphql.adi.demoGraphQL.repository.UsuarioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class TareaService {

    @Autowired
    private TareaRepository tareaRepository;

    @Autowired
    private UsuarioService usuarioService;

    private Tarea toTarea(inputTarea inputTarea){
        Tarea tarea = new Tarea();
        tarea.setTitulo(inputTarea.getTitulo());
        tarea.setDescripcion(inputTarea.getDescripcion());
        tarea.setCompletada(inputTarea.getCompletada());
        
        Usuario usuario = usuarioService.findById(inputTarea.getUsuario());
        if (usuario == null) {
            throw new UserNotFoundException("El usuario con id " + inputTarea.getUsuario() + " no existe");
        }

        tarea.setUsuario(usuario);
        return tarea;
    }

    @Transactional(readOnly = true)
    public List<Tarea> findAllTareas() {
        return tareaRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Tarea findById(Integer id) {
        return tareaRepository.findById(id).orElse(null);
    }

    @Transactional(readOnly = true)
    public List<Tarea> findTareaByUsuarioId(Integer idUsuario) {
        return tareaRepository.findTareaByUsuarioId(idUsuario);
    }

    @Transactional
    public Tarea crear(inputTarea inputTarea){
        return tareaRepository.save(toTarea(inputTarea));
    }

    @Transactional
    public Tarea actualizarTarea(Integer id,inputTarea inputTarea) {
        Tarea tarea = tareaRepository.findById(id).orElse(null);
        if (tarea == null) return null;

        tarea = toTarea(inputTarea);
        tarea.setId(id);

        return tareaRepository.save(tarea);
    }

    @Transactional
    public Boolean eliminarTarea(Integer id){
        Tarea equipo = tareaRepository.findById(id).orElse(null);
        if (equipo == null) return false;
        tareaRepository.deleteById(id);
        return true;
    }
}
