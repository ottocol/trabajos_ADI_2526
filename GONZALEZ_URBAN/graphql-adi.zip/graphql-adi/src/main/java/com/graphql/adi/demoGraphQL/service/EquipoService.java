package com.graphql.adi.demoGraphQL.service;

import com.graphql.adi.demoGraphQL.graphql.inputEquipo;
import com.graphql.adi.demoGraphQL.model.Equipo;
import com.graphql.adi.demoGraphQL.repository.EquipoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EquipoService {
    @Autowired
    private EquipoRepository equipoRepository;


    private Equipo toEquipo(inputEquipo inputEquipo){
        Equipo equipo = new Equipo();
        equipo.setNombre(inputEquipo.getNombre());
        equipo.setDescripcion(inputEquipo.getDescripcion());
        return equipo;
    }

    @Transactional(readOnly = true)
    public List<Equipo> findAllEquipos()
    {
        return equipoRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Equipo findEquipoById(Integer id)
    {
        return equipoRepository.findById(id).orElse(null);
    }

    @Transactional(readOnly = true)
    public List<Equipo> findEquiposByUsuarioId(Integer id)
    {
        return equipoRepository.findByUsuariosId(id);
    }

    @Transactional
    public Equipo crear(inputEquipo inputEquipo){
        return equipoRepository.save(toEquipo(inputEquipo));
    }

    @Transactional
    public Equipo actualizarEquipo(Integer id,inputEquipo inputEquipo){
        Equipo equipo = equipoRepository.findById(id).orElse(null);
        if (equipo == null) return null;

        equipo.setNombre(inputEquipo.getNombre());
        equipo.setDescripcion(inputEquipo.getDescripcion());

        return equipoRepository.save(equipo);
    }

    @Transactional
    public Boolean eliminarEquipo(Integer id){
        Equipo equipo = equipoRepository.findById(id).orElse(null);
        if (equipo == null) return false;
        equipoRepository.deleteById(id);
        return true;
    }
}
