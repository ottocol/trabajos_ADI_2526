package com.graphql.adi.demoGraphQL.controller;

import com.graphql.adi.demoGraphQL.service.UsuarioService;
import com.graphql.adi.demoGraphQL.model.Usuario;
import com.graphql.adi.demoGraphQL.graphql.inputUsuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;


@Controller
public class UsuarioController {
    @Autowired
    private UsuarioService usuarioService;

    @QueryMapping(name = "findAllUsuarios")
    public List<Usuario> findAll() {
        return usuarioService.findAll();
    }

    @QueryMapping(name = "findUsuarioById")
    public Usuario findById(@Argument(name = "UsuarioId") Integer id) {
        return usuarioService.findById(id);
    }

    @QueryMapping(name = "findUsuarioByEmail")
    public Usuario findByEmail(@Argument(name = "Email") String email) {
        return usuarioService.findByEmail(email);
    }

    @QueryMapping(name = "findUsuariosByEquipo")
    public List<Usuario> findByEquipo(@Argument(name = "EquipoId") Integer equipoId) {
        return usuarioService.findByEquipoId(equipoId);
    }

    @MutationMapping(name = "createUsuario")
    public Usuario registrar(@Argument(name = "input") inputUsuario usuario) {
        return usuarioService.registrar(usuario);
    }

    @MutationMapping(name = "updateUsuario")
    public Usuario actualizar(@Argument(name = "id") Integer id, @Argument(name = "input") inputUsuario usuario) {
        return usuarioService.actualizarUsuario(id,usuario);
    }

    @MutationMapping(name = "deleteUsuario")
    public String eliminar(@Argument(name = "id") Integer id) {
        if (usuarioService.eliminarUsuario(id)){
            return "Usuario " + id + " eliminado correctamente";
        }
        return "Usuario " + id + " no ha podido ser eliminado";
    }

}
