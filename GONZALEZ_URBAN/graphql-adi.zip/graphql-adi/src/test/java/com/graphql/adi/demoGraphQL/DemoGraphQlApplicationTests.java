package com.graphql.adi.demoGraphQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoGraphQlApplicationTests {

	@Test
	void contextLoads() {
	}

}
