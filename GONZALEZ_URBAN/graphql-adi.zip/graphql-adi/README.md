# GraphQL ADI
 - Video: https://youtu.be/X8DRY9dmsCM
 - Presentación: https://www.canva.com/design/DAG-a1NJlKQ/ncmxQBFD_neQ04-TXkA6wA/edit?utm_content=DAG-a1NJlKQ&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton
 - Miembros: 
 - Sergio González Urbán
 - Javier Gárcia Cutillas
 - Antonio Mainar Sánchez
## Referencias
- https://youtu.be/FAfH-twzEVI?si=XzE2RZKcbqv9C-zF
- https://www.youtube.com/watch?v=Exxl5R7X6ak
- https://graphql.org/
- https://www.ibm.com/es-es/think/topics/graphql
- https://engineering.fb.com/2015/09/14/core-infra/graphql-a-data-query-language/
- https://es.wikipedia.org/wiki/GraphQL
- https://www.redhat.com/es/topics/api/what-is-graphql
- https://spring.io/guides/gs/graphql-server
- https://www.paradigmadigital.com/dev/dominando-graphql-spring-boot-guia-definitiva/

# Como poner el proyecto en marcha desde este mismo lugar ejecutar
  
./mvnw spring-boot:run  
  
localhost:8080/graphiql -> para consola de graphql  
el endpoint es localhost:8080/graphql  
y la consola h2 está en localhost:8080/h2-console
![img.png](img.png)  
La contraseña es pass