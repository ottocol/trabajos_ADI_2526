/**
 * useToast, composable para sistema de notificaciones
 * Gestiona notificaciones toast que aparecen temporalmente
 *
 * Estado global:
 * - toasts: Array de notificaciones activas
 * - toastId: Contador para IDs únicos
 *
 * Métodos:
 * - show(message, type, duration): Muestra un toast genérico
 * - success(message): Toast verde de éxito
 * - error(message): Toast rojo de error
 * - warning(message): Toast amarillo de advertencia
 * - info(message): Toast azul informativo
 * - confirm(message, onConfirm, onCancel): Toast modal con botones Aceptar/Cancelar
 * - remove(id): Cierra un toast específico
 */
import { ref } from 'vue'

// Estado global compartido entre todas las instancias
const toasts = ref([])
let toastId = 0

export function useToast() {
  const show = (message, type = 'info', duration = 3000) => {
    const id = toastId++
    const toast = {
      id,
      message,
      type, // 'success', 'error', 'warning', 'info'
      visible: true
    }

    toasts.value.push(toast)

    if (duration > 0) {
      setTimeout(() => {
        remove(id)
      }, duration)
    }

    return id
  }

  const remove = (id) => {
    const index = toasts.value.findIndex(t => t.id === id)
    if (index > -1) {
      toasts.value.splice(index, 1)
    }
  }

  const success = (message, duration = 3000) => {
    return show(message, 'success', duration)
  }

  const error = (message, duration = 4000) => {
    return show(message, 'error', duration)
  }

  const warning = (message, duration = 3500) => {
    return show(message, 'warning', duration)
  }

  const info = (message, duration = 3000) => {
    return show(message, 'info', duration)
  }

  const confirm = (message, onConfirm, onCancel) => {
    const id = toastId++
    const toast = {
      id,
      message,
      type: 'confirm',
      visible: true,
      onConfirm: () => {
        remove(id)
        if (onConfirm) onConfirm()
      },
      onCancel: () => {
        remove(id)
        if (onCancel) onCancel()
      }
    }

    toasts.value.push(toast)
    return id
  }

  return {
    toasts,
    show,
    remove,
    success,
    error,
    warning,
    info,
    confirm
  }
}
