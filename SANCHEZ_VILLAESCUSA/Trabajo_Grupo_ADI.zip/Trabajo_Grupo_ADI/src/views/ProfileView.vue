<script setup>
import { ref, onMounted, computed } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { useRouter } from 'vue-router'
import { updateUser } from '@/services/users'
import { useBooksStore } from '@/stores/books'
import { listReviewsByUser } from '@/services/reviews'
import { useToast } from '@/composables/useToast'
import BookCard from '@/components/BookCard.vue'

const auth = useAuthStore()
const router = useRouter()
const booksStore = useBooksStore()
const toast = useToast()

const profile = ref(null)
const isLoading = ref(true)
const isUpdating = ref(false)
const isEditing = ref(false)
const isEditingAvatar = ref(false)
const userBooks = ref([])
const userReviews = ref([])
const recentActivity = ref([])

const formData = ref({
  nombre: '',
  nom_mostrado: '',
  email: '',
  avatar: '',
  bio: '',
  fecha_nac: '',
  genero_fav: ''
})

const loadUserProfile = async () => {
  if (!auth.isLoggedIn || !auth.currentUser) {
    router.push('/login')
    return
  }

  try {
    isLoading.value = true
    profile.value = auth.currentUser

    // Mapeo de campos de 'usuarios' al formulario
    formData.value = {
      nombre: profile.value.nombre || '',
      nom_mostrado: profile.value.nom_mostrado || '',
      email: profile.value.email || '',
      avatar: profile.value.avatar || '',
      bio: profile.value.bio || '',
      fecha_nac: profile.value.fecha_nac || '',
      genero_fav: profile.value.genero_fav || ''
    }

    await loadUserStats()
  } catch (error) {
    console.error('Error cargando perfil:', error)
  } finally {
    isLoading.value = false
  }
}

const loadUserStats = async () => {
  try {
    // LLAMADA CORREGIDA: Trae solo los libros donde id_creador == mi ID
    userBooks.value = await booksStore.loadUserBooks(auth.currentUser.id)

    // Reseñas del usuario (esto ya lo teníamos bien)
    const reviewsResult = await listReviewsByUser(auth.currentUser.id, {
      perPage: 100,
      expand: 'libro'
    })
    userReviews.value = reviewsResult.items

    // Reconstruir la actividad con los datos filtrados
    buildRecentActivity()
  } catch (error) {
    console.error('Error cargando estadísticas:', error)
  }
}

const buildRecentActivity = () => {
  const activities = []
  userBooks.value.forEach(book => {
    activities.push({
      date: new Date(book.created),
      type: 'book',
      action: `Añadió el libro "${book.titulo}"`,
      link: `/book/${book.id}`
    })
  })

  userReviews.value.forEach(review => {
    const bookTitle = review.expand?.libro?.titulo || 'un libro'
    activities.push({
      date: new Date(review.created),
      type: 'review',
      action: `Escribió una reseña para "${bookTitle}"`,
      link: `/book/${review.libro}`
    })
  })

  if (profile.value?.creado) {
    activities.push({
      date: new Date(profile.value.creado),
      type: 'join',
      action: 'Se unió a Biblioteca Digital'
    })
  }

  recentActivity.value = activities.sort((a, b) => b.date - a.date).slice(0, 5)
}

const updateProfile = async () => {
  try {
    isUpdating.value = true
    // Enviar campos correctos según service/users.js
    await updateUser(auth.currentUser.id, {
      nombre: formData.value.nombre,
      nom_mostrado: formData.value.nom_mostrado,
      bio: formData.value.bio,
      fecha_nac: formData.value.fecha_nac,
      genero_fav: formData.value.genero_fav
    })

    await auth.init() // Refrescar store
    profile.value = auth.currentUser
    isEditing.value = false
    toast.success('Perfil actualizado')
  } catch (error) {
    toast.error('Error al actualizar')
  } finally {
    isUpdating.value = false
  }
}

const updateAvatar = async () => {
  try {
    isUpdating.value = true
    await updateUser(auth.currentUser.id, { avatar: formData.value.avatar })
    await auth.init()
    profile.value = auth.currentUser
    isEditingAvatar.value = false
    toast.success('Avatar actualizado')
  } catch (error) {
    toast.error('Error al actualizar avatar')
  } finally {
    isUpdating.value = false
  }
}

const startEditing = () => { isEditing.value = true }
const cancelEdit = () => { isEditing.value = false; loadUserProfile(); }
const toggleAvatarEdit = () => { isEditingAvatar.value = !isEditingAvatar.value }
const cancelAvatarEdit = () => { isEditingAvatar.value = false; formData.value.avatar = profile.value.avatar || ''; }

const formatDate = (date) => new Date(date).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' })

const displayName = computed(() => profile.value?.nom_mostrado || profile.value?.nombre || 'Usuario')
const memberSince = computed(() => profile.value?.creado ? new Date(profile.value.creado).toLocaleDateString('es-ES', { month: 'long', year: 'numeric' }) : '')
const avatarUrl = computed(() => profile.value?.avatar || 'https://via.placeholder.com/150/4A90E2/FFFFFF?text=' + displayName.value[0])

onMounted(loadUserProfile)
</script>

<template>
  <section v-if="isLoading" class="loading">Cargando perfil...</section>
  <section v-else-if="!profile" class="not-found">
    <h1>Perfil no disponible</h1>
    <router-link to="/login" class="button button--primary">Iniciar sesión</router-link>
  </section>
  <section v-else class="profile-section">
    <div class="profile-container">
      <h1 class="profile-section__title">Mi Perfil</h1>

      <div class="user-info">
        <div class="user-info__avatar-wrapper">
          <div class="user-info__avatar">
            <img v-if="profile.avatar" :src="avatarUrl" class="user-info__image">
            <div v-else class="user-info__placeholder">{{ displayName[0] }}</div>
          </div>
          <button type="button" class="user-info__edit-avatar" @click="toggleAvatarEdit"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/></svg></button>
        </div>
        <div class="user-info__details">
          <h2 class="user-info__name">{{ displayName }}</h2>
          <p class="user-info__role">Usuario</p>
          <p class="user-info__member-since">Miembro desde: <span>{{ memberSince }}</span></p>
          <div v-if="isEditingAvatar" class="user-info__avatar-edit">
            <input type="url" v-model="formData.avatar" class="user-info__avatar-input" placeholder="URL del avatar">
            <div class="user-info__avatar-actions">
              <button class="button button--primary button--small" @click="updateAvatar">Guardar</button>
              <button class="button button--secondary button--small" @click="cancelAvatarEdit">Cancelar</button>
            </div>
          </div>
        </div>
      </div>

      <form class="profile-form" @submit.prevent="updateProfile">
        <div class="profile-form__header">
          <h3 class="profile-form__title">Información Personal</h3>
        </div>
        <div class="profile-form__row">
          <div class="profile-form__field"><label class="profile-form__label">Nombre:</label><input v-model="formData.nombre" class="profile-form__input" :disabled="!isEditing"></div>
          <div class="profile-form__field"><label class="profile-form__label">Nick:</label><input v-model="formData.nom_mostrado" class="profile-form__input" :disabled="!isEditing"></div>
        </div>
        <div class="profile-form__field"><label class="profile-form__label">Email:</label><input v-model="formData.email" class="profile-form__input" disabled></div>
        <div class="profile-form__row">
          <div class="profile-form__field"><label class="profile-form__label">Nacimiento:</label><input type="date" v-model="formData.fecha_nac" class="profile-form__input" :disabled="!isEditing"></div>
          <div class="profile-form__field"><label class="profile-form__label">Género Fav:</label><input v-model="formData.genero_fav" class="profile-form__input" :disabled="!isEditing"></div>
        </div>
        <div class="profile-form__field"><label class="profile-form__label">Biografía:</label><textarea v-model="formData.bio" class="profile-form__textarea" :disabled="!isEditing"></textarea></div>
        <div class="profile-form__actions">
          <template v-if="isEditing">
            <button type="submit" class="button button--primary">Guardar</button>
            <button type="button" class="button button--secondary" @click="cancelEdit">Cancelar</button>
          </template>
          <button v-else type="button" class="button button--primary" @click="startEditing">Editar Perfil</button>
        </div>
      </form>

      <div class="user-stats">
        <h3 class="user-stats__title">Mis Estadísticas</h3>
        <div class="user-stats__grid">
          <div class="user-stats__item"><span class="user-stats__number">{{ userBooks.length }}</span><span class="user-stats__label">Libros Añadidos</span></div>
          <div class="user-stats__item"><span class="user-stats__number">{{ userReviews.length }}</span><span class="user-stats__label">Reseñas Escritas</span></div>
        </div>
      </div>

      <div v-if="userBooks.length > 0" class="user-books">
        <h3 class="user-books__title">Mis Libros</h3>
        <div class="user-books__grid">
          <BookCard v-for="book in userBooks" :key="book.id" :book="book" />
        </div>
      </div>

      <div class="activity-history">
        <h3 class="activity-history__title">Actividad Reciente</h3>
        <div v-if="recentActivity.length === 0" class="activity-history__empty"><p>No hay actividad reciente</p></div>
        <div v-else class="activity-history__list">
          <component :is="activity.link ? 'router-link' : 'div'" v-for="(activity, index) in recentActivity" :key="index" :to="activity.link" class="activity-history__item" :class="{ 'activity-history__item--link': activity.link }">
            <span class="activity-history__date">{{ formatDate(activity.date) }}</span>
            <span class="activity-history__action">{{ activity.action }}</span>
          </component>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.profile-section { max-width: 1000px; margin: 0 auto; }
.profile-container { display: flex; flex-direction: column; gap: 2rem; }
.profile-section__title { text-align: center; color: var(--primary-color); font-size: 2.5rem; margin-bottom: 1rem; }
.user-info { background: var(--card-background); padding: 2rem; border-radius: 12px; display: flex; align-items: center; gap: 2rem; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
.user-info__avatar-wrapper { position: relative; flex-shrink: 0; }
.user-info__image { width: 120px; height: 120px; border-radius: 50%; object-fit: cover; border: 3px solid var(--secondary-color); display: block; }
.user-info__placeholder { width: 120px; height: 120px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-size: 3rem; font-weight: bold; border: 3px solid var(--secondary-color); }
.user-info__edit-avatar { position: absolute; bottom: 0; left: 0; width: 32px; height: 32px; border-radius: 50%; background: var(--secondary-color); color: white; border: 2px solid white; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: transform 0.2s; }
.user-info__edit-avatar:hover { transform: scale(1.1); }
.user-info__avatar-edit { margin-top: 1rem; }
.user-info__avatar-input { width: 100%; padding: 0.5rem; border: 1px solid var(--border-color); border-radius: 5px; margin-bottom: 0.5rem; }
.user-info__avatar-actions { display: flex; gap: 0.5rem; justify-content: flex-end; }
.profile-form { background: var(--card-background); padding: 2rem; border-radius: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
.profile-form__header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
.profile-form__title { margin: 0; }
.profile-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
.profile-form__field { margin-bottom: 1rem; }
.profile-form__label { display: block; margin-bottom: 0.4rem; font-weight: 500; color: #555; }
.profile-form__input { width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--border-color); border-radius: 6px; font-size: 1rem; box-sizing: border-box; }
.profile-form__textarea { width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--border-color); border-radius: 6px; font-size: 1rem; min-height: 80px; resize: vertical; box-sizing: border-box; }
.profile-form__actions { display: flex; gap: 0.75rem; justify-content: flex-end; margin-top: 1.5rem; }
.user-stats__grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; }
.user-stats__item { text-align: center; padding: 1rem; background: #f8f9fa; border-radius: 8px; border: 1px solid var(--border-color); }
.user-stats__number { display: block; font-size: 2rem; font-weight: bold; color: var(--secondary-color); }
.user-books__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1.5rem; }
.activity-history__item { display: flex; justify-content: space-between; align-items: center; padding: 1rem; background: #f8f9fa; border-radius: 8px; border-left: 4px solid var(--secondary-color); text-decoration: none; color: inherit; }
.activity-history__item--link:hover { background: #e9ecef; transform: translateX(5px); }
</style>
