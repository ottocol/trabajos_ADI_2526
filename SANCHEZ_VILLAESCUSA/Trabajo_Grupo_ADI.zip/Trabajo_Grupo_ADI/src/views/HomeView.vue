<script setup>
import { ref, computed, onMounted } from 'vue'
import BookCard from '@/components/BookCard.vue'
import { useBooksStore } from '@/stores/books'

const booksStore = useBooksStore()
const searchQuery = ref('')

const books = computed(() => booksStore.books)
const isLoading = computed(() => booksStore.isLoading)
const error = computed(() => booksStore.error)
const currentPage = computed(() => booksStore.currentPage)
const totalPages = computed(() => booksStore.totalPages)
const totalItems = computed(() => booksStore.totalItems)
const perPage = booksStore.perPage

const loadBooks = async (page = 1) => {
  try {
    await booksStore.loadBooks({ page, perPage })
  } catch (err) {
    console.error('Error cargando libros:', err)
  }
}

const handleSearch = async () => {
  if (!searchQuery.value.trim()) {
    await loadBooks(1)
    return
  }
  try {
    await booksStore.searchBooks(searchQuery.value)
  } catch (err) {
    console.error('Error buscando libros:', err)
  }
}

const clearSearch = async () => {
  searchQuery.value = ''
  await loadBooks(1)
}

const goToPage = async (page) => {
  if (page < 1 || page > totalPages.value || page === currentPage.value) return
  window.scrollTo({ top: 0, behavior: 'smooth' })
  await loadBooks(page)
}

const nextPage = () => goToPage(currentPage.value + 1)
const prevPage = () => goToPage(currentPage.value - 1)

onMounted(() => {
  loadBooks()
})
</script>

<template>
  <section class="book-list-section">
    <h1 class="book-list-section__title">Explora nuestra colección</h1>

    <div class="search-bar">
      <input
        type="search"
        class="search-bar__input"
        placeholder="Busca por título, autor o género..."
        v-model="searchQuery"
        @keyup.enter="handleSearch"
      >
      <button class="search-bar__button" @click="handleSearch">Buscar</button>
      <button
        v-if="searchQuery"
        class="search-bar__button search-bar__button--clear"
        @click="clearSearch"
        title="Restablecer búsqueda"
      >
        Limpiar
      </button>
    </div>

    <div v-if="isLoading" class="loading">Cargando libros...</div>

    <div v-else-if="error" class="error-message">
      <p>Error al cargar los libros. Intenta de nuevo.</p>
      <button class="button button--primary" @click="loadBooks(1)">Reintentar</button>
    </div>

    <TransitionGroup 
      name="fade" 
      tag="div" 
      class="book-grid" 
      v-if="!isLoading && !error && books.length > 0" 
      appear
    >
      <BookCard 
        v-for="(book, index) in books" 
        :key="book.id" 
        :book="book" 
        :style="{ '--i': index }" 
      />
    </TransitionGroup>

    <div v-else-if="!isLoading && !error && books.length === 0" class="no-results">
      No se encontraron libros.
    </div>

    <div v-if="!isLoading && !error && totalPages > 1 && !searchQuery" class="pagination">
      <button class="pagination__button" :disabled="currentPage === 1" @click="prevPage">← Anterior</button>
      
      <div class="pagination__pages">
        <button
          v-for="page in totalPages"
          :key="page"
          class="pagination__page"
          :class="{ 'pagination__page--active': page === currentPage }"
          @click="goToPage(page)"
        >
          {{ page }}
        </button>
      </div>

      <button class="pagination__button" :disabled="currentPage === totalPages" @click="nextPage">Siguiente →</button>
    </div>

    <div v-if="!isLoading && !error && !searchQuery" class="pagination-info">
      Mostrando {{ books.length }} de {{ totalItems }} libros (página {{ currentPage }} de {{ totalPages }})
    </div>
  </section>
</template>

<style scoped>
/* Estilos originales restaurados */
.book-list-section__title { text-align: center; font-size: 2.5rem; color: var(--primary-color); margin-bottom: 2rem; }

.search-bar { display: flex; max-width: 700px; margin: 0 auto 3rem; }
.search-bar__input { flex-grow: 1; padding: 1rem; border: 1px solid var(--border-color); border-radius: 8px 0 0 8px; font-size: 1.1rem; }
.search-bar__button { padding: 0 1.5rem; border: none; background: var(--secondary-color); color: white; cursor: pointer; border-radius: 0 8px 8px 0; font-weight: bold; }
.search-bar__button--clear { background: #e74c3c; margin-left: 5px; border-radius: 8px; }

.book-grid { 
  display: grid; 
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); /* Estilo estrecho para 4 tarjetas */
  gap: 2rem; 
  margin-bottom: 3rem; 
}

.fade-enter-active { transition: all 0.5s ease; transition-delay: calc(var(--i) * 0.05s); }
.fade-enter-from { opacity: 0; transform: translateY(30px); }

.pagination { display: flex; justify-content: center; align-items: center; gap: 1rem; margin: 3rem 0; }
.pagination__button { padding: 0.8rem 1.2rem; border: 1px solid #ddd; border-radius: 6px; background: white; cursor: pointer; }
.pagination__page { padding: 0.8rem 1.2rem; border: 1px solid #ddd; border-radius: 6px; background: white; cursor: pointer; }
.pagination__page--active { background: var(--primary-color); color: white; border-color: var(--primary-color); font-weight: bold; }
.pagination-info { text-align: center; color: #666; margin-bottom: 2rem; }
</style>