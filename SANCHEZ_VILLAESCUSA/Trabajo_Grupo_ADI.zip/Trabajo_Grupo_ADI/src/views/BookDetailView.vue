<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useBooksStore } from '@/stores/books'
import { listReviewsByBook, createReview, updateReview, deleteReview } from '@/services/reviews'
import { useToast } from '@/composables/useToast'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const booksStore = useBooksStore()
const toast = useToast()

const book = computed(() => booksStore.currentBook)
const reviews = ref([])
const isLoading = computed(() => booksStore.isLoading)
const isLoadingReviews = ref(false)
const bookId = computed(() => route.params.id)

const newReview = ref({ comentario: '', valoracion: 5 })
const editingReview = ref(null)
const editForm = ref({ comentario: '', valoracion: 5 })

const loadBook = async () => {
  try { await booksStore.getBook(bookId.value, { expand: 'id_creador' }) }
  catch (error) { console.error('Error cargando libro:', error) }
}

const loadReviews = async () => {
  try {
    isLoadingReviews.value = true
    const result = await listReviewsByBook(bookId.value, { perPage: 50, expand: 'autor' })
    reviews.value = result.items
  } catch (error) { console.error('Error cargando reseñas:', error) }
  finally { isLoadingReviews.value = false }
}

const getRatingStars = (rating) => '★'.repeat(rating) + '☆'.repeat(5 - rating)

const handleSubmitReview = async () => {
  if (!newReview.value.comentario.trim()) { toast.warning('Por favor escribe una reseña'); return; }
  try {
    await createReview({
      libro: bookId.value,
      autor: auth.currentUser.id,
      valoracion: newReview.value.valoracion,
      comentario: newReview.value.comentario
    });
    newReview.value.comentario = '';
    await loadReviews();
    toast.success('Reseña publicada correctamente');
  } catch (error) { toast.error('Error al publicar'); }
}

// LOGICA DE BORRADO DE LIBRO CORREGIDA
const handleDeleteBook = () => {
  toast.confirm(
    '¿Estás seguro de que quieres eliminar este libro?',
    async () => {
      try {
        await booksStore.deleteBook(bookId.value)
        toast.success('Libro eliminado correctamente')
        router.push('/') // Volver al inicio
      } catch (error) {
        console.error('Error eliminando libro:', error)
        toast.error('Error al eliminar el libro')
      }
    }
  )
}

const canEditReview = (review) => auth.currentUser?.id === review.autor
const canDeleteReview = (review) => canEditReview(review) || auth.isAdmin
const canEditBook = computed(() => auth.currentUser?.id === book.value?.id_creador)
const canDeleteBook = computed(() => canEditBook.value || auth.isAdmin)

const startEditReview = (review) => {
  editingReview.value = review.id
  editForm.value = { comentario: review.comentario, valoracion: review.valoracion }
}
const cancelEditReview = () => { editingReview.value = null }

const handleUpdateReview = async (reviewId) => {
  try {
    await updateReview(reviewId, { ...editForm.value })
    toast.success('Reseña actualizada');
    cancelEditReview();
    await loadReviews();
  } catch (error) { toast.error('Error al actualizar'); }
}

const handleDeleteReview = (reviewId) => {
  toast.confirm('¿Eliminar esta reseña?', async () => {
    try {
      await deleteReview(reviewId);
      toast.success('Reseña eliminada');
      await loadReviews();
    } catch (error) { toast.error('Error al eliminar'); }
  })
}

const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })
}

onMounted(async () => { await loadBook(); await loadReviews(); })
</script>

<template>
  <div v-if="isLoading" class="loading">Cargando libro...</div>
  <div v-else-if="!book" class="not-found">
    <h1>Libro no encontrado</h1>
    <router-link to="/" class="button button--primary">Volver al inicio</router-link>
  </div>

  <div v-else>
    <section class="book-detail">
      <div class="book-detail__cover">
        <img :src="book.portada" :alt="book.titulo" class="book-detail__image">
      </div>
      <div class="book-detail__info">
        <h1 class="book-detail__title">{{ book.titulo }}</h1>
        <h2 class="book-detail__author">por {{ book.autor }}</h2>
        <p class="book-detail__meta">
          <strong>Género:</strong> {{ book.genero }}
          <span v-if="book.fec_publicacion"> | <strong>Año:</strong> {{ new Date(book.fec_publicacion).getFullYear() }}</span>
        </p>
        <p class="book-detail__synopsis">{{ book.sinopsis }}</p>
        <div v-if="canEditBook || canDeleteBook" class="book-detail__actions">
          <button v-if="canEditBook" class="button button--primary" @click="router.push(`/book/${bookId}/edit`)">Editar Libro</button>
          <button v-if="canDeleteBook" class="button button--danger" @click="handleDeleteBook">Eliminar Libro</button>
        </div>
      </div>
    </section>

    <section class="review-section">
      <h2 class="review-section__title">Reseñas de los Lectores</h2>

      <form v-if="auth.isLoggedIn" class="review-form" @submit.prevent="handleSubmitReview">
        <h3 class="review-form__title">Deja tu opinión</h3>
        <textarea v-model="newReview.comentario" class="review-form__textarea" rows="4"></textarea>
        <div class="review-form__actions">
          <select v-model.number="newReview.valoracion" class="review-form__rating">
            <option v-for="n in 5" :key="n" :value="6-n">{{ getRatingStars(6-n) }}</option>
          </select>
          <button type="submit" class="button button--primary">Publicar Reseña</button>
        </div>
      </form>

      <div v-if="isLoadingReviews" class="loading">Cargando reseñas...</div>
      <div v-else-if="reviews.length === 0" class="no-reviews">No hay reseñas aún.</div>
      <div v-else class="review-list">
        <article v-for="review in reviews" :key="review.id" class="review-card">
          <template v-if="editingReview !== review.id">
            <div class="review-card__header">
              <div class="review-card__author-info">
                <div class="review-card__avatar-wrapper">
                  <img v-if="review.expand?.autor?.avatar" :src="review.expand.autor.avatar" class="review-card__avatar">
                  <div v-else class="review-card__avatar-placeholder">{{ (review.expand?.autor?.nombre_mostrado || 'U')[0] }}</div>
                </div>
                <span class="review-card__author">{{ review.expand?.autor?.nombre_mostrado || 'Usuario' }}</span>
              </div>
              <span class="review-card__rating">{{ getRatingStars(review.valoracion) }}</span>
            </div>
            <p class="review-card__comment">{{ review.comentario }}</p>
            <div class="review-card__footer">
              <small>{{ formatDate(review.created) }}</small>
              <div v-if="canEditReview(review) || canDeleteReview(review)" class="review-card__actions">
                <button v-if="canEditReview(review)" class="review-card__btn review-card__btn--edit" @click="startEditReview(review)">Editar</button>
                <button v-if="canDeleteReview(review)" class="review-card__btn review-card__btn--delete" @click="handleDeleteReview(review.id)">Eliminar</button>
              </div>
            </div>
          </template>
          <template v-else>
            <div class="review-edit">
              <textarea v-model="editForm.comentario" class="review-edit__textarea" rows="4"></textarea>
              <div class="review-edit__controls">
                <select v-model.number="editForm.valoracion" class="review-edit__rating">
                  <option v-for="n in 5" :key="n" :value="6-n">{{ getRatingStars(6-n) }}</option>
                </select>
                <div class="review-edit__buttons">
                  <button class="button button--primary button--small" @click="handleUpdateReview(review.id)">Guardar</button>
                  <button class="button button--secondary button--small" @click="cancelEditReview">Cancelar</button>
                </div>
              </div>
            </div>
          </template>
        </article>
      </div>
    </section>
  </div>
</template>

<style scoped>
.book-detail { display: grid; grid-template-columns: 1fr 2fr; gap: 2rem; background: var(--card-background); padding: 2rem; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); margin-bottom: 3rem; }
.book-detail__image { width: 100%; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
.book-detail__title { margin: 0; font-size: 2.5rem; color: var(--primary-color); }
.book-detail__author { margin: 0.5rem 0 1rem; font-size: 1.5rem; color: #555; font-weight: normal; }
.review-section { margin-top: 3rem; }
.review-section__title { border-bottom: 2px solid var(--border-color); padding-bottom: 0.5rem; color: var(--primary-color); font-size: 1.8rem; }
.review-form { background: #f9f9f9; padding: 1.5rem; border-radius: 8px; margin: 1.5rem 0; box-sizing: border-box; }
.review-form__textarea { width: 100%; padding: 0.8rem; border: 1px solid var(--border-color); border-radius: 5px; resize: vertical; box-sizing: border-box; }
.review-form__actions { display: flex; justify-content: space-between; align-items: center; margin-top: 1rem; gap: 1rem; }
.review-form__rating { padding: 0.5rem; border: 1px solid var(--border-color); border-radius: 5px; font-size: 1rem; }
.review-card { background: var(--card-background); padding: 1.5rem; border-radius: 8px; border-left: 5px solid var(--secondary-color); box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1.5rem; }
.review-card__header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.8rem; }
.review-card__author-info { display: flex; align-items: center; gap: 0.8rem; }
.review-card__avatar-wrapper { width: 40px; height: 40px; }
.review-card__avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
.review-card__avatar-placeholder { width: 40px; height: 40px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-weight: bold; }
.review-card__footer { display: flex; justify-content: space-between; align-items: center; margin-top: 1rem; padding-top: 0.8rem; border-top: 1px solid #e5e5e5; }
.review-card__btn { padding: 0.4rem 0.8rem; border: none; border-radius: 5px; font-size: 0.85rem; cursor: pointer; }
.review-card__btn--edit { background: #3b82f6; color: white; }
.review-card__btn--delete { background: #ef4444; color: white; }
</style>
