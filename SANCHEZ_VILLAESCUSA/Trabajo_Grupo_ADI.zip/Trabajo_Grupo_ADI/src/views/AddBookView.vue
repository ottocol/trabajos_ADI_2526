<!--
  AddBookView, formulario para añadir nuevos libros
  Permite a usuarios logeados añadir libros a la db
  Requiere título, autor, género, portada y sinopsis. ISBN y fecha son opcionales

  Variables reactivas:
  - formData: Campos del formulario (titulo, autor, genero, portada, etc.)
  - isSubmitting: Indica si se está enviando el formulario

  Métodos:
  - handleSubmit(): Crea el libro en la BD y redirige al home
  - handleCancel(): Cancela y vuelve al home sin guardar
-->
<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useBooksStore } from '@/stores/books'
import { useToast } from '@/composables/useToast'

const router = useRouter()
const auth = useAuthStore()
const booksStore = useBooksStore()
const toast = useToast()

const formData = ref({
  titulo: '',
  autor: '',
  genero: '',
  fec_publicacion: '',
  portada: '',
  isbn: '',
  sinopsis: ''
})

const isSubmitting = ref(false)

const handleSubmit = async () => {
  if (!auth.currentUser) {
    toast.warning('Debes iniciar sesión para añadir un libro')
    router.push('/login')
    return
  }

  try {
    isSubmitting.value = true

    const bookData = {
      titulo: formData.value.titulo,
      autor: formData.value.autor,
      genero: formData.value.genero,
      portada: formData.value.portada,
      sinopsis: formData.value.sinopsis,
      id_creador: auth.currentUser.id
    }

    // Campos opcionales
    if (formData.value.fec_publicacion) {
      bookData.fec_publicacion = formData.value.fec_publicacion
    }
    if (formData.value.isbn) {
      bookData.isbn = formData.value.isbn
    }

    await booksStore.createBook(bookData)
    toast.success('Libro añadido correctamente')
    router.push('/')
  } catch (error) {
    console.error('Error añadiendo libro:', error)
    toast.error('Error al añadir el libro: ' + (error.message || 'Error desconocido'))
  } finally {
    isSubmitting.value = false
  }
}

const handleCancel = () => {
  router.push('/')
}
</script>

<template>
  <section class="add-book-form">
    <h1 class="add-book-form__title">Añadir un nuevo libro</h1>

    <form class="form-layout" @submit.prevent="handleSubmit">
      <div class="form-layout__group">
        <label for="titulo" class="form-layout__label">Título del libro *</label>
        <input
          type="text"
          id="titulo"
          v-model="formData.titulo"
          class="form-layout__input"
          required
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="autor" class="form-layout__label">Autor *</label>
        <input
          type="text"
          id="autor"
          v-model="formData.autor"
          class="form-layout__input"
          required
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="genero" class="form-layout__label">Género *</label>
        <input
          type="text"
          id="genero"
          v-model="formData.genero"
          class="form-layout__input"
          required
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="isbn" class="form-layout__label">ISBN</label>
        <input
          type="text"
          id="isbn"
          v-model="formData.isbn"
          class="form-layout__input"
          placeholder="Ej: 9788497593796"
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="fec_publicacion" class="form-layout__label">Fecha de publicación</label>
        <input
          type="date"
          id="fec_publicacion"
          v-model="formData.fec_publicacion"
          class="form-layout__input"
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="portada" class="form-layout__label">URL de la portada *</label>
        <input
          type="url"
          id="portada"
          v-model="formData.portada"
          class="form-layout__input"
          placeholder="https://ejemplo.com/portada.jpg"
          required
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="sinopsis" class="form-layout__label">Sinopsis *</label>
        <textarea
          id="sinopsis"
          v-model="formData.sinopsis"
          class="form-layout__textarea"
          rows="6"
          required
          :disabled="isSubmitting"
        ></textarea>
      </div>

      <div class="form-layout__actions">
        <button type="submit" class="button button--primary" :disabled="isSubmitting">
          {{ isSubmitting ? 'Guardando...' : 'Guardar Libro' }}
        </button>
        <button
          type="button"
          class="button button--secondary"
          @click="handleCancel"
          :disabled="isSubmitting"
        >
          Cancelar
        </button>
      </div>
    </form>
  </section>
</template>

<style scoped>
.add-book-form__title {
    text-align: center;
    color: var(--primary-color);
    font-size: 2rem;
    margin-bottom: 2rem;
}

.form-layout {
    max-width: 700px;
    margin: 0 auto;
    background: var(--card-background);
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.form-layout__group {
    margin-bottom: 1.5rem;
}

.form-layout__label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: bold;
    color: var(--text-color);
}

.form-layout__input,
.form-layout__textarea {
    width: 100%;
    padding: 0.8rem;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    font-size: 1rem;
    box-sizing: border-box;
    font-family: inherit;
}

.form-layout__textarea {
    resize: vertical;
}

.form-layout__actions {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    margin-top: 2rem;
}

@media (max-width: 768px) {
    .form-layout {
        padding: 1.5rem;
    }

    .form-layout__actions {
        flex-direction: column;
    }
}
</style>
