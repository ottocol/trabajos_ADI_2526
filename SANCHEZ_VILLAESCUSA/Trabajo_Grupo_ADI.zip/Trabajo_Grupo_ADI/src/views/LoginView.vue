<!--
  LoginView, formulario de inicio de sesión
  Permite a los usuarios entrar con email y contraseña
  Muestra efecto temblor si las datos son incorrectas

  Variables reactivas:
  - email, password: Datos del usuario
  - errorMessage: Mensaje de error si falla el login
  - isLoading: Indica si se está procesando el login
  - showShake: Activa animación de temblor en error

  Métodos:
  - handleLogin(): Intenta autenticar al usuario, activa temblor si falla
-->
<script setup>
import { ref } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { useToast } from '@/composables/useToast'

const auth = useAuthStore()
const toast = useToast()
const email = ref('')
const password = ref('')
const errorMessage = ref(null)
const isLoading = ref(false)
const showShake = ref(false)

const handleLogin = async () => {
  errorMessage.value = null
  showShake.value = false
  isLoading.value = true

  try {
    const success = await auth.login(email.value, password.value)
    if (!success) {
      errorMessage.value = 'Email o contraseña incorrectos'
      showShake.value = true
      setTimeout(() => showShake.value = false, 500)
    } else {
      toast.success('¡Bienvenido de nuevo!')
    }
  } catch {
    errorMessage.value = 'Error al conectar con el servidor'
    showShake.value = true
    setTimeout(() => showShake.value = false, 500)
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <section class="login-section">
    <div class="login-container">
      <h1 class="login-container__title">Iniciar Sesión</h1>

      <form class="login-form" :class="{ 'shake': showShake }" @submit.prevent="handleLogin">
        <div class="login-form__field">
          <label for="email" class="login-form__label">Email:</label>
          <input
            type="email"
            id="email"
            v-model="email"
            class="login-form__input"
            required
            :disabled="isLoading"
          >
        </div>

        <div class="login-form__field">
          <label for="password" class="login-form__label">Contraseña:</label>
          <input
            type="password"
            id="password"
            v-model="password"
            class="login-form__input"
            required
            :disabled="isLoading"
          >
        </div>

        <div v-if="errorMessage" class="login-form__error">
          {{ errorMessage }}
        </div>

        <button type="submit" class="button button--primary login-form__submit" :disabled="isLoading">
          {{ isLoading ? 'Iniciando sesión...' : 'Iniciar Sesión' }}
        </button>
      </form>

      <p class="login-form__register-link">
        ¿No tienes cuenta?
        <router-link to="/register" class="login-form__link">Regístrate aquí</router-link>
      </p>

      <div class="login-info">
        <h3>Usuarios de prueba:</h3>
        <ul>
          <li><strong>Email:</strong> saul@example.com | <strong>Contraseña:</strong> saul1234</li>
          <li><strong>Email:</strong> fabian@example.com | <strong>Contraseña:</strong> fabian1234</li>
          <li><strong>Email:</strong> admin@example.com | <strong>Contraseña:</strong> admin1234</li>
        </ul>
      </div>
    </div>
  </section>
</template>

<style scoped>
.login-section {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 60vh;
}

.login-container {
    background: var(--card-background);
    padding: 3rem;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    max-width: 500px;
    width: 100%;
}

.login-container__title {
    text-align: center;
    color: var(--primary-color);
    margin-bottom: 2rem;
    font-size: 2rem;
}

.login-form__field {
    margin-bottom: 1.5rem;
}

.login-form__label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: bold;
    color: var(--text-color);
}

.login-form__input {
    width: 100%;
    padding: 0.8rem;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    font-size: 1rem;
    box-sizing: border-box;
}

.login-form__error {
    background: #ffe6e6;
    color: var(--danger-color);
    padding: 0.8rem;
    border-radius: 5px;
    margin-bottom: 1rem;
    border: 1px solid #ffb3b3;
}

.login-form__submit {
    width: 100%;
    margin-bottom: 1rem;
}

.login-form__register-link {
    text-align: center;
    color: #666;
    margin: 1rem 0;
    padding: 1rem;
    background: #f8f9fa;
    border-radius: 5px;
}

.login-form__link {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: bold;
}

.login-form__link:hover {
    text-decoration: underline;
}

.login-info {
    background: #f0f8ff;
    padding: 1.5rem;
    border-radius: 8px;
    margin-top: 2rem;
    border: 1px solid #cce7ff;
}

.login-info h3 {
    margin-top: 0;
    color: var(--primary-color);
    font-size: 1.1rem;
}

.login-info ul {
    list-style: none;
    padding: 0;
    margin: 0.5rem 0 0;
}

.login-info li {
    padding: 0.3rem 0;
    font-size: 0.9rem;
    color: #555;
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  10%, 30%, 50%, 70%, 90% { transform: translateX(-10px); }
  20%, 40%, 60%, 80% { transform: translateX(10px); }
}

.shake {
  animation: shake 0.5s ease-in-out;
}

@media (max-width: 768px) {
    .login-container {
        padding: 2rem;
    }
}
</style>
