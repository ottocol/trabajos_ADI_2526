<!--
  RegisterView, formulario de registro de nuevos usuarios
  Permite crear una cuenta nueva con email, contraseña y datos personales
  Valida que las contraseñas coincidan y tengan mínimo 8 caracteres
  Hace auto-login después de registrarse exitosamente

  Variables reactivas:
  - formData: Todos los campos del formulario (email, password, nombre, bio, etc)
  - errorMessage: Mensaje de error si falla el registro
  - isLoading: Indica si se está procesando el registro
  - passwordMismatch: Indica si las contraseñas no coinciden

  Métodos:
  - validatePasswords(): Comprueba que password y passwordConfirm sean iguales
  - handleRegister(): Crea la cuenta, hace login automático y redirige al home
-->
<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { register, login } from '@/services/auth'
import { useToast } from '@/composables/useToast'

const router = useRouter()
const toast = useToast()

const formData = ref({
  email: '',
  password: '',
  passwordConfirm: '',
  name: '',
  nombre_mostrado: '',
  bio: '',
  fecha_nacimiento: '',
  genero_fav: ''
})

const errorMessage = ref(null)
const isLoading = ref(false)
const passwordMismatch = ref(false)

const validatePasswords = () => {
  passwordMismatch.value = formData.value.password !== formData.value.passwordConfirm
}

const handleRegister = async () => {
  errorMessage.value = null

  // Validar que las contraseñas coincidan
  if (formData.value.password !== formData.value.passwordConfirm) {
    errorMessage.value = 'Las contraseñas no coinciden'
    passwordMismatch.value = true
    return
  }

  // Validar longitud mínima de contraseña
  if (formData.value.password.length < 8) {
    errorMessage.value = 'La contraseña debe tener al menos 8 caracteres'
    return
  }

  isLoading.value = true

  try {
    // Registrar usuario
    await register({
      email: formData.value.email,
      password: formData.value.password,
      passwordConfirm: formData.value.passwordConfirm,
      name: formData.value.name,
      nombre_mostrado: formData.value.nombre_mostrado || formData.value.name,
      bio: formData.value.bio,
      fecha_nacimiento: formData.value.fecha_nacimiento || null,
      genero_fav: formData.value.genero_fav
    })

    // Auto-login después del registro
    await login(formData.value.email, formData.value.password)

    toast.success('¡Cuenta creada exitosamente! Bienvenido')
    // Redirigir al home con recarga
    window.location.href = '/'
  } catch (error) {
    console.error('Error en registro:', error)

    // Manejar errores específicos de PocketBase
    if (error.data?.email) {
      errorMessage.value = 'Este email ya está registrado'
    } else if (error.data?.password) {
      errorMessage.value = 'La contraseña no cumple con los requisitos'
    } else {
      errorMessage.value = error.message || 'Error al registrar usuario. Inténtalo de nuevo.'
    }
  } finally {
    isLoading.value = false
  }
}

const handleCancel = () => {
  router.push('/login')
}
</script>

<template>
  <section class="register-section">
    <div class="register-container">
      <h1 class="register-container__title">Crear Cuenta</h1>
      <p class="register-container__subtitle">Únete a nuestra comunidad de lectores</p>

      <form class="register-form" @submit.prevent="handleRegister">
        <!-- Información de cuenta -->
        <fieldset class="register-form__fieldset">
          <legend class="register-form__legend">Información de Cuenta</legend>

          <div class="register-form__field">
            <label for="email" class="register-form__label">Email *</label>
            <input
              type="email"
              id="email"
              v-model="formData.email"
              class="register-form__input"
              required
              :disabled="isLoading"
              placeholder="tu@email.com"
            >
          </div>

          <div class="register-form__row">
            <div class="register-form__field">
              <label for="password" class="register-form__label">Contraseña *</label>
              <input
                type="password"
                id="password"
                v-model="formData.password"
                class="register-form__input"
                required
                minlength="8"
                :disabled="isLoading"
                @input="validatePasswords"
                placeholder="Mínimo 8 caracteres"
              >
            </div>

            <div class="register-form__field">
              <label for="passwordConfirm" class="register-form__label">Confirmar Contraseña *</label>
              <input
                type="password"
                id="passwordConfirm"
                v-model="formData.passwordConfirm"
                class="register-form__input"
                :class="{ 'register-form__input--error': passwordMismatch }"
                required
                minlength="8"
                :disabled="isLoading"
                @input="validatePasswords"
                placeholder="Repite la contraseña"
              >
            </div>
          </div>

          <p v-if="passwordMismatch" class="register-form__hint register-form__hint--error">
            Las contraseñas no coinciden
          </p>
        </fieldset>

        <!-- Información personal -->
        <fieldset class="register-form__fieldset">
          <legend class="register-form__legend">Información Personal</legend>

          <div class="register-form__field">
            <label for="name" class="register-form__label">Nombre Completo *</label>
            <input
              type="text"
              id="name"
              v-model="formData.name"
              class="register-form__input"
              required
              :disabled="isLoading"
              placeholder="Juan Pérez"
            >
          </div>

          <div class="register-form__field">
            <label for="nombre_mostrado" class="register-form__label">Nombre para Mostrar</label>
            <input
              type="text"
              id="nombre_mostrado"
              v-model="formData.nombre_mostrado"
              class="register-form__input"
              :disabled="isLoading"
              :placeholder="formData.name || 'JuanP'"
            >
            <p class="register-form__hint">
              Si lo dejas vacío, se usará tu nombre completo
            </p>
          </div>

          <div class="register-form__row">
            <div class="register-form__field">
              <label for="fecha_nacimiento" class="register-form__label">Fecha de Nacimiento</label>
              <input
                type="date"
                id="fecha_nacimiento"
                v-model="formData.fecha_nacimiento"
                class="register-form__input"
                :disabled="isLoading"
                :max="new Date().toISOString().split('T')[0]"
              >
            </div>

            <div class="register-form__field">
              <label for="genero_fav" class="register-form__label">Género Favorito</label>
              <input
                type="text"
                id="genero_fav"
                v-model="formData.genero_fav"
                class="register-form__input"
                :disabled="isLoading"
                placeholder="Ciencia Ficción, Terror..."
              >
            </div>
          </div>

          <div class="register-form__field">
            <label for="bio" class="register-form__label">Biografía</label>
            <textarea
              id="bio"
              v-model="formData.bio"
              class="register-form__textarea"
              rows="4"
              :disabled="isLoading"
              placeholder="Cuéntanos sobre tus gustos de lectura..."
            ></textarea>
          </div>
        </fieldset>

        <div v-if="errorMessage" class="register-form__error">
          {{ errorMessage }}
        </div>

        <div class="register-form__actions">
          <button type="submit" class="button button--primary" :disabled="isLoading || passwordMismatch">
            {{ isLoading ? 'Creando cuenta...' : 'Crear Cuenta' }}
          </button>
          <button
            type="button"
            class="button button--secondary"
            @click="handleCancel"
            :disabled="isLoading"
          >
            Cancelar
          </button>
        </div>

        <p class="register-form__login-link">
          ¿Ya tienes cuenta?
          <router-link to="/login" class="register-form__link">Inicia sesión aquí</router-link>
        </p>
      </form>
    </div>
  </section>
</template>

<style scoped>
.register-section {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 80vh;
    padding: 2rem 1rem;
}

.register-container {
    background: var(--card-background);
    padding: 3rem;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    max-width: 800px;
    width: 100%;
}

.register-container__title {
    text-align: center;
    color: var(--primary-color);
    margin-bottom: 0.5rem;
    font-size: 2.5rem;
}

.register-container__subtitle {
    text-align: center;
    color: #666;
    margin-bottom: 2rem;
    font-size: 1.1rem;
}

.register-form__fieldset {
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 1.5rem;
    margin-bottom: 2rem;
}

.register-form__legend {
    font-size: 1.2rem;
    font-weight: bold;
    color: var(--primary-color);
    padding: 0 0.5rem;
}

.register-form__field {
    margin-bottom: 1.5rem;
}

.register-form__row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.register-form__label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: bold;
    color: var(--text-color);
}

.register-form__input,
.register-form__textarea {
    width: 100%;
    padding: 0.8rem;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    font-size: 1rem;
    box-sizing: border-box;
    transition: border-color 0.3s ease;
}

.register-form__input:focus,
.register-form__textarea:focus {
    outline: none;
    border-color: var(--primary-color);
}

.register-form__input--error {
    border-color: var(--danger-color);
}

.register-form__textarea {
    resize: vertical;
    font-family: inherit;
}

.register-form__hint {
    font-size: 0.85rem;
    color: #666;
    margin-top: 0.3rem;
    font-style: italic;
}

.register-form__hint--error {
    color: var(--danger-color);
    font-style: normal;
}

.register-form__error {
    background: #ffe6e6;
    color: var(--danger-color);
    padding: 1rem;
    border-radius: 5px;
    margin-bottom: 1.5rem;
    border: 1px solid #ffb3b3;
    text-align: center;
}

.register-form__actions {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.register-form__actions button {
    flex: 1;
}

.register-form__login-link {
    text-align: center;
    color: #666;
    margin: 0;
}

.register-form__link {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: bold;
}

.register-form__link:hover {
    text-decoration: underline;
}

@media (max-width: 768px) {
    .register-container {
        padding: 2rem 1.5rem;
    }

    .register-form__row {
        grid-template-columns: 1fr;
    }

    .register-form__actions {
        flex-direction: column;
    }
}
</style>
