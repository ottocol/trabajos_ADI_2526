<!--
  EditBookView, formulario para editar libros
  Permite al creador del libro (no al admin) editar su informacin
  Pre-carga los datos actuales y verifica permisos antes de mostrar el formulario

  Variables reactivas:
  - formData: Campos del formulario con los datos actuales del libro
  - isLoading: Indica si se está cargando el libro
  - isSubmitting: Indica si se está guardando los cambios
  - errorMessage: Mensaje de error si falla carga o guardado
  - originalBook: Copia del libro original para referencia

  Métodos:
  - loadBook(): Carga los datos del libro y verifica permisos del usuario
  - handleSubmit(): Guarda los cambios y redirige a la página del libro
  - handleCancel(): Cancela edición y vuelve a la página del libro
-->
<script setup>
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useBooksStore } from '@/stores/books'
import { useToast } from '@/composables/useToast'

const router = useRouter()
const route = useRoute()
const auth = useAuthStore()
const booksStore = useBooksStore()
const toast = useToast()

const bookId = route.params.id

const formData = ref({
  titulo: '',
  autor: '',
  genero: '',
  fec_publicacion: '',
  portada: '',
  isbn: '',
  sinopsis: ''
})

const isLoading = ref(true)
const isSubmitting = ref(false)
const errorMessage = ref(null)
const originalBook = ref(null)

const loadBook = async () => {
  if (!auth.currentUser) {
    router.push('/login')
    return
  }

  try {
    isLoading.value = true
    const book = await booksStore.getBook(bookId)

    // Verificar que el usuario sea el creador del libro o sea admin
    if (book.id_creador !== auth.currentUser.id && !auth.isAdmin) {
      errorMessage.value = 'No tienes permisos para editar este libro'
      setTimeout(() => router.push(`/book/${bookId}`), 2000)
      return
    }

    originalBook.value = book

    // Cargar datos en el formulario
    formData.value = {
      titulo: book.titulo || '',
      autor: book.autor || '',
      genero: book.genero || '',
      fec_publicacion: book.fec_publicacion ? book.fec_publicacion.slice(0, 10) : '',
      portada: book.portada || '',
      isbn: book.isbn || '',
      sinopsis: book.sinopsis || ''
    }
  } catch (error) {
    console.error('Error cargando libro:', error)
    errorMessage.value = 'Error al cargar el libro'
    setTimeout(() => router.push('/'), 2000)
  } finally {
    isLoading.value = false
  }
}

const handleSubmit = async () => {
  errorMessage.value = null

  try {
    isSubmitting.value = true

    const updateData = {
      titulo: formData.value.titulo,
      autor: formData.value.autor,
      genero: formData.value.genero,
      portada: formData.value.portada,
      sinopsis: formData.value.sinopsis
    }

    // Campos opcionales
    if (formData.value.fec_publicacion) {
      updateData.fec_publicacion = formData.value.fec_publicacion
    }
    if (formData.value.isbn) {
      updateData.isbn = formData.value.isbn
    }

    await booksStore.updateBook(bookId, updateData)

    toast.success('Libro actualizado correctamente')
    // Redirigir a la página del libro
    router.push(`/book/${bookId}`)
  } catch (error) {
    console.error('Error actualizando libro:', error)
    errorMessage.value = 'Error al actualizar el libro: ' + (error.message || 'Error desconocido')
    toast.error('Error al actualizar el libro')
  } finally {
    isSubmitting.value = false
  }
}

const handleCancel = () => {
  router.push(`/book/${bookId}`)
}

onMounted(() => {
  loadBook()
})
</script>

<template>
  <section v-if="isLoading" class="loading">
    <p>Cargando libro...</p>
  </section>

  <section v-else-if="errorMessage && !originalBook" class="error-section">
    <div class="error-message">
      <h2>Error</h2>
      <p>{{ errorMessage }}</p>
    </div>
  </section>

  <section v-else class="edit-book-form">
    <h1 class="edit-book-form__title">Editar Libro</h1>
    <p class="edit-book-form__subtitle">Modifica los datos del libro "{{ originalBook?.titulo }}"</p>

    <form class="form-layout" @submit.prevent="handleSubmit">
      <div v-if="errorMessage" class="form-layout__error">
        {{ errorMessage }}
      </div>

      <div class="form-layout__group">
        <label for="titulo" class="form-layout__label">Título del libro *</label>
        <input
          type="text"
          id="titulo"
          v-model="formData.titulo"
          class="form-layout__input"
          required
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="autor" class="form-layout__label">Autor *</label>
        <input
          type="text"
          id="autor"
          v-model="formData.autor"
          class="form-layout__input"
          required
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="genero" class="form-layout__label">Género *</label>
        <input
          type="text"
          id="genero"
          v-model="formData.genero"
          class="form-layout__input"
          required
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="isbn" class="form-layout__label">ISBN</label>
        <input
          type="text"
          id="isbn"
          v-model="formData.isbn"
          class="form-layout__input"
          placeholder="Ej: 9788497593796"
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="fec_publicacion" class="form-layout__label">Fecha de publicación</label>
        <input
          type="date"
          id="fec_publicacion"
          v-model="formData.fec_publicacion"
          class="form-layout__input"
          :disabled="isSubmitting"
        >
      </div>

      <div class="form-layout__group">
        <label for="portada" class="form-layout__label">URL de la portada *</label>
        <input
          type="url"
          id="portada"
          v-model="formData.portada"
          class="form-layout__input"
          placeholder="https://ejemplo.com/portada.jpg"
          required
          :disabled="isSubmitting"
        >
        <div v-if="formData.portada" class="form-layout__preview">
          <img :src="formData.portada" alt="Vista previa" class="form-layout__preview-image">
        </div>
      </div>

      <div class="form-layout__group">
        <label for="sinopsis" class="form-layout__label">Sinopsis *</label>
        <textarea
          id="sinopsis"
          v-model="formData.sinopsis"
          class="form-layout__textarea"
          rows="6"
          required
          :disabled="isSubmitting"
        ></textarea>
      </div>

      <div class="form-layout__actions">
        <button type="submit" class="button button--primary" :disabled="isSubmitting">
          {{ isSubmitting ? 'Guardando cambios...' : 'Guardar Cambios' }}
        </button>
        <button
          type="button"
          class="button button--secondary"
          @click="handleCancel"
          :disabled="isSubmitting"
        >
          Cancelar
        </button>
      </div>
    </form>
  </section>
</template>

<style scoped>
.loading,
.error-section {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 60vh;
    text-align: center;
}

.error-message {
    background: #ffe6e6;
    color: var(--danger-color);
    padding: 2rem;
    border-radius: 8px;
    border: 1px solid #ffb3b3;
    max-width: 500px;
}

.error-message h2 {
    margin-top: 0;
}

.edit-book-form__title {
    text-align: center;
    color: var(--primary-color);
    font-size: 2rem;
    margin-bottom: 0.5rem;
}

.edit-book-form__subtitle {
    text-align: center;
    color: #666;
    font-size: 1.1rem;
    margin-bottom: 2rem;
}

.form-layout {
    max-width: 700px;
    margin: 0 auto;
    background: var(--card-background);
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.form-layout__error {
    background: #ffe6e6;
    color: var(--danger-color);
    padding: 1rem;
    border-radius: 5px;
    margin-bottom: 1.5rem;
    border: 1px solid #ffb3b3;
}

.form-layout__group {
    margin-bottom: 1.5rem;
}

.form-layout__label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: bold;
    color: var(--text-color);
}

.form-layout__input,
.form-layout__textarea {
    width: 100%;
    padding: 0.8rem;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    font-size: 1rem;
    box-sizing: border-box;
    font-family: inherit;
}

.form-layout__textarea {
    resize: vertical;
}

.form-layout__preview {
    margin-top: 1rem;
    text-align: center;
}

.form-layout__preview-image {
    max-width: 200px;
    max-height: 300px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.form-layout__actions {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    margin-top: 2rem;
}

@media (max-width: 768px) {
    .form-layout {
        padding: 1.5rem;
    }

    .form-layout__actions {
        flex-direction: column;
    }
}
</style>
