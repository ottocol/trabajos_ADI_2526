/**
 * Store de autenticación, gestiona el usuario logueado
 *
 * Estado:
 * - currentUser: Datos del usuario logeado (null si no hay)
 *
 * Computed:
 * - isLoggedIn: true si hay un usuario autenticado
 * - isAdmin: true si el usuario tiene es_admin = true
 *
 * Acciones:
 * - login(email, password): inicia sesión y redirige al home
 * - logout(): cierra sesión y redirige al login
 * - init(): intenta refrescar la sesión al iniciar la app
 */
import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { useRouter } from 'vue-router'
import { login as loginWithFirebase, logout as logoutFirebase, getCurrentUser, isAuthenticated, refreshAuth, waitForAuth } from '@/services/auth'

export const useAuthStore = defineStore('auth', () => {
  const router = useRouter()

  // Estado: usuario actual logeado
  const currentUser = ref(null)

  // Computed: verifica si hay sesión activa
  const isLoggedIn = computed(() => !!currentUser.value && isAuthenticated())

  // Computed: verifica si el usuario es administrador
  const isAdmin = computed(() => {
    return !!currentUser.value && currentUser.value.es_admin === true
  })

  /**
   * Inicia sesión con email y contraseña
   * @param {string} email - Email del usuario
   * @param {string} password - Contraseña del usuario
   * @returns {boolean} true si el login fue exitoso, sino false
   */
  async function login(email, password) {
    try {
      await loginWithFirebase(email, password)
      currentUser.value = getCurrentUser()
      await router.push('/')
      return true
    } catch (err) {
      console.error('Login failed', err)
      return false
    }
  }

  /**
   * Intenta refrescar la sesión al iniciar la app y mantiene la sesion activa si el token esta bien
   */
  async function init() {
    try {
      // Esperar a que Firebase Auth esté inicializado
      await waitForAuth()
      if (isAuthenticated()) {
        await refreshAuth()
        currentUser.value = getCurrentUser()
      }
    } catch {
      // Ignorar errores de refresco
    }
  }

  /**
   * cierra sesion y te lleva al login
   */
  async function logout() {
    await logoutFirebase()
    currentUser.value = null
    await router.push('/login')
  }

  return { currentUser, isLoggedIn, isAdmin, login, logout, init }
})
