import { defineStore } from 'pinia';
import * as booksService from '@/services/books';

export const useBooksStore = defineStore('books', {
  state: () => ({
    books: [],
    currentBook: null,
    isLoading: false,
    error: null,
    currentPage: 1,
    totalPages: 0,
    totalItems: 0,
    perPage: 10
  }),

  actions: {
    async loadBooks({ page = 1, perPage = 10 } = {}) {
      try {
        this.isLoading = true;
        const result = await booksService.listBooks({ page, perPage });
        this.books = result.items;
        this.totalItems = result.totalItems;
        this.totalPages = result.totalPages;
        this.currentPage = page;
      } catch (error) {
        this.error = error.message;
      } finally {
        this.isLoading = false;
      }
    },

    /**
     * Acción para cargar solo los libros del usuario
     */
    async loadUserBooks(userId) {
      try {
        this.isLoading = true;
        return await booksService.listBooksByUser(userId);
      } catch (error) {
        console.error('Error cargando libros del usuario:', error);
        return [];
      } finally {
        this.isLoading = false;
      }
    },

    async searchBooks(query) {
      try {
        this.isLoading = true;
        this.books = await booksService.searchBooks(query);
        this.totalPages = 1;
        this.currentPage = 1;
      } finally {
        this.isLoading = false;
      }
    },

    async getBook(id) {
      try {
        this.isLoading = true;
        this.currentBook = await booksService.getBook(id);
        return this.currentBook;
      } finally {
        this.isLoading = false;
      }
    },

    async updateBook(id, bookData) {
      try {
        this.isLoading = true;
        const updatedBook = await booksService.updateBook(id, bookData);
        // Actualizar en la lista local si existe
        const index = this.books.findIndex(b => b.id === id);
        if (index !== -1) {
          this.books[index] = { ...this.books[index], ...updatedBook };
        }
        // Actualizar currentBook si es el mismo
        if (this.currentBook?.id === id) {
          this.currentBook = { ...this.currentBook, ...updatedBook };
        }
        return updatedBook;
      } finally {
        this.isLoading = false;
      }
    },

    async deleteBook(id) {
      await booksService.deleteBook(id);
      this.books = this.books.filter(b => b.id !== id);
    },

    async createBook(bookData) {
      try {
        this.isLoading = true;
        const newBook = await booksService.createBook(bookData);
        this.books.unshift(newBook);
        return newBook;
      } finally {
        this.isLoading = false;
      }
    }
  }
});
