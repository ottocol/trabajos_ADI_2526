import {
  collection, doc, getDocs, getDoc, addDoc, updateDoc, deleteDoc,
  query, where, orderBy, Timestamp, getCountFromServer
} from 'firebase/firestore';
import { db } from './firebase';

const COLLECTION = 'libros';

/**
 * Helper para convertir Timestamp de Firestore a string de fecha
 */
function timestampToDateString(value) {
  if (!value) return null;
  // Si tiene método toDate (Timestamp de Firestore)
  if (typeof value.toDate === 'function') {
    return value.toDate().toISOString().slice(0, 10);
  }
  // Si tiene seconds (objeto Timestamp serializado)
  if (value.seconds !== undefined) {
    return new Date(value.seconds * 1000).toISOString().slice(0, 10);
  }
  // Si ya es string, devolverlo
  if (typeof value === 'string') {
    return value.slice(0, 10);
  }
  return null;
}

// Paginación general para el Inicio
export async function listBooks({ page = 1, perPage = 10 } = {}) {
  const booksRef = collection(db, COLLECTION);
  const countSnapshot = await getCountFromServer(booksRef);
  const totalItems = countSnapshot.data().count;

  const q = query(booksRef, orderBy('created', 'desc'));
  const snapshot = await getDocs(q);

  const allItems = snapshot.docs.map(doc => {
    const data = doc.data();
    return {
      id: doc.id,
      ...data,
      created: data.created?.toDate?.()?.toISOString() || data.created,
      fec_publicacion: timestampToDateString(data.fec_publicacion)
    };
  });

  const start = (page - 1) * perPage;
  const items = allItems.slice(start, start + perPage);

  return { items, totalItems, totalPages: Math.ceil(totalItems / perPage) };
}

/**
 * NUEVA FUNCIÓN: Lista solo los libros de un usuario específico
 * IMPORTANTE: Esto puede requerir un índice compuesto en Firebase:
 * id_creador (Ascendente) + created (Descendente)
 */
export async function listBooksByUser(userId) {
  const booksRef = collection(db, COLLECTION);
  const q = query(
    booksRef,
    where('id_creador', '==', userId),
    orderBy('created', 'desc')
  );

  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => {
    const data = doc.data();
    return {
      id: doc.id,
      ...data,
      created: data.created?.toDate?.()?.toISOString() || data.created,
      fec_publicacion: timestampToDateString(data.fec_publicacion)
    };
  });
}

// ... (Resto de funciones: searchBooks, getBook, createBook, updateBook, deleteBook se mantienen igual)
export async function searchBooks(searchTerm) {
  const booksRef = collection(db, COLLECTION);
  const snapshot = await getDocs(query(booksRef, orderBy('created', 'desc')));
  const term = searchTerm.toLowerCase();
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
    .filter(book => book.titulo?.toLowerCase().includes(term) || book.autor?.toLowerCase().includes(term));
}

export async function getBook(id) {
  const docRef = doc(db, COLLECTION, id);
  const snap = await getDoc(docRef);
  if (!snap.exists()) throw new Error('Libro no encontrado');
  const data = snap.data();
  return {
    id: snap.id,
    ...data,
    fec_publicacion: timestampToDateString(data.fec_publicacion)
  };
}

export async function createBook(data) {
  const bookData = { ...data, created: Timestamp.now() };

  // Convertir fec_publicacion a Timestamp si existe
  if (bookData.fec_publicacion && typeof bookData.fec_publicacion === 'string') {
    bookData.fec_publicacion = Timestamp.fromDate(new Date(bookData.fec_publicacion));
  }

  const docRef = await addDoc(collection(db, COLLECTION), bookData);
  return { id: docRef.id, ...bookData };
}

export async function updateBook(id, data) {
  const docRef = doc(db, COLLECTION, id);

  // Convertir fec_publicacion a Timestamp si existe
  const updateData = { ...data };
  if (updateData.fec_publicacion && typeof updateData.fec_publicacion === 'string') {
    updateData.fec_publicacion = Timestamp.fromDate(new Date(updateData.fec_publicacion));
  }

  await updateDoc(docRef, updateData);
  return { id, ...data };
}

export async function deleteBook(id) {
  await deleteDoc(doc(db, COLLECTION, id));
  return true;
}
