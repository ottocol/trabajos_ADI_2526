import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc,
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy,
  Timestamp 
} from 'firebase/firestore';
import { updatePassword, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth';
import { db, auth } from './firebase';

const COLLECTION = 'usuarios';

/**
 * Helper para convertir Timestamp de Firestore a string ISO
 */
function timestampToString(timestamp) {
  if (!timestamp) return null;
  if (timestamp.toDate) {
    return timestamp.toDate().toISOString().slice(0, 10);
  }
  return timestamp;
}

/**
 * Helper para convertir documento Firestore a objeto con id
 * Convierte Timestamps a strings de fecha
 */
function docToUser(docSnap) {
  const data = docSnap.data();
  return { 
    id: docSnap.id, 
    ...data,
    creado: timestampToString(data.creado),
    fecha_nac: timestampToString(data.fecha_nac)
  };
}

/**
 * Lista todos los usuarios con paginación, filtros y ordenación
 * @param {Object} options - Opciones de listado
 * @returns {Promise<Object>} Resultado paginado con items, page, perPage, totalItems, totalPages
 */
export async function listUsers({ page = 1, perPage = 30, filter = '', sort = '-created' } = {}) {
  const usersRef = collection(db, COLLECTION);
  const q = query(usersRef, orderBy('creado', 'desc'));
  const snapshot = await getDocs(q);
  
  const items = snapshot.docs.map(docToUser);
  
  return {
    page,
    perPage,
    totalItems: items.length,
    totalPages: 1,
    items: items.slice(0, perPage)
  };
}

/**
 * Obtiene todos los usuarios sin paginación
 * @param {Object} options - Opciones de listado
 * @returns {Promise<Array>} Array con todos los usuarios
 */
export async function getAllUsers({ filter = '', sort = '-created' } = {}) {
  const usersRef = collection(db, COLLECTION);
  const q = query(usersRef, orderBy('creado', 'desc'));
  const snapshot = await getDocs(q);
  
  return snapshot.docs.map(docToUser);
}

/**
 * Busca usuarios por nombre, email o nombre mostrado
 * @param {string} searchText - Texto a buscar
 * @param {Object} options - Opciones adicionales
 * @returns {Promise<Object>} Resultado paginado
 */
export async function searchUsers(searchText, { page = 1, perPage = 30 } = {}) {
  if (!searchText || searchText.trim() === '') {
    return listUsers({ page, perPage });
  }
  
  const allUsers = await getAllUsers();
  const searchTerm = searchText.trim().toLowerCase();
  
  const filteredUsers = allUsers.filter(user => {
    const nombre = (user.nombre || '').toLowerCase();
    const email = (user.email || '').toLowerCase();
    const nomMostrado = (user.nom_mostrado || '').toLowerCase();
    
    return nombre.includes(searchTerm) || 
           email.includes(searchTerm) || 
           nomMostrado.includes(searchTerm);
  });
  
  return {
    page,
    perPage,
    totalItems: filteredUsers.length,
    totalPages: 1,
    items: filteredUsers.slice(0, perPage)
  };
}

/**
 * Obtiene un usuario específico por su ID
 * @param {string} id - ID del usuario
 * @param {Object} options - Opciones adicionales
 * @returns {Promise<Object>} Objeto usuario
 */
export async function getUser(id, options = {}) {
  const docRef = doc(db, COLLECTION, id);
  const docSnap = await getDoc(docRef);
  
  if (!docSnap.exists()) {
    throw new Error('Usuario no encontrado');
  }
  
  return docToUser(docSnap);
}

/**
 * Crea un nuevo usuario (para uso administrativo)
 * Nota: Para registro normal, usar la función register() del servicio auth.js
 * @param {Object} userData - Datos del usuario
 * @returns {Promise<Object>} Usuario creado
 */
export async function createUser(userData) {
  const userDocData = {
    email: userData.email,
    nombre: userData.nombre || '',
    nom_mostrado: userData.nom_mostrado || '',
    bio: userData.bio || '',
    fecha_nac: userData.fecha_nac ? Timestamp.fromDate(new Date(userData.fecha_nac)) : null,
    genero_fav: userData.genero_fav || '',
    avatar: '',
    es_admin: false,
    creado: Timestamp.now()
  };
  
  // Si se proporciona un ID específico, usarlo
  if (userData.id) {
    await setDoc(doc(db, COLLECTION, userData.id), userDocData);
    return { id: userData.id, ...userDocData };
  }
  
  // Si no, crear con ID automático (aunque esto no es lo típico para usuarios)
  const docRef = doc(collection(db, COLLECTION));
  await setDoc(docRef, userDocData);
  return { id: docRef.id, ...userDocData };
}

/**
 * Actualiza un usuario existente
 * @param {string} id - ID del usuario
 * @param {Object} data - Datos a actualizar
 * @returns {Promise<Object>} Usuario actualizado
 */
export async function updateUser(id, data) {
  const docRef = doc(db, COLLECTION, id);
  
  const updateData = { ...data };
  if (data.fecha_nac) {
    updateData.fecha_nac = Timestamp.fromDate(new Date(data.fecha_nac));
  }
  
  await updateDoc(docRef, updateData);
  
  const updatedDoc = await getDoc(docRef);
  return docToUser(updatedDoc);
}

/**
 * Elimina un usuario por su ID
 * @param {string} id - ID del usuario
 * @returns {Promise<boolean>} true si se eliminó correctamente
 */
export async function deleteUser(id) {
  const docRef = doc(db, COLLECTION, id);
  await deleteDoc(docRef);
  return true;
}

/**
 * Cambia la contraseña de un usuario
 * @param {string} id - ID del usuario
 * @param {string} oldPassword - Contraseña actual
 * @param {string} password - Nueva contraseña
 * @param {string} passwordConfirm - Confirmación de nueva contraseña
 * @returns {Promise<boolean>} true si se cambió correctamente
 */
export async function changePassword(id, oldPassword, password, passwordConfirm) {
  if (password !== passwordConfirm) {
    throw new Error('Las contraseñas no coinciden');
  }
  
  const user = auth.currentUser;
  if (!user || user.uid !== id) {
    throw new Error('No autorizado para cambiar esta contraseña');
  }
  
  // Reautenticar al usuario antes de cambiar la contraseña
  const credential = EmailAuthProvider.credential(user.email, oldPassword);
  await reauthenticateWithCredential(user, credential);
  
  // Cambiar la contraseña
  await updatePassword(user, password);
  
  return true;
}
