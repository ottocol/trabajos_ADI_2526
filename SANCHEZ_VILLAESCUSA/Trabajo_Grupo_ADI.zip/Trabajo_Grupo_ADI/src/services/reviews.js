import { 
  collection, doc, getDocs, getDoc, addDoc, updateDoc, deleteDoc, 
  query, where, orderBy, Timestamp 
} from 'firebase/firestore';
import { db } from './firebase';

const COLLECTION = 'resenas';

function timestampToString(timestamp) {
  if (!timestamp) return null;
  return timestamp.toDate ? timestamp.toDate().toISOString() : timestamp;
}

function docToReview(docSnap) {
  const data = docSnap.data();
  return { 
    id: docSnap.id, 
    ...data,
    created: timestampToString(data.created)
  };
}

// Lista reseñas de un libro (para BookDetail)
export async function listReviewsByBook(bookId, { page = 1, perPage = 30, expand = null } = {}) {
  const reviewsRef = collection(db, COLLECTION);
  const q = query(reviewsRef, where('libro', '==', bookId), orderBy('created', 'desc'));
  const snapshot = await getDocs(q);
  let items = snapshot.docs.map(docToReview);

  if (expand === 'autor') {
    items = await Promise.all(items.map(async (review) => {
      if (review.autor) {
        try {
          const userDoc = await getDoc(doc(db, 'usuarios', review.autor));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            return {
              ...review,
              expand: { 
                autor: { 
                  id: userDoc.id, 
                  ...userData,
                  nombre_mostrado: userData.nom_mostrado || userData.nombre 
                } 
              }
            };
          }
        } catch (e) { console.error("Error cargando autor:", e); }
      }
      return { ...review, expand: { autor: null } };
    }));
  }
  return { page, perPage, items: items.slice(0, perPage) };
}

// NUEVA FUNCIÓN: Lista reseñas de un usuario (para Profile)
// Corrige el error "doesn't provide an export named: 'listReviewsByUser'"
export async function listReviewsByUser(userId, { page = 1, perPage = 30, expand = null } = {}) {
  const reviewsRef = collection(db, COLLECTION);
  // REQUIERE ÍNDICE: autor (ASC) + created (DESC)
  const q = query(reviewsRef, where('autor', '==', userId), orderBy('created', 'desc'));
  const snapshot = await getDocs(q);
  let items = snapshot.docs.map(docToReview);

  if (expand === 'libro') {
    items = await Promise.all(items.map(async (review) => {
      if (review.libro) {
        try {
          const bookDoc = await getDoc(doc(db, 'libros', review.libro));
          if (bookDoc.exists()) {
            return { 
              ...review, 
              expand: { libro: { id: bookDoc.id, ...bookDoc.data() } } 
            };
          }
        } catch (e) { console.error("Error expandiendo libro:", e); }
      }
      return { ...review, expand: { libro: null } };
    }));
  }
  return { page, perPage, items: items.slice(0, perPage) };
}

export async function createReview(data) {
  const docRef = await addDoc(collection(db, COLLECTION), { ...data, created: Timestamp.now() });
  return { id: docRef.id, ...data };
}

export async function deleteReview(id) {
  const docRef = doc(db, COLLECTION, id);
  await deleteDoc(docRef);
  return true;
}

export async function updateReview(id, data) {
  const docRef = doc(db, COLLECTION, id);
  await updateDoc(docRef, { ...data, editado: true });
  const snap = await getDoc(docRef);
  return docToReview(snap);
}