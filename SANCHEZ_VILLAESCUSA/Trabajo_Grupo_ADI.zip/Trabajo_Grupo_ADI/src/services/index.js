/**
 * Índice centralizado de servicios
 * Exporta todas las funciones de la capa de servicios para facilitar imports
 */

// Autenticación
export {
  login,
  logout,
  register,
  isAuthenticated,
  getCurrentUser,
  refreshAuth,
  requestVerification,
  requestPasswordReset,
  confirmPasswordReset
} from './auth';

// Usuarios
export {
  listUsers,
  getAllUsers,
  searchUsers,
  getUser,
  createUser,
  updateUser,
  deleteUser,
  changePassword
} from './users';

// Libros
export {
  listBooks,
  getAllBooks,
  searchBooks,
  searchBooksByGenre,
  searchBooksByAuthor,
  getBook,
  createBook,
  updateBook,
  deleteBook
} from './books';

// Reseñas
export {
  listReviews,
  listReviewsByBook,
  listReviewsByUser,
  searchReviews,
  listReviewsByRating,
  getReview,
  createReview,
  updateReview,
  deleteReview
} from './reviews';

// Firebase (para casos avanzados)
export { auth, db } from './firebase';
