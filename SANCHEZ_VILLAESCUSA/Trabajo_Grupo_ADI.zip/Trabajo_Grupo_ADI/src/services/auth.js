import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail
} from 'firebase/auth';
import { doc, setDoc, getDoc, Timestamp } from 'firebase/firestore';
import { auth, db } from './firebase';

const COLLECTION = 'usuarios';

// Estado interno para el usuario actual (sincronizado con onAuthStateChanged)
let currentUserData = null;
let authInitialized = false;
let authInitPromise = null;

/**
 * Helper para convertir Timestamp de Firestore a string ISO
 */
function timestampToString(timestamp) {
  if (!timestamp) return null;
  if (timestamp.toDate) {
    return timestamp.toDate().toISOString().slice(0, 10);
  }
  return timestamp;
}

/**
 * Helper para procesar datos de usuario y convertir Timestamps
 */
function processUserData(data) {
  return {
    ...data,
    creado: timestampToString(data.creado),
    fecha_nac: timestampToString(data.fecha_nac)
  };
}

/**
 * Inicializa el listener de autenticación
 * @returns {Promise<Object|null>} Usuario actual o null
 */
function initAuthListener() {
  if (authInitPromise) return authInitPromise;

  authInitPromise = new Promise((resolve) => {
    onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // Obtener datos adicionales del usuario desde Firestore
        const userDoc = await getDoc(doc(db, COLLECTION, firebaseUser.uid));
        if (userDoc.exists()) {
          currentUserData = {
            id: firebaseUser.uid,
            email: firebaseUser.email,
            ...processUserData(userDoc.data())
          };
        } else {
          currentUserData = {
            id: firebaseUser.uid,
            email: firebaseUser.email
          };
        }
      } else {
        currentUserData = null;
      }
      authInitialized = true;
      resolve(currentUserData);
    });
  });

  return authInitPromise;
}

// Iniciar el listener al cargar el módulo
initAuthListener();

/**
 * Espera a que la autenticación esté inicializada
 * @returns {Promise<void>}
 */
export async function waitForAuth() {
  if (authInitialized) return;
  await initAuthListener();
}

/**
 * Inicia sesión con email y contraseña
 * @param {string} email - Email del usuario
 * @param {string} password - Contraseña del usuario
 * @returns {Promise<Object>} Datos de autenticación { token, record }
 */
export async function login(email, password) {
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  const firebaseUser = userCredential.user;

  // Obtener datos adicionales del usuario desde Firestore
  const userDoc = await getDoc(doc(db, COLLECTION, firebaseUser.uid));
  const userData = userDoc.exists() ? processUserData(userDoc.data()) : {};

  currentUserData = {
    id: firebaseUser.uid,
    email: firebaseUser.email,
    ...userData
  };

  // Mantener compatibilidad con el contrato anterior
  return {
    token: await firebaseUser.getIdToken(),
    record: currentUserData
  };
}

/**
 * Cierra la sesión del usuario actual
 */
export async function logout() {
  await signOut(auth);
  currentUserData = null;
}

/**
 * Verifica si hay un usuario autenticado
 * @returns {boolean} true si hay sesión válida
 */
export function isAuthenticated() {
  return !!auth.currentUser;
}

/**
 * Obtiene el usuario actualmente autenticado
 * @returns {Object|null} Usuario autenticado o null
 */
export function getCurrentUser() {
  return currentUserData;
}

/**
 * Refresca el token de autenticación
 * @returns {Promise<Object|null>} Datos de autenticación actualizados o null
 */
export async function refreshAuth() {
  if (!auth.currentUser) return null;

  // Refrescar datos del usuario desde Firestore
  const userDoc = await getDoc(doc(db, COLLECTION, auth.currentUser.uid));
  const userData = userDoc.exists() ? processUserData(userDoc.data()) : {};

  currentUserData = {
    id: auth.currentUser.uid,
    email: auth.currentUser.email,
    ...userData
  };

  return {
    token: await auth.currentUser.getIdToken(true),
    record: currentUserData
  };
}

/**
 * Registra un nuevo usuario en el sistema
 * @param {Object} userData - Datos del usuario
 * @param {string} userData.email - Email del usuario
 * @param {string} userData.password - Contraseña
 * @param {string} userData.passwordConfirm - Confirmación de contraseña (no usada en Firebase, pero mantenida por compatibilidad)
 * @param {string} userData.nombre - Nombre completo
 * @param {string} [userData.nom_mostrado] - Nombre para mostrar
 * @param {string} [userData.bio] - Biografía del usuario
 * @param {string} [userData.fecha_nac] - Fecha de nacimiento (YYYY-MM-DD)
 * @param {string} [userData.genero_fav] - Género literario favorito
 * @returns {Promise<Object>} Usuario registrado
 */
export async function register({ email, password, passwordConfirm, nombre, nom_mostrado, bio, fecha_nac, genero_fav }) {
  // Crear usuario en Firebase Auth
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  const firebaseUser = userCredential.user;

  // Preparar datos para Firestore (campos personalizados)
  const userDocData = {
    email,
    nombre: nombre || '',
    nom_mostrado: nom_mostrado || '',
    bio: bio || '',
    fecha_nac: fecha_nac ? Timestamp.fromDate(new Date(fecha_nac)) : null,
    genero_fav: genero_fav || '',
    avatar: '',
    es_admin: false,
    creado: Timestamp.now()
  };

  // Crear documento en la colección usuarios de Firestore
  await setDoc(doc(db, COLLECTION, firebaseUser.uid), userDocData);

  currentUserData = {
    id: firebaseUser.uid,
    ...userDocData
  };

  return currentUserData;
}

/**
 * Solicita verificación de email para el usuario
 * @param {string} email - Email del usuario (no usado en Firebase, envía al usuario actual)
 * @returns {Promise<boolean>} true si se envió el email correctamente
 */
export async function requestVerification(email) {
  if (auth.currentUser) {
    await sendEmailVerification(auth.currentUser);
    return true;
  }
  return false;
}

/**
 * Solicita restablecimiento de contraseña
 * @param {string} email - Email del usuario
 * @returns {Promise<boolean>} true si se envió el email correctamente
 */
export async function requestPasswordReset(email) {
  await sendPasswordResetEmail(auth, email);
  return true;
}

/**
 * Confirma el restablecimiento de contraseña con el token recibido
 * NOTA: En Firebase, esto se maneja automáticamente via el link del email
 * Esta función se mantiene por compatibilidad pero no es necesaria
 * @param {string} token - Token de restablecimiento
 * @param {string} password - Nueva contraseña
 * @param {string} passwordConfirm - Confirmación de nueva contraseña
 * @returns {Promise<boolean>} true si se cambió correctamente
 */
export async function confirmPasswordReset(token, password, passwordConfirm) {
  // Firebase maneja esto automáticamente con su propia UI
  // Se puede implementar con confirmPasswordReset de Firebase si se necesita UI custom
  console.warn('confirmPasswordReset: Firebase maneja esto automáticamente via email');
  return true;
}
