<!--
  SiteFooter, footer de la pagina
  Muestra el nombre del proyecto
-->
<template>
  <footer class="site-footer">
    <p>&copy; 2025 - Biblioteca Digital. Proyecto para ADI.</p>
  </footer>
</template>

<style scoped>
.site-footer {
    text-align: center;
    padding: 2rem;
    margin-top: 3rem;
    background-color: #f1f1f1;
    color: #555;
}
</style>
