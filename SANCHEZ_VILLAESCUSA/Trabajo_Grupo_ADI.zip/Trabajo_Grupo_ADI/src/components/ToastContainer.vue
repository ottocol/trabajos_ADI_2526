<!--
  ToastContainer, sistema de notificaciones
  Muestra mensajes temporales en la esquina superior derecha
  Tiene distintos tipos: success, error, warning, info, confirm
  Los toasts normales se auto-cierran, los de confirmación requieren respuesta

  Variables reactivas:
  - toasts: Array de notificaciones activas

  Métodos:
  - remove(id): Cierra una notificación específica
-->
<script setup>
import { useToast } from '@/composables/useToast'

const { toasts, remove } = useToast()
</script>

<template>
  <div class="toast-container">
    <TransitionGroup name="toast">
      <div
        v-for="toast in toasts"
        :key="toast.id"
        :class="['toast', `toast--${toast.type}`]"
      >
        <div class="toast__content">
          <div class="toast__icon">
            <span v-if="toast.type === 'success'">✓</span>
            <span v-else-if="toast.type === 'error'">✕</span>
            <span v-else-if="toast.type === 'warning'">⚠</span>
            <span v-else-if="toast.type === 'info'">ℹ</span>
            <span v-else-if="toast.type === 'confirm'">?</span>
          </div>
          <div class="toast__message">{{ toast.message }}</div>
          <button
            v-if="toast.type !== 'confirm'"
            class="toast__close"
            @click="remove(toast.id)"
            aria-label="Cerrar"
          >
            ×
          </button>
        </div>
        <div v-if="toast.type === 'confirm'" class="toast__actions">
          <button class="toast__btn toast__btn--confirm" @click="toast.onConfirm">
            Aceptar
          </button>
          <button class="toast__btn toast__btn--cancel" @click="toast.onCancel">
            Cancelar
          </button>
        </div>
      </div>
    </TransitionGroup>
  </div>
</template>

<style scoped>
.toast-container {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-width: 400px;
  pointer-events: none;
}

.toast {
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  padding: 16px;
  min-width: 300px;
  pointer-events: auto;
  border-left: 4px solid;
}

.toast--success {
  border-left-color: #10b981;
}

.toast--error {
  border-left-color: #ef4444;
}

.toast--warning {
  border-left-color: #f59e0b;
}

.toast--info {
  border-left-color: #3b82f6;
}

.toast--confirm {
  border-left-color: #8b5cf6;
}

.toast__content {
  display: flex;
  align-items: flex-start;
  gap: 12px;
}

.toast__icon {
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 16px;
}

.toast--success .toast__icon {
  background: #d1fae5;
  color: #10b981;
}

.toast--error .toast__icon {
  background: #fee2e2;
  color: #ef4444;
}

.toast--warning .toast__icon {
  background: #fef3c7;
  color: #f59e0b;
}

.toast--info .toast__icon {
  background: #dbeafe;
  color: #3b82f6;
}

.toast--confirm .toast__icon {
  background: #ede9fe;
  color: #8b5cf6;
}

.toast__message {
  flex: 1;
  font-size: 14px;
  line-height: 1.5;
  color: #374151;
}

.toast__close {
  background: none;
  border: none;
  font-size: 24px;
  line-height: 1;
  color: #9ca3af;
  cursor: pointer;
  padding: 0;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: color 0.2s;
}

.toast__close:hover {
  color: #374151;
}

.toast__actions {
  display: flex;
  gap: 8px;
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid #e5e7eb;
}

.toast__btn {
  flex: 1;
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.toast__btn--confirm {
  background: #8b5cf6;
  color: white;
}

.toast__btn--confirm:hover {
  background: #7c3aed;
}

.toast__btn--cancel {
  background: #f3f4f6;
  color: #374151;
}

.toast__btn--cancel:hover {
  background: #e5e7eb;
}

/* Animaciones */
.toast-enter-active,
.toast-leave-active {
  transition: all 0.3s ease;
}

.toast-enter-from {
  opacity: 0;
  transform: translateX(100%);
}

.toast-leave-to {
  opacity: 0;
  transform: translateX(100%) scale(0.95);
}

.toast-move {
  transition: transform 0.3s ease;
}

@media (max-width: 640px) {
  .toast-container {
    left: 20px;
    right: 20px;
    max-width: none;
  }

  .toast {
    min-width: auto;
  }
}
</style>
