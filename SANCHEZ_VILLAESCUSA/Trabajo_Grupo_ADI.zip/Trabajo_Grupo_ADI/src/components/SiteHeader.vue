<!--
  SiteHeader, cabecera de navegación principal
  Muestra el logo y menú de navegación
  Cambia dinámicamente según si el usuario está autenticado o no
  Muestra nombre de usuario y opciones de login/logout

  Variables reactivas:
  - userName: Nombre del usuario actual (nombre_mostrado > name > email)
-->
<script setup>
import { computed } from 'vue'
import { RouterLink } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()

// Obtiene el nombre del usuario logueado
const userName = computed(() => {
  if (!auth.currentUser) return ''
  return auth.currentUser.nombre_mostrado || auth.currentUser.name || auth.currentUser.email
})
</script>

<template>
  <header class="site-header">
    <div class="site-header__logo">
      <RouterLink to="/">Biblioteca Digital</RouterLink>
    </div>
    <nav class="site-nav">
      <ul class="site-nav__list">
        <li class="site-nav__item">
          <RouterLink to="/" class="site-nav__link">Inicio</RouterLink>
        </li>

        <template v-if="auth.isLoggedIn">
          <li class="site-nav__item">
            <RouterLink to="/add-book" class="site-nav__link">Añadir Libro</RouterLink>
          </li>
          <li class="site-nav__item">
            <RouterLink to="/profile" class="site-nav__link">Mi Perfil</RouterLink>
          </li>
          <li class="site-nav__item">
            <a href="#" @click.prevent="auth.logout()" class="site-nav__link">Cerrar Sesión</a>
          </li>
        </template>

        <template v-else>
          <li class="site-nav__item">
            <RouterLink to="/login" class="site-nav__link">Iniciar Sesión</RouterLink>
          </li>
          <li class="site-nav__item">
            <RouterLink to="/register" class="site-nav__link site-nav__link--register">Registrarse</RouterLink>
          </li>
        </template>
      </ul>
      <div v-if="auth.isLoggedIn" class="site-nav__welcome">
        Bienvenido, {{ userName }}
      </div>
    </nav>
  </header>
</template>

<style scoped>
.site-header {
    background-color: var(--primary-color);
    color: white;
    padding: 1rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
}

.site-header__logo a {
    color: white;
    text-decoration: none;
    font-size: 1.5rem;
    font-weight: bold;
}

.site-nav__list {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    gap: 1.5rem;
}

.site-nav__link {
    color: white;
    text-decoration: none;
    font-size: 1rem;
    padding: 0.5rem 0;
    border-bottom: 2px solid transparent;
    transition: border-color 0.3s;
}

.site-nav__link:hover {
    border-bottom-color: var(--secondary-color);
}

/* Estilo para el enlace activo de Vue Router */
.site-nav__link.router-link-exact-active {
    border-bottom-color: var(--secondary-color);
    font-weight: bold;
}

.site-nav__link--register {
    background-color: var(--secondary-color);
    padding: 0.5rem 1rem;
    border-radius: 5px;
    border: none;
}

.site-nav__link--register:hover {
    background-color: #e67e22;
    border-bottom-color: transparent;
}

.site-nav__welcome {
    color: white;
    font-size: 0.9rem;
    margin-left: 1rem;
}

/* Responsive */
@media (max-width: 768px) {
    .site-header {
        flex-direction: column;
        gap: 1rem;
    }

    .site-nav__list {
        flex-wrap: wrap;
        gap: 1rem;
        justify-content: center;
    }

    .site-nav__welcome {
        margin-left: 0;
        margin-top: 0.5rem;
    }
}
</style>
