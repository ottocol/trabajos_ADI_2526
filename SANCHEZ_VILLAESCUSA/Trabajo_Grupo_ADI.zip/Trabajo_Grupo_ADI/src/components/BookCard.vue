<!--
  BookCard, este componente es una tarjeta para mostrar informacion basicda de un libro (título, autor, genero)
  Al hacer hover se amplía y muestra la sinopsis con un overlay
  Hace clic para ir a la página de detalles del libro

  Props:
  - book: Objeto con datos del libro (id, titulo, autor, genero, portada, sinopsis)
-->
<script setup>
defineProps({
  book: {
    type: Object,
    required: true
  }
})
</script>

<template>
  <article class="book-card">
    <router-link :to="`/book/${book.id}`" class="book-card__link">
      <img
        :src="book.portada"
        :alt="`Portada de ${book.titulo}`"
        class="book-card__image"
      >
      <div class="book-card__info">
        <h3 class="book-card__title">{{ book.titulo }}</h3>
        <p class="book-card__author">{{ book.autor }}</p>
        <p class="book-card__genre">{{ book.genero }}</p>
      </div>
      <div
        class="book-card__overlay"
        :style="{ backgroundImage: `url(${book.portada}), linear-gradient(to bottom, transparent 0%, rgba(0, 0, 0, 0.75) 60%)` }"
      >
        <div class="book-card__overlay-info">
          <h3 class="book-card__overlay-title">{{ book.titulo }}</h3>
          <p class="book-card__overlay-author">{{ book.autor }}</p>
          <p class="book-card__overlay-genre"><strong>Género:</strong> {{ book.genero }}</p>
          <p class="book-card__overlay-synopsis">{{ book.sinopsis }}</p>
        </div>
      </div>
    </router-link>
  </article>
</template>

<style scoped>
.book-card {
    background-color: var(--card-background);
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    transition: transform 0.3s, box-shadow 0.3s;
    position: relative;
}

.book-card:hover {
    transform: scale(1.5);
    box-shadow: 0 20px 40px rgba(0,0,0,0.4);
    z-index: 100;
}

.book-card__link {
    text-decoration: none;
    color: inherit;
    display: block;
    position: relative;
    height: 100%;
}

.book-card__image {
    width: 100%;
    height: 280px;
    object-fit: cover;
    display: block;
}

.book-card__info {
    padding: 1rem;
    background: var(--card-background);
}

.book-card__title {
    margin: 0 0 0.5rem;
    font-size: 1.1rem;
    color: var(--text-color);
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
}

.book-card__author {
    margin: 0;
    font-size: 0.9rem;
    color: #666;
}

.book-card__genre {
    margin: 0.5rem 0 0;
    font-size: 0.85rem;
    color: #888;
    font-style: italic;
}

.book-card__overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    transition: opacity 0.3s;
    border-radius: 8px;
    overflow: hidden;
    background-size: cover;
    background-position: center;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
}

.book-card:hover .book-card__overlay {
    opacity: 1;
}

.book-card__overlay-info {
    padding: 1.5rem;
    color: white;
    z-index: 2;
    background: linear-gradient(to bottom, transparent 0%, rgba(0, 0, 0, 0.85) 40%, rgba(0, 0, 0, 0.95) 100%);
}

.book-card__overlay-title {
    margin: 0 0 0.5rem;
    font-size: 1.2rem;
    color: var(--secondary-color);
    font-weight: bold;
  }

.book-card__overlay-author {
    margin: 0 0 0.5rem;
    font-size: 1rem;
    color: #eee;
}

.book-card__overlay-genre {
    margin: 0 0 0.8rem;
    font-size: 0.9rem;
    color: #ddd;
}

.book-card__overlay-synopsis {
    margin: 0;
    font-size: 0.85rem;
    line-height: 1.5;
    color: #fff;
    text-align: left;
    max-height: 150px;
    overflow-y: auto;
}

/* Scrollbar personalizada para el contenido del overlay */
.book-card__overlay-synopsis::-webkit-scrollbar {
    width: 5px;
}

.book-card__overlay-synopsis::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
}

.book-card__overlay-synopsis::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.4);
    border-radius: 10px;
}

.book-card__overlay-synopsis::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.6);
}
</style>
