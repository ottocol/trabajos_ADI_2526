<script setup>
import { RouterView } from 'vue-router'
import SiteHeader from '@/components/SiteHeader.vue'
import SiteFooter from '@/components/SiteFooter.vue'
import ToastContainer from '@/components/ToastContainer.vue'
</script>

<template>
  <div class="app-wrapper">
    <SiteHeader />
    <main class="main-content">
      <RouterView />
    </main>
    <SiteFooter />
    <ToastContainer />
  </div>
</template>

<style scoped>
.app-wrapper {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.main-content {
  flex: 1;
  max-width: 1200px;
  margin: 2rem auto;
  padding: 0 1rem;
  width: 100%;
  box-sizing: border-box;
}
</style>
