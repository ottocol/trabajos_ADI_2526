import { initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Cargar credenciales del service account
const serviceAccountPath = join(__dirname, '..', 'serviceAccountKey.json');

let serviceAccount;
try {
  serviceAccount = JSON.parse(readFileSync(serviceAccountPath, 'utf8'));
} catch (error) {
  console.error('\nError: No se encontró el archivo serviceAccountKey.json');
  console.log('\nPara obtener las credenciales:');
  console.log('1. Ve a Firebase Console > Project Settings > Service Accounts');
  console.log('2. Haz clic en "Generate new private key"');
  console.log('3. Guarda el archivo como "serviceAccountKey.json" en la raíz del proyecto');
  process.exit(1);
}

// Inicializar Firebase Admin
initializeApp({
  credential: cert(serviceAccount)
});

const auth = getAuth();
const db = getFirestore();

async function deleteCollection(collectionName) {
  const collectionRef = db.collection(collectionName);
  const snapshot = await collectionRef.get();
  
  if (snapshot.empty) {
    return 0;
  }

  const batch = db.batch();
  snapshot.docs.forEach((doc) => {
    batch.delete(doc.ref);
  });
  
  await batch.commit();
  return snapshot.size;
}

async function deleteAllUsers() {
  let deletedCount = 0;
  let nextPageToken;

  do {
    const listUsersResult = await auth.listUsers(1000, nextPageToken);
    const uids = listUsersResult.users.map(user => user.uid);
    
    if (uids.length > 0) {
      await auth.deleteUsers(uids);
      deletedCount += uids.length;
    }
    
    nextPageToken = listUsersResult.pageToken;
  } while (nextPageToken);

  return deletedCount;
}

async function clearDatabase() {
  try {
    console.log('Limpiando base de datos de Firebase...\n');

    // Eliminar todas las reseñas
    console.log('Eliminando reseñas...');
    const resenasCount = await deleteCollection('resenas');
    console.log(` ${resenasCount} reseñas eliminadas`);

    // Eliminar todos los libros
    console.log('Eliminando libros...');
    const librosCount = await deleteCollection('libros');
    console.log(` ${librosCount} libros eliminados`);

    // Eliminar documentos de usuarios en Firestore
    console.log('Eliminando documentos de usuarios...');
    const usuariosDocsCount = await deleteCollection('usuarios');
    console.log(` ${usuariosDocsCount} documentos de usuarios eliminados`);

    // Eliminar usuarios de Firebase Auth
    console.log('Eliminando usuarios de Firebase Auth...');
    const authUsersCount = await deleteAllUsers();
    console.log(` ${authUsersCount} usuarios de Auth eliminados`);

    console.log('\n' + '='.repeat(50));
    console.log('Base de datos limpiada exitosamente!');
    console.log('='.repeat(50));
    console.log('\nAhora puedes ejecutar: npm run db:seed');

  } catch (error) {
    console.error('\nError durante la limpieza:', error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

// Ejecutar limpieza
clearDatabase();
