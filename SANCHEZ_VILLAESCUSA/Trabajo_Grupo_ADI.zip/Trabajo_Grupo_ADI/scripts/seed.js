import { initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Cargar credenciales del service account
const serviceAccountPath = join(__dirname, '..', 'serviceAccountKey.json');

let serviceAccount;
try {
  serviceAccount = JSON.parse(readFileSync(serviceAccountPath, 'utf8'));
} catch (error) {
  console.error('\nError: No se encontró el archivo serviceAccountKey.json');
  console.log('\nPara obtener las credenciales:');
  console.log('1. Ve a Firebase Console > Project Settings > Service Accounts');
  console.log('2. Haz clic en "Generate new private key"');
  console.log('3. Guarda el archivo como "serviceAccountKey.json" en la raíz del proyecto');
  console.log('\nIMPORTANTE: Añade serviceAccountKey.json a .gitignore\n');
  process.exit(1);
}

// Inicializar Firebase Admin
initializeApp({
  credential: cert(serviceAccount)
});

const auth = getAuth();
const db = getFirestore();

async function seed() {
  try {
    console.log('Iniciando seed de datos para Firebase...\n');

    // 1. Crear usuarios de ejemplo
    console.log('Creando usuarios...');
    
    const usuarios = [];
    const usuariosData = [
      {
        email: 'saul@example.com',
        password: 'saul1234',
        nombre: 'Saúl Cañas Rodríguez',
        nom_mostrado: 'SaúlCR',
        bio: 'Amante de la ciencia ficción y las novelas de misterio. Siempre buscando nuevas aventuras literarias.',
        genero_fav: 'Ciencia Ficción',
        es_admin: false,
        avatar: 'https://i.pravatar.cc/150?img=12',
        fecha_nac: '1998-03-15',
        creado: '2024-01-10'
      },
      {
        email: 'fabian@example.com',
        password: 'fabian1234',
        nombre: 'Fabián García López',
        nom_mostrado: 'FabiánGL',
        bio: 'Lector empedernido de fantasía épica. Tolkien es mi autor favorito de todos los tiempos.',
        genero_fav: 'Fantasía',
        es_admin: false,
        avatar: 'https://i.pravatar.cc/150?img=33',
        fecha_nac: '1995-07-22',
        creado: '2024-02-05'
      },
      {
        email: 'admin@example.com',
        password: 'admin1234',
        nombre: 'Administrador Sistema',
        nom_mostrado: 'BiblioAdmin',
        bio: 'Administrador de la biblioteca digital. Aquí para ayudarte a encontrar tu próxima lectura.',
        genero_fav: 'Variado',
        es_admin: true,
        avatar: 'https://i.pravatar.cc/150?img=68',
        fecha_nac: '1990-01-01',
        creado: '2023-12-01'
      },
      {
        email: 'ana@example.com',
        password: 'ana12345',
        nombre: 'Ana Martínez Pérez',
        nom_mostrado: 'AnaBooks',
        bio: 'Amante de las novelas románticas y los finales felices. Recomiendo libros que te hacen suspirar.',
        genero_fav: 'Romance',
        es_admin: false,
        avatar: 'https://i.pravatar.cc/150?img=47',
        fecha_nac: '1997-11-08',
        creado: '2024-03-20'
      },
      {
        email: 'carlos@example.com',
        password: 'carlos1234',
        nombre: 'Carlos López Hernández',
        nom_mostrado: 'CarlosH',
        bio: 'Fan del terror y suspense. Si no me da miedo, no me interesa. Stephen King es mi gurú.',
        genero_fav: 'Terror',
        es_admin: false,
        avatar: 'https://i.pravatar.cc/150?img=15',
        fecha_nac: '1992-10-31',
        creado: '2024-01-25'
      },
      {
        email: 'lucia@example.com',
        password: 'lucia1234',
        nombre: 'Lucía Fernández Ruiz',
        nom_mostrado: 'LucíaLectora',
        bio: 'Disfruto de novelas históricas y biografías. Me encanta aprender sobre otras épocas.',
        genero_fav: 'Histórica',
        es_admin: false,
        avatar: 'https://i.pravatar.cc/150?img=48',
        fecha_nac: '1994-05-18',
        creado: '2024-04-12'
      },
      {
        email: 'miguel@example.com',
        password: 'miguel1234',
        nombre: 'Miguel Rodríguez Sanz',
        nom_mostrado: 'MiguelCyber',
        bio: 'Me encanta la ciencia ficción y el cyberpunk. Neuromante cambió mi vida.',
        genero_fav: 'Ciencia Ficción',
        es_admin: false,
        avatar: 'https://i.pravatar.cc/150?img=52',
        fecha_nac: '1996-08-25',
        creado: '2024-02-28'
      },
      {
        email: 'elena@example.com',
        password: 'elena1234',
        nombre: 'Elena Sánchez Moreno',
        nom_mostrado: 'ElenaClásicos',
        bio: 'Lectora de clásicos y literatura universal. Cervantes, Austen y Dickens son mis favoritos.',
        genero_fav: 'Clásicos',
        es_admin: false,
        avatar: 'https://i.pravatar.cc/150?img=32',
        fecha_nac: '1993-02-14',
        creado: '2024-05-08'
      },
      {
        email: 'javier@example.com',
        password: 'javier1234',
        nombre: 'Javier Morales Castro',
        nom_mostrado: 'JaviAventuras',
        bio: 'Apasionado de las novelas de aventuras. Julio Verne me inspiró a soñar en grande.',
        genero_fav: 'Aventura',
        es_admin: false,
        avatar: 'https://i.pravatar.cc/150?img=60',
        fecha_nac: '1999-06-30',
        creado: '2024-06-15'
      },
      {
        email: 'sofia@example.com',
        password: 'sofia1234',
        nombre: 'Sofía Torres Navarro',
        nom_mostrado: 'SofíaReads',
        bio: 'Me gusta explorar diferentes géneros literarios. Cada libro es una nueva aventura.',
        genero_fav: 'Variado',
        es_admin: false,
        avatar: 'https://i.pravatar.cc/150?img=44',
        fecha_nac: '2000-09-12',
        creado: '2024-07-01'
      }
    ];

    for (const userData of usuariosData) {
      try {
        let userRecord;
        try {
          userRecord = await auth.getUserByEmail(userData.email);
          console.log(`Usuario ya existe: ${userData.email}`);
        } catch (error) {
          userRecord = await auth.createUser({
            email: userData.email,
            password: userData.password,
            displayName: userData.nombre
          });
          console.log(`Usuario creado: ${userData.email}`);
        }

        const userDocData = {
          email: userData.email,
          nombre: userData.nombre,
          name: userData.nombre, // alias para la vista
          nom_mostrado: userData.nom_mostrado,
          nombre_mostrado: userData.nom_mostrado, // alias para la vista
          bio: userData.bio,
          genero_fav: userData.genero_fav,
          es_admin: userData.es_admin,
          avatar: userData.avatar,
          fecha_nac: userData.fecha_nac ? Timestamp.fromDate(new Date(userData.fecha_nac)) : null,
          fecha_nacimiento: userData.fecha_nac ? Timestamp.fromDate(new Date(userData.fecha_nac)) : null, // alias para la vista
          creado: userData.creado ? Timestamp.fromDate(new Date(userData.creado)) : Timestamp.now(),
          created: userData.creado ? Timestamp.fromDate(new Date(userData.creado)) : Timestamp.now() // alias para la vista
        };

        await db.collection('usuarios').doc(userRecord.uid).set(userDocData, { merge: true });
        usuarios.push({ id: userRecord.uid, ...userDocData });

      } catch (error) {
        console.error(`Error con ${userData.email}:`, error.message);
      }
    }

    if (usuarios.length === 0) {
      console.error('\nNo se pudieron crear usuarios. Abortando seed.');
      process.exit(1);
    }

    // 2. Crear libros de ejemplo
    console.log('\nCreando libros...');
    
    const libros = [];
    const librosData = [
      { titulo: 'Dune', autor: 'Frank Herbert', genero: 'Ciencia Ficción', fec_publicacion: '1965-06-01', sinopsis: 'En el desértico planeta Arrakis, Paul Atreides debe liderar a su pueblo en una batalla por el control del melange.', portada: 'https://m.media-amazon.com/images/I/81A1Mn-x49L._UF1000,1000_QL80_.jpg', isbn: '978-0441172719', id_creador: usuarios[0]?.id },
      { titulo: 'El nombre del viento', autor: 'Patrick Rothfuss', genero: 'Fantasía', fec_publicacion: '2007-03-27', sinopsis: 'Kvothe cuenta su propia historia: cómo creció y se convirtió en leyenda.', portada: 'https://m.media-amazon.com/images/I/91PjnllfsxL.jpg', isbn: '978-0756404079', id_creador: usuarios[1]?.id },
      { titulo: '1984', autor: 'George Orwell', genero: 'Distopía', fec_publicacion: '1949-06-08', sinopsis: 'Winston Smith lucha por mantener su humanidad bajo la vigilancia del Gran Hermano.', portada: 'https://m.media-amazon.com/images/I/71sOSrd+JxL.jpg', isbn: '978-0451524935', id_creador: usuarios[0]?.id },
      { titulo: 'Cien años de soledad', autor: 'Gabriel García Márquez', genero: 'Realismo Mágico', fec_publicacion: '1967-05-30', sinopsis: 'La historia de la familia Buendía a lo largo de siete generaciones en Macondo.', portada: 'https://m.media-amazon.com/images/I/91TvVQS7loL.jpg', isbn: '978-0060883287', id_creador: usuarios[2]?.id },
      { titulo: 'El Hobbit', autor: 'J.R.R. Tolkien', genero: 'Fantasía', fec_publicacion: '1937-09-21', sinopsis: 'Bilbo Bolsón es arrastrado a una aventura épica para recuperar un tesoro.', portada: 'https://m.media-amazon.com/images/I/91U3Yg8PFDL._UF1000,1000_QL80_.jpg', isbn: '978-0547928227', id_creador: usuarios[1]?.id },
      { titulo: 'El Resplandor', autor: 'Stephen King', genero: 'Terror', fec_publicacion: '1977-01-28', sinopsis: 'Jack Torrance acepta un trabajo en el hotel Overlook donde fuerzas sobrenaturales amenazan a su familia.', portada: 'https://m.media-amazon.com/images/I/91n8sen+w1L.jpg', isbn: '978-0307743657', id_creador: usuarios[4]?.id },
      { titulo: 'Orgullo y Prejuicio', autor: 'Jane Austen', genero: 'Romance', fec_publicacion: '1813-01-28', sinopsis: 'Elizabeth Bennet navega por la sociedad inglesa del siglo XIX.', portada: 'https://m.media-amazon.com/images/I/71wnBzT9WqL._AC_UF1000,1000_QL80_.jpg', isbn: '978-0141439518', id_creador: usuarios[3]?.id },
      { titulo: 'Fundación', autor: 'Isaac Asimov', genero: 'Ciencia Ficción', fec_publicacion: '1951-06-01', sinopsis: 'Hari Seldon desarrolla la psicohistoria para predecir el futuro.', portada: 'https://m.media-amazon.com/images/I/81i5i05EgHL._AC_UF1000,1000_QL80_.jpg', isbn: '978-0553293357', id_creador: usuarios[6]?.id },
      { titulo: 'El Señor de los Anillos', autor: 'J.R.R. Tolkien', genero: 'Fantasía', fec_publicacion: '1954-07-29', sinopsis: 'Frodo debe destruir el anillo en el Monte del Destino.', portada: 'https://m.media-amazon.com/images/I/816QLZKwmIL.jpg', isbn: '978-0544003415', id_creador: usuarios[1]?.id },
      { titulo: 'Don Quijote de la Mancha', autor: 'Miguel de Cervantes', genero: 'Clásicos', fec_publicacion: '1605-01-16', sinopsis: 'Las aventuras del ingenioso hidalgo Don Quijote y Sancho Panza.', portada: 'https://m.media-amazon.com/images/I/91CIwR3QU1L._UF1000,1000_QL80_.jpg', isbn: '978-8491050551', id_creador: usuarios[7]?.id },
      { titulo: 'Harry Potter y la Piedra Filosofal', autor: 'J.K. Rowling', genero: 'Fantasía', fec_publicacion: '1997-06-26', sinopsis: 'Harry descubre que es un mago y comienza su educación en Hogwarts.', portada: 'https://m.media-amazon.com/images/I/61mEUsasD-L.jpg', isbn: '978-8478884452', id_creador: usuarios[8]?.id },
      { titulo: 'Neuromante', autor: 'William Gibson', genero: 'Ciencia Ficción', fec_publicacion: '1984-07-01', sinopsis: 'Case, un hacker caído en desgracia, es reclutado para el último trabajo.', portada: 'https://m.media-amazon.com/images/I/818Y1vupv0L.jpg', isbn: '978-0441569595', id_creador: usuarios[6]?.id },
      { titulo: 'La Sombra del Viento', autor: 'Carlos Ruiz Zafón', genero: 'Misterio', fec_publicacion: '2001-04-17', sinopsis: 'En la Barcelona de posguerra, Daniel descubre un libro maldito.', portada: 'https://m.media-amazon.com/images/I/61ZSuWFzQRL.jpg', isbn: '978-8408163251', id_creador: usuarios[0]?.id },
      { titulo: 'Los Pilares de la Tierra', autor: 'Ken Follett', genero: 'Histórica', fec_publicacion: '1989-10-01', sinopsis: 'La construcción de una catedral en la Inglaterra medieval.', portada: 'https://m.media-amazon.com/images/I/912cN-bjuiL.jpg', isbn: '978-0451166890', id_creador: usuarios[5]?.id },
      { titulo: 'It (Eso)', autor: 'Stephen King', genero: 'Terror', fec_publicacion: '1986-09-15', sinopsis: 'Niños se enfrentan a una entidad malévola con forma de payaso.', portada: 'https://m.media-amazon.com/images/I/71BwqlcZyVL._AC_UF1000,1000_QL80_.jpg', isbn: '978-0450411434', id_creador: usuarios[4]?.id }
    ];

    for (const libroData of librosData) {
      if (!libroData.id_creador) continue;
      
      try {
        const libroDoc = {
          ...libroData,
          fec_publicacion: libroData.fec_publicacion ? Timestamp.fromDate(new Date(libroData.fec_publicacion)) : null,
          created: Timestamp.now()
        };

        const docRef = await db.collection('libros').add(libroDoc);
        libros.push({ id: docRef.id, ...libroDoc });
        console.log(`Libro creado: ${libroData.titulo}`);
      } catch (error) {
        console.error(`Error creando ${libroData.titulo}:`, error.message);
      }
    }

    // 3. Crear reseñas
    console.log('\nCreando reseñas...');
    
    const resenasData = [
      { libro: 0, autor: 1, valoracion: 5, comentario: 'Obra maestra de la ciencia ficción!' },
      { libro: 0, autor: 2, valoracion: 4, comentario: 'Muy buen libro, aunque al principio denso.' },
      { libro: 1, autor: 0, valoracion: 5, comentario: 'La narrativa de Rothfuss es hermosa.' },
      { libro: 1, autor: 8, valoracion: 5, comentario: 'Kvothe es un personaje fascinante.' },
      { libro: 2, autor: 1, valoracion: 5, comentario: 'Aterrador por lo relevante que sigue siendo.' },
      { libro: 2, autor: 7, valoracion: 5, comentario: 'Un clásico imprescindible.' },
      { libro: 3, autor: 0, valoracion: 5, comentario: 'Obra maestra del realismo mágico.' },
      { libro: 4, autor: 2, valoracion: 4, comentario: 'Perfecto para iniciarse en la Tierra Media.' },
      { libro: 4, autor: 8, valoracion: 5, comentario: 'Una aventura encantadora.' },
      { libro: 5, autor: 4, valoracion: 5, comentario: 'No pude dormir después de leerlo.' },
      { libro: 6, autor: 3, valoracion: 5, comentario: 'Jane Austen es maravillosa.' },
      { libro: 7, autor: 0, valoracion: 5, comentario: 'La psicohistoria de Asimov es fascinante.' },
      { libro: 8, autor: 1, valoracion: 5, comentario: 'Tolkien es el maestro.' },
      { libro: 9, autor: 7, valoracion: 5, comentario: 'El clásico de clásicos.' },
      { libro: 10, autor: 8, valoracion: 5, comentario: 'El libro que me hizo amar la lectura.' },
      { libro: 11, autor: 6, valoracion: 5, comentario: 'Gibson definió el cyberpunk.' },
      { libro: 12, autor: 9, valoracion: 5, comentario: 'Historia misteriosa y cautivadora.' },
      { libro: 13, autor: 5, valoracion: 5, comentario: 'Épica histórica de primera.' },
      { libro: 14, autor: 4, valoracion: 5, comentario: 'King en su máximo esplendor.' }
    ];

    let resenasCreadas = 0;
    for (const resenaData of resenasData) {
      const libro = libros[resenaData.libro];
      const autor = usuarios[resenaData.autor];
      
      if (!libro || !autor) continue;
      
      try {
        await db.collection('resenas').add({
          libro: libro.id,
          autor: autor.id,
          valoracion: resenaData.valoracion,
          comentario: resenaData.comentario,
          editado: false,
          created: Timestamp.now()
        });
        resenasCreadas++;
      } catch (error) {
        console.error(`Error creando reseña:`, error.message);
      }
    }
    console.log(`${resenasCreadas} reseñas creadas`);

    // Resumen
    console.log('\n' + '='.repeat(50));
    console.log('Seed completado exitosamente!');
    console.log('='.repeat(50));
    console.log(`\nResumen:`);
    console.log(`   ${usuarios.length} usuarios`);
    console.log(`   ${libros.length} libros`);
    console.log(`   ${resenasCreadas} reseñas`);
    console.log(`\nCredenciales de prueba:`);
    console.log(`   saul@example.com / saul1234`);
    console.log(`   fabian@example.com / fabian1234`);
    console.log(`   admin@example.com / admin1234 [ADMIN]`);
    console.log('');

  } catch (error) {
    console.error('\nError durante el seed:', error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

seed();
