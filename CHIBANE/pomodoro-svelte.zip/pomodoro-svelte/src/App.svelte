<script>
  import { onMount, onDestroy } from 'svelte';
  import { 
    Play, Pause, RotateCcw, CheckCircle, Circle, Moon, Sun, 
    Plus, Trash2, Tag, Download, Settings, TrendingUp, Calendar, Award 
  } from 'lucide-svelte';

  let minutes = 25;
  let seconds = 0;
  let isActive = false;
  let mode = 'work';
  let timerInterval;
  let tasks = [];
  let newTask = '';
  let newTaskCategory = '';
  let completedSessions = [];
  let darkMode = false;
  let showSettings = false;
  let workDuration = 25;
  let breakDuration = 5;
  let categories = ['Trabajo', 'Estudio', 'Personal', 'Proyecto'];

  onMount(() => {
    const savedTasks = localStorage.getItem('pomodoroTasks');
    const savedSessions = localStorage.getItem('pomodoroSessions');
    const savedMode = localStorage.getItem('pomodoroMode');
    const savedWorkDuration = localStorage.getItem('workDuration');
    const savedBreakDuration = localStorage.getItem('breakDuration');

    if (savedTasks) tasks = JSON.parse(savedTasks);
    if (savedSessions) completedSessions = JSON.parse(savedSessions);
    if (savedMode) darkMode = savedMode === 'dark';
    if (savedWorkDuration) {
      workDuration = parseInt(savedWorkDuration);
      minutes = workDuration;
    }
    if (savedBreakDuration) breakDuration = parseInt(savedBreakDuration);

    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  });

  $: if (typeof window !== 'undefined') {
    localStorage.setItem('pomodoroTasks', JSON.stringify(tasks));
  }
  $: if (typeof window !== 'undefined') {
    localStorage.setItem('pomodoroSessions', JSON.stringify(completedSessions));
  }
  $: if (typeof window !== 'undefined') {
    localStorage.setItem('pomodoroMode', darkMode ? 'dark' : 'light');
  }
  $: if (typeof window !== 'undefined') {
    localStorage.setItem('workDuration', workDuration.toString());
  }
  $: if (typeof window !== 'undefined') {
    localStorage.setItem('breakDuration', breakDuration.toString());
  }

  $: if (isActive) {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(() => {
      if (seconds === 0) {
        if (minutes === 0) {
          handleTimerComplete();
        } else {
          minutes--;
          seconds = 59;
        }
      } else {
        seconds--;
      }
    }, 1000);
  } else {
    if (timerInterval) {
      clearInterval(timerInterval);
      timerInterval = null;
    }
  }

  onDestroy(() => {
    if (timerInterval) clearInterval(timerInterval);
  });

  function handleTimerComplete() {
    isActive = false;
    
    if (mode === 'work') {
      completedSessions = [...completedSessions, {
        date: new Date().toISOString().split('T')[0],
        timestamp: Date.now(),
        duration: workDuration
      }];
      
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('¡Pomodoro completado!', { body: 'Tiempo de descanso 🎉' });
      }
      
      mode = 'break';
      minutes = breakDuration;
      seconds = 0;
    } else {
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('¡Descanso terminado!', { body: 'Hora de volver al trabajo 💪' });
      }
      mode = 'work';
      minutes = workDuration;
      seconds = 0;
    }
  }

  function toggleTimer() {
    isActive = !isActive;
  }

  function resetTimer() {
    isActive = false;
    minutes = mode === 'work' ? workDuration : breakDuration;
    seconds = 0;
  }

  function addTask() {
    if (newTask.trim()) {
      tasks = [...tasks, {
        id: Date.now(),
        text: newTask,
        completed: false,
        category: newTaskCategory || 'Sin categoría',
        createdAt: new Date().toISOString()
      }];
      newTask = '';
      newTaskCategory = '';
    }
  }

  function toggleTask(id) {
    tasks = tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    );
  }

  function deleteTask(id) {
    tasks = tasks.filter(task => task.id !== id);
  }

  function exportData() {
    const data = { tasks, sessions: completedSessions, categories, exportDate: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pomodoro-data-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  $: totalSeconds = mode === 'work' ? workDuration * 60 : breakDuration * 60;
  $: currentSeconds = minutes * 60 + seconds;
  $: progress = ((totalSeconds - currentSeconds) / totalSeconds) * 100;
  $: today = new Date().toISOString().split('T')[0];
  $: sessionsToday = completedSessions.filter(s => s.date === today).length;
  $: last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - i);
    return date.toISOString().split('T')[0];
  }).reverse();
  $: sessionsByDay = last7Days.map(date => ({
    date,
    count: completedSessions.filter(s => s.date === date).length
  }));
  $: maxSessions = Math.max(...sessionsByDay.map(d => d.count), 1);
  $: currentStreak = (() => {
    let streak = 0;
    const sortedDates = [...new Set(completedSessions.map(s => s.date))].sort().reverse();
    for (let i = 0; i < sortedDates.length; i++) {
      const date = new Date(sortedDates[i]);
      const expectedDate = new Date();
      expectedDate.setDate(expectedDate.getDate() - i);
      if (date.toISOString().split('T')[0] === expectedDate.toISOString().split('T')[0]) {
        streak++;
      } else break;
    }
    return streak;
  })();
  $: tasksByCategory = categories.map(cat => ({
    category: cat,
    total: tasks.filter(t => t.category === cat).length,
    completed: tasks.filter(t => t.category === cat && t.completed).length
  }));
  $: totalMinutes = completedSessions.reduce((acc, s) => acc + (s.duration || 25), 0);
  $: bgColor = darkMode ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 to-pink-50';
  $: cardBg = darkMode ? 'bg-gray-800' : 'bg-white';
  $: textColor = darkMode ? 'text-white' : 'text-gray-800';
  $: textSecondary = darkMode ? 'text-gray-400' : 'text-gray-600';
</script>

<div class="min-h-screen {bgColor} {textColor} p-4 md:p-8">
  <div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-8">
      <div>
        <h1 class="text-4xl font-bold">🍅 Pomodoro Pro</h1>
        <p class="text-sm {textSecondary}">Sistema avanzado de productividad</p>
      </div>
      <div class="flex gap-2">
        <button on:click={exportData} class="{cardBg} p-3 rounded-full shadow-lg hover:scale-110 transition-transform">
          <Download class="w-5 h-5" />
        </button>
        <button on:click={() => showSettings = !showSettings} class="{cardBg} p-3 rounded-full shadow-lg hover:scale-110 transition-transform">
          <Settings class="w-5 h-5" />
        </button>
        <button on:click={() => darkMode = !darkMode} class="{cardBg} p-3 rounded-full shadow-lg hover:scale-110 transition-transform">
          {#if darkMode}<Sun class="w-5 h-5" />{:else}<Moon class="w-5 h-5" />{/if}
        </button>
      </div>
    </div>

    {#if showSettings}
      <div class="{cardBg} rounded-2xl shadow-xl p-6 mb-8">
        <h3 class="text-xl font-bold mb-4">⚙️ Configuración</h3>
        <div class="grid md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm {textSecondary} mb-2">Duración trabajo (min)</label>
            <input type="number" bind:value={workDuration} on:input={() => !isActive && mode === 'work' && (minutes = workDuration)}
              class="w-full px-4 py-2 rounded-lg {darkMode ? 'bg-gray-700 text-white' : 'bg-gray-100'}" min="1" max="60" />
          </div>
          <div>
            <label class="block text-sm {textSecondary} mb-2">Duración descanso (min)</label>
            <input type="number" bind:value={breakDuration} on:input={() => !isActive && mode === 'break' && (minutes = breakDuration)}
              class="w-full px-4 py-2 rounded-lg {darkMode ? 'bg-gray-700 text-white' : 'bg-gray-100'}" min="1" max="30" />
          </div>
        </div>
      </div>
    {/if}

    <div class="grid lg:grid-cols-3 gap-6">
      <div class="{cardBg} rounded-2xl shadow-xl p-6">
        <div class="text-center mb-4">
          <span class="text-lg font-semibold {mode === 'work' ? 'text-red-500' : 'text-green-500'}">
            {mode === 'work' ? '🔥 TRABAJO' : '☕ DESCANSO'}
          </span>
        </div>
        <div class="relative w-48 h-48 mx-auto mb-6">
          <svg class="transform -rotate-90 w-48 h-48">
            <circle cx="96" cy="96" r="88" stroke={darkMode ? '#374151' : '#e5e7eb'} stroke-width="10" fill="none" />
            <circle cx="96" cy="96" r="88" stroke={mode === 'work' ? '#ef4444' : '#10b981'} stroke-width="10" fill="none"
              stroke-dasharray={2 * Math.PI * 88} stroke-dashoffset={2 * Math.PI * 88 * (1 - progress / 100)}
              stroke-linecap="round" class="transition-all duration-1000" />
          </svg>
          <div class="absolute inset-0 flex items-center justify-center">
            <div class="text-4xl font-bold">{String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}</div>
          </div>
        </div>
        <div class="flex justify-center gap-4 mb-6">
          <button on:click={toggleTimer}
            class="p-4 rounded-full {mode === 'work' ? 'bg-red-500' : 'bg-green-500'} text-white shadow-lg hover:scale-110 transition-transform">
            {#if isActive}<Pause class="w-6 h-6" />{:else}<Play class="w-6 h-6" />{/if}
          </button>
          <button on:click={resetTimer}
            class="p-4 rounded-full {darkMode ? 'bg-gray-700' : 'bg-gray-200'} shadow-lg hover:scale-110 transition-transform">
            <RotateCcw class="w-6 h-6" />
          </button>
        </div>
        <div class="grid grid-cols-3 gap-3 text-center">
          <div class="{darkMode ? 'bg-gray-700' : 'bg-purple-50'} rounded-lg p-3">
            <Calendar class="w-5 h-5 mx-auto mb-1 text-purple-500" />
            <div class="text-xl font-bold">{sessionsToday}</div>
            <div class="text-xs {textSecondary}">Hoy</div>
          </div>
          <div class="{darkMode ? 'bg-gray-700' : 'bg-blue-50'} rounded-lg p-3">
            <Award class="w-5 h-5 mx-auto mb-1 text-blue-500" />
            <div class="text-xl font-bold">{currentStreak}</div>
            <div class="text-xs {textSecondary}">Racha</div>
          </div>
          <div class="{darkMode ? 'bg-gray-700' : 'bg-green-50'} rounded-lg p-3">
            <TrendingUp class="w-5 h-5 mx-auto mb-1 text-green-500" />
            <div class="text-xl font-bold">{completedSessions.length}</div>
            <div class="text-xs {textSecondary}">Total</div>
          </div>
        </div>
      </div>

      <div class="{cardBg} rounded-2xl shadow-xl p-6">
        <h2 class="text-xl font-bold mb-4">📝 Tareas</h2>
        <div class="space-y-2 mb-4">
          <input type="text" bind:value={newTask} on:keypress={(e) => e.key === 'Enter' && addTask()}
            placeholder="Nueva tarea..." class="w-full px-4 py-2 rounded-lg {darkMode ? 'bg-gray-700 text-white' : 'bg-gray-100'}" />
          <div class="flex gap-2">
            <select bind:value={newTaskCategory} class="flex-1 px-4 py-2 rounded-lg {darkMode ? 'bg-gray-700 text-white' : 'bg-gray-100'}">
              <option value="">Sin categoría</option>
              {#each categories as cat}<option value={cat}>{cat}</option>{/each}
            </select>
            <button on:click={addTask} class="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600">
              <Plus class="w-5 h-5" />
            </button>
          </div>
        </div>
        <div class="space-y-2 max-h-96 overflow-y-auto">
          {#if tasks.length === 0}
            <p class="text-center {textSecondary} py-8">No hay tareas aún</p>
          {:else}
            {#each tasks as task (task.id)}
              <div class="flex items-center gap-2 p-3 rounded-lg {darkMode ? 'bg-gray-700' : 'bg-gray-50'}">
                <button on:click={() => toggleTask(task.id)}>
                  {#if task.completed}<CheckCircle class="w-5 h-5 text-green-500" />
                  {:else}<Circle class="w-5 h-5 text-gray-400" />{/if}
                </button>
                <div class="flex-1">
                  <div class="{task.completed ? 'line-through opacity-50' : ''}">{task.text}</div>
                  {#if task.category && task.category !== 'Sin categoría'}
                    <div class="flex items-center gap-1 mt-1">
                      <Tag class="w-3 h-3 text-purple-500" />
                      <span class="text-xs text-purple-500">{task.category}</span>
                    </div>
                  {/if}
                </div>
                <button on:click={() => deleteTask(task.id)} class="text-red-500 hover:scale-110 transition-transform">
                  <Trash2 class="w-4 h-4" />
                </button>
              </div>
            {/each}
          {/if}
        </div>
      </div>

      <div class="space-y-6">
        <div class="{cardBg} rounded-2xl shadow-xl p-6">
          <h2 class="text-xl font-bold mb-4">📊 Últimos 7 días</h2>
          <div class="flex items-end justify-between h-32 gap-1">
            {#each sessionsByDay as day}
              <div class="flex-1 flex flex-col items-center gap-2">
                <div class="w-full flex items-end justify-center h-24">
                  <div class="w-full bg-gradient-to-t from-purple-500 to-pink-500 rounded-t-lg"
                    style="height: {(day.count / maxSessions) * 100}%; min-height: {day.count > 0 ? '8px' : '0'}"></div>
                </div>
                <div class="text-xs {textSecondary}">{new Date(day.date).toLocaleDateString('es-ES', { weekday: 'short' })}</div>
                <div class="text-sm font-bold">{day.count}</div>
              </div>
            {/each}
          </div>
        </div>

        <div class="{cardBg} rounded-2xl shadow-xl p-6">
          <h2 class="text-xl font-bold mb-4">🏷️ Por categoría</h2>
          <div class="space-y-3">
            {#each tasksByCategory.filter(c => c.total > 0) as cat}
              <div>
                <div class="flex justify-between text-sm mb-1">
                  <span>{cat.category}</span>
                  <span class={textSecondary}>{cat.completed}/{cat.total}</span>
                </div>
                <div class="h-2 {darkMode ? 'bg-gray-700' : 'bg-gray-200'} rounded-full overflow-hidden">
                  <div class="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                    style="width: {(cat.completed / cat.total) * 100}%"></div>
                </div>
              </div>
            {/each}
          </div>
        </div>

        <div class="{cardBg} rounded-2xl shadow-xl p-6 text-center">
          <h2 class="text-xl font-bold mb-2">⏱️ Tiempo total</h2>
          <div class="text-4xl font-bold text-purple-500">
            {Math.floor(totalMinutes / 60)}h {totalMinutes % 60}m
          </div>
          <p class="text-sm {textSecondary}">de trabajo concentrado</p>
        </div>
      </div>
    </div>
  </div>
</div>
