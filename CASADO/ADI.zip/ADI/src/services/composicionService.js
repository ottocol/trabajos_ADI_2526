import { supabase } from "../config/supabase.js";

const TABLE = "Composicion";

export async function createCompo(datos) {
	const { data, error } = await supabase.from(TABLE).insert(datos).select().single();
	if (error) throw error;
	return data;
}

export async function obtenerComposicion(id) {
	const { data, error } = await supabase.from(TABLE).select("*").eq("id", id).single();
	if (error) throw error;
	return data;
}

export async function obtenerTodosComposicions(pagina = 1, porPagina = 20) {
	const desde = (pagina - 1) * porPagina;
	const hasta = desde + porPagina - 1;

	const { data, error, count } = await supabase
		.from(TABLE)
		.select("*", { count: "exact" })
		.order("created_at", { ascending: false })
		.range(desde, hasta);

	if (error) throw error;

	return {
		items: data,
		page: pagina,
		perPage: porPagina,
		totalItems: count,
		totalPages: Math.ceil(count / porPagina),
	};
}

export async function buscarComposicionPersonaje(personajeId) {
	const { data, error } = await supabase
		.from(TABLE)
		.select("*")
		.contains("personajes", [personajeId]);

	if (error) throw error;
	return data;
}

export async function buscarComposicionNombre(texto) {
	const { data, error } = await supabase
		.from(TABLE)
		.select("*")
		.ilike("nombre", `%${texto}%`);

	if (error) throw error;
	return data;
}

export async function obtenerComposicionesPorUsuario(usuarioId) {
	const { data, error } = await supabase
		.from(TABLE)
		.select("*")
		.eq("usuario", usuarioId)
		.order("created_at", { ascending: false });

	if (error) throw error;
	return data;
}

export async function deleteCompo(id) {
	const { error } = await supabase.from(TABLE).delete().eq("id", id);
	if (error) throw error;
	return true;
}

export async function editCompo(id, datos) {
	const { data, error } = await supabase.from(TABLE).update(datos).eq("id", id).select().single();
	if (error) throw error;
	return data;
}
