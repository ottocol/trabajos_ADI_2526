import { supabase } from "../config/supabase.js";

const TABLE = "Personaje";

export async function createPersonaje(datos) {
	const existentes = await buscarPersonajeNombre(datos.nombre);
	if (existentes.length > 0) {
		throw new Error(`Ya existe un personaje con el nombre "${datos.nombre}"`);
	}
	const { data, error } = await supabase.from(TABLE).insert(datos).select().single();
	if (error) throw error;
	return data;
}

export async function obtenerPersonaje(id) {
	const { data, error } = await supabase.from(TABLE).select("*").eq("id", id).single();
	if (error) throw error;
	return data;
}

export async function obtenerTodosPersonajes(pagina = 1, porPagina = 20) {
	const desde = (pagina - 1) * porPagina;
	const hasta = desde + porPagina - 1;

	const { data, error, count } = await supabase
		.from(TABLE)
		.select("*", { count: "exact" })
		.order("created_at", { ascending: false })
		.range(desde, hasta);

	if (error) throw error;

	return {
		items: data,
		page: pagina,
		perPage: porPagina,
		totalItems: count,
		totalPages: Math.ceil(count / porPagina),
	};
}

export async function buscarPersonajeSinergia(sinergiaId) {
	const { data, error } = await supabase
		.from(TABLE)
		.select("*")
		.contains("sinergias", [sinergiaId]);

	if (error) throw error;
	return data;
}

export async function buscarPersonajeNombre(texto) {
	const { data, error } = await supabase
		.from(TABLE)
		.select("*")
		.ilike("nombre", `%${texto}%`);

	if (error) throw error;
	return data;
}

export async function deletePersonaje(id) {
	const { error } = await supabase.from(TABLE).delete().eq("id", id);
	if (error) throw error;
	return true;
}

export async function editPersonaje(id, datos) {
	const { data, error } = await supabase.from(TABLE).update(datos).eq("id", id).select().single();
	if (error) throw error;
	return data;
}
