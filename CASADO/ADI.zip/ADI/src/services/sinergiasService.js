import { supabase } from "../config/supabase.js";
import { obtenerSinergiasDesdeRiot } from "./riotService.js";

const TABLE = "Sinergia";

export { obtenerSinergiasDesdeRiot };

export async function createSinergia(datos) {
	const existentes = await buscarSinergiasPorNombre(datos.nombre_sinergia);
	if (existentes.length > 0) {
		throw new Error(`Ya existe una sinergia con el nombre "${datos.nombre_sinergia}"`);
	}

	const { data: sinergia, error } = await supabase
		.from(TABLE)
		.insert(datos)
		.select()
		.single();

	if (error) throw error;

	const personajesIds = datos.personajes || [];
	for (const personajeId of personajesIds) {
		try {
			const { data: personaje } = await supabase
				.from("Personaje")
				.select("sinergias")
				.eq("id", personajeId)
				.single();

			const sinergiasPersonaje = [...(personaje?.sinergias || [])];
			if (!sinergiasPersonaje.includes(sinergia.id)) {
				sinergiasPersonaje.push(sinergia.id);
				await supabase
					.from("Personaje")
					.update({ sinergias: sinergiasPersonaje })
					.eq("id", personajeId);
			}
		} catch (error) {
			// Error al agregar sinergia
		}
	}

	return sinergia;
}

export async function obtenerSinergia(id) {
	const { data, error } = await supabase
		.from(TABLE)
		.select("*")
		.eq("id", id)
		.single();

	if (error) throw error;
	
	// Si tiene personajes, obtenerlos manualmente
	if (data?.personajes && data.personajes.length > 0) {
		const { data: personajesData } = await supabase
			.from("Personaje")
			.select("*")
			.in("id", data.personajes);
		
		data.expand = { personajes: personajesData || [] };
	}
	
	return data;
}

export async function obtenerTodasSinergias(pagina = 1, porPagina = 20) {
	const desde = (pagina - 1) * porPagina;
	const hasta = desde + porPagina - 1;

	const { data, error, count } = await supabase
		.from(TABLE)
		.select("*", { count: "exact" })
		.order("created_at", { ascending: false })
		.range(desde, hasta);

	if (error) throw error;

	return {
		items: data,
		page: pagina,
		perPage: porPagina,
		totalItems: count,
		totalPages: Math.ceil(count / porPagina),
	};
}

export async function buscarSinergiasPorNombre(texto) {
	const { data, error } = await supabase
		.from(TABLE)
		.select("*")
		.ilike("nombre_sinergia", `%${texto}%`);

	if (error) throw error;
	return data;
}

export async function deleteSinergia(id) {
	const { data: sinergia } = await supabase
		.from(TABLE)
		.select("personajes")
		.eq("id", id)
		.single();

	const personajesIds = sinergia?.personajes || [];

	const { error } = await supabase.from(TABLE).delete().eq("id", id);
	if (error) throw error;

	for (const personajeId of personajesIds) {
		try {
			const { data: personaje } = await supabase
				.from("Personaje")
				.select("sinergias")
				.eq("id", personajeId)
				.single();

			const sinergiasPersonaje = [...(personaje?.sinergias || [])];
			const nuevasSinergias = sinergiasPersonaje.filter((sId) => sId !== id);
			await supabase
				.from("Personaje")
				.update({ sinergias: nuevasSinergias })
				.eq("id", personajeId);
		} catch (error) {
			// Error al remover sinergia
		}
	}

	return true;
}

export async function editSinergia(id, datos) {
	const { data: sinergiaActual } = await supabase
		.from(TABLE)
		.select("personajes")
		.eq("id", id)
		.single();

	const personajesAnteriores = sinergiaActual?.personajes || [];
	const personajesNuevos = datos.personajes || [];

	const { data: sinergiaActualizada, error } = await supabase
		.from(TABLE)
		.update(datos)
		.eq("id", id)
		.select()
		.single();

	if (error) throw error;

	const personajesARemover = personajesAnteriores.filter((pId) => !personajesNuevos.includes(pId));
	for (const personajeId of personajesARemover) {
		try {
			const { data: personaje } = await supabase
				.from("Personaje")
				.select("sinergias")
				.eq("id", personajeId)
				.single();

			const sinergiasPersonaje = [...(personaje?.sinergias || [])];
			const nuevasSinergias = sinergiasPersonaje.filter((sId) => sId !== id);
			await supabase
				.from("Personaje")
				.update({ sinergias: nuevasSinergias })
				.eq("id", personajeId);
		} catch (error) {
			// Error al remover sinergia
		}
	}

	const personajesAAgregar = personajesNuevos.filter((pId) => !personajesAnteriores.includes(pId));
	for (const personajeId of personajesAAgregar) {
		try {
			const { data: personaje } = await supabase
				.from("Personaje")
				.select("sinergias")
				.eq("id", personajeId)
				.single();

			const sinergiasPersonaje = [...(personaje?.sinergias || [])];
			if (!sinergiasPersonaje.includes(id)) {
				sinergiasPersonaje.push(id);
				await supabase
					.from("Personaje")
					.update({ sinergias: sinergiasPersonaje })
					.eq("id", personajeId);
			}
		} catch (error) {
			// Error al agregar sinergia
		}
	}

	return sinergiaActualizada;
}
