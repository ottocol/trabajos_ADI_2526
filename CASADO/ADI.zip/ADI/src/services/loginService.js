import { supabase } from "../config/supabase.js";

const TABLE = "Usuario";

// Registra un nuevo usuario
export async function register(email, password, passwordConfirm, nombre) {
	try {
		if (password !== passwordConfirm) {
			throw new Error("Las contraseñas no coinciden");
		}

		// Crear usuario en Supabase Auth
		const { data: authData, error: authError } = await supabase.auth.signUp({
			email,
			password,
			options: {
				data: {
					nombre,
				},
			},
		});

		if (authError) throw authError;

		// Insertar datos adicionales en la tabla Usuario
		const { data: userData, error: userError } = await supabase
			.from(TABLE)
			.insert({
				id: authData.user.id,
				email,
				nombre,
				fecha_registro: new Date().toISOString(),
			})
			.select()
			.single();

		if (userError) throw userError;

		return {
			token: authData.session?.access_token,
			usuario: { ...userData, ...authData.user.user_metadata },
		};
	} catch (error) {
		throw new Error(`Error al registrar usuario: ${error.message}`);
	}
}

// Inicia sesión con email y contraseña
export async function login(email, password) {
	try {
		const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
			email,
			password,
		});

		if (authError) throw authError;

		// Obtener datos adicionales del usuario
		const { data: userData, error: userError } = await supabase
			.from(TABLE)
			.select("*")
			.eq("id", authData.user.id)
			.single();

		if (userError && userError.code !== "PGRST116") {
			// Si el usuario no existe en la tabla, créalo
			const { data: newUserData } = await supabase
				.from(TABLE)
				.insert({
					id: authData.user.id,
					email: authData.user.email,
					nombre: authData.user.user_metadata?.nombre || email.split("@")[0],
					fecha_registro: new Date().toISOString(),
				})
				.select()
				.single();
			
			return {
				token: authData.session?.access_token,
				usuario: { ...newUserData, ...authData.user.user_metadata },
			};
		}

		return {
			token: authData.session?.access_token,
			usuario: { ...userData, ...authData.user.user_metadata },
		};
	} catch (error) {
		throw new Error(`Error al iniciar sesión: ${error.message}`);
	}
}

// Cierra la sesión actual
export async function logout() {
	await supabase.auth.signOut();
}

export async function estaSesionActiva() {
	const { data } = await supabase.auth.getSession();
	return !!data.session;
}

export async function obtenerUsuarioActual() {
	const { data: { user } } = await supabase.auth.getUser();
	
	if (!user) return null;

	// Obtener datos adicionales de la tabla Usuario
	const { data: userData } = await supabase
		.from(TABLE)
		.select("*")
		.eq("id", user.id)
		.single();

	return { ...userData, ...user.user_metadata };
}

export async function obtenerToken() {
	const { data } = await supabase.auth.getSession();
	return data.session?.access_token || null;
}
