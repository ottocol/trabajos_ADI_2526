const RIOT_VERSION = "15.19.1";
const RIOT_BASE_URL = `https://ddragon.leagueoflegends.com/cdn/${RIOT_VERSION}/data/es_ES`;
const RIOT_VERSIONS_URL = "https://ddragon.leagueoflegends.com/api/versions.json";
const RIOT_IMG_BASE_URL = `https://ddragon.leagueoflegends.com/cdn/${RIOT_VERSION}/img`;

export async function fetchRiotVersion() {
	try {
		const response = await fetch(RIOT_VERSIONS_URL);
		if (!response.ok) {
			throw new Error(`Error al obtener versiones de Riot: ${response.status}`);
		}

		const versions = await response.json();

		if (!Array.isArray(versions) || versions.length === 0) {
			return "No hay versión";
		}

		return versions[0];
	} catch (error) {
		return "No hay versión";
	}
}

export async function obtenerSinergiasDesdeRiot() {
	try {
		const response = await fetch(`${RIOT_BASE_URL}/tft-trait.json`);
		if (!response.ok) {
			throw new Error(`Error al obtener datos de Riot: ${response.status}`);
		}

		const jsonData = await response.json();

		const sinergiasFiltradas = Object.values(jsonData.data).filter((sinergia) => {
			return sinergia.id.startsWith("TFT15_") && !sinergia.id.includes("Mechanic");
		});

		return sinergiasFiltradas.map((sinergia) => ({
			id_riot: sinergia.id,
			nombre: sinergia.name,
			imagen: sinergia.image?.full ? `${RIOT_IMG_BASE_URL}/tft-trait/${sinergia.image.full}` : "",
		}));
	} catch (error) {
		throw new Error(`Error al obtener sinergias de Riot: ${error.message}`);
	}
}

export async function obtenerCampeonesDesdeRiot() {
	try {
		const response = await fetch(`${RIOT_BASE_URL}/tft-champion.json`);
		if (!response.ok) {
			throw new Error(`Error al obtener datos de Riot: ${response.status}`);
		}

		const jsonData = await response.json();

		const campeonesFiltrados = Object.values(jsonData.data).filter((campeon) => {
			return campeon.id.startsWith("TFT15_");
		});

		return campeonesFiltrados.map((campeon) => ({
			id_riot: campeon.id,
			nombre: campeon.name,
			coste: campeon.tier,
			imagen: campeon.image?.full ? `${RIOT_IMG_BASE_URL}/tft-champion/${campeon.image.full}` : "",
			sinergias: campeon.traits || [],
		}));
	} catch (error) {
		throw new Error(`Error al obtener campeones de Riot: ${error.message}`);
	}
}
