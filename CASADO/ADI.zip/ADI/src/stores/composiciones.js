import { ref, computed } from "vue";
import { defineStore } from "pinia";
import {
	obtenerTodosComposicions,
	obtenerComposicion as obtenerComposicionService,
	createCompo,
	editCompo,
	deleteCompo,
	buscarComposicionNombre,
	buscarComposicionPersonaje,
	obtenerComposicionesPorUsuario,
} from "@/services/composicionService.js";
import { obtenerPersonaje } from "@/services/personajeService.js";
import { useAuthStore } from "@/stores/auth.js";

export const useComposicionesStore = defineStore("composiciones", () => {
	const composiciones = ref([]);
	const loading = ref(false);
	const error = ref(null);
	const searchQuery = ref("");

	const composicionesFiltradas = computed(() => {
		if (!searchQuery.value) {
			return composiciones.value;
		}
		return composiciones.value.filter((composicion) =>
			composicion.nombre.toLowerCase().includes(searchQuery.value.toLowerCase()),
		);
	});

	const composicionesDelUsuario = computed(() => {
		const authStore = useAuthStore();
		if (!authStore.isAuthenticated || !authStore.user) {
			return [];
		}
		return composiciones.value.filter((comp) => comp.usuario_id === authStore.user.id);
	});

	function mapearComposicion(composicion) {
		return {
			id: composicion.id,
			nombre: composicion.nombre || "Sin nombre",
			personajes: composicion.personajes || [],
			personajesData: composicion.personajesData || [],
			usuario_id: composicion.usuario || composicion.usuario_id,
			tasa_victoria: composicion.tasa_de_victorias || composicion.tasa_victoria || 0,
			posicion_promedio: composicion.posicion_promedio || 0,
			tasa_seleccion: composicion.tasa_de_seleccion || 0,
			tasa_top4: composicion.tasa_top_4 || 0,
			created: composicion.created,
			updated: composicion.updated,
		};
	}

	async function cargarPersonajesParaComposicion(composicion) {
		if (!composicion.personajes || composicion.personajes.length === 0) {
			return [];
		}

		const personajesData = [];
		for (const personajeId of composicion.personajes) {
			try {
				const personaje = await obtenerPersonaje(personajeId);
				personajesData.push({
					id: personaje.id,
					nombre: personaje.nombre,
					imagen: personaje.imagen,
					slug: personaje.nombre?.toLowerCase().replace(/\s+/g, "-"),
				});
			} catch (err) {
				// Error al cargar personaje
			}
		}
		return personajesData;
	}

	async function cargarTodasComposiciones(pagina = 1, porPagina = 100) {
		try {
			loading.value = true;
			error.value = null;

			const resultado = await obtenerTodosComposicions(pagina, porPagina);

			const composicionesConPersonajes = [];
			for (const comp of resultado.items) {
				const personajesData = await cargarPersonajesParaComposicion(comp);
				composicionesConPersonajes.push(
					mapearComposicion({
						...comp,
						personajesData,
					}),
				);
			}

			composiciones.value = composicionesConPersonajes;

			return composiciones.value;
		} catch (err) {
			error.value = "Error al cargar las composiciones: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function obtenerComposicion(id) {
		try {
			const composicion = await obtenerComposicionService(id);
			const personajesData = await cargarPersonajesParaComposicion(composicion);
			return mapearComposicion({
				...composicion,
				personajesData,
			});
		} catch (err) {
			throw err;
		}
	}

	async function crearComposicion(datos) {
		try {
			loading.value = true;
			error.value = null;

			const authStore = useAuthStore();
			if (!authStore.isAuthenticated || !authStore.user) {
				throw new Error("Debes estar autenticado para crear una composición");
			}

			const datosConUsuario = {
				...datos,
				usuario: authStore.user.id,
			};

			const nuevaComposicion = await createCompo(datosConUsuario);
			const personajesData = await cargarPersonajesParaComposicion(nuevaComposicion);
			const composicionMapeada = mapearComposicion({
				...nuevaComposicion,
				personajesData,
			});

			composiciones.value.unshift(composicionMapeada);

			return composicionMapeada;
		} catch (err) {
			error.value = "Error al crear composición: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function editarComposicion(id, datos) {
		try {
			loading.value = true;
			error.value = null;

			const authStore = useAuthStore();
			if (!authStore.isAuthenticated) {
				throw new Error("Debes estar autenticado para editar una composición");
			}

			const composicionExistente = composiciones.value.find((c) => c.id === id);
			if (composicionExistente && composicionExistente.usuario_id !== authStore.user.id) {
				throw new Error("No tienes permiso para editar esta composición");
			}

			const composicionActualizada = await editCompo(id, datos);
			const personajesData = await cargarPersonajesParaComposicion(composicionActualizada);
			const composicionMapeada = mapearComposicion({
				...composicionActualizada,
				personajesData,
			});

			const index = composiciones.value.findIndex((c) => c.id === id);
			if (index !== -1) {
				composiciones.value[index] = composicionMapeada;
			}

			return composicionMapeada;
		} catch (err) {
			error.value = "Error al editar composición: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function eliminarComposicion(id) {
		try {
			loading.value = true;
			error.value = null;

			const authStore = useAuthStore();
			if (!authStore.isAuthenticated) {
				throw new Error("Debes estar autenticado para eliminar una composición");
			}

			const composicionExistente = composiciones.value.find((c) => c.id === id);
			if (composicionExistente && composicionExistente.usuario_id !== authStore.user.id) {
				throw new Error("No tienes permiso para eliminar esta composición");
			}

			await deleteCompo(id);

			composiciones.value = composiciones.value.filter((c) => c.id !== id);

			return true;
		} catch (err) {
			error.value = "Error al eliminar composición: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function buscarComposiciones(texto) {
		try {
			loading.value = true;
			error.value = null;

			const resultado = await buscarComposicionNombre(texto);

			const composicionesConPersonajes = [];
			for (const comp of resultado) {
				const personajesData = await cargarPersonajesParaComposicion(comp);
				composicionesConPersonajes.push(
					mapearComposicion({
						...comp,
						personajesData,
					}),
				);
			}

			composiciones.value = composicionesConPersonajes;

			return composiciones.value;
		} catch (err) {
			error.value = "Error al buscar composiciones: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function buscarComposicionesPorPersonaje(personajeId) {
		try {
			loading.value = true;
			error.value = null;

			const resultado = await buscarComposicionPersonaje(personajeId);

			const composicionesConPersonajes = [];
			for (const comp of resultado) {
				const personajesData = await cargarPersonajesParaComposicion(comp);
				composicionesConPersonajes.push(
					mapearComposicion({
						...comp,
						personajesData,
					}),
				);
			}

			return composicionesConPersonajes;
		} catch (err) {
			error.value = "Error al buscar composiciones por personaje: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function cargarComposicionesDelUsuario(usuarioId) {
		try {
			loading.value = true;
			error.value = null;

			const resultado = await obtenerComposicionesPorUsuario(usuarioId);

			const composicionesConPersonajes = [];
			for (const comp of resultado) {
				const personajesData = await cargarPersonajesParaComposicion(comp);
				composicionesConPersonajes.push(
					mapearComposicion({
						...comp,
						personajesData,
					}),
				);
			}

			return composicionesConPersonajes;
		} catch (err) {
			error.value = "Error al cargar composiciones del usuario: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	function setSearchQuery(query) {
		searchQuery.value = query;
	}

	function limpiarError() {
		error.value = null;
	}

	return {
		composiciones,
		loading,
		error,
		searchQuery,
		composicionesFiltradas,
		composicionesDelUsuario,
		cargarTodasComposiciones,
		obtenerComposicion,
		crearComposicion,
		editarComposicion,
		eliminarComposicion,
		buscarComposiciones,
		buscarComposicionesPorPersonaje,
		cargarComposicionesDelUsuario,
		setSearchQuery,
		limpiarError,
	};
});
