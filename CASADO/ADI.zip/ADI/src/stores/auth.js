import { ref, computed } from "vue";
import { defineStore } from "pinia";
import {
	login as loginService,
	register as registerService,
	logout as logoutService,
	estaSesionActiva,
	obtenerUsuarioActual,
	obtenerToken,
} from "@/services/loginService.js";
import { editUser } from "@/services/usuarioService.js";
import { supabase } from "@/config/supabase.js";

export const useAuthStore = defineStore("auth", () => {
	// Datos
	const user = ref(null);
	const token = ref(null);

	// Getters
	const isAuthenticated = computed(() => !!token.value);
	const userName = computed(() => user.value?.nombre || "Invitado");
	const userEmail = computed(() => user.value?.email || "");
	const userFechaRegistro = computed(() => {
		if (!user.value?.fecha_registro) return "";
		const fecha = new Date(user.value.fecha_registro);
		return fecha.toLocaleDateString("es-ES");
	});
	const userAvatar = computed(() => {
		if (!user.value?.avatar) return null;
		// Generar URL pública del storage de Supabase
		const { data } = supabase.storage
			.from("avatars")
			.getPublicUrl(`${user.value.id}/${user.value.avatar}`);
		return data?.publicUrl || null;
	});

	// Funciones
	async function login(email, password) {
		try {
			const response = await loginService(email, password);
			user.value = response.usuario;
			token.value = response.token;
			return response;
		} catch (error) {
			throw error;
		}
	}

	async function register(email, password, passwordConfirm, nombre) {
		try {
			const response = await registerService(email, password, passwordConfirm, nombre);
			user.value = response.usuario;
			token.value = response.token;
			return response;
		} catch (error) {
			throw error;
		}
	}

	async function logout() {
		await logoutService();
		user.value = null;
		token.value = null;
	}

	async function checkAuth() {
		const sesionActiva = await estaSesionActiva();
		if (sesionActiva) {
			user.value = await obtenerUsuarioActual();
			token.value = await obtenerToken();
		}
	}

	async function updateProfile(datos) {
		try {
			if (!user.value?.id) throw new Error("Usuario no autenticado");

			const updatedUser = await editUser(user.value.id, datos);
			user.value = updatedUser;
			return updatedUser;
		} catch (error) {
			throw error;
		}
	}

	async function uploadAvatar(file) {
		try {
			if (!user.value?.id) throw new Error("Usuario no autenticado");

			const fileExt = file.name.split(".").pop();
			const fileName = `avatar.${fileExt}`;
			const filePath = `${user.value.id}/${fileName}`;

			// Subir archivo al storage
			const { error: uploadError } = await supabase.storage
				.from("avatars")
				.upload(filePath, file, { upsert: true });

			if (uploadError) throw uploadError;

			// Actualizar referencia en la base de datos
			const updatedUser = await editUser(user.value.id, { avatar: fileName });
			user.value = updatedUser;

			return updatedUser;
		} catch (error) {
			throw error;
		}
	}

	return {
		user,
		token,
		isAuthenticated,
		userName,
		userEmail,
		userFechaRegistro,
		userAvatar,
		login,
		register,
		logout,
		checkAuth,
		updateProfile,
		uploadAvatar,
	};
});
