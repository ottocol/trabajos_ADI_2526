import { ref, computed } from "vue";
import { defineStore } from "pinia";
import {
	obtenerTodosPersonajes,
	buscarPersonajeNombre,
	buscarPersonajeSinergia,
	obtenerPersonaje as obtenerPersonajeService,
	createPersonaje,
} from "@/services/personajeService.js";
import { obtenerSinergia } from "@/services/sinergiasService.js";
import { obtenerCampeonesDesdeRiot } from "@/services/riotService.js";

export const usePersonajesStore = defineStore("personajes", () => {
	const personajes = ref([]);
	const loading = ref(false);
	const error = ref(null);
	const searchQuery = ref("");
	const cache = ref(new Map());

	const personajesFiltrados = computed(() => {
		if (!searchQuery.value) {
			return personajes.value;
		}
		return personajes.value.filter((personaje) => personaje.nombre.toLowerCase().includes(searchQuery.value.toLowerCase()));
	});

	async function cargarSinergiasParaPersonaje(sinergiasIds) {
		if (!sinergiasIds || !Array.isArray(sinergiasIds) || sinergiasIds.length === 0) {
			return [];
		}

		const sinergias = [];
		for (const id of sinergiasIds) {
			try {
				const sinergia = await obtenerSinergia(id);
				sinergias.push({
					id: sinergia.id,
					nombre: sinergia.nombre_sinergia || sinergia.nombre || "Sin nombre",
					imagen: sinergia.imagen && sinergia.imagen.trim() !== "" ? sinergia.imagen : "/helicoptero.jpg",
					slug: (sinergia.nombre_sinergia || sinergia.nombre)?.toLowerCase().replace(/\s+/g, "-"),
				});
			} catch (error) {
				// Error al cargar sinergia
			}
		}

		return sinergias;
	}

	function mapearPersonaje(personaje, sinergias = []) {
		return {
			id: personaje.id,
			nombre: personaje.nombre || "Sin nombre",
			imagen: personaje.imagen && personaje.imagen.trim() !== "" ? personaje.imagen : "/helicoptero.jpg",
			slug: personaje.nombre?.toLowerCase().replace(/\s+/g, "-"),
			vida: personaje.vida || 0,
			velocidad_de_ataque: personaje.velocidad_de_ataque || 0,
			dano_de_ataque: personaje.dano_de_ataque || 0,
			poder_de_habilidad: personaje.poder_de_habilidad || 0,
			armadura: personaje.armadura || 0,
			resistencia_magica: personaje.resistencia_magica || 0,
			probabilidad_de_critico: personaje.probabilidad_de_critico || 0,
			mana_habilidad: personaje.mana_habilidad || 0,
			coste: personaje.coste || 0,
			nombre_habilidad: personaje.nombre_habilidad || "",
			desc_habilidad: personaje.desc_habilidad || "",
			sinergias: sinergias,
		};
	}

	async function cargarTodosPersonajes(pagina = 1, porPagina = 100) {
		try {
			loading.value = true;
			error.value = null;

			const resultado = await obtenerTodosPersonajes(pagina, porPagina);

			const todosPersonajes = [];
			for (const personaje of resultado.items) {
				const sinergias = await cargarSinergiasParaPersonaje(personaje.sinergias);
				const personajeMapeado = mapearPersonaje(personaje, sinergias);
				todosPersonajes.push(personajeMapeado);
				cache.value.set(personajeMapeado.id, personajeMapeado);
			}

			personajes.value = todosPersonajes;

			return personajes.value;
		} catch (err) {
			error.value = "Error al cargar los personajes: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function obtenerPersonaje(id, usarCache = true) {
		try {
			if (usarCache && cache.value.has(id)) {
				return cache.value.get(id);
			}

			const personaje = await obtenerPersonajeService(id);
			const sinergias = await cargarSinergiasParaPersonaje(personaje.sinergias);
			const personajeMapeado = mapearPersonaje(personaje, sinergias);

			cache.value.set(id, personajeMapeado);

			return personajeMapeado;
		} catch (err) {
			throw err;
		}
	}

	async function buscarPersonajes(texto) {
		try {
			loading.value = true;
			error.value = null;

			const resultado = await buscarPersonajeNombre(texto);

			const personajesBuscados = [];
			for (const personaje of resultado) {
				const sinergias = await cargarSinergiasParaPersonaje(personaje.sinergias);
				personajesBuscados.push(mapearPersonaje(personaje, sinergias));
			}

			personajes.value = personajesBuscados;

			return personajes.value;
		} catch (err) {
			error.value = "Error al buscar personajes: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function buscarPersonajesPorSinergia(sinergiaId) {
		try {
			loading.value = true;
			error.value = null;

			const resultado = await buscarPersonajeSinergia(sinergiaId);

			const personajesFiltrados = [];
			for (const personaje of resultado) {
				const sinergias = await cargarSinergiasParaPersonaje(personaje.sinergias);
				personajesFiltrados.push(mapearPersonaje(personaje, sinergias));
			}

			return personajesFiltrados;
		} catch (err) {
			error.value = "Error al buscar personajes por sinergia: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	function setSearchQuery(query) {
		searchQuery.value = query;
	}

	function limpiarError() {
		error.value = null;
	}

	function limpiarCache() {
		cache.value.clear();
	}

	async function rellenarBaseDatosDesdeRiot() {
		try {
			loading.value = true;
			error.value = null;

			const campeonesRiot = await obtenerCampeonesDesdeRiot();

			const personajesCreados = [];
			const personajesOmitidos = [];
			const personajesError = [];

			for (const campeon of campeonesRiot) {
				try {
					const personajesExistentes = await buscarPersonajeNombre(campeon.nombre);

					if (personajesExistentes.length > 0) {
						personajesOmitidos.push(campeon.nombre);
						continue;
					}

					const nuevoPersonaje = {
						nombre: campeon.nombre,
						vida: 100,
						velocidad_de_ataque: 1.0,
						dano_de_ataque: 50,
						poder_de_habilidad: 100,
						armadura: 20,
						resistencia_magica: 20,
						probabilidad_de_critico: 25,
						mana_habilidad: 50,
						coste: campeon.coste,
						nombre_habilidad: "Habilidad desconocida",
						desc_habilidad: "Descripción no disponible",
						imagen: campeon.imagen,
						sinergias: [],
					};

					const personajeCreado = await createPersonaje(nuevoPersonaje);
					personajesCreados.push(personajeCreado);
				} catch (err) {
					personajesError.push({ nombre: campeon.nombre, error: err.message });
				}
			}

			return {
				exitosos: personajesCreados,
				omitidos: personajesOmitidos,
				errores: personajesError,
				total: campeonesRiot.length,
			};
		} catch (err) {
			error.value = "Error al rellenar base de datos desde Riot: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	return {
		personajes,
		loading,
		error,
		searchQuery,
		personajesFiltrados,
		cargarTodosPersonajes,
		obtenerPersonaje,
		buscarPersonajes,
		buscarPersonajesPorSinergia,
		setSearchQuery,
		limpiarError,
		limpiarCache,
		rellenarBaseDatosDesdeRiot,
	};
});
