import { ref, computed } from "vue";
import { defineStore } from "pinia";
import {
	obtenerTodasSinergias,
	buscarSinergiasPorNombre,
	obtenerSinergia as obtenerSinergiaService,
	createSinergia,
	editSinergia,
	deleteSinergia,
} from "@/services/sinergiasService.js";
import { obtenerPersonaje } from "@/services/personajeService.js";
import { obtenerSinergiasDesdeRiot } from "@/services/riotService.js";

export const useSinergiasStore = defineStore("sinergias", () => {
	const sinergias = ref([]);
	const loading = ref(false);
	const error = ref(null);
	const searchQuery = ref("");

	const sinergiasFiltradas = computed(() => {
		if (!searchQuery.value) {
			return sinergias.value;
		}
		return sinergias.value.filter((sinergia) => sinergia.nombre.toLowerCase().includes(searchQuery.value.toLowerCase()));
	});

	async function cargarPersonajesParaSinergia(personajesIds) {
		if (!personajesIds || !Array.isArray(personajesIds) || personajesIds.length === 0) {
			return [];
		}

		const personajesPromises = personajesIds.map(async (id) => {
			try {
				const personaje = await obtenerPersonaje(id);
				return {
					id: personaje.id,
					nombre: personaje.nombre,
					imagen: personaje.imagen && personaje.imagen.trim() !== "" ? personaje.imagen : "/helicoptero.jpg",
					slug: personaje.nombre?.toLowerCase().replace(/\s+/g, "-"),
				};
			} catch (error) {
				return null;
			}
		});

		const resultados = await Promise.all(personajesPromises);
		return resultados.filter((p) => p !== null);
	}

	function mapearSinergia(sinergia) {
		const unidades = {};
		for (let i = 1; i <= 10; i++) {
			const campo = `Unidad${i}`;
			unidades[i] = sinergia[campo] || "—";
		}

		const personajes = sinergia.expand?.personajes
			? sinergia.expand.personajes.map((p) => ({
					id: p.id,
					nombre: p.nombre,
					imagen: p.imagen && p.imagen.trim() !== "" ? p.imagen : "/helicoptero.jpg",
					slug: p.nombre?.toLowerCase().replace(/\s+/g, "-"),
				}))
			: [];

		return {
			id: sinergia.id,
			nombre: sinergia.nombre_sinergia || sinergia.nombre || "Sin nombre",
			imagen: sinergia.imagen || "/helicoptero.jpg",
			slug: (sinergia.nombre_sinergia || sinergia.nombre || "sin-nombre").toLowerCase().replace(/\s+/g, "-"),
			unidades: unidades,
			personajes: personajes,
		};
	}

	async function cargarTodasSinergias(pagina = 1, porPagina = 100) {
		try {
			loading.value = true;
			error.value = null;

			const resultado = await obtenerTodasSinergias(pagina, porPagina);

			sinergias.value = resultado.items.map(mapearSinergia);
			return sinergias.value;
		} catch (err) {
			error.value = "Error al cargar las sinergias: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function buscarSinergias(texto) {
		try {
			loading.value = true;
			error.value = null;

			const resultado = await buscarSinergiasPorNombre(texto);

			sinergias.value = resultado.map(mapearSinergia);
			return sinergias.value;
		} catch (err) {
			error.value = "Error al buscar sinergias: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function obtenerSinergia(id) {
		try {
			const sinergia = await obtenerSinergiaService(id);
			return mapearSinergia(sinergia);
		} catch (err) {
			throw err;
		}
	}

	function setSearchQuery(query) {
		searchQuery.value = query;
	}

	function limpiarError() {
		error.value = null;
	}

	async function rellenarBaseDatosConSinergiasDesdeRiot() {
		try {
			loading.value = true;
			error.value = null;

			const sinergiasRiot = await obtenerSinergiasDesdeRiot();

			const sinergiasCreadas = [];
			const sinergiasOmitidas = [];
			const sinergiasError = [];

			for (const sinergia of sinergiasRiot) {
				try {
					const sinergiasExistentes = await buscarSinergiasPorNombre(sinergia.nombre);

					if (sinergiasExistentes.length > 0) {
						sinergiasOmitidas.push(sinergia.nombre);
						continue;
					}

					const nuevaSinergia = {
						nombre_sinergia: sinergia.nombre,
						Unidad1: "",
						Unidad2: "",
						Unidad3: "",
						Unidad4: "",
						Unidad5: "",
						Unidad6: "",
						Unidad7: "",
						Unidad8: "",
						Unidad9: "",
						Unidad10: "",
						imagen: sinergia.imagen,
						personajes: [],
					};

					const sinergiaCreada = await createSinergia(nuevaSinergia);
					sinergiasCreadas.push(sinergiaCreada);
				} catch (err) {
					sinergiasError.push({ nombre: sinergia.nombre, error: err.message });
				}
			}

			return {
				exitosos: sinergiasCreadas,
				omitidos: sinergiasOmitidas,
				errores: sinergiasError,
				total: sinergiasRiot.length,
			};
		} catch (err) {
			error.value = "Error al rellenar base de datos con sinergias desde Riot: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function editarSinergia(id, datos) {
		try {
			loading.value = true;
			error.value = null;

			const datosActualizados = {
				nombre_sinergia: datos.nombre,
				imagen: datos.imagen || "/helicoptero.jpg",
				personajes: datos.personajes || [],
			};

			for (let i = 1; i <= 10; i++) {
				datosActualizados[`Unidad${i}`] = datos.unidades?.[i] || "";
			}

			await editSinergia(id, datosActualizados);

			await cargarTodasSinergias();
		} catch (err) {
			error.value = "Error al editar la sinergia: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	async function eliminarSinergia(id) {
		try {
			loading.value = true;
			error.value = null;

			await deleteSinergia(id);

			await cargarTodasSinergias();
		} catch (err) {
			error.value = "Error al eliminar la sinergia: " + err.message;
			throw err;
		} finally {
			loading.value = false;
		}
	}

	return {
		sinergias,
		loading,
		error,
		searchQuery,
		sinergiasFiltradas,
		cargarTodasSinergias,
		buscarSinergias,
		obtenerSinergia,
		setSearchQuery,
		limpiarError,
		rellenarBaseDatosConSinergiasDesdeRiot,
		editarSinergia,
		eliminarSinergia,
	};
});
