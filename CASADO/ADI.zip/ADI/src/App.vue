<script setup>
import { useAuthStore } from "./stores/auth";
import { usePersonajesStore } from "./stores/personajes";
import { useSinergiasStore } from "./stores/sinergias";
import { onMounted } from "vue";

const authStore = useAuthStore();
const personajesStore = usePersonajesStore();
const sinergiasStore = useSinergiasStore();

onMounted(async () => {
	await authStore.checkAuth();

	setTimeout(async () => {
		try {
			const resultado = await personajesStore.rellenarBaseDatosDesdeRiot();
			if (resultado.exitosos.length > 0) {
				await personajesStore.cargarTodosPersonajes();
			}
		} catch (error) {
			// Error al rellenar personajes
		}

		try {
			const resultadoSinergias = await sinergiasStore.rellenarBaseDatosConSinergiasDesdeRiot();
			if (resultadoSinergias.exitosos.length > 0) {
				await sinergiasStore.cargarTodasSinergias();
			}
		} catch (error) {
			// Error al rellenar sinergias
		}
	}, 1000);
});
</script>

<template>
	<v-app>
		<router-view />
	</v-app>
</template>

<style>
/* Aplicar el fondo a v-app en lugar de body */
.v-application {
	background-color: var(--bg-primary) !important;
}
</style>
