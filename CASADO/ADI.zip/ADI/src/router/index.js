import { createRouter, createWebHistory } from "vue-router";
import HomeView from "@/views/HomeView.vue";
import AuthView from "@/views/AuthView.vue";
import SinergiasView from "@/views/SinergiasView.vue";
import ProfileView from "@/views/ProfileView.vue";
import { useAuthStore } from "@/stores/auth";
import PersonajesView from "@/views/PersonajesView.vue";
import PersonajeDetailView from "@/views/PersonajeDetailView.vue";
import SinergiaDetailView from "@/views/SinergiaDetailView.vue";
import ComposicionesView from "@/views/ComposicionesView.vue";

const router = createRouter({
	history: createWebHistory(import.meta.env.BASE_URL),
	routes: [
		{
			path: "/",
			name: "home",
			component: HomeView,
		},
		{
			path: "/auth",
			name: "auth",
			component: AuthView,
		},
		{
			path: "/sinergias",
			name: "sinergias",
			component: SinergiasView,
		},
		{
			path: "/sinergias/:slug",
			name: "sinergia-detail",
			component: SinergiaDetailView,
		},
		{
			path: "/personajes",
			name: "personajes",
			component: PersonajesView,
		},
		{
			path: "/personajes/:slug",
			name: "personaje-detail",
			component: PersonajeDetailView,
		},
		{
			path: "/composiciones",
			name: "composiciones",
			component: ComposicionesView,
		},
		{
			path: "/profile",
			name: "profile",
			component: ProfileView,
			meta: { requiresAuth: true },
		},
	],
});

router.beforeEach((to, from, next) => {
	const authStore = useAuthStore();
	if (to.meta.requiresAuth && !authStore.isAuthenticated) {
		next({ name: "auth" });
	} else if (to.name === "auth" && authStore.isAuthenticated) {
		next({ name: "profile" });
	} else {
		next();
	}
});

export default router;
