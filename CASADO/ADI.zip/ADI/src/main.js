import { createApp } from "vue";
import { createPinia } from "pinia";

import App from "./App.vue";
import router from "./router";

// Vuetify
import "vuetify/styles";
import "./CSS/global.css";
import { createVuetify } from "vuetify";
import * as components from "vuetify/components";
import * as directives from "vuetify/directives";
import "@mdi/font/css/materialdesignicons.css";

// VeeValidate
import { configure, defineRule } from "vee-validate";
import { required, email, min, max, confirmed } from "@vee-validate/rules";

// Definir reglas de validación
defineRule("required", required);
defineRule("email", email);
defineRule("min", min);
defineRule("max", max);
defineRule("confirmed", confirmed);

// Configurar mensajes en español
configure({
	generateMessage: (context) => {
		const messages = {
			required: `El campo ${context.field} es obligatorio`,
			email: `El campo ${context.field} debe ser un email válido`,
			min: `El campo ${context.field} debe tener al menos ${context.rule.params[0]} caracteres`,
			max: `El campo ${context.field} no puede tener más de ${context.rule.params[0]} caracteres`,
			confirmed: `La confirmación de contraseña no es igual a la contraseña`,
		};
		return messages[context.rule.name] || `El campo ${context.field} no es válido`;
	},
});

const vuetify = createVuetify({
	components,
	directives,
});

const app = createApp(App);

app.use(createPinia());
app.use(router);
app.use(vuetify);

app.mount("#app");
