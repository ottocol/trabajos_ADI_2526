<script setup>
import "@/CSS/global.css";
import HeaderComponent from "@/components/HeaderComponent.vue";
import FooterComponent from "@/components/FooterComponent.vue";
import SinergiaComponent from "@/components/SinergiaComponent.vue";
import SearchBarComponent from "@/components/SearchBarComponent.vue";
import { ref, onMounted, computed } from 'vue';
import { useSinergiasStore } from '@/stores/sinergias.js';

const sinergiasStore = useSinergiasStore();
const sugerencias = ref(['Sniper', 'Star guardian']);
const paginaActual = ref(1);
const elementosPorPagina = 10;

const totalPaginas = computed(() => {
	return Math.ceil(sinergiasStore.sinergiasFiltradas.length / elementosPorPagina);
});

const sinergiasPaginadas = computed(() => {
	const inicio = (paginaActual.value - 1) * elementosPorPagina;
	const fin = inicio + elementosPorPagina;
	return sinergiasStore.sinergiasFiltradas.slice(inicio, fin);
});

onMounted(async () => {
	await sinergiasStore.cargarTodasSinergias();
});

const handleSearch = async () => {
	paginaActual.value = 1;
	if (!sinergiasStore.searchQuery.trim()) {
		await sinergiasStore.cargarTodasSinergias();
		return;
	}
	
	await sinergiasStore.buscarSinergias(sinergiasStore.searchQuery);
};

const cambiarPagina = (pagina) => {
	paginaActual.value = pagina;
	window.scrollTo({ top: 0, behavior: 'smooth' });
};

const handleSinergiaActualizada = async () => {
	await sinergiasStore.cargarTodasSinergias();
};
</script>

<template>
	<div>
		<HeaderComponent />
		<main>
			<h1>Sinergias del set 15 de TFT</h1>
			
			<SearchBarComponent 
				v-model="sinergiasStore.searchQuery"
				:sugerencias="sugerencias"
				placeholder="Busca sinergias..."
				@search="handleSearch"
			/>

		<div v-if="sinergiasStore.loading" style="text-align: center; padding: 2rem;">
			<p>Cargando sinergias...</p>
		</div>

		<div v-else-if="sinergiasStore.error" style="text-align: center; padding: 2rem; color: red;">
			<p>{{ sinergiasStore.error }}</p>
		</div>

		<template v-else>
			<SinergiaComponent 
				v-for="sinergia in sinergiasPaginadas" 
				:key="sinergia.id"
				:sinergia="sinergia"
				@updated="handleSinergiaActualizada"
			/>

			<div v-if="sinergiasStore.sinergiasFiltradas.length === 0" style="text-align: center; padding: 2rem;">
				<p>No se encontraron sinergias.</p>
			</div>

			<!-- Controles de paginación -->
			<div v-if="totalPaginas > 1" class="pagination">
				<v-pagination
					v-model="paginaActual"
					:length="totalPaginas"
					:total-visible="7"
					@update:model-value="cambiarPagina"
				></v-pagination>
			</div>
		</template>
		</main>
		<FooterComponent />
	</div>
</template>

<style scoped>
.pagination {
	display: flex;
	justify-content: center;
	align-items: center;
	margin: 2rem 0;
	padding: 1rem;
}
</style>
