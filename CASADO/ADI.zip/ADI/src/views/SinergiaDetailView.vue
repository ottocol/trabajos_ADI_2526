<script setup>
import "@/CSS/global.css";
import HeaderComponent from "@/components/HeaderComponent.vue";
import FooterComponent from "@/components/FooterComponent.vue";
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useSinergiasStore } from "@/stores/sinergias.js";

const route = useRoute();
const router = useRouter();
const sinergiasStore = useSinergiasStore();
const sinergia = ref(null);
const loading = ref(true);
const error = ref(null);

onMounted(async () => {
	try {
		loading.value = true;
		error.value = null;

		const slug = decodeURIComponent(route.params.slug);

		if (sinergiasStore.sinergias.length === 0) {
			await sinergiasStore.cargarTodasSinergias();
		}

		const sinergiaEncontrada = sinergiasStore.sinergias.find(
			(s) =>
				s.slug === slug ||
				s.slug === slug.toLowerCase().replace(/\s+/g, "-") ||
				s.nombre.toLowerCase() === slug.toLowerCase() ||
				s.nombre.toLowerCase().replace(/\s+/g, "-") === slug.toLowerCase(),
		);

		if (!sinergiaEncontrada) {
			error.value = `No se encontró la sinergia "${slug}"`;
			return;
		}

		sinergia.value = sinergiaEncontrada;
	} catch (err) {
		error.value = "Error al cargar la sinergia: " + err.message;
	} finally {
		loading.value = false;
	}
});

const volverASinergias = () => {
	router.push("/sinergias");
};
</script>

<template>
	<div>
		<HeaderComponent />
		<main>
			<!-- Botón volver -->
			<div class="back-button-container">
				<button @click="volverASinergias" class="back-button">← Volver a Sinergias</button>
			</div>

			<!-- Estado de carga -->
			<div v-if="loading" class="loading-state">
				<div class="spinner"></div>
				<p>Cargando sinergia...</p>
			</div>

			<!-- Estado de error -->
			<div v-else-if="error" class="error-state">
				<p class="error-message">{{ error }}</p>
				<button @click="volverASinergias" class="btn-secondary">Volver a Sinergias</button>
			</div>

			<!-- Contenido de la sinergia -->
			<template v-else-if="sinergia">
				<!-- Cabecera con imagen y nombre -->
				<div class="sinergia-header">
					<div class="sinergia-image-container">
						<img :src="sinergia.imagen" :alt="sinergia.nombre" class="sinergia-image-large sinergia-icon-img" />
					</div>
					<div class="sinergia-header-info">
						<h1 class="sinergia-title">{{ sinergia.nombre }}</h1>
					</div>
				</div>

				<!-- Bonificaciones por unidades -->
				<div class="bonuses-section">
					<h2 class="section-title">Bonificaciones</h2>
					<div class="bonuses-grid">
						<div
							v-for="(valor, unidad) in sinergia.unidades"
							:key="unidad"
							class="bonus-card"
							:class="{ 'bonus-empty': valor === '—' }"
						>
							<div class="bonus-units">{{ unidad }}</div>
							<div class="bonus-value">{{ valor }}</div>
						</div>
					</div>
				</div>

				<!-- Personajes con esta sinergia -->
				<div v-if="sinergia.personajes && sinergia.personajes.length > 0" class="personajes-section">
					<h2 class="section-title">Personajes</h2>
					<div class="personajes-grid">
						<router-link
							v-for="personaje in sinergia.personajes"
							:key="personaje.id"
							:to="`/personajes/${personaje.slug}`"
							class="personaje-card"
						>
							<img :src="personaje.imagen" :alt="personaje.nombre" class="personaje-card-image" />
							<div class="personaje-card-name">{{ personaje.nombre }}</div>
							<div v-if="personaje.coste && personaje.coste !== '—'" class="personaje-card-cost">
								{{ personaje.coste }}
							</div>
						</router-link>
					</div>
				</div>
			</template>
		</main>
		<FooterComponent />
	</div>
</template>

<style scoped>
/* Contenedor del botón volver */
.back-button-container {
	margin: var(--space-6) 0 var(--space-8) 0;
}

.back-button {
	background: var(--btn-primary);
	color: white;
	border: none;
	padding: var(--space-3) var(--space-6);
	border-radius: var(--border-radius-lg);
	font-size: var(--font-size-base);
	font-weight: var(--font-weight-medium);
	cursor: pointer;
	transition: all var(--transition-fast);
	box-shadow: var(--shadow-sm);
}

.back-button:hover {
	background: var(--btn-primary-hover);
	transform: translateY(-1px);
	box-shadow: var(--shadow-md);
}

.back-button:active {
	transform: translateY(0);
}

/* Estados de carga y error */
.loading-state,
.error-state {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: var(--space-20);
	text-align: center;
}

.spinner {
	width: 48px;
	height: 48px;
	border: 4px solid var(--gray-200);
	border-top-color: var(--blue-600);
	border-radius: 50%;
	animation: spin 0.8s linear infinite;
	margin-bottom: var(--space-4);
}

@keyframes spin {
	to {
		transform: rotate(360deg);
	}
}

.error-message {
	color: var(--error);
	font-size: var(--font-size-lg);
	margin-bottom: var(--space-6);
}

.btn-secondary {
	background: var(--btn-secondary);
	color: white;
	border: none;
	padding: var(--space-3) var(--space-6);
	border-radius: var(--border-radius-lg);
	font-size: var(--font-size-base);
	font-weight: var(--font-weight-medium);
	cursor: pointer;
	transition: all var(--transition-fast);
}

.btn-secondary:hover {
	background: var(--btn-secondary-hover);
}

/* Header de la sinergia */
.sinergia-header {
	display: flex;
	gap: var(--space-8);
	align-items: center;
	margin-bottom: var(--space-12);
	padding: var(--space-8);
	background: white;
	border-radius: var(--border-radius-2xl);
	box-shadow: var(--shadow-lg);
	border: 2px solid var(--border-primary);
}

.sinergia-image-container {
	flex-shrink: 0;
}

.sinergia-image-large {
	width: 200px;
	height: 200px;
	object-fit: cover;
	border-radius: var(--border-radius-xl);
	border: 4px solid white;
	box-shadow: var(--shadow-xl);
}

.sinergia-header-info {
	flex: 1;
}

.sinergia-title {
	font-size: var(--font-size-5xl);
	font-weight: var(--font-weight-bold);
	color: var(--text-primary);
	margin: 0;
	line-height: 1.2;
}

/* Secciones */
.bonuses-section,
.personajes-section {
	margin-bottom: var(--space-12);
}

.section-title {
	font-size: var(--font-size-3xl);
	font-weight: var(--font-weight-bold);
	color: var(--text-primary);
	margin-bottom: var(--space-6);
	padding-bottom: var(--space-3);
	border-bottom: 3px solid var(--blue-500);
}

/* Grid de bonificaciones */
.bonuses-grid {
	display: grid;
	grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
	gap: var(--space-4);
}

.bonus-card {
	background: white;
	padding: var(--space-6);
	border-radius: var(--border-radius-xl);
	text-align: center;
	transition: all var(--transition-fast);
	box-shadow: var(--shadow-sm);
	color: var(--text-primary);
	border: 2px solid var(--border-primary);
}

.bonus-card:hover {
	transform: translateY(-4px);
	box-shadow: var(--shadow-lg);
	border-color: var(--blue-400);
}

.bonus-card.bonus-empty {
	background: var(--gray-200);
	color: var(--gray-400);
}

.bonus-card.bonus-empty::before {
	display: none;
}

.bonus-units {
	font-size: var(--font-size-sm);
	font-weight: var(--font-weight-semibold);
	margin-bottom: var(--space-2);
	text-transform: uppercase;
	letter-spacing: 0.05em;
	color: var(--text-secondary);
}

.bonus-value {
	font-size: var(--font-size-xl);
	font-weight: var(--font-weight-bold);
	line-height: var(--line-height-tight);
	color: var(--blue-600);
}

/* Grid de personajes */
.personajes-grid {
	display: grid;
	grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
	gap: var(--space-5);
}

.personaje-card {
	background: white;
	border-radius: var(--border-radius-xl);
	overflow: hidden;
	text-decoration: none;
	color: var(--text-primary);
	transition: all var(--transition-fast);
	box-shadow: var(--shadow-sm);
	border: 2px solid var(--border-primary);
	position: relative;
}

.personaje-card:hover {
	transform: translateY(-8px);
	box-shadow: var(--shadow-xl);
	border-color: var(--blue-500);
}

.personaje-card-image {
	width: 100%;
	height: 150px;
	object-fit: cover;
	display: block;
}

.personaje-card-name {
	padding: var(--space-3) var(--space-4);
	font-weight: var(--font-weight-semibold);
	text-align: center;
	font-size: var(--font-size-base);
}

.personaje-card-cost {
	position: absolute;
	top: var(--space-2);
	right: var(--space-2);
	background: var(--gold);
	color: var(--gray-900);
	padding: var(--space-1) var(--space-3);
	border-radius: var(--border-radius-full);
	font-weight: var(--font-weight-bold);
	font-size: var(--font-size-sm);
	box-shadow: var(--shadow-md);
}

/* Responsive */
@media (max-width: 768px) {
	.sinergia-header {
		flex-direction: column;
		text-align: center;
	}

	.sinergia-title {
		font-size: var(--font-size-3xl);
	}

	.sinergia-image-large {
		width: 150px;
		height: 150px;
	}

	.bonuses-grid {
		grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
	}

	.personajes-grid {
		grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
	}
}

.sinergia-icon-img {
	filter: invert(1);
	background: transparent;
}
</style>
