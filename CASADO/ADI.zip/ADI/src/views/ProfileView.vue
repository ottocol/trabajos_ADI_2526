<script setup>
import { ref, onMounted } from "vue";
import HeaderComponent from "@/components/HeaderComponent.vue";
import FooterComponent from "@/components/FooterComponent.vue";
import ComposicionComponent from "@/components/ComposicionComponent.vue";
import CrearComposicionModal from "@/components/CrearComposicionModal.vue";
import { useAuthStore } from "@/stores/auth";
import { useComposicionesStore } from "@/stores/composiciones";
import { useForm, useField } from "vee-validate";

const { handleSubmit, errors } = useForm();

const { value: nombre } = useField("nombre", "required|min:3");
const { value: contraseñaActual } = useField("contraseñaActual");
const { value: contraseña } = useField("contraseña");
const { value: confirmar } = useField("confirmar", "confirmed:@contraseña");

const editar = ref(false);
const composicionesUsuario = ref([]);
const loadingComposiciones = ref(false);
const showCrearModal = ref(false);

const authStore = useAuthStore();
const composicionesStore = useComposicionesStore();

// Inicializar los campos con los datos del usuario
onMounted(async () => {
	nombre.value = authStore.userName;
	await cargarComposiciones();
});

const cargarComposiciones = async () => {
	if (!authStore.isAuthenticated || !authStore.user) return;

	try {
		loadingComposiciones.value = true;
		composicionesUsuario.value = await composicionesStore.cargarComposicionesDelUsuario(authStore.user.id);
	} catch (error) {
		// Error al cargar composiciones
	} finally {
		loadingComposiciones.value = false;
	}
};

const onSubmit = handleSubmit(async (values) => {
	try {
		const datos = {
			nombre: values.nombre,
		};

		// Solo añadir password si se está cambiando
		if (values.contraseña) {
			datos.oldPassword = values.contraseñaActual;
			datos.password = values.contraseña;
			datos.passwordConfirm = values.confirmar;
		}

		await authStore.updateProfile(datos);
		alert("Perfil actualizado correctamente");
		contraseñaActual.value = "";
		contraseña.value = "";
		confirmar.value = "";
		editar.value = false;
	} catch (error) {
		alert("Error al actualizar perfil: " + error.message);
	}
});

function cancelar() {
	nombre.value = authStore.userName;
	contraseñaActual.value = "";
	contraseña.value = "";
	confirmar.value = "";
	editar.value = false;
}

const handleComposicionUpdated = async () => {
	await cargarComposiciones();
};

const handleComposicionCreated = async () => {
	await cargarComposiciones();
};

const abrirModalCrear = () => {
	showCrearModal.value = true;
};
</script>

<template>
	<HeaderComponent />
	<main>
		<v-container>
			<v-card class="my-6">
				<v-row>
					<v-col cols="12" md="6">
						<div class="ma-6">
							<img v-if="authStore.userAvatar" :src="authStore.userAvatar" alt="Avatar" />
							<img v-else src="/helicoptero.jpg" alt="Default Avatar" />
						</div>
					</v-col>
					<v-col cols="12" md="6">
						<form @submit.prevent="onSubmit">
							<div class="ma-6">
								<div class="mb-4">
									<label class="field-label">Nombre de usuario</label>
									<v-text-field
										v-model="nombre"
										:error-messages="errors.nombre"
										prepend-icon="mdi-account-box"
										variant="outlined"
										:disabled="!editar"
									/>
								</div>
								<div class="mb-4">
									<label class="field-label">Email</label>
									<v-text-field
										:model-value="authStore.userEmail"
										prepend-icon="mdi-email"
										variant="outlined"
										disabled
										hide-details
									/>
								</div>
								<div class="mb-4">
									<label class="field-label">Fecha de registro</label>
									<v-text-field
										:model-value="authStore.userFechaRegistro"
										prepend-icon="mdi-calendar"
										variant="outlined"
										disabled
										hide-details
									/>
								</div>
								<div v-if="editar" class="mb-4">
									<label class="field-label">Contraseña actual (para cambiarla)</label>
									<v-text-field
										v-model="contraseñaActual"
										:error-messages="errors.contraseñaActual"
										type="password"
										prepend-icon="mdi-lock"
										variant="outlined"
										placeholder="Solo si quieres cambiar la contraseña"
									/>
								</div>
								<div v-if="editar && contraseñaActual" class="mb-4">
									<label class="field-label">Nueva contraseña</label>
									<v-text-field
										v-model="contraseña"
										:error-messages="errors.contraseña"
										type="password"
										prepend-icon="mdi-lock"
										variant="outlined"
									/>
								</div>
								<div v-if="editar && contraseñaActual" class="mb-4">
									<label class="field-label">Confirmar nueva contraseña</label>
									<v-text-field
										v-model="confirmar"
										:error-messages="errors.confirmar"
										type="password"
										prepend-icon="mdi-lock"
										variant="outlined"
									/>
								</div>
								<v-btn v-if="!editar" @click="editar = true" color="primary" class="my-6">Editar</v-btn>
								<v-btn v-if="editar" @click="cancelar" color="error" class="my-6 mr-2">Cancelar</v-btn>
								<v-btn v-if="editar" type="submit" color="success" class="my-6">Guardar</v-btn>
							</div>
						</form>
					</v-col>
				</v-row>
			</v-card>

			<!-- Composiciones del usuario -->
			<v-card class="my-6">
				<v-card-title class="text-h5 pa-6 d-flex justify-space-between align-center">
					<span>Mis Composiciones ({{ composicionesUsuario.length }})</span>
					<v-btn color="primary" prepend-icon="mdi-plus" @click="abrirModalCrear"> Añadir Composición </v-btn>
				</v-card-title>
				<v-card-text>
					<div v-if="loadingComposiciones" class="text-center pa-6">
						<v-progress-circular indeterminate color="primary"></v-progress-circular>
						<p class="mt-4">Cargando composiciones...</p>
					</div>
					<div v-else-if="composicionesUsuario.length === 0" class="text-center pa-6">
						<p class="text-h6 text-grey">No has creado ninguna composición todavía</p>
					</div>
					<div v-else class="composiciones-lista">
						<ComposicionComponent
							v-for="composicion in composicionesUsuario"
							:key="composicion.id"
							:composicion="composicion"
							@updated="handleComposicionUpdated"
						/>
					</div>
				</v-card-text>
			</v-card>
		</v-container>
	</main>
	<FooterComponent />

	<!-- Modal de crear composición -->
	<CrearComposicionModal :show="showCrearModal" @close="showCrearModal = false" @created="handleComposicionCreated" />
</template>

<style scoped>
.field-label {
	display: block;
	font-size: 1rem;
	font-weight: 500;
	color: rgba(0, 0, 0, 0.7);
	margin-bottom: 0.5rem;
}

:deep(.v-field--disabled) {
	opacity: 1 !important;
}

:deep(.v-field--disabled input) {
	color: rgba(0, 0, 0, 0.87) !important;
	font-size: 1.1rem !important;
}

:deep(.v-field--disabled .v-field__outline) {
	color: rgba(0, 0, 0, 0.38) !important;
}

:deep(.v-field--disabled .v-icon) {
	opacity: 1 !important;
	font-size: 1.5rem !important;
}

.composiciones-lista {
	display: flex;
	flex-direction: column;
	gap: 1rem;
	padding: 1rem 0;
}
</style>
