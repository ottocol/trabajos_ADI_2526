<script setup>
import "@/CSS/global.css";
import HeaderComponent from "@/components/HeaderComponent.vue";
import FooterComponent from "@/components/FooterComponent.vue";
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { usePersonajesStore } from "@/stores/personajes.js";

const route = useRoute();
const router = useRouter();
const personajesStore = usePersonajesStore();
const personaje = ref(null);
const loading = ref(true);
const error = ref(null);

onMounted(async () => {
	try {
		loading.value = true;
		error.value = null;

		const slug = route.params.slug;

		if (personajesStore.personajes.length === 0) {
			await personajesStore.cargarTodosPersonajes();
		}

		const personajeEncontrado = personajesStore.personajes.find(
			(p) => p.slug === slug || p.nombre.toLowerCase() === slug.toLowerCase(),
		);

		if (!personajeEncontrado) {
			error.value = `No se encontró el personaje "${slug}"`;
			return;
		}

		personaje.value = personajeEncontrado;
	} catch (err) {
		error.value = "Error al cargar el personaje: " + err.message;
	} finally {
		loading.value = false;
	}
});

const volverAPersonajes = () => {
	router.push("/personajes");
};
</script>

<template>
	<div>
		<HeaderComponent />
		<main>
			<!-- Botón volver -->
			<div class="back-button-container">
				<button @click="volverAPersonajes" class="back-button">← Volver a Personajes</button>
			</div>

			<!-- Estado de carga -->
			<div v-if="loading" class="loading-state">
				<div class="spinner"></div>
				<p>Cargando personaje...</p>
			</div>

			<!-- Estado de error -->
			<div v-else-if="error" class="error-state">
				<p class="error-message">{{ error }}</p>
				<button @click="volverAPersonajes" class="btn-secondary">Volver a Personajes</button>
			</div>

			<!-- Contenido del personaje -->
			<template v-else-if="personaje">
				<!-- Cabecera con imagen y nombre -->
				<div class="personaje-header">
					<div class="personaje-image-container">
						<img :src="personaje.imagen" :alt="personaje.nombre" class="personaje-image-large" />
						<div class="personaje-coste-badge" v-if="personaje.coste && personaje.coste !== '—'">
							<span class="coste-value">{{ personaje.coste }}</span>
						</div>
					</div>

					<div class="personaje-header-info">
						<h1 class="personaje-title">{{ personaje.nombre }}</h1>

						<!-- Sinergias en header -->
						<div v-if="personaje.sinergias && personaje.sinergias.length > 0" class="sinergias-badges">
							<router-link
								v-for="sinergia in personaje.sinergias"
								:key="sinergia.id"
								:to="`/sinergias/${sinergia.slug}`"
								class="sinergia-badge"
							>
								<img
									:src="sinergia.imagen"
									:alt="sinergia.nombre"
									class="sinergia-badge-icon sinergia-icon-img"
								/>
								<span class="sinergia-badge-text">{{ sinergia.nombre }}</span>
							</router-link>
						</div>
					</div>
				</div>

				<!-- Estadísticas principales -->
				<div class="stats-section">
					<h2 class="section-title">Estadísticas</h2>
					<div class="stats-grid">
						<div class="stat-card">
							<div class="stat-value">{{ personaje.vida }}</div>
							<div class="stat-label">Vida</div>
						</div>
						<div class="stat-card">
							<div class="stat-value">{{ personaje.dano_de_ataque }}</div>
							<div class="stat-label">Daño</div>
						</div>
						<div class="stat-card">
							<div class="stat-value">{{ personaje.velocidad_de_ataque }}</div>
							<div class="stat-label">Vel. Ataque</div>
						</div>
						<div class="stat-card">
							<div class="stat-value">{{ personaje.poder_de_habilidad }}</div>
							<div class="stat-label">Poder Hab.</div>
						</div>
						<div class="stat-card">
							<div class="stat-value">{{ personaje.armadura }}</div>
							<div class="stat-label">Armadura</div>
						</div>
						<div class="stat-card">
							<div class="stat-value">{{ personaje.resistencia_magica }}</div>
							<div class="stat-label">Resist. Mág.</div>
						</div>
						<div class="stat-card">
							<div class="stat-value">{{ personaje.probabilidad_de_critico }}</div>
							<div class="stat-label">Prob. Crítico</div>
						</div>
						<div class="stat-card">
							<div class="stat-value">{{ personaje.mana_habilidad }}</div>
							<div class="stat-label">Maná</div>
						</div>
					</div>
				</div>

				<!-- Habilidad -->
				<div v-if="personaje.nombre_habilidad && personaje.nombre_habilidad !== '—'" class="ability-section">
					<h2 class="section-title">Habilidad</h2>
					<div class="ability-card">
						<div class="ability-header">
							<h3 class="ability-name">{{ personaje.nombre_habilidad }}</h3>
							<div class="ability-mana">
								<span class="mana-text">{{ personaje.mana_habilidad }} Maná</span>
							</div>
						</div>
						<p class="ability-description">{{ personaje.desc_habilidad }}</p>
					</div>
				</div>
			</template>
		</main>
		<FooterComponent />
	</div>
</template>

<style scoped>
/* Contenedor del botón volver */
.back-button-container {
	margin: var(--space-6) 0 var(--space-8) 0;
}

.back-button {
	background: var(--btn-primary);
	color: white;
	border: none;
	padding: var(--space-3) var(--space-6);
	border-radius: var(--border-radius-lg);
	font-size: var(--font-size-base);
	font-weight: var(--font-weight-medium);
	cursor: pointer;
	transition: all var(--transition-fast);
	box-shadow: var(--shadow-sm);
}

.back-button:hover {
	background: var(--btn-primary-hover);
	transform: translateY(-1px);
	box-shadow: var(--shadow-md);
}

.back-button:active {
	transform: translateY(0);
}

/* Estados de carga y error */
.loading-state,
.error-state {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: var(--space-20);
	text-align: center;
}

.spinner {
	width: 48px;
	height: 48px;
	border: 4px solid var(--gray-200);
	border-top-color: var(--blue-600);
	border-radius: 50%;
	animation: spin 0.8s linear infinite;
	margin-bottom: var(--space-4);
}

@keyframes spin {
	to {
		transform: rotate(360deg);
	}
}

.error-message {
	color: var(--error);
	font-size: var(--font-size-lg);
	margin-bottom: var(--space-6);
}

.btn-secondary {
	background: var(--btn-secondary);
	color: white;
	border: none;
	padding: var(--space-3) var(--space-6);
	border-radius: var(--border-radius-lg);
	font-size: var(--font-size-base);
	font-weight: var(--font-weight-medium);
	cursor: pointer;
	transition: all var(--transition-fast);
}

.btn-secondary:hover {
	background: var(--btn-secondary-hover);
}

/* Header del personaje */
.personaje-header {
	display: flex;
	gap: var(--space-8);
	align-items: start;
	margin-bottom: var(--space-12);
	padding: var(--space-8);
	background: linear-gradient(135deg, var(--gray-50) 0%, var(--blue-50) 100%);
	border-radius: var(--border-radius-2xl);
	box-shadow: var(--shadow-lg);
}

.personaje-image-container {
	position: relative;
	flex-shrink: 0;
}

.personaje-image-large {
	width: 250px;
	height: 250px;
	object-fit: cover;
	border-radius: var(--border-radius-xl);
	border: 4px solid white;
	box-shadow: var(--shadow-xl);
}

.personaje-coste-badge {
	position: absolute;
	bottom: var(--space-3);
	right: var(--space-3);
	background: var(--gold);
	padding: var(--space-2) var(--space-4);
	border-radius: var(--border-radius-full);
	display: flex;
	align-items: center;
	gap: var(--space-2);
	box-shadow: var(--shadow-md);
	font-weight: var(--font-weight-bold);
	font-size: var(--font-size-xl);
	color: var(--gray-900);
}

.personaje-header-info {
	flex: 1;
	display: flex;
	flex-direction: column;
	gap: var(--space-6);
}

.personaje-title {
	font-size: var(--font-size-5xl);
	font-weight: var(--font-weight-bold);
	color: var(--text-primary);
	margin: 0;
	line-height: 1.2;
}

.sinergias-badges {
	display: flex;
	flex-wrap: wrap;
	gap: var(--space-3);
}

.sinergia-badge {
	display: flex;
	align-items: center;
	gap: var(--space-2);
	padding: var(--space-2) var(--space-4);
	background: white;
	border: 2px solid var(--border-primary);
	border-radius: var(--border-radius-lg);
	text-decoration: none;
	color: var(--text-primary);
	font-weight: var(--font-weight-medium);
	transition: all var(--transition-fast);
	box-shadow: var(--shadow-sm);
}

.sinergia-badge:hover {
	border-color: var(--blue-500);
	transform: translateY(-2px);
	box-shadow: var(--shadow-md);
	background: var(--blue-50);
}

.sinergia-badge-icon {
	width: 32px;
	height: 32px;
	object-fit: cover;
	border-radius: var(--border-radius-md);
}

/* Secciones */
.stats-section,
.ability-section {
	margin-bottom: var(--space-12);
}

.section-title {
	font-size: var(--font-size-3xl);
	font-weight: var(--font-weight-bold);
	color: var(--text-primary);
	margin-bottom: var(--space-6);
	padding-bottom: var(--space-3);
	border-bottom: 3px solid var(--blue-500);
}

/* Grid de estadísticas */
.stats-grid {
	display: grid;
	grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
	gap: var(--space-4);
}

.stat-card {
	background: white;
	padding: var(--space-6);
	border-radius: var(--border-radius-xl);
	border: 2px solid var(--border-primary);
	text-align: center;
	transition: all var(--transition-fast);
	box-shadow: var(--shadow-sm);
}

.stat-card:hover {
	transform: translateY(-4px);
	box-shadow: var(--shadow-lg);
	border-color: var(--blue-400);
}

.stat-value {
	font-size: var(--font-size-3xl);
	font-weight: var(--font-weight-bold);
	color: var(--blue-600);
	margin-bottom: var(--space-1);
}

.stat-label {
	font-size: var(--font-size-sm);
	color: var(--text-secondary);
	font-weight: var(--font-weight-medium);
}

/* Tarjeta de habilidad */
.ability-card {
	background: white;
	padding: var(--space-8);
	border-radius: var(--border-radius-2xl);
	box-shadow: var(--shadow-xl);
	border: 2px solid var(--border-primary);
}

.ability-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	margin-bottom: var(--space-6);
	flex-wrap: wrap;
	gap: var(--space-4);
}

.ability-name {
	font-size: var(--font-size-2xl);
	font-weight: var(--font-weight-bold);
	margin: 0;
	color: var(--text-primary);
}

.ability-mana {
	display: flex;
	align-items: center;
	gap: var(--space-2);
	background: var(--blue-50);
	padding: var(--space-2) var(--space-4);
	border-radius: var(--border-radius-full);
	border: 2px solid var(--blue-200);
}

.mana-text {
	font-weight: var(--font-weight-semibold);
	font-size: var(--font-size-lg);
	color: var(--blue-600);
}

.ability-description {
	font-size: var(--font-size-lg);
	line-height: var(--line-height-relaxed);
	margin: 0;
	color: var(--text-secondary);
}

/* Responsive */
@media (max-width: 768px) {
	.personaje-header {
		flex-direction: column;
		align-items: center;
		text-align: center;
	}

	.personaje-title {
		font-size: var(--font-size-3xl);
	}

	.personaje-image-large {
		width: 200px;
		height: 200px;
	}

	.stats-grid {
		grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
	}

	.sinergias-badges {
		justify-content: center;
	}
}

.sinergia-icon-img {
	filter: invert(1);
	background: transparent;
}
</style>
