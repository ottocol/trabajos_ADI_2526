<script setup>
import HeaderComponent from "@/components/HeaderComponent.vue";
import FooterComponent from "@/components/FooterComponent.vue";
import { fetchRiotVersion as riotVersionService } from "@/services/riotService.js";
import { onMounted, ref, computed } from "vue";
import { usePersonajesStore } from "@/stores/personajes";
import { useSinergiasStore } from "@/stores/sinergias";

const version = ref("14.23");
const personajesStore = usePersonajesStore();
const sinergiaStore = useSinergiasStore();

// Computed para tomar los primeros 5 personajes reactivamente
const personajes = computed(() => personajesStore.personajes.slice(0, 5));

// Computed para tomar las primeras 5 sinergias reactivamente
const sinergias = computed(() => sinergiaStore.sinergias.slice(0, 5));

onMounted(async () => {
	try {
		const fetchedVersion = await riotVersionService();
		if (fetchedVersion) {
			version.value = fetchedVersion;
		}

		await personajesStore.cargarTodosPersonajes(1, 100);
		await sinergiaStore.cargarTodasSinergias(1, 100);
	} catch (error) {
		// Error al cargar datos
	}
});
</script>

<template>
	<HeaderComponent />

	<!-- Hero Section -->
	<v-container fluid class="pa-0">
		<v-img
			src="https://www.startpage.com/av/proxy-image?piurl=https%3A%2F%2Fcdnb.artstation.com%2Fp%2Fassets%2Fimages%2Fimages%2F035%2F609%2F209%2Flarge%2Fcaelys-tft-couverture-hd-x.jpg%3F1615407995&sp=1764152011T96a866557cb69fc6861c1b027907ebb1f11fc6ab46ac046c491b20535506d3a6"
			height="400"
			cover
			gradient="to bottom, rgba(0,0,0,.5), rgba(0,0,0,.9)"
		>
			<v-container class="fill-height">
				<v-row align="center" justify="center">
					<v-col cols="12" class="text-center">
						<h1 class="text-h2 text-md-h1 font-weight-bold text-white mb-4 text-shadow">
							Bienvenido a TFT Companion
						</h1>
						<p class="text-h5 text-md-h4 text-white text-shadow">Tu guía definitiva para el set {{ version }}</p>
					</v-col>
				</v-row>
			</v-container>
		</v-img>
	</v-container>

	<!-- Content Section -->
	<v-container class="my-8">
		<v-row>
			<v-col cols="12" class="text-center mb-6">
				<h2 class="text-h3 text-md-h2 font-weight-bold text-primary">Explora nuestro contenido</h2>
				<p class="text-h6 text-medium-emphasis mt-2">
					Descubre personajes, sinergias y composiciones para dominar el juego
				</p>
			</v-col>
		</v-row>

		<v-row>
			<!-- Personajes Section -->
			<v-col cols="12" md="6">
				<v-card elevation="3" class="fill-height d-flex flex-column">
					<v-card-title class="bg-surface-variant">
						<h3 class="text-h5">Personajes Destacados</h3>
					</v-card-title>
					<v-divider></v-divider>
					<v-card-text class="pa-4 flex-grow-1">
						<v-card
							v-for="personaje in personajes"
							:key="personaje.id"
							class="mb-3"
							variant="outlined"
							color="primary"
							hover
						>
							<v-row align="center" no-gutters>
								<v-col cols="3" sm="2">
									<v-img
										:src="personaje.imagen"
										:alt="personaje.nombre"
										cover
										aspect-ratio="1"
										class="rounded ma-2"
									/>
								</v-col>
								<v-col cols="5" sm="6" class="px-4">
									<div class="text-body-1 font-weight-medium">{{ personaje.nombre }}</div>
								</v-col>
								<v-col cols="4" class="text-center">
									<v-btn
										:to="`/personajes/${personaje.slug || personaje.nombre.toLowerCase().replace(/\s+/g, '-')}`"
										color="primary"
										variant="elevated"
										size="small"
									>
										Ver más
									</v-btn>
								</v-col>
							</v-row>
						</v-card>
						<div v-if="!personajes || personajes.length === 0" class="text-center pa-8">
							<v-progress-circular indeterminate color="primary"></v-progress-circular>
						</div>
					</v-card-text>
					<v-card-actions>
						<v-btn block variant="text" color="primary" to="/personajes">
							Ver todos los personajes
							<v-icon end>mdi-arrow-right</v-icon>
						</v-btn>
					</v-card-actions>
				</v-card>
			</v-col>

			<!-- Sinergias Section -->
			<v-col cols="12" md="6">
				<v-card elevation="3" class="fill-height d-flex flex-column">
					<v-card-title class="bg-surface-variant">
						<h3 class="text-h5">Sinergias Populares</h3>
					</v-card-title>
					<v-divider></v-divider>
					<v-card-text class="pa-4 flex-grow-1">
						<v-card
							v-for="sinergia in sinergias"
							:key="sinergia.id"
							class="mb-3"
							variant="outlined"
							color="primary"
							hover
						>
							<v-row align="center" no-gutters>
								<v-col cols="3" sm="2">
									<v-img
										:src="sinergia.imagen"
										:alt="sinergia.nombre"
										cover
										aspect-ratio="1"
										class="rounded ma-2 sinergia-icon-img"
									/>
								</v-col>
								<v-col cols="9" sm="10" class="px-4">
									<div class="text-body-1 font-weight-medium">{{ sinergia.nombre }}</div>
								</v-col>
							</v-row>
						</v-card>
						<div v-if="!sinergias || sinergias.length === 0" class="text-center pa-8">
							<v-progress-circular indeterminate color="primary"></v-progress-circular>
						</div>
					</v-card-text>
					<v-card-actions>
						<v-btn block variant="text" color="primary" to="/sinergias">
							Ver todas las sinergias
							<v-icon end>mdi-arrow-right</v-icon>
						</v-btn>
					</v-card-actions>
				</v-card>
			</v-col>
		</v-row>

		<!-- Composiciones Section -->
		<v-row class="mt-4">
			<v-col cols="12">
				<v-card elevation="3">
					<v-card-title class="bg-surface-variant">
						<h3 class="text-h5">Composiciones Meta</h3>
					</v-card-title>
					<v-divider></v-divider>
					<v-card-text class="text-center pa-8">
						<v-icon size="64" color="primary">mdi-strategy</v-icon>
						<h4 class="text-h5 mt-4">Descubre las mejores composiciones</h4>
						<p class="text-body-1 mt-2 text-medium-emphasis">
							Explora las composiciones más efectivas del meta actual y mejora tu estrategia
						</p>
						<v-btn color="primary" size="large" class="mt-4" to="/composiciones">
							Explorar composiciones
							<v-icon end>mdi-arrow-right</v-icon>
						</v-btn>
					</v-card-text>
				</v-card>
			</v-col>
		</v-row>
	</v-container>

	<FooterComponent />
</template>

<style scoped>
.text-shadow {
	text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.9);
}

.sinergia-icon-img {
	filter: invert(1);
}
</style>
