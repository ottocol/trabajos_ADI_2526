<script setup>
import HeaderComponent from "@/components/HeaderComponent.vue";
import FooterComponent from "@/components/FooterComponent.vue";
import LoginFormComponent from "@/components/LoginFormComponent.vue";
import RegisterFormComponent from "@/components/RegisterFormComponent.vue";
</script>

<template>
	<HeaderComponent />
	<main>
		<v-container>
			<h1 class="text-center my-6">Autenticación</h1>
			<v-row>
				<v-col cols="12" md="6">
					<LoginFormComponent />
				</v-col>
				<v-col cols="12" md="6">
					<RegisterFormComponent />
				</v-col>
			</v-row>
		</v-container>
	</main>
	<FooterComponent />
</template>
