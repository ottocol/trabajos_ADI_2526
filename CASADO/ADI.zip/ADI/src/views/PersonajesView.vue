<script setup>
import "@/CSS/global.css";
import HeaderComponent from "@/components/HeaderComponent.vue";
import FooterComponent from "@/components/FooterComponent.vue";
import PersonajeComponent from "@/components/PersonajeComponent.vue";
import SearchBarComponent from "@/components/SearchBarComponent.vue";
import { ref, onMounted, computed } from 'vue';
import { usePersonajesStore } from '@/stores/personajes.js';

const personajesStore = usePersonajesStore();
const sugerencias = ref(['Briar', 'Garen', 'Jinx']);
const paginaActual = ref(1);
const elementosPorPagina = 10;

const totalPaginas = computed(() => {
	return Math.ceil(personajesStore.personajesFiltrados.length / elementosPorPagina);
});

const personajesPaginados = computed(() => {
	const inicio = (paginaActual.value - 1) * elementosPorPagina;
	const fin = inicio + elementosPorPagina;
	return personajesStore.personajesFiltrados.slice(inicio, fin);
});

onMounted(async () => {
	await personajesStore.cargarTodosPersonajes();
});

const handleSearch = async () => {
	paginaActual.value = 1;
	if (!personajesStore.searchQuery.trim()) {
		await personajesStore.cargarTodosPersonajes();
		return;
	}
	
	await personajesStore.buscarPersonajes(personajesStore.searchQuery);
};

const cambiarPagina = (pagina) => {
	paginaActual.value = pagina;
	window.scrollTo({ top: 0, behavior: 'smooth' });
};
</script>

<template>
	<div>
		<HeaderComponent />
		<main>
			<h1>Personajes del set 15 de TFT</h1>
			
			<SearchBarComponent 
				v-model="personajesStore.searchQuery"
				:sugerencias="sugerencias"
				placeholder="Busca personajes..."
				@search="handleSearch"
			/>

		<div v-if="personajesStore.loading" style="text-align: center; padding: 2rem;">
			<p>Cargando personajes...</p>
		</div>

		<div v-else-if="personajesStore.error" style="text-align: center; padding: 2rem; color: red;">
			<p>{{ personajesStore.error }}</p>
		</div>

		<template v-else>
			<PersonajeComponent 
				v-for="personaje in personajesPaginados" 
				:key="personaje.id"
				:personaje="personaje"
			/>

			<div v-if="personajesStore.personajesFiltrados.length === 0" style="text-align: center; padding: 2rem;">
				<p>No se encontraron personajes.</p>
			</div>

			<!-- Controles de paginación -->
			<div v-if="totalPaginas > 1" class="pagination">
				<v-pagination
					v-model="paginaActual"
					:length="totalPaginas"
					:total-visible="7"
					@update:model-value="cambiarPagina"
				></v-pagination>
			</div>
		</template>
		</main>
		<FooterComponent />
	</div>
</template>

<style scoped>
.pagination {
	display: flex;
	justify-content: center;
	align-items: center;
	margin: 2rem 0;
	padding: 1rem;
}
</style>
