<script setup>
import "@/CSS/global.css";
import HeaderComponent from "@/components/HeaderComponent.vue";
import FooterComponent from "@/components/FooterComponent.vue";
import ComposicionComponent from "@/components/ComposicionComponent.vue";
import SearchBarComponent from "@/components/SearchBarComponent.vue";
import { ref, onMounted, computed } from 'vue';
import { useComposicionesStore } from '@/stores/composiciones.js';

const composicionesStore = useComposicionesStore();
const sugerencias = ref(['Briar carry', 'Star guardians']);
const paginaActual = ref(1);
const elementosPorPagina = 10;

const totalPaginas = computed(() => {
	return Math.ceil(composicionesStore.composicionesFiltradas.length / elementosPorPagina);
});

const composicionesPaginadas = computed(() => {
	const inicio = (paginaActual.value - 1) * elementosPorPagina;
	const fin = inicio + elementosPorPagina;
	return composicionesStore.composicionesFiltradas.slice(inicio, fin);
});

onMounted(async () => {
	await composicionesStore.cargarTodasComposiciones();
});

const handleSearch = async () => {
	paginaActual.value = 1;
	if (!composicionesStore.searchQuery.trim()) {
		await composicionesStore.cargarTodasComposiciones();
		return;
	}
	
	await composicionesStore.buscarComposiciones(composicionesStore.searchQuery);
};

const cambiarPagina = (pagina) => {
	paginaActual.value = pagina;
	window.scrollTo({ top: 0, behavior: 'smooth' });
};
</script>

<template>
	<div>
		<HeaderComponent />
		<main>
			<h1>Mejores composiciones del set 15 de TFT</h1>
			
			<SearchBarComponent 
				v-model="composicionesStore.searchQuery"
				:sugerencias="sugerencias"
				placeholder="Busca composiciones..."
				@search="handleSearch"
			/>

			<div v-if="composicionesStore.loading" style="text-align: center; padding: 2rem;">
				<p>Cargando composiciones...</p>
			</div>

			<div v-else-if="composicionesStore.error" style="text-align: center; padding: 2rem; color: red;">
				<p>{{ composicionesStore.error }}</p>
			</div>

			<template v-else>
				<ComposicionComponent 
					v-for="composicion in composicionesPaginadas" 
					:key="composicion.id"
					:composicion="composicion"
				/>

				<div v-if="composicionesStore.composicionesFiltradas.length === 0" style="text-align: center; padding: 2rem;">
					<p>No se encontraron composiciones.</p>
				</div>

				<!-- Controles de paginación -->
				<div v-if="totalPaginas > 1" class="pagination">
					<v-pagination
						v-model="paginaActual"
						:length="totalPaginas"
						:total-visible="7"
						@update:model-value="cambiarPagina"
					></v-pagination>
				</div>
			</template>
		</main>
		<FooterComponent />
	</div>
</template>

<style scoped>
.pagination {
	display: flex;
	justify-content: center;
	align-items: center;
	margin: 2rem 0;
	padding: 1rem;
}
</style>
