//Archivo supabase.js
import { createClient } from "@supabase/supabase-js";

// Estas variables deben ser configuradas en un archivo .env
// VITE_SUPABASE_URL=tu_url_de_supabase
// VITE_SUPABASE_ANON_KEY=tu_anon_key_de_supabase

// Si no hay archivo .env, usa estas credenciales por defecto
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://lfuklalxbzzandpfyxkf.supabase.co";
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxmdWtsYWx4Ynp6YW5kcGZ5eGtmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg3NDI1MzAsImV4cCI6MjA4NDMxODUzMH0.FPLpTp-fVCJV6CI_5QKTzdP_8v9NEEts5Go_LbSQqqM";

if (!supabaseAnonKey) {
	throw new Error("⚠️ VITE_SUPABASE_ANON_KEY no está configurada. Crea un archivo .env con tus credenciales.");
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
