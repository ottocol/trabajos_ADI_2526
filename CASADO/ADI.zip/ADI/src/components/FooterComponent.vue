<script setup>
import "@/CSS/headerFooter.css";
</script>

<template>
	<footer data-component="SiteFooter">© 2025 - Derechos reservados a Pablo Garcia Belando y Carlos Maria Casado Lopez</footer>
</template>
