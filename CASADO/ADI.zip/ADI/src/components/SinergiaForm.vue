<template>
	<v-form ref="formRef">
		<!-- Mensaje de error -->
		<v-alert v-if="errorMessage" type="error" class="mb-4">
			{{ errorMessage }}
		</v-alert>

		<!-- Nombre de la sinergia -->
		<v-text-field
			v-model="localDatos.nombre"
			label="Nombre de la sinergia *"
			variant="outlined"
			:rules="rules.nombre"
			required
		></v-text-field>

		<!-- URL de la imagen -->
		<v-text-field
			v-model="localDatos.imagen"
			label="URL de la imagen"
			variant="outlined"
			hint="Deja vacío para usar imagen por defecto"
			persistent-hint
		></v-text-field>

		<!-- Unidades (1-10) -->
		<div class="unidades-section">
			<h4 class="mb-3">Unidades</h4>
			<v-row>
				<v-col v-for="i in 10" :key="i" cols="12" sm="6" md="4">
					<v-text-field
						v-model="localDatos.unidades[i]"
						:label="`Unidad ${i}`"
						variant="outlined"
						density="compact"
					></v-text-field>
				</v-col>
			</v-row>
		</div>

		<!-- Selección de personajes -->
		<div class="personajes-section mb-6">
			<label class="text-subtitle-1 font-weight-medium mb-2 d-block">
				Personajes ({{ localDatos.personajes.length }} seleccionados)
			</label>
			<div class="personajes-grid">
				<div
					v-for="personaje in todosPersonajes"
					:key="personaje.id"
					class="personaje-card"
					:class="{ 'personaje-selected': localDatos.personajes.includes(personaje.id) }"
					@click="togglePersonaje(personaje.id)"
				>
					<img :src="personaje.imagen" :alt="personaje.nombre" :title="personaje.nombre" />
					<span class="personaje-nombre">{{ personaje.nombre }}</span>
					<span v-if="localDatos.personajes.includes(personaje.id)" class="check-icon">✓</span>
				</div>
			</div>
			<v-input :rules="rules.personajes" class="personajes-validation" style="margin-top: 0">
				<template v-slot:default></template>
			</v-input>
		</div>
	</v-form>
</template>

<script setup>
import { ref, watch, onMounted, defineProps, defineEmits, defineExpose } from "vue";
import { usePersonajesStore } from "@/stores/personajes.js";

const props = defineProps({
	sinergia: {
		type: Object,
		default: null,
	},
});

const emit = defineEmits(["submit"]);

const personajesStore = usePersonajesStore();
const todosPersonajes = ref([]);

const formRef = ref(null);
const errorMessage = ref("");

const localDatos = ref({
	nombre: "",
	imagen: "",
	unidades: {},
	personajes: [],
});

// Reglas de validación
const rules = {
	nombre: [
		(v) => !!v || "El nombre es obligatorio",
		(v) => (v && v.length >= 2) || "El nombre debe tener al menos 2 caracteres",
	],
	personajes: [() => localDatos.value.personajes.length >= 1 || "Debes seleccionar al menos 1 personaje"],
};

onMounted(async () => {
	if (personajesStore.personajes.length === 0) {
		await personajesStore.cargarTodosPersonajes();
	}
	todosPersonajes.value = personajesStore.personajes;
});

watch(
	() => props.sinergia,
	(nuevaSinergia) => {
		if (nuevaSinergia) {
			localDatos.value.nombre = nuevaSinergia.nombre || nuevaSinergia.nombre_sinergia || "";
			localDatos.value.imagen = nuevaSinergia.imagen || "";

			localDatos.value.unidades = {};
			for (let i = 1; i <= 10; i++) {
				localDatos.value.unidades[i] = nuevaSinergia[`Unidad${i}`] || "";
			}

			localDatos.value.personajes = nuevaSinergia.expand?.personajes
				? nuevaSinergia.expand.personajes.map((p) => p.id)
				: nuevaSinergia.personajes?.map((p) => (typeof p === "string" ? p : p.id)) || [];
		}
	},
	{ immediate: true },
);

function togglePersonaje(personajeId) {
	const index = localDatos.value.personajes.indexOf(personajeId);
	if (index > -1) {
		localDatos.value.personajes.splice(index, 1);
	} else {
		localDatos.value.personajes.push(personajeId);
	}
}

function resetForm() {
	localDatos.value = {
		nombre: "",
		imagen: "",
		unidades: {},
		personajes: [],
	};
	formRef.value?.reset();
	errorMessage.value = "";
}

function setError(message) {
	errorMessage.value = message;
}

async function handleSubmit() {
	const { valid } = await formRef.value.validate();

	if (!valid) {
		return;
	}

	const datos = {
		nombre: localDatos.value.nombre,
		imagen: localDatos.value.imagen || "/helicoptero.jpg",
		unidades: localDatos.value.unidades,
		personajes: localDatos.value.personajes,
	};

	emit("submit", datos);
}

defineExpose({
	resetForm,
	setError,
	handleSubmit,
});
</script>

<style scoped>
.unidades-section {
	margin-bottom: 24px;
}

.unidades-section h4 {
	color: rgb(var(--v-theme-primary));
	font-weight: var(--font-weight-medium);
}

.personajes-section {
	margin-bottom: 24px;
}

.personajes-validation {
	margin-top: -20px;
}

.personajes-validation :deep(.v-input__control) {
	min-height: 0;
	display: none;
}

.personajes-validation :deep(.v-input__details) {
	padding-top: 4px;
	min-height: 0;
}

.personajes-grid {
	display: grid;
	grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
	gap: var(--space-3);
	max-height: 400px;
	overflow-y: auto;
	padding: var(--space-2);
	border: 2px solid rgba(0, 0, 0, 0.23);
	border-radius: var(--border-radius-md);
}

.personaje-card {
	position: relative;
	display: flex;
	flex-direction: column;
	align-items: center;
	gap: var(--space-2);
	padding: var(--space-3);
	border: 2px solid rgba(0, 0, 0, 0.23);
	border-radius: var(--border-radius-md);
	cursor: pointer;
	transition: all 0.2s ease;
	background: white;
}

.personaje-card:hover {
	border-color: rgb(var(--v-theme-primary));
	transform: translateY(-2px);
	box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.personaje-selected {
	border-color: rgb(var(--v-theme-primary));
	background: rgba(var(--v-theme-primary), 0.08);
}

.personaje-card img {
	width: 64px;
	height: 64px;
	object-fit: cover;
	border-radius: var(--border-radius-md);
}

.personaje-nombre {
	font-size: var(--font-size-sm);
	text-align: center;
	color: var(--text-primary);
	font-weight: var(--font-weight-medium);
}

.check-icon {
	position: absolute;
	top: var(--space-2);
	right: var(--space-2);
	background: rgb(var(--v-theme-primary));
	color: white;
	width: 24px;
	height: 24px;
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
	font-size: var(--font-size-sm);
	font-weight: var(--font-weight-bold);
}

@media (max-width: 768px) {
	.personajes-grid {
		grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
		max-height: 300px;
	}
}
</style>
