<template>
	<Teleport to="body">
		<div v-if="modelValue" class="modal-overlay" @click.self="cerrar">
			<div class="modal-content">
				<div class="modal-header">
					<h2>Editar Sinergia</h2>
					<button class="close-btn" @click="cerrar">×</button>
				</div>

				<div class="modal-body">
					<SinergiaForm ref="formRef" :sinergia="sinergia" @submit="handleSubmit" />
				</div>

				<div class="modal-footer">
					<button class="btn-secondary" @click="cerrar">Cancelar</button>
					<button class="btn-primary" @click="submitForm">Guardar Cambios</button>
				</div>
			</div>
		</div>
	</Teleport>
</template>

<script setup>
import { ref, defineProps, defineEmits } from "vue";
import SinergiaForm from "./SinergiaForm.vue";
import { useSinergiasStore } from "@/stores/sinergias.js";

const props = defineProps({
	modelValue: {
		type: Boolean,
		required: true,
	},
	sinergia: {
		type: Object,
		required: true,
	},
});

const emit = defineEmits(["update:modelValue", "updated"]);

const sinergiasStore = useSinergiasStore();
const formRef = ref(null);

function cerrar() {
	emit("update:modelValue", false);
	formRef.value?.resetForm();
}

async function submitForm() {
	await formRef.value.handleSubmit();
}

async function handleSubmit(datos) {
	try {
		await sinergiasStore.editarSinergia(props.sinergia.id, datos);
		emit("updated");
		cerrar();
	} catch (error) {
		formRef.value?.setError("Error al actualizar la sinergia: " + error.message);
	}
}
</script>

<style scoped>
.modal-overlay {
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(0, 0, 0, 0.6);
	display: flex;
	align-items: center;
	justify-content: center;
	z-index: 1000;
	padding: var(--space-4);
}

.modal-content {
	background: white;
	border-radius: var(--border-radius-xl);
	max-width: 900px;
	width: 100%;
	max-height: 90vh;
	display: flex;
	flex-direction: column;
	box-shadow: var(--shadow-2xl);
}

.modal-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: var(--space-6);
	border-bottom: 2px solid var(--border-primary);
}

.modal-header h2 {
	margin: 0;
	font-size: var(--font-size-2xl);
	color: var(--text-primary);
}

.close-btn {
	background: none;
	border: none;
	font-size: var(--font-size-3xl);
	cursor: pointer;
	color: var(--text-secondary);
	padding: 0;
	width: 32px;
	height: 32px;
	display: flex;
	align-items: center;
	justify-content: center;
	border-radius: var(--border-radius-md);
	transition: all 0.2s ease;
}

.close-btn:hover {
	background: var(--gray-100);
	color: var(--text-primary);
}

.modal-body {
	padding: var(--space-6);
	overflow-y: auto;
	flex: 1;
}

.modal-footer {
	display: flex;
	justify-content: flex-end;
	gap: var(--space-3);
	padding: var(--space-6);
	border-top: 2px solid var(--border-primary);
}

.btn-primary,
.btn-secondary {
	padding: var(--space-3) var(--space-6);
	border-radius: var(--border-radius-md);
	font-size: var(--font-size-base);
	font-weight: var(--font-weight-semibold);
	cursor: pointer;
	transition: all 0.2s ease;
	border: none;
}

.btn-primary {
	background: var(--btn-primary);
	color: white;
}

.btn-primary:hover:not(:disabled) {
	background: var(--btn-primary-hover);
	transform: translateY(-1px);
	box-shadow: var(--shadow-md);
}

.btn-primary:disabled {
	opacity: 0.5;
	cursor: not-allowed;
}

.btn-secondary {
	background: var(--gray-200);
	color: var(--text-primary);
}

.btn-secondary:hover {
	background: var(--gray-300);
}

@media (max-width: 768px) {
	.modal-content {
		max-height: 95vh;
	}
}
</style>
