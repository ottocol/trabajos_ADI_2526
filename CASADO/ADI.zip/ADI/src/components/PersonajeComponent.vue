<script setup>
import "@/CSS/componentes.css";
import { computed, ref } from 'vue';

const props = defineProps({
	personaje: {
		type: Object,
		required: true,
		default: () => ({
			nombre: 'Nombre Personaje',
			imagen: '/helicoptero.jpg',
			vida: '—',
			velocidad_de_ataque: '—',
			dano_de_ataque: '—',
			poder_de_habilidad: '—',
			armadura: '—',
			resistencia_magica: '—',
			probabilidad_de_critico: '—',
			mana_habilidad: '—',
			coste: '—',
			nombre_habilidad: '—',
			desc_habilidad: '—',
			sinergias: []
		})
	}
});

const expandido = ref(false);

const stats = computed(() => [
	{ label: 'Vida', value: props.personaje.vida || '—' },
	{ label: 'Velocidad de ataque', value: props.personaje.velocidad_de_ataque || '—' },
	{ label: 'Daño de ataque', value: props.personaje.dano_de_ataque || '—' },
	{ label: 'Poder de habilidad', value: props.personaje.poder_de_habilidad || '—' },
	{ label: 'Armadura', value: props.personaje.armadura || '—' },
	{ label: 'Resistencia mágica', value: props.personaje.resistencia_magica || '—' },
	{ label: 'Prob. de crítico', value: props.personaje.probabilidad_de_critico || '—' },
	{ label: 'Maná de habilidad', value: props.personaje.mana_habilidad || '—' },
	{ label: 'Coste', value: props.personaje.coste || '—' },
	{ label: 'Nombre de habilidad', value: props.personaje.nombre_habilidad || '—' },
	{ label: 'Descripción de habilidad', value: props.personaje.desc_habilidad || '—' }
]);

const toggleExpansion = () => {
	expandido.value = !expandido.value;
};
</script>

<template>
	<div class="componente" data-component="personaje-component">
		<div class="personaje-grid" :class="{ 'personaje-grid-collapsed': !expandido }" data-component="personaje-grid">
			<!-- Nombre del personaje -->
			<div class="personaje-nombre" data-component="personaje-nombre" @click="toggleExpansion" style="cursor: pointer;">
				<div class="personaje-stat-nombre" data-component="personaje-stat-nombre">
					<div class="personaje-stat-value" data-component="personaje-stat-value">
						{{ personaje.nombre }}
						<span class="expand-icon">{{ expandido ? '▲' : '▼' }}</span>
					</div>
					<img 
						:src="personaje.imagen" 
						:alt="personaje.nombre" 
						:title="personaje.nombre" 
						class="toggle-image"
						height="32" 
						width="32"
					>
				</div>
			</div>

			<!-- Vista colapsada: solo sinergias -->
			<div v-if="!expandido" class="personaje-sinergias-collapsed">
				<router-link 
					v-for="sinergia in personaje.sinergias" 
					:key="sinergia.id || sinergia.nombre"
					:to="`/sinergias/${sinergia.slug || (typeof sinergia === 'string' ? sinergia.toLowerCase().replace(/\s+/g, '-') : sinergia.nombre?.toLowerCase().replace(/\s+/g, '-'))}`"
					class="toggle-label-image" 
					:data-name="sinergia.nombre"
				>
					<img
						:src="sinergia.imagen || '/helicoptero.jpg'"
						:alt="sinergia.nombre"
						:title="sinergia.nombre"
						class="toggle-image sinergia-icon-img"
					>
				</router-link>
				<router-link 
					:to="`/personajes/${personaje.slug || personaje.nombre.toLowerCase().replace(/\s+/g, '-')}`"
					class="ver-detalles-btn"
				>
					Ver más
				</router-link>
			</div>

			<!-- Vista expandida: todas las stats -->
			<template v-else>
				<!-- Datos del personaje -->
				<div class="personaje-datos" data-component="personaje-datos">
					<div 
						v-for="(stat, index) in stats" 
						:key="index"
						class="personaje-stat" 
						data-component="personaje-stat"
					>
						<div class="personaje-stat-value" data-component="personaje-stat-value">
							{{ stat.value }}
						</div>
						<div class="personaje-stat-label" data-component="personaje-stat-label">
							{{ stat.label }}
						</div>
					</div>
				</div>

				<!-- Iconos de sinergias -->
				<div class="comp-iconos">
					<router-link 
						v-for="sinergia in personaje.sinergias" 
						:key="sinergia.id || sinergia.nombre"
						:to="`/sinergias/${sinergia.slug || (typeof sinergia === 'string' ? sinergia.toLowerCase().replace(/\s+/g, '-') : sinergia.nombre?.toLowerCase().replace(/\s+/g, '-'))}`"
						class="toggle-label-image" 
						:data-name="sinergia.nombre"
					>
						<img
							:src="sinergia.imagen || '/helicoptero.jpg'"
							:alt="sinergia.nombre"
							:title="sinergia.nombre"
							class="toggle-image sinergia-icon-img"
						>
					</router-link>
				</div>
			</template>
		</div>
	</div>
</template>

<style scoped>
.componente {
	transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.personaje-grid {
	transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.personaje-grid-collapsed {
	display: flex;
	align-items: center;
	gap: var(--space-4);
}

.personaje-nombre {
	transition: all 0.2s ease;
}

.personaje-nombre:hover {
	opacity: 0.8;
}

.personaje-sinergias-collapsed {
	display: flex;
	align-items: center;
	gap: var(--space-3);
	flex-wrap: wrap;
	flex: 1;
	animation: fadeIn 0.3s ease-in-out;
}

.personaje-datos,
.comp-iconos {
	animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
	from {
		opacity: 0;
		transform: translateY(-8px);
	}
	to {
		opacity: 1;
		transform: translateY(0);
	}
}

.expand-icon {
	margin-left: var(--space-2);
	font-size: 0.7rem;
	opacity: 0.5;
	transition: all 0.2s ease;
	display: inline-block;
}

.personaje-nombre:hover .expand-icon {
	opacity: 0.8;
	transform: scale(1.1);
}

.ver-detalles-btn {
	padding: var(--space-2) var(--space-4);
	background: var(--btn-primary);
	color: white;
	border-radius: var(--border-radius-md);
	text-decoration: none;
	font-size: var(--font-size-sm);
	font-weight: var(--font-weight-medium);
	transition: all 0.2s ease;
	white-space: nowrap;
	margin-left: auto;
}

.ver-detalles-btn:hover {
	background: var(--btn-primary-hover);
	transform: translateY(-1px);
	box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.toggle-label-image {
	transition: all 0.2s ease;
}

.toggle-label-image:hover {
	transform: translateY(-2px);
}

.sinergia-icon-img {
	filter: invert(1);
	background: transparent;
}
</style>
