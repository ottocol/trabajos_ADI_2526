<script setup>
import { ref } from 'vue';
import { useComposicionesStore } from '@/stores/composiciones.js';
import ComposicionForm from './ComposicionForm.vue';

const props = defineProps({
	show: {
		type: Boolean,
		default: false
	}
});

const emit = defineEmits(['close', 'created']);

const composicionesStore = useComposicionesStore();
const formRef = ref(null);
const loading = ref(false);

const handleSubmit = async (datos) => {
	try {
		loading.value = true;

		await composicionesStore.crearComposicion(datos);

		emit('created');
		emit('close');
		if (formRef.value) {
			formRef.value.resetForm();
		}
	} catch (err) {
		if (formRef.value) {
			formRef.value.setError(err.message || 'Error al crear la composición');
		}
	} finally {
		loading.value = false;
	}
};

const handleCancel = () => {
	emit('close');
	if (formRef.value) {
		formRef.value.resetForm();
	}
};
</script>

<template>
	<Teleport to="body">
		<div v-if="show" class="modal-overlay" @click.self="handleCancel">
			<div class="modal-content" @click.stop>
				<div class="modal-header">
					<h2>Crear Nueva Composición</h2>
					<button @click="handleCancel" class="btn-close">✕</button>
				</div>

				<div class="modal-body">
					<ComposicionForm 
						ref="formRef"
						@submit="handleSubmit"
						@cancel="handleCancel"
					/>
				</div>

				<div class="modal-footer">
					<button @click="handleCancel" type="button" class="btn-secondary">
						Cancelar
					</button>
					<button @click="formRef?.handleSubmit?.()" type="button" class="btn-primary" :disabled="loading">
						{{ loading ? 'Creando...' : 'Crear' }}
					</button>
				</div>
			</div>
		</div>
	</Teleport>
</template>

<style scoped>
.modal-overlay {
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(0, 0, 0, 0.6);
	display: flex;
	align-items: center;
	justify-content: center;
	z-index: 9999;
	padding: 1rem;
}

.modal-content {
	background: white;
	border-radius: var(--border-radius-xl);
	max-width: 900px;
	width: 100%;
	max-height: 90vh;
	display: flex;
	flex-direction: column;
	box-shadow: var(--shadow-2xl);
}

.modal-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: var(--space-6);
	border-bottom: 2px solid var(--border-primary);
}

.modal-header h2 {
	margin: 0;
	font-size: var(--font-size-2xl);
	color: var(--text-primary);
}

.btn-close {
	background: none;
	border: none;
	font-size: var(--font-size-3xl);
	cursor: pointer;
	color: var(--text-secondary);
	padding: 0;
	width: 32px;
	height: 32px;
	display: flex;
	align-items: center;
	justify-content: center;
	border-radius: var(--border-radius-md);
	transition: all 0.2s ease;
}

.btn-close:hover {
	background: var(--gray-100);
	color: var(--text-primary);
}

.modal-body {
	padding: var(--space-6);
	overflow-y: auto;
	flex: 1;
}

.modal-footer {
	display: flex;
	justify-content: flex-end;
	gap: var(--space-3);
	padding: var(--space-6);
	border-top: 2px solid var(--border-primary);
}

.btn-primary,
.btn-secondary {
	padding: var(--space-3) var(--space-6);
	border-radius: var(--border-radius-md);
	font-size: var(--font-size-base);
	font-weight: var(--font-weight-semibold);
	cursor: pointer;
	transition: all 0.2s ease;
	border: none;
}

.btn-primary {
	background: var(--btn-primary);
	color: white;
}

.btn-primary:hover:not(:disabled) {
	background: var(--btn-primary-hover);
	transform: translateY(-1px);
	box-shadow: var(--shadow-md);
}

.btn-primary:disabled {
	opacity: 0.5;
	cursor: not-allowed;
}

.btn-secondary {
	background: var(--gray-200);
	color: var(--text-primary);
}

.btn-secondary:hover {
	background: var(--gray-300);
}

@media (max-width: 768px) {
	.modal-content {
		max-height: 95vh;
	}
}

</style>
