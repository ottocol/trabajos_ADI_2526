<script setup>
import { ref, watch, onMounted } from 'vue';
import { usePersonajesStore } from '@/stores/personajes.js';

const props = defineProps({
	composicion: {
		type: Object,
		default: null
	}
});

const emit = defineEmits(['submit', 'cancel']);

const personajesStore = usePersonajesStore();
const formRef = ref(null);

const form = ref({
	nombre: '',
	personajes: [],
	posicion_promedio: 4,
	tasa_de_seleccion: 0,
	tasa_de_victorias: 0,
	tasa_top_4: 0
});

const error = ref(null);

const rules = {
	nombre: [
		v => !!v || 'El nombre es obligatorio',
		v => (v && v.length >= 1) || 'El nombre debe tener al menos 1 carácter',
	],
	posicion: [
		v => v !== null && v !== undefined && v !== '' || 'La posición promedio es obligatoria',
		v => {
			const num = parseFloat(v);
			return (!isNaN(num) && num >= 1 && num <= 8) || 'La posición debe estar entre 1 y 8';
		}
	],
	tasa: [
		v => {
			if (v === null || v === undefined || v === '') return true;
			const num = parseFloat(v);
			return (!isNaN(num) && num >= 0 && num <= 100) || 'La tasa debe estar entre 0 y 100';
		}
	],
	personajes: [
		() => form.value.personajes.length > 0 || 'Debes seleccionar al menos un personaje'
	]
};

const resetForm = () => {
	form.value = {
		nombre: '',
		personajes: [],
		posicion_promedio: 4,
		tasa_de_seleccion: 0,
		tasa_de_victorias: 0,
		tasa_top_4: 0
	};
	error.value = null;
	if (formRef.value) {
		formRef.value.resetValidation();
	}
};

watch(() => props.composicion, (newVal) => {
	if (newVal) {
		form.value = {
			nombre: newVal.nombre || '',
			personajes: [...(newVal.personajes || [])],
			posicion_promedio: newVal.posicion_promedio || 4,
			tasa_de_seleccion: newVal.tasa_seleccion || 0,
			tasa_de_victorias: newVal.tasa_victoria || 0,
			tasa_top_4: newVal.tasa_top4 || 0
		};
	} else {
		resetForm();
	}
}, { immediate: true });

onMounted(async () => {
	if (personajesStore.personajes.length === 0) {
		await personajesStore.cargarTodosPersonajes();
	}
});

const togglePersonaje = (personajeId) => {
	const index = form.value.personajes.indexOf(personajeId);
	if (index > -1) {
		form.value.personajes.splice(index, 1);
	} else {
		form.value.personajes.push(personajeId);
	}
};

const isPersonajeSelected = (personajeId) => {
	return form.value.personajes.includes(personajeId);
};

const handleSubmit = async () => {
	const { valid } = await formRef.value.validate();
	
	if (!valid) {
		error.value = 'Por favor, corrige los errores del formulario';
		return;
	}

	error.value = null;

	const datos = {
		nombre: form.value.nombre,
		personajes: form.value.personajes,
		posicion_promedio: parseFloat(form.value.posicion_promedio) || 4,
		tasa_de_seleccion: parseFloat(form.value.tasa_de_seleccion) || 0,
		tasa_de_victorias: parseFloat(form.value.tasa_de_victorias) || 0,
		tasa_top_4: parseFloat(form.value.tasa_top_4) || 0
	};

	emit('submit', datos);
};

const handleCancel = () => {
	emit('cancel');
};

defineExpose({
	resetForm,
	setError: (msg) => { error.value = msg; },
	handleSubmit
});
</script>

<template>
	<v-form ref="formRef" @submit.prevent="handleSubmit">
		<v-alert v-if="error" type="error" class="mb-4">
			{{ error }}
		</v-alert>

		<!-- Nombre -->
		<v-text-field
			v-model="form.nombre"
			label="Nombre de la composición"
			placeholder="Ej: Briar Carry"
			:rules="rules.nombre"
			variant="outlined"
			required
		></v-text-field>

		<!-- Personajes -->
		<div class="personajes-section mb-6">
			<label class="text-subtitle-1 font-weight-medium mb-2 d-block">
				Personajes ({{ form.personajes.length }} seleccionados)
			</label>
			<div class="personajes-grid">
				<div
					v-for="personaje in personajesStore.personajes"
					:key="personaje.id"
					@click="togglePersonaje(personaje.id)"
					class="personaje-card"
					:class="{ 'personaje-selected': isPersonajeSelected(personaje.id) }"
				>
					<img 
						:src="personaje.imagen" 
						:alt="personaje.nombre"
						:title="personaje.nombre"
					/>
					<span class="personaje-nombre">{{ personaje.nombre }}</span>
					<span v-if="isPersonajeSelected(personaje.id)" class="check-icon">✓</span>
				</div>
			</div>
			<v-input :rules="rules.personajes" class="personajes-validation" style="margin-top: 0;">
				<template v-slot:default></template>
			</v-input>
		</div>

		<!-- Estadísticas -->
		<v-row>
			<v-col cols="12" md="6">
				<v-text-field
					v-model.number="form.posicion_promedio"
					label="Posición promedio"
					type="number"
					step="0.01"
					min="1"
					max="8"
					:rules="rules.posicion"
					variant="outlined"
					required
					hint="Entre 1 y 8"
					persistent-hint
				></v-text-field>
			</v-col>

			<v-col cols="12" md="6">
				<v-text-field
					v-model.number="form.tasa_de_seleccion"
					label="Tasa de selección (%)"
					type="number"
					step="0.01"
					min="0"
					max="100"
					:rules="rules.tasa"
					variant="outlined"
					hint="Entre 0 y 100"
					persistent-hint
				></v-text-field>
			</v-col>

			<v-col cols="12" md="6">
				<v-text-field
					v-model.number="form.tasa_de_victorias"
					label="Tasa de victorias (%)"
					type="number"
					step="0.01"
					min="0"
					max="100"
					:rules="rules.tasa"
					variant="outlined"
					hint="Entre 0 y 100"
					persistent-hint
				></v-text-field>
			</v-col>

			<v-col cols="12" md="6">
				<v-text-field
					v-model.number="form.tasa_top_4"
					label="Tasa Top 4 (%)"
					type="number"
					step="0.01"
					min="0"
					max="100"
					:rules="rules.tasa"
					variant="outlined"
					hint="Entre 0 y 100"
					persistent-hint
				></v-text-field>
			</v-col>
		</v-row>
	</v-form>
</template>

<style scoped>
.personajes-section {
	margin-bottom: 24px;
}

.personajes-validation {
	margin-top: -20px;
}

.personajes-validation :deep(.v-input__control) {
	min-height: 0;
	display: none;
}

.personajes-validation :deep(.v-input__details) {
	padding-top: 4px;
	min-height: 0;
}

.personajes-grid {
	display: grid;
	grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
	gap: var(--space-3);
	max-height: 400px;
	overflow-y: auto;
	padding: var(--space-2);
	border: 2px solid rgba(0, 0, 0, 0.23);
	border-radius: var(--border-radius-md);
}

.personaje-card {
	position: relative;
	display: flex;
	flex-direction: column;
	align-items: center;
	gap: var(--space-2);
	padding: var(--space-3);
	border: 2px solid rgba(0, 0, 0, 0.23);
	border-radius: var(--border-radius-md);
	cursor: pointer;
	transition: all 0.2s ease;
	background: white;
}

.personaje-card:hover {
	border-color: rgb(var(--v-theme-primary));
	transform: translateY(-2px);
	box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.personaje-selected {
	border-color: rgb(var(--v-theme-primary));
	background: rgba(var(--v-theme-primary), 0.08);
}

.personaje-card img {
	width: 64px;
	height: 64px;
	object-fit: cover;
	border-radius: var(--border-radius-md);
}

.personaje-nombre {
	font-size: var(--font-size-sm);
	text-align: center;
	color: var(--text-primary);
	font-weight: var(--font-weight-medium);
}

.check-icon {
	position: absolute;
	top: var(--space-2);
	right: var(--space-2);
	background: rgb(var(--v-theme-primary));
	color: white;
	width: 24px;
	height: 24px;
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
	font-size: var(--font-size-sm);
	font-weight: var(--font-weight-bold);
}

@media (max-width: 768px) {
	.personajes-grid {
		grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
		max-height: 300px;
	}
}
</style>
