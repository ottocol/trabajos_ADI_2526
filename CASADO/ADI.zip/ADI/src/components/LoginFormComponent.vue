<script setup>
import { ref } from "vue";
import { useForm, useField } from "vee-validate";
import { useRouter } from "vue-router";
import { useAuthStore } from "@/stores/auth";

const authStore = useAuthStore();
const router = useRouter();
const { handleSubmit, errors } = useForm();

const { value: email } = useField("email", "required|email");

const { value: contraseña } = useField("contraseña", "required|min:8");

const loading = ref(false);
const shake = ref(false);

const triggerShake = () => {
	shake.value = true;
	setTimeout(() => {
		shake.value = false;
	}, 500);
};

const onSubmit = handleSubmit(
	async (values) => {
		loading.value = true;
		try {
			await authStore.login(values.email, values.contraseña);
			router.push("/profile");
		} catch (error) {
			loading.value = false;
			triggerShake();
		}
	},
	() => {
		// Callback cuando la validación de campos falla
		triggerShake();
	},
);
</script>

<template>
	<v-card>
		<v-card-title>Iniciar sesión</v-card-title>
		<v-card-text>
			<form @submit.prevent="onSubmit">
				<v-text-field
					v-model="email"
					label="Email"
					type="email"
					:error-messages="errors.email"
					placeholder="prueba@prueba.com"
					prepend-icon="mdi-email"
					variant="outlined"
					class="mb-2"
				/>

				<v-text-field
					v-model="contraseña"
					label="Contraseña"
					type="password"
					:error-messages="errors.contraseña"
					hint="Mínimo 8 caracteres"
					prepend-icon="mdi-lock"
					variant="outlined"
					class="mb-2"
				/>

				<v-btn type="submit" color="primary" :loading="loading" block size="large" :class="{ 'shake-animation': shake }">
					Iniciar sesión
				</v-btn>
			</form>
		</v-card-text>
	</v-card>
</template>

<style scoped>
.shake-animation {
	animation: shake 0.5s;
}

@keyframes shake {
	0%,
	100% {
		transform: translateX(0);
	}
	10%,
	30%,
	50%,
	70%,
	90% {
		transform: translateX(-10px);
	}
	20%,
	40%,
	60%,
	80% {
		transform: translateX(10px);
	}
}
</style>
