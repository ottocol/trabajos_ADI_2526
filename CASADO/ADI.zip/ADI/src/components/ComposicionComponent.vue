<script setup>
import "@/CSS/componentes.css";
import { computed, ref } from 'vue';
import { useAuthStore } from '@/stores/auth.js';
import { useComposicionesStore } from '@/stores/composiciones.js';
import EditarComposicionModal from './EditarComposicionModal.vue';

const props = defineProps({
	composicion: {
		type: Object,
		required: true,
		default: () => ({
			nombre: 'Nombre Composición',
			personajes: [],
			tasa_victoria: 0,
			posicion_promedio: 0,
			tasa_seleccion: 0,
			tasa_top4: 0
		})
	}
});

const emit = defineEmits(['updated']);

const authStore = useAuthStore();
const composicionesStore = useComposicionesStore();
const showEditModal = ref(false);

const esDelUsuario = computed(() => {
	return authStore.isAuthenticated && 
	       authStore.user && 
	       props.composicion.usuario_id === authStore.user.id;
});

const stats = computed(() => [
	{ label: 'Posición promedio', value: props.composicion.posicion_promedio?.toFixed(2) || '—' },
	{ label: 'Tasa de selección', value: props.composicion.tasa_seleccion?.toFixed(2) || '—' },
	{ label: 'Tasa de victorias', value: props.composicion.tasa_victoria?.toFixed(2) || '—' },
	{ label: 'Top 4', value: props.composicion.tasa_top4?.toFixed(2) || '—' }
]);

const editarComposicion = () => {
	showEditModal.value = true;
};

const handleUpdated = async () => {
	await composicionesStore.cargarTodasComposiciones();
	emit('updated');
};

const eliminarComposicion = async () => {
	if (!confirm(`¿Estás seguro de que quieres eliminar "${props.composicion.nombre}"?`)) {
		return;
	}
	
	try {
		await composicionesStore.eliminarComposicion(props.composicion.id);
	} catch (err) {
		alert('Error al eliminar la composición: ' + err.message);
	}
};
</script>

<template>
	<div class="componente" data-component="composicion-component" :class="{ 'componente-propio': esDelUsuario }">
		<div class="composicion-grid" data-component="composicion-grid">
			<!-- Nombre de la composición -->
			<div class="composicion-nombre" data-component="composicion-nombre">
				<div class="composicion-stat-nombre" data-component="composicion-stat-nombre">
					<div class="composicion-stat-value" data-component="composicion-stat-value">
						{{ composicion.nombre }}
					</div>
				</div>
			</div>

			<!-- Iconos de personajes -->
			<div class="composicion-iconos" data-component="composicion-iconos">
				<router-link 
					v-for="personaje in composicion.personajesData" 
					:key="personaje.id || personaje.nombre || personaje"
					:to="`/personajes/${personaje.slug || (typeof personaje === 'string' ? personaje.toLowerCase().replace(/\s+/g, '-') : personaje.nombre?.toLowerCase().replace(/\s+/g, '-'))}`"
					class="toggle-label-image" 
					:data-name="personaje.nombre || personaje"
				>
					<img
						:src="personaje.imagen || '/helicoptero.jpg'"
						:alt="personaje.nombre || personaje"
						:title="personaje.nombre || personaje"
						class="toggle-image"
					>
				</router-link>
			</div>

			<!-- Datos de la composición -->
			<div class="composicion-datos" data-component="composicion-datos">
				<div 
					v-for="(stat, index) in stats" 
					:key="index"
					class="composicion-stat" 
					data-component="composicion-stat"
				>
					<div class="composicion-stat-value" data-component="composicion-stat-value">
						{{ stat.value }}
					</div>
					<div class="composicion-stat-label" data-component="composicion-stat-label">
						{{ stat.label }}
					</div>
				</div>
			</div>

			<!-- Botones de editar/eliminar si es del usuario -->
			<div v-if="esDelUsuario" class="composicion-acciones">
				<button @click="editarComposicion" class="btn-editar" title="Editar composición">
					✏️
				</button>
				<button @click="eliminarComposicion" class="btn-eliminar" title="Eliminar composición">
					🗑️
				</button>
			</div>
		</div>

		<!-- Modal de edición -->
		<EditarComposicionModal 
			:show="showEditModal"
			:composicion="composicion"
			@close="showEditModal = false"
			@updated="handleUpdated"
		/>
	</div>
</template>

<style scoped>
.componente-propio {
	position: relative;
	border: 2px solid var(--blue-400);
	border-radius: var(--border-radius-lg);
	box-shadow: 0 0 0 2px var(--blue-100);
}

.composicion-acciones {
	position: absolute;
	top: var(--space-2);
	right: var(--space-2);
	display: flex;
	gap: var(--space-2);
	opacity: 0;
	transition: opacity 0.2s ease;
}

.componente-propio:hover .composicion-acciones {
	opacity: 1;
}

.btn-editar,
.btn-eliminar {
	background: white;
	border: 2px solid var(--border-primary);
	border-radius: var(--border-radius-md);
	padding: var(--space-2);
	cursor: pointer;
	font-size: var(--font-size-lg);
	transition: all 0.2s ease;
	width: 36px;
	height: 36px;
	display: flex;
	align-items: center;
	justify-content: center;
}

.btn-editar:hover {
	background: var(--blue-50);
	border-color: var(--blue-500);
	transform: scale(1.1);
}

.btn-eliminar:hover {
	background: var(--red-50);
	border-color: var(--red-500);
	transform: scale(1.1);
}

.btn-editar:active,
.btn-eliminar:active {
	transform: scale(0.95);
}
</style>
