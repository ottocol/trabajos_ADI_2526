<script setup>
import "@/CSS/componentes.css";
import { computed, ref, defineEmits } from "vue";
import EditarSinergiaModal from "./EditarSinergiaModal.vue";
import { useSinergiasStore } from "@/stores/sinergias.js";

const props = defineProps({
	sinergia: {
		type: Object,
		required: true,
		default: () => ({
			nombre: "Nombre de Sinergia",
			imagen: "/helicoptero.jpg",
			unidades: {
				1: "—",
				2: "—",
				3: "—",
				4: "—",
				5: "—",
				6: "—",
				7: "—",
				8: "—",
				9: "—",
				10: "—",
			},
			personajes: [],
		}),
	},
});

const emit = defineEmits(["updated"]);

const sinergiasStore = useSinergiasStore();
const expandido = ref(false);
const mostrarModalEditar = ref(false);

const unidadesValidas = computed(() => {
	const unidades = props.sinergia?.unidades || {};
	if (typeof unidades !== "object" || Object.keys(unidades).length === 0) {
		return {
			1: "—",
			2: "—",
			3: "—",
			4: "—",
			5: "—",
			6: "—",
			7: "—",
			8: "—",
			9: "—",
			10: "—",
		};
	}

	return unidades;
});

const toggleExpansion = () => {
	expandido.value = !expandido.value;
};

const abrirModalEditar = () => {
	mostrarModalEditar.value = true;
};

const handleSinergiaActualizada = () => {
	emit("updated");
};

const eliminarSinergia = async () => {
	if (confirm(`¿Estás seguro de que quieres eliminar la sinergia "${props.sinergia.nombre}"?`)) {
		try {
			await sinergiasStore.eliminarSinergia(props.sinergia.id);
			emit("updated");
		} catch (error) {
			alert("Error al eliminar la sinergia: " + error.message);
		}
	}
};
</script>

<template>
	<div class="sinergia-grid" :class="{ 'sinergia-grid-collapsed': !expandido }" data-component="sinergia-grid">
		<!-- Nombre de la sinergia -->
		<div class="sinergia-nombre" data-component="sinergia-nombre" @click="toggleExpansion" style="cursor: pointer">
			<div class="sinergia-stat-nombre" data-component="sinergia-stat-nombre">
				<div class="sinergia-stat-value" data-component="sinergia-stat-value">
					{{ sinergia.nombre }}
					<span class="expand-icon">{{ expandido ? "▲" : "▼" }}</span>
				</div>
				<img
					:src="sinergia.imagen"
					:alt="sinergia.nombre"
					:title="sinergia.nombre"
					class="toggle-image sinergia-icon-img"
					height="32"
					width="32"
				/>
			</div>
		</div>

		<!-- Botones de editar y eliminar (flotantes) -->
		<div class="sinergia-actions">
			<button @click.stop="abrirModalEditar" class="btn-editar" title="Editar sinergia">
				✏️
			</button>
			<button @click.stop="eliminarSinergia" class="btn-eliminar" title="Eliminar sinergia">
				🗑️
			</button>
		</div>

			<!-- Vista colapsada: solo personajes -->
			<div v-if="!expandido" class="sinergia-personajes-collapsed">
				<router-link
					v-for="personaje in sinergia.personajes"
					:key="personaje.id || personaje.nombre || personaje"
					:to="`/personajes/${personaje.slug || (typeof personaje === 'string' ? personaje.toLowerCase().replace(/\s+/g, '-') : personaje.nombre?.toLowerCase().replace(/\s+/g, '-'))}`"
					class="toggle-label-image"
					:data-name="personaje.nombre || personaje"
				>
					<img
						:src="personaje.imagen || '/helicoptero.jpg'"
						:alt="personaje.nombre || personaje"
						:title="personaje.nombre || personaje"
						class="toggle-image"
					/>
				</router-link>
				<router-link
					:to="`/sinergias/${sinergia.slug || sinergia.nombre.toLowerCase().replace(/\s+/g, '-')}`"
					class="ver-detalles-btn"
				>
					Ver más
				</router-link>
			</div>

			<!-- Vista expandida: todas las unidades -->
			<template v-else>
				<!-- Datos de unidades -->
				<div class="sinergia-datos" data-component="sinergia-datos">
					<div
						v-for="(valor, unidad) in unidadesValidas"
						:key="unidad"
						class="sinergia-stat"
						data-component="sinergia-stat"
					>
						<div class="sinergia-stat-value" data-component="sinergia-stat-value">
							{{ valor }}
						</div>
						<div class="sinergia-stat-label" data-component="sinergia-stat-label">
							{{ unidad }} {{ unidad === "1" ? "Unidad" : "Unidades" }}
						</div>
					</div>
				</div>

				<!-- Iconos de personajes -->
				<div class="sinergia-iconos">
					<router-link
						v-for="personaje in sinergia.personajes"
						:key="personaje.id || personaje.nombre || personaje"
						:to="`/personajes/${personaje.slug || (typeof personaje === 'string' ? personaje.toLowerCase().replace(/\s+/g, '-') : personaje.nombre?.toLowerCase().replace(/\s+/g, '-'))}`"
						class="toggle-label-image"
						:data-name="personaje.nombre || personaje"
					>
						<img
							:src="personaje.imagen || '/helicoptero.jpg'"
							:alt="personaje.nombre || personaje"
							:title="personaje.nombre || personaje"
							class="toggle-image"
						/>
					</router-link>
			</div>
		</template>
	</div>

	<!-- Modal de edición -->
	<EditarSinergiaModal
		v-model="mostrarModalEditar"
		:sinergia="sinergia"
		@updated="handleSinergiaActualizada"
	/>
</template><style scoped>
.sinergia-grid {
	position: relative;
	transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.sinergia-grid:hover .sinergia-actions {
	opacity: 1;
}

.sinergia-grid-collapsed {
	display: flex;
	align-items: center;
	gap: var(--space-4);
}

.sinergia-nombre {
	transition: all 0.2s ease;
}

.sinergia-nombre:hover {
	opacity: 0.8;
}

.sinergia-actions {
	position: absolute;
	top: var(--space-2);
	right: var(--space-2);
	display: flex;
	gap: var(--space-2);
	opacity: 0;
	transition: opacity 0.2s ease;
}

.btn-editar,
.btn-eliminar {
	background: white;
	border: 2px solid var(--border-primary);
	border-radius: var(--border-radius-md);
	padding: var(--space-2);
	cursor: pointer;
	font-size: var(--font-size-lg);
	transition: all 0.2s ease;
	width: 36px;
	height: 36px;
	display: flex;
	align-items: center;
	justify-content: center;
}

.btn-editar:hover {
	background: var(--blue-50);
	border-color: var(--blue-500);
	transform: scale(1.1);
}

.btn-eliminar:hover {
	background: var(--red-50);
	border-color: var(--red-500);
	transform: scale(1.1);
}

.btn-editar:active,
.btn-eliminar:active {
	transform: scale(0.95);
}

.sinergia-personajes-collapsed {
	display: flex;
	align-items: center;
	gap: var(--space-3);
	flex-wrap: wrap;
	flex: 1;
	animation: fadeIn 0.3s ease-in-out;
}

.sinergia-datos,
.sinergia-iconos {
	animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
	from {
		opacity: 0;
		transform: translateY(-8px);
	}
	to {
		opacity: 1;
		transform: translateY(0);
	}
}

.expand-icon {
	margin-left: var(--space-2);
	font-size: 0.7rem;
	opacity: 0.5;
	transition: all 0.2s ease;
	display: inline-block;
}

.sinergia-nombre:hover .expand-icon {
	opacity: 0.8;
	transform: scale(1.1);
}

.ver-detalles-btn {
	padding: var(--space-2) var(--space-4);
	background: var(--btn-primary);
	color: white;
	border-radius: var(--border-radius-md);
	text-decoration: none;
	font-size: var(--font-size-sm);
	font-weight: var(--font-weight-medium);
	transition: all 0.2s ease;
	white-space: nowrap;
	margin-left: auto;
}

.ver-detalles-btn:hover {
	background: var(--btn-primary-hover);
	transform: translateY(-1px);
	box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.toggle-label-image {
	transition: all 0.2s ease;
}

.toggle-label-image:hover {
	transform: translateY(-2px);
}

.sinergia-icon-img {
	filter: invert(1);
	background: transparent;
}
</style>
