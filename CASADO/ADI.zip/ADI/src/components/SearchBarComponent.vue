<script setup>
import "@/CSS/barraBusqueda.css";
import { computed } from 'vue';

const props = defineProps({
	modelValue: {
		type: String,
		default: ''
	},
	placeholder: {
		type: String,
		default: 'Escribe tu búsqueda...'
	},
	sugerencias: {
		type: Array,
		default: () => []
	},
	ariaLabel: {
		type: String,
		default: 'Buscar en el sitio'
	}
});

const emit = defineEmits(['update:modelValue', 'search']);

const searchQuery = computed({
	get() {
		return props.modelValue;
	},
	set(value) {
		emit('update:modelValue', value);
	}
});

const handleSubmit = (event) => {
	event.preventDefault();
	emit('search', searchQuery.value);
};
</script>

<template>
	<form 
		@submit="handleSubmit"
		role="search" 
		:aria-label="ariaLabel"
		class="barra-busqueda"
	>
		<label for="q">Buscar:</label>
		<input 
			id="q" 
			v-model="searchQuery"
			name="q" 
			type="search" 
			:placeholder="placeholder"
			autocomplete="on"
			:list="sugerencias.length > 0 ? 'sugerencias' : undefined" 
			aria-describedby="hint" 
		/>
		<datalist 
			v-if="sugerencias.length > 0" 
			id="sugerencias" 
			data-component="sugerencias-busqueda"
		>
			<option 
				v-for="sugerencia in sugerencias" 
				:key="sugerencia"
				:value="sugerencia"
			/>
		</datalist>

		<button type="submit" data-component="buscar-button">Buscar</button>
		<p id="hint">Pulsa Enter o el botón "Buscar".</p>
	</form>
</template>
