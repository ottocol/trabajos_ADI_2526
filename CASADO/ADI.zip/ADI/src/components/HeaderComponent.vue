<script setup>
import "@/CSS/headerFooter.css";
import { useAuthStore } from "@/stores/auth";

const authStore = useAuthStore();
</script>

<template>
	<div>
		<header data-component="SiteHeader">
			<nav data-component="SiteNavBar">
				<ul>
					<li class="logo">
						<router-link to="/"><img src="/logo.svg" alt="TFT Composiciones Logo" /></router-link>
					</li>
					<li><router-link to="/composiciones">Composiciones</router-link></li>
					<li><router-link to="/personajes">Personajes</router-link></li>
					<li><router-link to="/sinergias">Sinergias</router-link></li>
					<li class="perfil">
						<v-menu v-if="authStore.isAuthenticated">
							<template v-slot:activator="{ props }">
								<v-btn v-bind="props" variant="text">
									{{ authStore.userName }}
									<v-icon end>mdi-chevron-down</v-icon>
								</v-btn>
							</template>
							<v-list>
								<v-list-item prepend-icon="mdi-account" to="/profile">
									<v-list-item-title>Perfil</v-list-item-title>
								</v-list-item>
								<v-list-item prepend-icon="mdi-logout" @click="authStore.logout" to="/">
									<v-list-item-title>Cerrar sesión</v-list-item-title>
								</v-list-item>
							</v-list>
						</v-menu>
						<router-link to="/auth" v-else><img src="/profile_icon.svg" alt="User Profile" /></router-link>
					</li>
				</ul>
			</nav>
			<hr />
		</header>
	</div>
</template>
