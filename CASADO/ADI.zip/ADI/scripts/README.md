# Scripts de Administración

Este directorio contiene scripts útiles para la gestión de la base de datos y datos iniciales.

## 📜 Scripts Disponibles

### `seed.js` - Poblado de Datos Iniciales

Crea el usuario de pruebas y carga automáticamente todos los personajes y sinergias desde la API de Riot Games.

#### Requisitos
- Service Role Key de Supabase (no la Anon Key)
- Conexión a internet (para acceder a la API de Riot)

#### Configuración

1. Obtén tu Service Role Key:
   - Ve a tu proyecto en Supabase Dashboard
   - Navega a **Settings → API**
   - Copia la **service_role** key (⚠️ NO la anon/public key)

2. Añade la key a tu archivo `.env`:
   ```env
   SUPABASE_SERVICE_KEY=tu_service_role_key_aqui
   ```

#### Uso

```bash
npm run seed
```

#### ¿Qué hace?

- ✅ Verifica si existe el usuario de pruebas `test@test.com`
- ✅ Si no existe, lo crea con password `test1234`
- ✅ Crea automáticamente el perfil en la tabla Usuario
- ✅ **Descarga todas las sinergias de TFT desde la API de Riot Games**
- ✅ **Descarga todos los personajes de TFT desde la API de Riot Games**
- ✅ Vincula automáticamente personajes con sus sinergias
- ✅ Evita duplicados (puedes ejecutarlo múltiples veces sin problema)
- ✅ Muestra el resultado y estadísticas

#### Ejemplo de Salida

```
🌱 Iniciando seeding de Supabase...

🔍 Verificando si el usuario de pruebas existe...
👤 Creando usuario de pruebas...
✅ Usuario de pruebas creado: test@test.com
   ID: 550e8400-e29b-41d4-a716-446655440000
✅ Perfil creado automáticamente por trigger

📋 Poblando sinergias...
🎮 Obteniendo sinergias desde Riot API...
   Encontradas 25 sinergias en Riot API
   ✅ 25 sinergias creadas, 0 ya existían

🎭 Poblando personajes...
🎮 Obteniendo personajes desde Riot API...
   Encontrados 60 personajes en Riot API
   ✅ 60 personajes creados, 0 ya existían

✨ Seeding completado exitosamente!

Resumen:
  ✅ Usuario de prueba creado
  ✅ Sinergias cargadas desde Riot API
  ✅ Personajes cargados desde Riot API

Credenciales de prueba:
  Email: test@test.com
  Password: test1234
```

---

## 🔐 Seguridad

⚠️ **IMPORTANTE**: La Service Role Key es muy poderosa y **NUNCA** debe:
- Exponerse en el frontend
- Subirse a repositorios públicos
- Incluirse en código de producción
- Compartirse públicamente

Solo úsala en: El script continuará cargando sinergias y personajes.
- Scripts de administración locales
- Pipelines de CI/CD seguros
- Entornos de servidor controlados

---

## 🆘 Troubleshooting

### Error: "SUPABASE_SERVICE_KEY no está configurada"

**Solución**: Añade la Service Role Key a tu archivo `.env`

### Error: "User already registered"

**Solución**: El usuario ya existe. Esto es normal si ejecutas el script más de una vez.

### Error: "Invalid API credentials"

**Solución**: Verifica que estés usando la **service_role** key y no la anon key.

### Error al conectar con Riot API

**Solución**: Verifica tu conexión a internet. La API de Riot debe ser accesible.

### Algunos personajes no tienen sinergias

**Solución**: Es normal. Algunos personajes pueden no tener sinergias o el mapeo de IDs de Riot a nombres puede necesitar ajustes.

---

## 📝 Agregar Más Datos

Para agregar más datos de seeding, edita `seed.js` y añade funciones similares a `createTestUser()`.

Ejemplo:

```javascript
async function createSampleData() {
    // Crear sinergias de ejemplo
    await supabase.from('Sinergia').insert([
        { nombre_sinergia: 'Guardián', imagen: '...' },
        { nombre_sinergia: 'Hechicero', imagen: '...' }
    ]);
    
    // Crear personajes de ejemplo
    await supabase.from('Personaje').insert([
        { nombre: 'Campeón 1', coste: 1, imagen: '...' }
    ]);
}
```

Luego llámala en la función `seedData()`.
