// Script de Seeding para Supabase
// Ejecuta: node scripts/seed.js

import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import fetch from 'node-fetch';

// Cargar variables de entorno
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://lfuklalxbzzandpfyxkf.supabase.co';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY; // Service Role Key (NO la Anon Key)

if (!supabaseServiceKey) {
	console.error('❌ Error: SUPABASE_SERVICE_KEY no está configurada');
	console.log('Necesitas la Service Role Key (no la Anon Key) de Supabase');
	console.log('Encuéntrala en: Settings → API → service_role key');
	process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
	auth: {
		autoRefreshToken: false,
		persistSession: false
	}
});

// Credenciales del usuario de pruebas
const TEST_USER = {
	email: 'test@test.com',
	password: 'test1234',
	nombre: 'Usuario Test'
};

// Configuración de la API de Riot
const RIOT_VERSION = "15.19.1";
const RIOT_BASE_URL = `https://ddragon.leagueoflegends.com/cdn/${RIOT_VERSION}/data/es_ES`;
const RIOT_IMG_BASE_URL = `https://ddragon.leagueoflegends.com/cdn/${RIOT_VERSION}/img`;

async function createTestUser() {
	console.log('🔍 Verificando si el usuario de pruebas existe...');

	// Verificar si el usuario ya existe
	const { data: existingUsers, error: searchError } = await supabase
		.from('Usuario')
		.select('*')
		.eq('email', TEST_USER.email);

	if (existingUsers && existingUsers.length > 0) {
		console.log('✅ Usuario de pruebas ya existe:', TEST_USER.email);
		return existingUsers[0];
	}

	console.log('👤 Creando usuario de pruebas...');

	// Crear usuario en Supabase Auth
	const { data: authData, error: authError } = await supabase.auth.admin.createUser({
		email: TEST_USER.email,
		password: TEST_USER.password,
		email_confirm: true,
		user_metadata: {
			nombre: TEST_USER.nombre
		}
	});

	if (authError) {
		console.error('❌ Error al crear usuario en Auth:', authError.message);
		throw authError;
	}

	console.log('✅ Usuario de pruebas creado:', TEST_USER.email);
	console.log('   ID:', authData.user.id);

	// El trigger handle_new_user() debería crear automáticamente el perfil
	// Verificar que se creó el perfil
	await new Promise(resolve => setTimeout(resolve, 1000)); // Esperar 1 segundo

	const { data: userProfile } = await supabase
		.from('Usuario')
		.select('*')
		.eq('id', authData.user.id)
		.single();

	if (!userProfile) {
		console.log('⚠️  Creando perfil manualmente...');
		
		const { error: insertError } = await supabase
			.from('Usuario')
			.insert({
				id: authData.user.id,
				email: TEST_USER.email,
				nombre: TEST_USER.nombre,
				fecha_registro: new Date().toISOString()
			});

		if (insertError) {
			console.error('❌ Error al crear perfil:', insertError.message);
		} else {
			console.log('✅ Perfil creado manualmente');
		}
	} else {
		console.log('✅ Perfil creado automáticamente por trigger');
	}

	return authData.user;
}

async function obtenerSinergiasDesdeRiot() {
	console.log('🎮 Obteniendo sinergias desde Riot API...');
	
	try {
		const response = await fetch(`${RIOT_BASE_URL}/tft-trait.json`);
		if (!response.ok) {
			throw new Error(`Error al obtener datos de Riot: ${response.status}`);
		}

		const jsonData = await response.json();

		const sinergiasFiltradas = Object.values(jsonData.data).filter((sinergia) => {
			return sinergia.id.startsWith("TFT15_") && !sinergia.id.includes("Mechanic");
		});

		return sinergiasFiltradas.map((sinergia) => ({
			nombre_sinergia: sinergia.name,
			imagen: sinergia.image?.full ? `${RIOT_IMG_BASE_URL}/tft-trait/${sinergia.image.full}` : "",
		}));
	} catch (error) {
		throw new Error(`Error al obtener sinergias de Riot: ${error.message}`);
	}
}

async function obtenerCampeonesDesdeRiot() {
	console.log('🎮 Obteniendo personajes desde Riot API...');
	
	try {
		const response = await fetch(`${RIOT_BASE_URL}/tft-champion.json`);
		if (!response.ok) {
			throw new Error(`Error al obtener datos de Riot: ${response.status}`);
		}

		const jsonData = await response.json();

		const campeonesFiltrados = Object.values(jsonData.data).filter((campeon) => {
			return campeon.id.startsWith("TFT15_");
		});

		return campeonesFiltrados.map((campeon) => ({
			nombre: campeon.name,
			coste: campeon.tier,
			imagen: campeon.image?.full ? `${RIOT_IMG_BASE_URL}/tft-champion/${campeon.image.full}` : "",
			sinergias_riot: campeon.traits || [], // IDs de Riot, las vincularemos después
		}));
	} catch (error) {
		throw new Error(`Error al obtener campeones de Riot: ${error.message}`);
	}
}

async function seedSinergias() {
	console.log('\n📋 Poblando sinergias...');
	
	const sinergias = await obtenerSinergiasDesdeRiot();
	console.log(`   Encontradas ${sinergias.length} sinergias en Riot API`);

	let creadas = 0;
	let existentes = 0;

	for (const sinergia of sinergias) {
		// Verificar si ya existe
		const { data: existing } = await supabase
			.from('Sinergia')
			.select('id')
			.eq('nombre_sinergia', sinergia.nombre_sinergia)
			.single();

		if (!existing) {
			const { error } = await supabase
				.from('Sinergia')
				.insert(sinergia);
			
			if (error) {
				console.error(`   ⚠️  Error al crear sinergia ${sinergia.nombre_sinergia}:`, error.message);
			} else {
				creadas++;
			}
		} else {
			existentes++;
		}
	}

	console.log(`   ✅ ${creadas} sinergias creadas, ${existentes} ya existían`);
	return sinergias;
}

async function seedPersonajes() {
	console.log('\n🎭 Poblando personajes...');
	
	const campeones = await obtenerCampeonesDesdeRiot();
	console.log(`   Encontrados ${campeones.length} personajes en Riot API`);

	// Obtener todas las sinergias para mapear IDs de Riot a IDs de Supabase
	const { data: sinergias } = await supabase
		.from('Sinergia')
		.select('id, nombre_sinergia');

	let creados = 0;
	let existentes = 0;

	for (const campeon of campeones) {
		// Verificar si ya existe
		const { data: existing } = await supabase
			.from('Personaje')
			.select('id')
			.eq('nombre', campeon.nombre)
			.single();

		if (!existing) {
			// Mapear sinergias de IDs de Riot a nombres y luego a IDs de Supabase
			const sinergiaIds = [];
			for (const traitId of campeon.sinergias_riot) {
				// Buscar la sinergia en nuestra BD que coincida con el nombre del trait de Riot
				const sinergia = sinergias?.find(s => {
					// El ID de Riot tiene formato "TFT15_NombreSinergia"
					// Necesitamos encontrar coincidencias aproximadas
					return traitId.includes(s.nombre_sinergia.replace(/\s/g, '')) ||
						   s.nombre_sinergia.toLowerCase().includes(traitId.replace('TFT15_', '').toLowerCase());
				});
				
				if (sinergia) {
					sinergiaIds.push(sinergia.id);
				}
			}

			const personajeData = {
				nombre: campeon.nombre,
				coste: campeon.coste,
				imagen: campeon.imagen,
				sinergias: sinergiaIds
			};

			const { error } = await supabase
				.from('Personaje')
				.insert(personajeData);
			
			if (error) {
				console.error(`   ⚠️  Error al crear personaje ${campeon.nombre}:`, error.message);
			} else {
				creados++;
			}
		} else {
			existentes++;
		}
	}

	console.log(`   ✅ ${creados} personajes creados, ${existentes} ya existían`);
}

async function seedData() {
	try {
		console.log('🌱 Iniciando seeding de Supabase...\n');

		// 1. Crear usuario de pruebas
		await createTestUser();

		// 2. Poblar sinergias desde Riot API
		await seedSinergias();

		// 3. Poblar personajes desde Riot API
		await seedPersonajes();

		console.log('\n✨ Seeding completado exitosamente!');
		console.log('\nResumen:');
		console.log('  ✅ Usuario de prueba creado');
		console.log('  ✅ Sinergias cargadas desde Riot API');
		console.log('  ✅ Personajes cargados desde Riot API');
		console.log('\nCredenciales de prueba:');
		console.log('  Email:', TEST_USER.email);
		console.log('  Password:', TEST_USER.password);
		
	} catch (error) {
		console.error('\n❌ Error durante el seeding:', error.message);
		console.error(error.stack);
		process.exit(1);
	}
}

// Ejecutar seeding
seedData();
