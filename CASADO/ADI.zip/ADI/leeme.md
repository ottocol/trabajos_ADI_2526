# LEEME - Partes Opcionales Implementadas

## Resumen de Funcionalidades Implementadas

Este proyecto implementa las siguientes partes opcionales del enunciado:

---

## 1. Búsqueda y Paginación de Datos (0.5 puntos)

### Búsqueda

Se ha implementado un componente `SearchBarComponent` que permite buscar en los siguientes recursos:

- **Personajes** (`PersonajesView.vue`): Búsqueda por nombre de personaje
- **Sinergias** (`SinergiasView.vue`): Búsqueda por nombre de sinergia
- **Composiciones** (`ComposicionesView.vue`): Búsqueda por nombre de composición

La búsqueda está implementada tanto en el **cliente** como en el **servidor** (backend).

### Paginación

Implementada usando el componente `v-pagination` de Vuetify:

- **10 elementos por página** en todas las vistas de listado
- Navegación entre páginas con controles visuales
- Scroll automático al inicio de la página al cambiar de página (`window.scrollTo`)
- La paginación se adapta dinámicamente al número de resultados
- Variable `elementosPorPagina = 10` en todas las vistas

**Archivos relevantes:**

- `src/views/PersonajesView.vue`
- `src/views/SinergiasView.vue`
- `src/views/ComposicionesView.vue`
- `src/components/SearchBarComponent.vue`

---

## 2. Transiciones y Animaciones (0.5 puntos)

### Animaciones CSS implementadas:

#### Efecto Shake en botones de Login/Registro

- **Ubicación**: `LoginFormComponent.vue` y `RegisterFormComponent.vue`
- **Funcionalidad**: El botón "tiembla" cuando:
    - Los campos de validación fallan (email inválido, contraseña corta, etc.)
    - El login/registro falla por credenciales incorrectas
- **Implementación**:
    - Usa animación CSS `@keyframes shake` con clase dinámica `:class="{ 'shake-animation': shake }"`
    - La función `triggerShake()` activa la animación por 500ms
    - Se ejecuta tanto en errores de validación como en errores del servidor

#### Transiciones de aparición/desaparición

- **Componente Personaje** (`PersonajeComponent.vue`):
    - Animación `fadeIn` cuando se expande/colapsa la información del personaje
    - Transiciones suaves en hover de elementos
    - Transición del ícono de expansión (▼/▲) con `transform: scale(1.1)`
    - Vista colapsada y expandida con `animation: fadeIn 0.3s ease-in-out`

- **Componente Sinergia** (`SinergiaComponent.vue`):
    - Animación `fadeIn` cuando se expande/colapsa la información de sinergia
    - Transiciones suaves entre vistas colapsada y expandida
    - Botones de editar/eliminar con transiciones en hover y active states

- **Componente Composición** (`ComposicionComponent.vue`):
    - Transiciones al mostrar botones de editar/eliminar al hacer hover
    - Efectos de escala (`transform: scale(1.1)`) y transformación en botones de acción
    - Borde especial animado para composiciones del usuario autenticado

**Archivos relevantes:**

- `src/components/LoginFormComponent.vue`
- `src/components/RegisterFormComponent.vue`
- `src/components/PersonajeComponent.vue`
- `src/components/SinergiaComponent.vue`
- `src/components/ComposicionComponent.vue`

---

## 3. Framework de Componentes Visuales - Vuetify (1 punto)

Se utiliza **Vuetify 3** como framework de componentes UI en toda la aplicación:

### Componentes de Vuetify utilizados:

- **v-card**, **v-card-title**, **v-card-text**: Tarjetas en formularios de login/registro
- **v-text-field**: Campos de entrada con validación visual integrada
- **v-btn**: Botones estilizados con estados de loading
- **v-container**, **v-row**, **v-col**: Sistema de grid responsive
- **v-pagination**: Controles de paginación en listados
- **v-dialog**: Modales para crear y editar composiciones (no implementados directamente, se usan modales customizados con Teleport)
- **v-select**: Selectores desplegables para elegir personajes (en formularios)
- **v-chip**: Chips para mostrar personajes seleccionados

### Configuración:

- Plugin Vuetify configurado directamente en `src/main.js`
- Tema personalizado con componentes y directivas
- Importación de Material Design Icons (`@mdi/font`)
- Estilos base de Vuetify importados con `import "vuetify/styles"`

**Archivos relevantes:**

- `src/main.js` - Configuración de Vuetify
- `src/components/LoginFormComponent.vue` (usa v-card, v-text-field, v-btn)
- `src/components/RegisterFormComponent.vue` (usa v-card, v-text-field, v-btn)
- Todos los componentes de vistas usan v-pagination

---

## 4. Vue Router para Navegación (0.5 puntos)

Implementación completa de **Vue Router 4** para la navegación SPA:

### Rutas configuradas:

- `/` - Home (página principal)
- `/auth` - Autenticación (login/registro)
- `/personajes` - Listado de personajes
- `/personajes/:slug` - Detalle de un personaje específico
- `/sinergias` - Listado de sinergias
- `/sinergias/:slug` - Detalle de una sinergia específica
- `/composiciones` - Listado de composiciones
- `/profile` - Perfil de usuario (requiere autenticación con `meta: { requiresAuth: true }`)

### Características implementadas:

- **Navegación guards**: Protección de rutas con `router.beforeEach` (líneas 55-64)
- **Redirección automática**:
    - Si no estás autenticado y accedes a `/profile`, redirige a `/auth`
    - Si estás autenticado e intentas acceder a `/auth`, redirige a `/profile`
- **Navegación programática**: Uso de `router.push()` tras login/registro exitoso
- **Router-link**: Enlaces reactivos en toda la aplicación para navegación entre personajes y sinergias
- **Parámetros dinámicos**: Uso de slugs para detalles de personajes y sinergias

**Archivo relevante:**

- `src/router/index.js` (todas las rutas y guards)

---

## 5. CRUD de Recursos Adicionales (0.5 puntos)

Se implementó un **CRUD completo** de **dos recursos adicionales**:

### 5.1 CRUD de Composiciones (Obligatorio)

#### Operaciones implementadas:

##### **Crear** (Create)

- Modal `CrearComposicionModal.vue` con formulario
- Selección de múltiples personajes
- Validación de campos
- Botón "Crear Composición" en `ComposicionesView.vue`

##### **Leer** (Read)

- Listado completo en `ComposicionesView.vue`
- Vista detallada individual (cada composición muestra: nombre, personajes, estadísticas)
- Búsqueda y paginación

##### **Actualizar** (Update)

- Modal `EditarComposicionModal.vue`
- Solo visible para composiciones creadas por el usuario autenticado
- Permite editar nombre y personajes de la composición
- Botón de editar (✏️) aparece al hacer hover

##### **Eliminar** (Delete)

- Botón de eliminar (🗑️) en cada composición del usuario
- Confirmación con `confirm()` antes de eliminar
- Solo visible para composiciones propias

### 5.2 CRUD de Sinergias (Opcional Adicional)

Se implementó también funcionalidad de **editar y eliminar sinergias**:

#### Operaciones implementadas:

##### **Editar** (Update)

- Modal `EditarSinergiaModal.vue` para modificar sinergias
- Botón de editar (✏️) visible al hacer hover en `SinergiaComponent.vue`
- Permite modificar los datos de la sinergia

##### **Eliminar** (Delete)

- Botón de eliminar (🗑️) en `SinergiaComponent.vue`
- Confirmación antes de eliminar
- Función `eliminarSinergia()` en el store de sinergias

### Características adicionales:

- **Indicador visual**: Las composiciones creadas por el usuario tienen un borde azul especial (clase `componente-propio`)
- **Permisos**: Solo puedes editar/eliminar tus propias composiciones (calculado con `computed esDelUsuario`)
- **Store dedicado**: `src/stores/composiciones.js` y `src/stores/sinergias.js` para gestión de estado
- **Integración con backend**: Todas las operaciones CRUD se sincronizan con el servidor

**Archivos relevantes:**

- **Composiciones:**
    - `src/views/ComposicionesView.vue`
    - `src/components/ComposicionComponent.vue`
    - `src/components/CrearComposicionModal.vue`
    - `src/components/EditarComposicionModal.vue`
    - `src/components/ComposicionForm.vue`
    - `src/stores/composiciones.js`

- **Sinergias:**
    - `src/components/SinergiaComponent.vue`
    - `src/components/EditarSinergiaModal.vue`
    - `src/stores/sinergias.js`

---

## Integración con API de Riot Games

### Población Automática de la Base de Datos

Una característica importante del proyecto es la **importación automática de datos** desde la API oficial de Riot Games (Data Dragon) para poblar la base de datos con personajes y sinergias del Set 15 de TFT.

### Funcionamiento

La importación se ejecuta **automáticamente al iniciar la aplicación** mediante el hook `onMounted` en `App.vue`:

```javascript
onMounted(async () => {
	await authStore.checkAuth();

	// Rellenar la base de datos con campeones y sinergias desde Riot en segundo plano
	setTimeout(async () => {
		// Primero personajes
		const resultado = await personajesStore.rellenarBaseDatosDesdeRiot();

		// Luego sinergias
		const resultadoSinergias = await sinergiasStore.rellenarBaseDatosConSinergiasDesdeRiot();
	}, 1000); // Espera 1 segundo para no bloquear la carga inicial
});
```

### Servicio de Riot (`src/services/riotService.js`)

#### Configuración de la API

- **Versión**: 15.19.1 del Data Dragon
- **Base URL**: `https://ddragon.leagueoflegends.com/cdn/15.19.1/data/es_ES`
- **Imágenes**: `https://ddragon.leagueoflegends.com/cdn/15.19.1/img`
- **Datos en español** para nombres y descripciones

#### Funciones principales:

1. **`obtenerCampeonesDesdeRiot()`**
    - Obtiene datos de `tft-champion.json`
    - Filtra solo campeones del Set 15 (que empiecen con `TFT15_`)
    - Extrae: nombre, coste (tier), imagen, sinergias asociadas
    - Genera URLs completas para las imágenes

2. **`obtenerSinergiasDesdeRiot()`**
    - Obtiene datos de `tft-trait.json`
    - Filtra sinergias del Set 15 que **NO** contengan "Mechanic" ya que son de otra modalidad que tiene el juego (sinergias ocultas)
    - Extrae: id de Riot, nombre, imagen
    - Construye URLs completas de imágenes

### Validación de Duplicados

Antes de crear cada recurso, el sistema **valida que no exista ya** en la base de datos:

#### Para Personajes (`src/stores/personajes.js`):

```javascript
// Verificar si ya existe un personaje con este nombre
const personajesExistentes = await buscarPersonajeNombre(campeon.nombre);

if (personajesExistentes.length > 0) {
    // El personaje ya existe, omitir creación
    personajesOmitidos.push(campeon.nombre);
    continue;
}
```

#### Para Sinergias (`src/stores/sinergias.js`):

```javascript
// Verificar si ya existe una sinergia con este nombre
const sinergiasExistentes = await buscarSinergiasPorNombre(sinergia.nombre);

if (sinergiasExistentes.length > 0) {
    // La sinergia ya existe, omitir creación
    sinergiasOmitidas.push(sinergia.nombre);
    continue;
}
```

### Resultado del Proceso

Ambas funciones (`rellenarBaseDatosDesdeRiot` y `rellenarBaseDatosConSinergiasDesdeRiot`) devuelven un objeto con estadísticas:

```javascript
return {
    exitosos: [...],      // Recursos creados exitosamente
    omitidos: [...],      // Recursos que ya existían (no duplicados)
    errores: [...],       // Recursos que fallaron al crearse
    total: N              // Total de recursos procesados
};
```

### Características adicionales:

- **Ejecución en segundo plano**: Con `setTimeout(1000)` para no bloquear la carga inicial de la app
- **Recarga automática**: Si se crean nuevos recursos, recarga las listas automáticamente
- **Manejo de errores**: Captura y registra errores individuales sin detener el proceso completo
- **Datos predeterminados**: Para campos no disponibles en la API de Riot, se usan valores por defecto (vida: 100, velocidad de ataque: 1.0, etc.)

### Archivos relevantes:

- `src/App.vue` - Lógica de importación en `onMounted`
- `src/services/riotService.js` - Funciones de acceso a la API de Riot
- `src/stores/personajes.js` - Función `rellenarBaseDatosDesdeRiot()`
- `src/stores/sinergias.js` - Función `rellenarBaseDatosConSinergiasDesdeRiot()`
