import { pb } from "../src/config/pb.js";
import { obtenerSinergiasDesdeRiot } from "../src/services/riotService.js";
import {
	createSinergia,
	obtenerSinergia,
	obtenerTodasSinergias,
	buscarSinergiasPorNombre,
	deleteSinergia,
} from "../src/services/sinergiasService.js";
import { TEST_USER } from "./testConfig.js";

describe("Integración Riot API y Sinergias - Tests de Integración", () => {
	let sinergiasCreadas = [];

	// Setup: Login antes de todos los tests
	beforeAll(async () => {
		try {
			await pb.collection("Usuario").authWithPassword(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			console.log("Autenticación exitosa para los tests de integración Riot-Sinergias");
		} catch (error) {
			console.error("Error en autenticación:", error.message);
			throw error;
		}
	});

	// Limpiar después de cada test
	afterEach(async () => {
		// Eliminar todas las sinergias creadas durante el test
		for (const sinergiaId of sinergiasCreadas) {
			try {
				await deleteSinergia(sinergiaId);
				console.log(`Sinergia ${sinergiaId} limpiada`);
			} catch (error) {
				// Ignorar errores si ya fue eliminada
			}
		}
		sinergiasCreadas = [];
	});

	describe("Flujo completo: Riot API -> Creación de Sinergias", () => {
		test("debería obtener sinergias de Riot y crear una en la base de datos", async () => {
			// 1. Obtener sinergias desde la API de Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();

			expect(Array.isArray(sinergiasRiot)).toBe(true);
			expect(sinergiasRiot.length).toBeGreaterThan(0);

			// 2. Seleccionar la primera sinergia
			const sinergiaRiot = sinergiasRiot[0];

			expect(sinergiaRiot).toHaveProperty("id_riot");
			expect(sinergiaRiot).toHaveProperty("nombre");
			expect(sinergiaRiot).toHaveProperty("imagen");

			// 3. Crear la sinergia en PocketBase usando datos de Riot
			const sinergiaData = {
				nombre_sinergia: sinergiaRiot.nombre,
				Unidad1: sinergiaRiot.id_riot,
			};

			const sinergiaCreada = await createSinergia(sinergiaData);
			sinergiasCreadas.push(sinergiaCreada.id);

			// 4. Verificar que se creó correctamente
			expect(sinergiaCreada).toBeDefined();
			expect(sinergiaCreada.id).toBeDefined();
			expect(sinergiaCreada.nombre_sinergia).toBe(sinergiaRiot.nombre);
			expect(sinergiaCreada.Unidad1).toBe(sinergiaRiot.id_riot);

			// 5. Verificar que se puede recuperar de la base de datos
			const sinergiaRecuperada = await obtenerSinergia(sinergiaCreada.id);
			expect(sinergiaRecuperada.id).toBe(sinergiaCreada.id);
			expect(sinergiaRecuperada.nombre_sinergia).toBe(sinergiaRiot.nombre);
		});

		test("debería crear múltiples sinergias desde datos de Riot", async () => {
			// 1. Obtener sinergias desde la API de Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();
			expect(sinergiasRiot.length).toBeGreaterThan(2);

			// 2. Tomar las primeras 3 sinergias
			const sinergiasACrear = sinergiasRiot.slice(0, 3);

			// 3. Crear cada sinergia en la base de datos (secuencialmente para evitar auto-cancelación)
			const sinergiasCreadas_temp = [];
			for (const sinergiaRiot of sinergiasACrear) {
				const sinergiaCreada = await createSinergia({
					nombre_sinergia: sinergiaRiot.nombre,
					Unidad1: sinergiaRiot.id_riot,
				});
				sinergiasCreadas_temp.push(sinergiaCreada);
			}

			// Guardar IDs para limpieza
			sinergiasCreadas.push(...sinergiasCreadas_temp.map((s) => s.id));

			// 4. Verificar que todas se crearon correctamente
			expect(sinergiasCreadas_temp.length).toBe(3);

			for (let i = 0; i < sinergiasCreadas_temp.length; i++) {
				const sinergiaCreada = sinergiasCreadas_temp[i];
				const sinergiaOriginal = sinergiasACrear[i];

				expect(sinergiaCreada.nombre_sinergia).toBe(sinergiaOriginal.nombre);
				expect(sinergiaCreada.Unidad1).toBe(sinergiaOriginal.id_riot);
			}

			// 5. Verificar que se pueden recuperar todas
			const todasLasSinergias = await obtenerTodasSinergias(1, 50);
			const idsCreados = sinergiasCreadas_temp.map((s) => s.id);

			for (const idCreado of idsCreados) {
				const encontrada = todasLasSinergias.items.find((s) => s.id === idCreado);
				expect(encontrada).toBeDefined();
			}
		});

		test("debería crear sinergia con información completa de Riot incluyendo imagen", async () => {
			// 1. Obtener sinergias desde la API de Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();

			// 2. Buscar una sinergia que tenga imagen
			const sinergiaConImagen = sinergiasRiot.find((s) => s.imagen && s.imagen.length > 0);
			expect(sinergiaConImagen).toBeDefined();

			// 3. Crear sinergia con todos los datos disponibles
			const sinergiaData = {
				nombre_sinergia: sinergiaConImagen.nombre,
				Unidad1: sinergiaConImagen.id_riot,
				// Aquí podrías agregar más campos si tu modelo lo permite
				// Por ejemplo: imagen_url: sinergiaConImagen.imagen
			};

			const sinergiaCreada = await createSinergia(sinergiaData);
			sinergiasCreadas.push(sinergiaCreada.id);

			// 4. Verificar todos los campos
			expect(sinergiaCreada.nombre_sinergia).toBe(sinergiaConImagen.nombre);
			expect(sinergiaCreada.Unidad1).toBe(sinergiaConImagen.id_riot);
		});

		test("debería buscar sinergias creadas desde Riot por nombre", async () => {
			// 1. Obtener sinergias desde Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();
			const sinergiaRiot = sinergiasRiot[0];

			// 2. Crear la sinergia en la BD
			const sinergiaCreada = await createSinergia({
				nombre_sinergia: sinergiaRiot.nombre,
				Unidad1: sinergiaRiot.id_riot,
			});
			sinergiasCreadas.push(sinergiaCreada.id);

			// 3. Buscar por nombre
			const resultados = await buscarSinergiasPorNombre(sinergiaRiot.nombre);

			// 4. Verificar que se encuentra la sinergia creada
			expect(Array.isArray(resultados)).toBe(true);
			const encontrada = resultados.find((s) => s.id === sinergiaCreada.id);
			expect(encontrada).toBeDefined();
			expect(encontrada.nombre_sinergia).toBe(sinergiaRiot.nombre);
		});

		test("debería verificar que todas las sinergias de Riot tienen formato válido", async () => {
			// 1. Obtener todas las sinergias de Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();

			// 2. Verificar estructura de cada sinergia
			for (const sinergia of sinergiasRiot) {
				expect(sinergia).toHaveProperty("id_riot");
				expect(sinergia).toHaveProperty("nombre");
				expect(sinergia).toHaveProperty("imagen");

				// Verificar formato del ID
				expect(sinergia.id_riot).toMatch(/^TFT15_/);
				expect(sinergia.id_riot).not.toContain("Mechanic");

				// Verificar que el nombre no esté vacío
				expect(sinergia.nombre).toBeTruthy();
				expect(sinergia.nombre.length).toBeGreaterThan(0);

				// La imagen puede ser string vacío, pero debe existir la propiedad
				expect(typeof sinergia.imagen).toBe("string");
			}
		});

		test("debería crear y actualizar sinergia con datos de Riot", async () => {
			// 1. Obtener sinergias desde Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();
			const sinergiaRiot1 = sinergiasRiot[0];
			const sinergiaRiot2 = sinergiasRiot[1];

			// 2. Crear sinergia con datos de la primera
			const sinergiaCreada = await createSinergia({
				nombre_sinergia: sinergiaRiot1.nombre,
				Unidad1: sinergiaRiot1.id_riot,
			});
			sinergiasCreadas.push(sinergiaCreada.id);

			// 3. Actualizar con datos de la segunda
			const { editSinergia } = await import("../src/services/sinergiasService.js");
			const sinergiaActualizada = await editSinergia(sinergiaCreada.id, {
				nombre_sinergia: sinergiaRiot2.nombre,
				Unidad2: sinergiaRiot2.id_riot,
			});

			// 4. Verificar actualización
			expect(sinergiaActualizada.nombre_sinergia).toBe(sinergiaRiot2.nombre);
			expect(sinergiaActualizada.Unidad1).toBe(sinergiaRiot1.id_riot);
			expect(sinergiaActualizada.Unidad2).toBe(sinergiaRiot2.id_riot);
		});

		test("debería importar sinergias específicas conocidas de TFT Set 15", async () => {
			// 1. Obtener sinergias desde Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();
			const ids = sinergiasRiot.map((s) => s.id_riot);

			// 2. Verificar que existen sinergias conocidas del Set 15
			const sinergiasConocidas = ["TFT15_Bastion", "TFT15_BattleAcademia", "TFT15_SoulFighter"];

			for (const idConocido of sinergiasConocidas) {
				expect(ids).toContain(idConocido);

				// 3. Encontrar y crear la sinergia
				const sinergiaRiot = sinergiasRiot.find((s) => s.id_riot === idConocido);
				expect(sinergiaRiot).toBeDefined();

				const sinergiaCreada = await createSinergia({
					nombre_sinergia: sinergiaRiot.nombre,
					Unidad1: sinergiaRiot.id_riot,
				});
				sinergiasCreadas.push(sinergiaCreada.id);

				// 4. Verificar creación
				expect(sinergiaCreada.id).toBeDefined();
				expect(sinergiaCreada.Unidad1).toBe(idConocido);
			}

			// 5. Verificar que todas se crearon
			expect(sinergiasCreadas.length).toBe(sinergiasConocidas.length);
		});

		test("debería manejar error si la API de Riot no está disponible", async () => {
			// Este test verifica que el error se propaga correctamente
			// En caso de fallo de la API de Riot
			try {
				const sinergiasRiot = await obtenerSinergiasDesdeRiot();
				expect(sinergiasRiot).toBeDefined();
				expect(Array.isArray(sinergiasRiot)).toBe(true);
			} catch (error) {
				// Si la API falla, debe lanzar un error descriptivo
				expect(error.message).toContain("Error al obtener sinergias de Riot");
			}
		});

		test("debería crear sinergias masivamente desde Riot (rendimiento)", async () => {
			const tiempoInicio = Date.now();

			// 1. Obtener sinergias desde Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();

			// 2. Tomar las primeras 5 para el test de rendimiento
			const sinergiasACrear = sinergiasRiot.slice(0, 5);

			// 3. Crear todas secuencialmente (para evitar auto-cancelación de PocketBase)
			const sinergiasCreadas_temp = [];
			for (const sinergiaRiot of sinergiasACrear) {
				const sinergiaCreada = await createSinergia({
					nombre_sinergia: sinergiaRiot.nombre,
					Unidad1: sinergiaRiot.id_riot,
				});
				sinergiasCreadas_temp.push(sinergiaCreada);
			}
			sinergiasCreadas.push(...sinergiasCreadas_temp.map((s) => s.id));

			const tiempoFin = Date.now();
			const tiempoTotal = tiempoFin - tiempoInicio;

			// 4. Verificar que se crearon todas
			expect(sinergiasCreadas_temp.length).toBe(5);

			// 5. Log de rendimiento (opcional)
			console.log(`Tiempo total para crear 5 sinergias: ${tiempoTotal}ms`);

			// El tiempo debería ser razonable (menos de 10 segundos dado que son secuenciales)
			expect(tiempoTotal).toBeLessThan(10000);
		});
	});

	describe("Validación de datos entre Riot y Base de datos", () => {
		test("debería mantener la integridad de datos entre Riot y BD", async () => {
			// 1. Obtener una sinergia de Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();
			const sinergiaRiot = sinergiasRiot[0];

			// 2. Crear en BD
			const sinergiaCreada = await createSinergia({
				nombre_sinergia: sinergiaRiot.nombre,
				Unidad1: sinergiaRiot.id_riot,
			});
			sinergiasCreadas.push(sinergiaCreada.id);

			// 3. Recuperar de BD
			const sinergiaRecuperada = await obtenerSinergia(sinergiaCreada.id);

			// 4. Verificar integridad de datos
			expect(sinergiaRecuperada.nombre_sinergia).toBe(sinergiaRiot.nombre);
			expect(sinergiaRecuperada.Unidad1).toBe(sinergiaRiot.id_riot);

			// Los datos recuperados deben coincidir exactamente con los originales
			expect(sinergiaRecuperada.nombre_sinergia).toBe(sinergiaCreada.nombre_sinergia);
			expect(sinergiaRecuperada.Unidad1).toBe(sinergiaCreada.Unidad1);
		});

		test("debería verificar que no hay sinergias duplicadas de Riot", async () => {
			// 1. Obtener sinergias de Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();

			// 2. Verificar que no hay IDs duplicados
			const ids = sinergiasRiot.map((s) => s.id_riot);
			const idsUnicos = new Set(ids);

			expect(ids.length).toBe(idsUnicos.size);

			// 3. Verificar que no hay nombres duplicados (aunque es posible)
			// Este test es informativo
			const nombres = sinergiasRiot.map((s) => s.nombre);
			const nombresUnicos = new Set(nombres);

			console.log(`Total de sinergias: ${sinergiasRiot.length}`);
			console.log(`IDs únicos: ${idsUnicos.size}`);
			console.log(`Nombres únicos: ${nombresUnicos.size}`);
		});
	});
});
