// Configuración compartida para todos los tests
export const TEST_USER = {
    EMAIL: 'test@test.com',
    PASSWORD: 'test1234',
    NOMBRE: 'Usuario Test'
};

// IMPORTANTE: Este usuario debe ser creado manualmente en Supabase
// o mediante el setup de tests antes de ejecutar los tests
