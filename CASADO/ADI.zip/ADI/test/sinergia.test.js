import { pb } from "../src/config/pb.js";
import {
	obtenerSinergiasDesdeRiot,
	createSinergia,
	obtenerSinergia,
	obtenerTodasSinergias,
	buscarSinergiasPorNombre,
	deleteSinergia,
	editSinergia,
} from "../src/services/sinergiasService.js";
import { TEST_USER } from "./testConfig.js";

describe("Sinergia Service Tests", () => {
	let sinergiaTestId = null;

	// Setup: Login antes de todos los tests
	beforeAll(async () => {
		try {
			await pb.collection("Usuario").authWithPassword(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			console.log("Autenticación exitosa para los tests de Sinergia");
		} catch (error) {
			console.error("Error en autenticación:", error.message);
			throw error;
		}
	});

	// Limpiar después de cada test si hay una sinergia creada
	afterEach(async () => {
		if (sinergiaTestId) {
			try {
				await deleteSinergia(sinergiaTestId);
				console.log(`Sinergia ${sinergiaTestId} limpiada`);
			} catch (error) {
				// Ignorar errores si ya fue eliminada
			}
			sinergiaTestId = null;
		}
	});

	describe("obtenerSinergiasDesdeRiot - Obtener datos de API Riot", () => {
		test("debería obtener sinergias desde la API de Riot Games", async () => {
			const sinergias = await obtenerSinergiasDesdeRiot();

			expect(Array.isArray(sinergias)).toBe(true);
			expect(sinergias.length).toBeGreaterThan(0);

			// Verificar que cada sinergia tenga la estructura esperada
			const primerasinergia = sinergias[0];
			expect(primerasinergia).toHaveProperty("id_riot");
			expect(primerasinergia).toHaveProperty("nombre");
			expect(primerasinergia).toHaveProperty("imagen");
			expect(primerasinergia.id_riot).toMatch(/^TFT15_/);
		});

		test("todas las sinergias deberían empezar con TFT15_", async () => {
			const sinergias = await obtenerSinergiasDesdeRiot();

			sinergias.forEach((sinergia) => {
				expect(sinergia.id_riot).toMatch(/^TFT15_/);
			});
		});

		test('ninguna sinergia debería contener "Mechanic" en el ID', async () => {
			const sinergias = await obtenerSinergiasDesdeRiot();

			sinergias.forEach((sinergia) => {
				expect(sinergia.id_riot).not.toContain("Mechanic");
			});
		});

		test("debería tener sinergias específicas conocidas", async () => {
			const sinergias = await obtenerSinergiasDesdeRiot();
			const ids = sinergias.map((s) => s.id_riot);

			// Verificar que existan algunas sinergias conocidas del set 15
			expect(ids).toContain("TFT15_Bastion");
			expect(ids).toContain("TFT15_BattleAcademia");
			expect(ids).toContain("TFT15_SoulFighter");
		});
	});

	describe("createSinergia - Crear Sinergia", () => {
		test("debería crear una sinergia correctamente", async () => {
			const timestamp = Date.now();
			const sinergiaData = {
				nombre_sinergia: `Sinergia Test ${timestamp}`,
				Unidad1: "Unidad1",
				Unidad2: "Unidad2",
				Unidad3: "Unidad3",
			};

			const sinergia = await createSinergia(sinergiaData);
			sinergiaTestId = sinergia.id;

			expect(sinergia).toBeDefined();
			expect(sinergia.id).toBeDefined();
			expect(sinergia.nombre_sinergia).toBe(sinergiaData.nombre_sinergia);
			expect(sinergia.Unidad1).toBe(sinergiaData.Unidad1);
		});

		test("debería crear una sinergia sin unidades", async () => {
			const timestamp = Date.now();
			const sinergiaData = {
				nombre_sinergia: `Sinergia Vacía ${timestamp}`,
			};

			const sinergia = await createSinergia(sinergiaData);
			sinergiaTestId = sinergia.id;

			expect(sinergia).toBeDefined();
			expect(sinergia.id).toBeDefined();
			expect(sinergia.nombre_sinergia).toBe(sinergiaData.nombre_sinergia);
		});

		test("debería crear una sinergia con todas las unidades", async () => {
			const timestamp = Date.now();
			const sinergiaData = {
				nombre_sinergia: `Sinergia Completa ${timestamp}`,
				Unidad1: "Unidad1",
				Unidad2: "Unidad2",
				Unidad3: "Unidad3",
				Unidad4: "Unidad4",
				Unidad5: "Unidad5",
				Unidad6: "Unidad6",
				Unidad7: "Unidad7",
				Unidad8: "Unidad8",
				Unidad9: "Unidad9",
				Unidad10: "Unidad10",
			};

			const sinergia = await createSinergia(sinergiaData);
			sinergiaTestId = sinergia.id;

			expect(sinergia).toBeDefined();
			expect(sinergia.Unidad1).toBe("Unidad1");
			expect(sinergia.Unidad10).toBe("Unidad10");
		});
	});

	describe("obtenerSinergia - Obtener Sinergia por ID", () => {
		test("debería obtener una sinergia por ID", async () => {
			// Crear sinergia primero
			const timestamp = Date.now();
			const sinergiaCreada = await createSinergia({
				nombre_sinergia: `Test Obtener ${timestamp}`,
				Unidad1: "TestUnidad",
			});
			sinergiaTestId = sinergiaCreada.id;

			// Obtener la sinergia
			const sinergia = await obtenerSinergia(sinergiaTestId);

			expect(sinergia).toBeDefined();
			expect(sinergia.id).toBe(sinergiaTestId);
			expect(sinergia.nombre_sinergia).toBe(sinergiaCreada.nombre_sinergia);
		});

		test("debería fallar al obtener sinergia con ID inexistente", async () => {
			await expect(obtenerSinergia("id_inexistente_xyz123")).rejects.toThrow();
		});
	});

	describe("obtenerTodasSinergias - Listar Sinergias", () => {
		test("debería listar todas las sinergias con paginación por defecto", async () => {
			const resultado = await obtenerTodasSinergias();

			expect(resultado).toBeDefined();
			expect(resultado.page).toBe(1);
			expect(resultado.perPage).toBe(20);
			expect(resultado.totalItems).toBeGreaterThanOrEqual(0);
			expect(resultado.totalPages).toBeGreaterThanOrEqual(0);
			expect(Array.isArray(resultado.items)).toBe(true);
		});

		test("debería listar sinergias con paginación personalizada", async () => {
			const resultado = await obtenerTodasSinergias(1, 5);

			expect(resultado).toBeDefined();
			expect(resultado.page).toBe(1);
			expect(resultado.perPage).toBe(5);
			expect(Array.isArray(resultado.items)).toBe(true);
			expect(resultado.items.length).toBeLessThanOrEqual(5);
		});

		test("debería ordenar sinergias por fecha de creación (más recientes primero)", async () => {
			// Crear dos sinergias
			const sinergia1 = await createSinergia({
				nombre_sinergia: `Sinergia 1 ${Date.now()}`,
			});

			await new Promise((resolve) => setTimeout(resolve, 100));

			const sinergia2 = await createSinergia({
				nombre_sinergia: `Sinergia 2 ${Date.now()}`,
			});

			const resultado = await obtenerTodasSinergias(1, 20);

			const index1 = resultado.items.findIndex((s) => s.id === sinergia1.id);
			const index2 = resultado.items.findIndex((s) => s.id === sinergia2.id);

			// sinergia2 debería estar antes que sinergia1 (más reciente primero)
			if (index1 !== -1 && index2 !== -1) {
				expect(index2).toBeLessThan(index1);
			}

			// Limpiar
			await deleteSinergia(sinergia1.id);
			await deleteSinergia(sinergia2.id);
		});
	});

	describe("buscarSinergiasPorNombre - Buscar Sinergias", () => {
		test("debería encontrar sinergias por nombre", async () => {
			const timestamp = Date.now();
			const nombreUnico = `BusquedaTest_${timestamp}`;

			// Crear sinergia con nombre único
			const sinergiaTest = await createSinergia({
				nombre_sinergia: nombreUnico,
			});
			sinergiaTestId = sinergiaTest.id;

			// Buscar por nombre
			const resultados = await buscarSinergiasPorNombre(nombreUnico);

			expect(Array.isArray(resultados)).toBe(true);
			expect(resultados.length).toBeGreaterThan(0);

			const encontrada = resultados.find((s) => s.id === sinergiaTestId);
			expect(encontrada).toBeDefined();
			expect(encontrada.nombre_sinergia).toBe(nombreUnico);
		});

		test("debería buscar de forma parcial", async () => {
			const timestamp = Date.now();
			const sinergiaTest = await createSinergia({
				nombre_sinergia: `SinergiaCompleta${timestamp}`,
			});
			sinergiaTestId = sinergiaTest.id;

			// Buscar con parte del nombre
			const resultados = await buscarSinergiasPorNombre("SinergiaCompleta");

			expect(Array.isArray(resultados)).toBe(true);
			expect(resultados.length).toBeGreaterThan(0);

			const encontrada = resultados.find((s) => s.id === sinergiaTestId);
			expect(encontrada).toBeDefined();
		});

		test("debería retornar array vacío si no encuentra coincidencias", async () => {
			const resultados = await buscarSinergiasPorNombre("texto_que_no_existe_xyz123");

			expect(Array.isArray(resultados)).toBe(true);
			expect(resultados.length).toBe(0);
		});
	});

	describe("editSinergia - Editar Sinergia", () => {
		test("debería editar una sinergia correctamente", async () => {
			// Crear sinergia primero
			const timestamp = Date.now();
			const sinergiaCreada = await createSinergia({
				nombre_sinergia: `Test Editar ${timestamp}`,
				Unidad1: "UnidadOriginal",
			});
			sinergiaTestId = sinergiaCreada.id;

			// Editar la sinergia
			const nuevoNombre = "Sinergia Editada Test";
			const editada = await editSinergia(sinergiaTestId, {
				nombre_sinergia: nuevoNombre,
				Unidad1: "UnidadEditada",
			});

			expect(editada).toBeDefined();
			expect(editada.id).toBe(sinergiaTestId);
			expect(editada.nombre_sinergia).toBe(nuevoNombre);
			expect(editada.Unidad1).toBe("UnidadEditada");
		});

		test("debería poder agregar unidades a una sinergia", async () => {
			const sinergiaCreada = await createSinergia({
				nombre_sinergia: "Sinergia Sin Unidades",
			});
			sinergiaTestId = sinergiaCreada.id;

			// Agregar unidades
			const editada = await editSinergia(sinergiaTestId, {
				Unidad1: "NuevaUnidad1",
				Unidad2: "NuevaUnidad2",
				Unidad3: "NuevaUnidad3",
			});

			expect(editada.Unidad1).toBe("NuevaUnidad1");
			expect(editada.Unidad2).toBe("NuevaUnidad2");
			expect(editada.Unidad3).toBe("NuevaUnidad3");
		});

		test("debería fallar al editar con ID inexistente", async () => {
			await expect(editSinergia("id_inexistente_xyz123", { nombre_sinergia: "Test" })).rejects.toThrow();
		});
	});

	describe("deleteSinergia - Eliminar Sinergia", () => {
		test("debería eliminar una sinergia correctamente", async () => {
			// Crear sinergia primero
			const timestamp = Date.now();
			const sinergiaCreada = await createSinergia({
				nombre_sinergia: `Test Eliminar ${timestamp}`,
			});
			const idAEliminar = sinergiaCreada.id;

			// Eliminar
			await deleteSinergia(idAEliminar);

			// Verificar que ya no existe
			await expect(obtenerSinergia(idAEliminar)).rejects.toThrow();

			// No necesitamos limpiar porque ya fue eliminada
			sinergiaTestId = null;
		});

		test("debería fallar al eliminar sinergia con ID inexistente", async () => {
			await expect(deleteSinergia("id_inexistente_xyz123")).rejects.toThrow();
		});
	});

	describe("Flujo completo CRUD", () => {
		test("debería completar un flujo completo: crear, leer, editar, eliminar", async () => {
			const timestamp = Date.now();

			// 1. Crear
			const sinergiaCreada = await createSinergia({
				nombre_sinergia: `Sinergia CRUD ${timestamp}`,
				Unidad1: "Unidad1",
				Unidad2: "Unidad2",
			});
			expect(sinergiaCreada.id).toBeDefined();
			sinergiaTestId = sinergiaCreada.id;

			// 2. Leer
			const sinergiaLeida = await obtenerSinergia(sinergiaTestId);
			expect(sinergiaLeida.id).toBe(sinergiaTestId);
			expect(sinergiaLeida.nombre_sinergia).toBe(`Sinergia CRUD ${timestamp}`);

			// 3. Editar
			const sinergiaEditada = await editSinergia(sinergiaTestId, {
				nombre_sinergia: "Sinergia CRUD Editada",
				Unidad3: "Unidad3",
			});
			expect(sinergiaEditada.nombre_sinergia).toBe("Sinergia CRUD Editada");
			expect(sinergiaEditada.Unidad3).toBe("Unidad3");

			// 4. Eliminar
			await deleteSinergia(sinergiaTestId);
			await expect(obtenerSinergia(sinergiaTestId)).rejects.toThrow();

			sinergiaTestId = null;
		});
	});

	describe("Integración con API de Riot", () => {
		test("debería poder crear sinergias usando datos de Riot", async () => {
			// Obtener datos de Riot
			const sinergiasRiot = await obtenerSinergiasDesdeRiot();
			expect(sinergiasRiot.length).toBeGreaterThan(0);

			// Usar la primera sinergia para crear en PocketBase
			const primerasinergia = sinergiasRiot[0];
			const sinergiaData = {
				nombre_sinergia: primerasinergia.nombre,
				Unidad1: primerasinergia.id_riot,
			};

			const sinergiaCreada = await createSinergia(sinergiaData);
			sinergiaTestId = sinergiaCreada.id;

			expect(sinergiaCreada).toBeDefined();
			expect(sinergiaCreada.nombre_sinergia).toBe(primerasinergia.nombre);
			expect(sinergiaCreada.Unidad1).toBe(primerasinergia.id_riot);
		});
	});
});
