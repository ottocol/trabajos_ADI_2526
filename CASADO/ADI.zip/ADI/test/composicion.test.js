import { pb } from "../src/config/pb.js";
import {
	createCompo,
	obtenerComposicion,
	obtenerTodosComposicions,
	buscarComposicionPersonaje,
	buscarComposicionNombre,
	deleteCompo,
	editCompo,
} from "../src/services/composicionService.js";
import { TEST_USER } from "./testConfig.js";

describe("Composicion Service Tests", () => {
	let composicionTestId = null;
	const PERSONAJE_ID = "v6rsh90qka5znss";

	// Setup: Login antes de todos los tests
	beforeAll(async () => {
		try {
			await pb.collection("Usuario").authWithPassword(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			console.log("Autenticación exitosa para los tests");
		} catch (error) {
			console.error("Error en autenticación:", error.message);
			throw error;
		}
	});

	// Limpiar después de cada test si hay una composición creada
	afterEach(async () => {
		if (composicionTestId) {
			try {
				await deleteCompo(composicionTestId);
				console.log(`Composición ${composicionTestId} limpiada`);
			} catch (error) {
				// Ignorar errores si ya fue eliminada
			}
			composicionTestId = null;
		}
	});

	describe("Crear Composición", () => {
		test("debería crear una composición correctamente", async () => {
			const usuarioActual = pb.authStore.record.id;
			const composicionData = {
				nombre: `Composición Test ${Date.now()}`,
				posicion_promedio: 3.5,
				tasa_de_seleccion: 15.8,
				tasa_de_victorias: 22.3,
				tasa_top_4: 45.6,
				usuario: usuarioActual,
				personajes: [],
			};

			const composicion = await createCompo(composicionData);
			composicionTestId = composicion.id;

			expect(composicion).toBeDefined();
			expect(composicion.id).toBeDefined();
			expect(composicion.nombre).toBe(composicionData.nombre);
			expect(composicion.posicion_promedio).toBe(composicionData.posicion_promedio);
			expect(composicion.tasa_de_seleccion).toBe(composicionData.tasa_de_seleccion);
			expect(composicion.tasa_de_victorias).toBe(composicionData.tasa_de_victorias);
			expect(composicion.tasa_top_4).toBe(composicionData.tasa_top_4);
			expect(composicion.usuario).toBe(usuarioActual);
		});

		test("debería fallar al crear composición con datos inválidos", async () => {
			await expect(
				createCompo({
					nombre: "",
					posicion_promedio: "texto_invalido",
				}),
			).rejects.toThrow();
		});
	});

	describe("Obtener Composición", () => {
		test("debería obtener una composición por ID", async () => {
			// Crear composición primero
			const usuarioActual = pb.authStore.record.id;
			const composicionCreada = await createCompo({
				nombre: `Test Obtener ${Date.now()}`,
				posicion_promedio: 2.5,
				tasa_de_seleccion: 10.0,
				tasa_de_victorias: 15.0,
				tasa_top_4: 35.0,
				usuario: usuarioActual,
				personajes: [],
			});
			composicionTestId = composicionCreada.id;

			// Obtener la composición
			const composicion = await obtenerComposicion(composicionTestId);

			expect(composicion).toBeDefined();
			expect(composicion.id).toBe(composicionTestId);
			expect(composicion.nombre).toBe(composicionCreada.nombre);
			expect(composicion.created).toBeDefined();
		});

		test("debería fallar al obtener composición con ID inexistente", async () => {
			await expect(obtenerComposicion("id_inexistente_xyz123")).rejects.toThrow();
		});
	});

	describe("Listar Composiciones", () => {
		test("debería listar todas las composiciones", async () => {
			const resultado = await obtenerTodosComposicions(1, 20);

			expect(resultado).toBeDefined();
			expect(resultado.page).toBe(1);
			expect(resultado.perPage).toBe(20);
			expect(resultado.totalItems).toBeGreaterThanOrEqual(0);
			expect(resultado.totalPages).toBeGreaterThanOrEqual(0);
			expect(Array.isArray(resultado.items)).toBe(true);
		});
	});

	describe("Editar Composición", () => {
		test("debería editar una composición correctamente", async () => {
			// Crear composición primero
			const usuarioActual = pb.authStore.record.id;
			const composicionCreada = await createCompo({
				nombre: `Test Editar ${Date.now()}`,
				posicion_promedio: 4.0,
				tasa_de_seleccion: 12.0,
				tasa_de_victorias: 18.0,
				tasa_top_4: 40.0,
				usuario: usuarioActual,
				personajes: [],
			});
			composicionTestId = composicionCreada.id;

			// Editar la composición
			const nuevoNombre = "Composición Editada Test";
			const nuevaPosicion = 2.8;
			const editado = await editCompo(composicionTestId, {
				nombre: nuevoNombre,
				posicion_promedio: nuevaPosicion,
			});

			expect(editado).toBeDefined();
			expect(editado.id).toBe(composicionTestId);
			expect(editado.nombre).toBe(nuevoNombre);
			expect(editado.posicion_promedio).toBe(nuevaPosicion);
		});
	});

	describe("Eliminar Composición", () => {
		test("debería eliminar una composición correctamente", async () => {
			// Crear composición primero
			const usuarioActual = pb.authStore.record.id;
			const composicionCreada = await createCompo({
				nombre: `Test Eliminar ${Date.now()}`,
				posicion_promedio: 3.0,
				tasa_de_seleccion: 8.0,
				tasa_de_victorias: 12.0,
				tasa_top_4: 30.0,
				usuario: usuarioActual,
				personajes: [],
			});
			const idAEliminar = composicionCreada.id;

			// Eliminar
			await deleteCompo(idAEliminar);

			// Verificar que ya no existe
			await expect(obtenerComposicion(idAEliminar)).rejects.toThrow();

			// No necesitamos limpiar porque ya fue eliminada
			composicionTestId = null;
		});
	});

	describe("Buscar Composición por Personaje", () => {
		test("debería encontrar composiciones con un personaje específico", async () => {
			const usuarioActual = pb.authStore.record.id;

			// Crear composición CON el personaje (array vacío por ahora, ya que no tenemos personajes creados)
			const compoConPersonaje = await createCompo({
				nombre: `CompoConPersonaje_${Date.now()}`,
				posicion_promedio: 4.5,
				tasa_de_seleccion: 20.0,
				tasa_de_victorias: 30.0,
				tasa_top_4: 55.0,
				usuario: usuarioActual,
				personajes: [],
			});

			// Crear composición SIN ese personaje
			const compoSinPersonaje = await createCompo({
				nombre: `CompoSinPersonaje_${Date.now()}`,
				posicion_promedio: 3.0,
				tasa_de_seleccion: 12.0,
				tasa_de_victorias: 20.0,
				tasa_top_4: 40.0,
				usuario: usuarioActual,
				personajes: [],
			});

			// Buscar composiciones que tengan este personaje (usando un ID de prueba)
			// Como no tenemos personajes reales, buscamos con un ID que no existe
			const resultados = await buscarComposicionPersonaje("test_personaje_id");

			// Verificaciones - debería retornar array vacío o no encontrar las composiciones
			expect(Array.isArray(resultados)).toBe(true);
			// No esperamos encontrar composiciones porque no usamos personajes reales en este test

			// Limpiar
			await deleteCompo(compoConPersonaje.id);
			await deleteCompo(compoSinPersonaje.id);
		});
	});

	describe("Buscar Composición por Nombre", () => {
		test("debería encontrar composiciones por nombre", async () => {
			const usuarioActual = pb.authStore.record.id;
			const nombreUnico = `BusquedaTest_${Date.now()}`;

			// Crear composición con nombre único
			const compoTest = await createCompo({
				nombre: nombreUnico,
				posicion_promedio: 4.2,
				tasa_de_seleccion: 18.5,
				tasa_de_victorias: 25.0,
				tasa_top_4: 50.0,
				usuario: usuarioActual,
				personajes: [],
			});

			// Buscar por parte del nombre
			const resultados = await buscarComposicionNombre("BusquedaTest");

			expect(Array.isArray(resultados)).toBe(true);
			expect(resultados.length).toBeGreaterThan(0);

			const encontrada = resultados.find((c) => c.id === compoTest.id);
			expect(encontrada).toBeDefined();
			expect(encontrada.nombre).toBe(nombreUnico);

			// Limpiar
			await deleteCompo(compoTest.id);
		});
	});
});
