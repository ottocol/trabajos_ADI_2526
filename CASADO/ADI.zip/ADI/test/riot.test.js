import { fetchRiotVersion, obtenerCampeonesDesdeRiot } from "../src/services/riotService.js";

describe("Riot Service Tests", () => {
	describe("Fetch Riot Version", () => {
		test("debería devolver una versión válida", async () => {
			const version = await fetchRiotVersion();

			expect(version).toBeDefined();
			expect(version).not.toBe("No hay versión");
			expect(typeof version).toBe("string");
			expect(version).toMatch(/^\d+\.\d+\.\d+$/);
		}, 10000);

		test("la versión debería seguir el formato correcto", async () => {
			const version = await fetchRiotVersion();

			const versionParts = version.split(".");
			expect(versionParts).toHaveLength(3);
			expect(parseInt(versionParts[0])).toBeGreaterThan(0);
			expect(parseInt(versionParts[1])).toBeGreaterThanOrEqual(0);
			expect(parseInt(versionParts[2])).toBeGreaterThanOrEqual(0);
		}, 10000);
	});

	describe("Obtener Campeones desde Riot", () => {
		test("debería devolver un array de campeones", async () => {
			const campeones = await obtenerCampeonesDesdeRiot();

			expect(Array.isArray(campeones)).toBe(true);
			expect(campeones.length).toBeGreaterThan(0);
		}, 10000);

		test("cada campeón debería tener la estructura correcta", async () => {
			const campeones = await obtenerCampeonesDesdeRiot();

			expect(campeones.length).toBeGreaterThan(0);

			const campeon = campeones[0];
			expect(campeon).toHaveProperty("id_riot");
			expect(campeon).toHaveProperty("nombre");
			expect(campeon).toHaveProperty("coste");
			expect(campeon).toHaveProperty("imagen");
			expect(campeon).toHaveProperty("sinergias");

			expect(typeof campeon.id_riot).toBe("string");
			expect(typeof campeon.nombre).toBe("string");
			expect(typeof campeon.coste).toBe("number");
			expect(typeof campeon.imagen).toBe("string");
			expect(Array.isArray(campeon.sinergias)).toBe(true);
		}, 10000);

		test("todos los campeones deberían empezar con TFT15_", async () => {
			const campeones = await obtenerCampeonesDesdeRiot();

			campeones.forEach((campeon) => {
				expect(campeon.id_riot).toMatch(/^TFT15_/);
			});
		}, 10000);

		test("los campeones deberían tener un coste válido", async () => {
			const campeones = await obtenerCampeonesDesdeRiot();

			campeones.forEach((campeon) => {
				expect(campeon.coste).toBeGreaterThanOrEqual(1);
				expect(campeon.coste).toBeLessThanOrEqual(5);
			});
		}, 10000);

		test("la propiedad sinergias debería ser un array", async () => {
			const campeones = await obtenerCampeonesDesdeRiot();

			campeones.forEach((campeon) => {
				expect(Array.isArray(campeon.sinergias)).toBe(true);
			});
		}, 10000);
	});
});
