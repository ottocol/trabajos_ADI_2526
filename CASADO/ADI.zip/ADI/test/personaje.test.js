import { pb } from "../src/config/pb.js";
import {
	createPersonaje,
	obtenerPersonaje,
	obtenerTodosPersonajes,
	buscarPersonajeSinergia,
	buscarPersonajeNombre,
	deletePersonaje,
	editPersonaje,
} from "../src/services/personajeService.js";
import { usePersonajesStore } from "../src/stores/personajes.js";
import { createPinia, setActivePinia } from "pinia";
import { TEST_USER } from "./testConfig.js";

describe("Personaje Service Tests", () => {
	let personajeTestId = null;
	let sinergiaTestId = null;

	// Setup: Login antes de todos los tests
	beforeAll(async () => {
		try {
			await pb.collection("Usuario").authWithPassword(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			console.log("Autenticación exitosa para los tests de Personaje");
		} catch (error) {
			console.error("Error en autenticación:", error.message);
			throw error;
		}
	});

	// Limpiar después de cada test
	afterEach(async () => {
		if (personajeTestId) {
			try {
				await deletePersonaje(personajeTestId);
				console.log(`Personaje ${personajeTestId} limpiado`);
			} catch (error) {
				// Ignorar errores si ya fue eliminado
			}
			personajeTestId = null;
		}
		if (sinergiaTestId) {
			try {
				await pb.collection("Sinergia").delete(sinergiaTestId);
				console.log(`Sinergia ${sinergiaTestId} limpiada`);
			} catch (error) {
				// Ignorar errores si ya fue eliminada
			}
			sinergiaTestId = null;
		}
	});

	describe("Crear Personaje", () => {
		test("debería crear un personaje correctamente", async () => {
			const personajeData = {
				nombre: `Personaje Test ${Date.now()}`,
				vida: 650,
				velocidad_de_ataque: 0.75,
				dano_de_ataque: 55,
				poder_de_habilidad: 100,
				armadura: 35,
				resistencia_magica: 35,
				probabilidad_de_critico: 25,
				mana_habilidad: 80,
				coste: 3,
				nombre_habilidad: "Habilidad Test",
				desc_habilidad: "Descripción de la habilidad de prueba",
				imagen: "https://example.com/personaje-test.jpg",
				sinergias: [],
			};

			const personaje = await createPersonaje(personajeData);
			personajeTestId = personaje.id;

			expect(personaje).toBeDefined();
			expect(personaje.id).toBeDefined();
			expect(personaje.nombre).toBe(personajeData.nombre);
			expect(personaje.vida).toBe(personajeData.vida);
			expect(personaje.velocidad_de_ataque).toBe(personajeData.velocidad_de_ataque);
			expect(personaje.dano_de_ataque).toBe(personajeData.dano_de_ataque);
			expect(personaje.poder_de_habilidad).toBe(personajeData.poder_de_habilidad);
			expect(personaje.armadura).toBe(personajeData.armadura);
			expect(personaje.resistencia_magica).toBe(personajeData.resistencia_magica);
			expect(personaje.probabilidad_de_critico).toBe(personajeData.probabilidad_de_critico);
			expect(personaje.mana_habilidad).toBe(personajeData.mana_habilidad);
			expect(personaje.coste).toBe(personajeData.coste);
			expect(personaje.nombre_habilidad).toBe(personajeData.nombre_habilidad);
		});

		test("debería fallar al crear personaje con datos inválidos", async () => {
			await expect(
				createPersonaje({
					nombre: "",
					vida: "texto_invalido",
				}),
			).rejects.toThrow();
		});
	});

	describe("Obtener Personaje", () => {
		test("debería obtener un personaje por ID", async () => {
			// Crear personaje primero
			const personajeCreado = await createPersonaje({
				nombre: `Test Obtener ${Date.now()}`,
				vida: 600,
				velocidad_de_ataque: 0.7,
				dano_de_ataque: 50,
				poder_de_habilidad: 90,
				armadura: 30,
				resistencia_magica: 30,
				probabilidad_de_critico: 20,
				mana_habilidad: 75,
				coste: 2,
				nombre_habilidad: "Habilidad Obtener",
				desc_habilidad: "Descripción de prueba",
				sinergias: [],
			});
			personajeTestId = personajeCreado.id;

			// Obtener el personaje
			const personaje = await obtenerPersonaje(personajeTestId);

			expect(personaje).toBeDefined();
			expect(personaje.id).toBe(personajeTestId);
			expect(personaje.nombre).toBe(personajeCreado.nombre);
			expect(personaje.vida).toBe(personajeCreado.vida);
			expect(personaje.coste).toBe(personajeCreado.coste);
			expect(personaje.created).toBeDefined();
		});

		test("debería fallar al obtener personaje con ID inexistente", async () => {
			await expect(obtenerPersonaje("id_inexistente_xyz123")).rejects.toThrow();
		});
	});

	describe("Listar Personajes", () => {
		test("debería listar todos los personajes", async () => {
			const resultado = await obtenerTodosPersonajes(1, 20);

			expect(resultado).toBeDefined();
			expect(resultado.page).toBe(1);
			expect(resultado.perPage).toBe(20);
			expect(resultado.totalItems).toBeGreaterThanOrEqual(0);
			expect(resultado.totalPages).toBeGreaterThanOrEqual(0);
			expect(Array.isArray(resultado.items)).toBe(true);
		});
	});

	describe("Editar Personaje", () => {
		test("debería editar un personaje correctamente", async () => {
			// Crear personaje primero
			const personajeCreado = await createPersonaje({
				nombre: `Test Editar ${Date.now()}`,
				vida: 700,
				velocidad_de_ataque: 0.8,
				dano_de_ataque: 60,
				poder_de_habilidad: 110,
				armadura: 40,
				resistencia_magica: 40,
				probabilidad_de_critico: 30,
				mana_habilidad: 90,
				coste: 4,
				nombre_habilidad: "Habilidad Editar",
				desc_habilidad: "Descripción para editar",
				sinergias: [],
			});
			personajeTestId = personajeCreado.id;

			// Editar el personaje
			const nuevoNombre = "Personaje Editado Test";
			const nuevaVida = 800;
			const nuevoCoste = 5;
			const editado = await editPersonaje(personajeTestId, {
				nombre: nuevoNombre,
				vida: nuevaVida,
				coste: nuevoCoste,
			});

			expect(editado).toBeDefined();
			expect(editado.id).toBe(personajeTestId);
			expect(editado.nombre).toBe(nuevoNombre);
			expect(editado.vida).toBe(nuevaVida);
			expect(editado.coste).toBe(nuevoCoste);
		});

		test("debería fallar al editar personaje inexistente", async () => {
			await expect(
				editPersonaje("id_inexistente_abc789", {
					nombre: "Personaje Fantasma",
				}),
			).rejects.toThrow();
		});
	});

	describe("Eliminar Personaje", () => {
		test("debería eliminar un personaje correctamente", async () => {
			// Crear personaje primero
			const personajeCreado = await createPersonaje({
				nombre: `Test Eliminar ${Date.now()}`,
				vida: 550,
				velocidad_de_ataque: 0.65,
				dano_de_ataque: 45,
				poder_de_habilidad: 85,
				armadura: 25,
				resistencia_magica: 25,
				probabilidad_de_critico: 15,
				mana_habilidad: 70,
				coste: 1,
				nombre_habilidad: "Habilidad Eliminar",
				desc_habilidad: "Descripción para eliminar",
				sinergias: [],
			});
			const idAEliminar = personajeCreado.id;

			// Eliminar
			await deletePersonaje(idAEliminar);

			// Verificar que ya no existe
			await expect(obtenerPersonaje(idAEliminar)).rejects.toThrow();

			// No necesitamos limpiar porque ya fue eliminado
			personajeTestId = null;
		});
	});

	describe("Buscar Personaje por Nombre", () => {
		test("debería encontrar personajes por nombre", async () => {
			const nombreUnico = `BusquedaNombreTest_${Date.now()}`;

			// Crear personaje con nombre único
			const personajeTest = await createPersonaje({
				nombre: nombreUnico,
				vida: 700,
				velocidad_de_ataque: 0.8,
				dano_de_ataque: 60,
				poder_de_habilidad: 110,
				armadura: 40,
				resistencia_magica: 40,
				probabilidad_de_critico: 30,
				mana_habilidad: 90,
				coste: 4,
				nombre_habilidad: "Habilidad Búsqueda",
				desc_habilidad: "Descripción de prueba para búsqueda",
				sinergias: [],
			});
			personajeTestId = personajeTest.id;

			// Buscar por parte del nombre
			const resultados = await buscarPersonajeNombre("BusquedaNombreTest");

			expect(Array.isArray(resultados)).toBe(true);
			expect(resultados.length).toBeGreaterThan(0);

			const encontrado = resultados.find((p) => p.id === personajeTest.id);
			expect(encontrado).toBeDefined();
			expect(encontrado.nombre).toBe(nombreUnico);
		});
	});

	describe("Buscar Personaje por Sinergia", () => {
		test("debería encontrar personajes con una sinergia específica", async () => {
			// Crear sinergia de prueba
			const sinergia = await pb.collection("Sinergia").create({
				nombre: `SinergiaTest_${Date.now()}`,
				descripcion: "Sinergia de prueba para testing",
			});
			sinergiaTestId = sinergia.id;

			// Crear personaje CON la sinergia
			const personajeConSinergia = await createPersonaje({
				nombre: `PersonajeConSinergia_${Date.now()}`,
				vida: 600,
				velocidad_de_ataque: 0.7,
				dano_de_ataque: 50,
				poder_de_habilidad: 95,
				armadura: 30,
				resistencia_magica: 30,
				probabilidad_de_critico: 20,
				mana_habilidad: 75,
				coste: 2,
				nombre_habilidad: "Habilidad Sinergia",
				desc_habilidad: "Descripción con sinergia",
				sinergias: [sinergiaTestId],
			});

			// Crear personaje SIN esa sinergia
			const personajeSinSinergia = await createPersonaje({
				nombre: `PersonajeSinSinergia_${Date.now()}`,
				vida: 550,
				velocidad_de_ataque: 0.65,
				dano_de_ataque: 45,
				poder_de_habilidad: 85,
				armadura: 25,
				resistencia_magica: 25,
				probabilidad_de_critico: 15,
				mana_habilidad: 70,
				coste: 1,
				nombre_habilidad: "Habilidad Sin Sinergia",
				desc_habilidad: "Descripción sin sinergia",
				sinergias: [],
			});

			// Buscar personajes que tengan esta sinergia
			const resultados = await buscarPersonajeSinergia(sinergiaTestId);

			expect(Array.isArray(resultados)).toBe(true);
			expect(resultados.length).toBeGreaterThan(0);

			const encontradoConSinergia = resultados.find((p) => p.id === personajeConSinergia.id);
			const encontradoSinSinergia = resultados.find((p) => p.id === personajeSinSinergia.id);

			expect(encontradoConSinergia).toBeDefined();
			expect(encontradoConSinergia.sinergias).toContain(sinergiaTestId);
			expect(encontradoSinSinergia).toBeUndefined();

			// Limpiar
			await deletePersonaje(personajeConSinergia.id);
			await deletePersonaje(personajeSinSinergia.id);
		});
	});

	describe("Rellenar Base de Datos desde Riot", () => {
		let personajesCreados = [];

		// Limpiar personajes creados después del test
		afterEach(async () => {
			for (const personaje of personajesCreados) {
				try {
					await deletePersonaje(personaje.id);
					console.log(`Personaje ${personaje.id} limpiado`);
				} catch (error) {
					// Ignorar errores si ya fue eliminado
				}
			}
			personajesCreados = [];
		});

		test("debería obtener campeones de Riot y crear o omitir personajes en la base de datos", async () => {
			// Crear instancia de Pinia para el store
			setActivePinia(createPinia());
			const store = usePersonajesStore();

			// Ejecutar la función de rellenar
			const resultado = await store.rellenarBaseDatosDesdeRiot();

			expect(resultado).toBeDefined();
			expect(resultado.exitosos).toBeDefined();
			expect(resultado.omitidos).toBeDefined();
			expect(resultado.errores).toBeDefined();
			expect(resultado.total).toBeGreaterThan(0);

			// Verificar que se procesaron todos los personajes (creados u omitidos)
			expect(Array.isArray(resultado.exitosos)).toBe(true);
			expect(Array.isArray(resultado.omitidos)).toBe(true);
			expect(resultado.exitosos.length + resultado.omitidos.length + resultado.errores.length).toBe(resultado.total);

			// Si se crearon personajes, verificar su estructura
			if (resultado.exitosos.length > 0) {
				const primerPersonaje = resultado.exitosos[0];
				expect(primerPersonaje).toBeDefined();
				expect(primerPersonaje.id).toBeDefined();
				expect(primerPersonaje.nombre).toBeDefined();
				expect(typeof primerPersonaje.coste).toBe("number");
				expect(primerPersonaje.coste).toBeGreaterThanOrEqual(1);
				expect(primerPersonaje.coste).toBeLessThanOrEqual(5);
				expect(primerPersonaje.imagen).toBeDefined();

				// Verificar que los personajes se pueden obtener de la base de datos
				const personajeObtenido = await obtenerPersonaje(primerPersonaje.id);
				expect(personajeObtenido).toBeDefined();
				expect(personajeObtenido.nombre).toBe(primerPersonaje.nombre);
			}

			// Guardar IDs para limpiar después
			personajesCreados = resultado.exitosos;
		}, 30000); // Timeout aumentado porque hace muchas llamadas

		test("debería manejar errores al rellenar la base de datos", async () => {
			setActivePinia(createPinia());
			const store = usePersonajesStore();

			// Este test solo verifica que la función maneja errores correctamente
			// Si hay algún error de red o de BD, debería devolver la estructura correcta
			const resultado = await store.rellenarBaseDatosDesdeRiot();

			expect(resultado).toBeDefined();
			expect(resultado.exitosos).toBeDefined();
			expect(resultado.omitidos).toBeDefined();
			expect(resultado.errores).toBeDefined();
			expect(resultado.total).toBeGreaterThan(0);

			personajesCreados = resultado.exitosos;
		}, 30000);

		test("debería omitir personajes que ya existen en la base de datos", async () => {
			setActivePinia(createPinia());
			const store = usePersonajesStore();

			// Primera ejecución: crea los personajes (o los omite si ya existen)
			const resultado1 = await store.rellenarBaseDatosDesdeRiot();
			personajesCreados = resultado1.exitosos;

			// Si se crearon personajes nuevos
			if (resultado1.exitosos.length > 0) {
				expect(resultado1.exitosos.length).toBeGreaterThan(0);

				// Segunda ejecución: debe omitir todos porque ya existen
				const resultado2 = await store.rellenarBaseDatosDesdeRiot();

				expect(resultado2.exitosos.length).toBe(0);
				expect(resultado2.omitidos.length).toBeGreaterThan(0);
			} else {
				// Si todos fueron omitidos, significa que ya existían
				expect(resultado1.omitidos.length).toBeGreaterThan(0);
			}

			// Verificar que la estructura del resultado es correcta
			expect(resultado1).toBeDefined();
			expect(resultado1.exitosos).toBeDefined();
			expect(resultado1.omitidos).toBeDefined();
			expect(resultado1.errores).toBeDefined();
			expect(resultado1.total).toBeGreaterThan(0);
		}, 60000); // Timeout aumentado porque hace 2 llamadas completas
	});
});
