import { pb } from "../src/config/pb.js";
import { register, login, logout, estaSesionActiva, obtenerUsuarioActual, obtenerToken } from "../src/services/loginService.js";
import { createUser, deleteUser } from "../src/services/usuarioService.js";
import { TEST_USER } from "./testConfig.js";

describe("Login Service Tests", () => {
	let usuarioTestId = null;
	let testUserEmail = null;
	let testUserPassword = null;

	// Setup: Asegurarse de que no hay sesión activa antes de los tests
	beforeAll(() => {
		logout(); // Limpiar cualquier sesión previa
	});

	// Limpiar después de cada test
	afterEach(async () => {
		// Si hay un usuario de prueba, eliminarlo
		if (usuarioTestId) {
			try {
				// Autenticarse como admin para poder eliminar
				await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
				await deleteUser(usuarioTestId);
				console.log(`Usuario ${usuarioTestId} limpiado`);
			} catch (error) {
				// Ignorar errores si ya fue eliminado
			}
			usuarioTestId = null;
			testUserEmail = null;
			testUserPassword = null;
		}
		// Cerrar cualquier sesión después de cada test
		logout();
	});

	describe("login - Iniciar Sesión", () => {
		test("debería iniciar sesión correctamente con credenciales válidas", async () => {
			const resultado = await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);

			expect(resultado).toBeDefined();
			expect(resultado.token).toBeDefined();
			expect(resultado.usuario).toBeDefined();
			expect(resultado.usuario.email).toBe(TEST_USER.EMAIL);
			expect(typeof resultado.token).toBe("string");
			expect(resultado.token.length).toBeGreaterThan(0);
		});

		test("debería fallar con credenciales incorrectas", async () => {
			await expect(login("usuario@inexistente.com", "password_incorrecta")).rejects.toThrow();
		});

		test("debería fallar con email vacío", async () => {
			await expect(login("", TEST_USER.PASSWORD)).rejects.toThrow();
		});

		test("debería fallar con contraseña vacía", async () => {
			await expect(login(TEST_USER.EMAIL, "")).rejects.toThrow();
		});

		test("debería actualizar el estado de sesión después del login", async () => {
			expect(estaSesionActiva()).toBe(false);

			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);

			expect(estaSesionActiva()).toBe(true);
		});
	});

	describe("logout - Cerrar Sesión", () => {
		test("debería cerrar sesión correctamente", async () => {
			// Primero iniciar sesión
			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			expect(estaSesionActiva()).toBe(true);

			// Cerrar sesión
			logout();

			expect(estaSesionActiva()).toBe(false);
			expect(obtenerUsuarioActual()).toBeNull();
			expect(obtenerToken()).toBeNull();
		});

		test("debería poder cerrar sesión aunque no haya sesión activa", () => {
			logout();
			expect(estaSesionActiva()).toBe(false);
		});
	});

	describe("estaSesionActiva - Verificar Sesión", () => {
		test("debería retornar false cuando no hay sesión", () => {
			logout();
			expect(estaSesionActiva()).toBe(false);
		});

		test("debería retornar true cuando hay sesión activa", async () => {
			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			expect(estaSesionActiva()).toBe(true);
		});
	});

	describe("obtenerUsuarioActual - Obtener Usuario Actual", () => {
		test("debería retornar null cuando no hay sesión", () => {
			logout();
			expect(obtenerUsuarioActual()).toBeNull();
		});

		test("debería retornar el usuario cuando hay sesión activa", async () => {
			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			const usuario = obtenerUsuarioActual();

			expect(usuario).toBeDefined();
			expect(usuario).not.toBeNull();
			expect(usuario.email).toBe(TEST_USER.EMAIL);
			expect(usuario.id).toBeDefined();
		});

		test("debería retornar el usuario completo con todos sus campos", async () => {
			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			const usuario = obtenerUsuarioActual();

			expect(usuario).toHaveProperty("id");
			expect(usuario).toHaveProperty("email");
			expect(usuario).toHaveProperty("nombre");
		});
	});

	describe("obtenerToken - Obtener Token de Autenticación", () => {
		test("debería retornar null cuando no hay sesión", () => {
			logout();
			expect(obtenerToken()).toBeNull();
		});

		test("debería retornar el token cuando hay sesión activa", async () => {
			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			const token = obtenerToken();

			expect(token).toBeDefined();
			expect(token).not.toBeNull();
			expect(typeof token).toBe("string");
			expect(token.length).toBeGreaterThan(0);
		});

		test("el token debería coincidir con el del login", async () => {
			const resultado = await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			const token = obtenerToken();

			expect(token).toBe(resultado.token);
		});
	});

	describe("Flujo completo de autenticación", () => {
		test("debería completar un flujo: login -> obtener datos -> logout", async () => {
			// 1. Verificar que no hay sesión
			expect(estaSesionActiva()).toBe(false);
			expect(obtenerUsuarioActual()).toBeNull();
			expect(obtenerToken()).toBeNull();

			// 2. Iniciar sesión
			const loginResult = await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			expect(loginResult.token).toBeDefined();
			expect(loginResult.usuario).toBeDefined();

			// 3. Verificar sesión activa
			expect(estaSesionActiva()).toBe(true);

			// 4. Obtener datos del usuario
			const usuario = obtenerUsuarioActual();
			expect(usuario).not.toBeNull();
			expect(usuario.email).toBe(TEST_USER.EMAIL);

			// 5. Obtener token
			const token = obtenerToken();
			expect(token).toBe(loginResult.token);

			// 6. Cerrar sesión
			logout();

			// 7. Verificar que se cerró la sesión
			expect(estaSesionActiva()).toBe(false);
			expect(obtenerUsuarioActual()).toBeNull();
			expect(obtenerToken()).toBeNull();
		});

		test("debería permitir login con usuario recién creado", async () => {
			// Autenticarse como admin para crear usuario
			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);

			// Crear usuario de prueba
			const timestamp = Date.now();
			testUserEmail = `testlogin${timestamp}@test.com`;
			testUserPassword = "Test1234";

			const nuevoUsuario = await createUser({
				email: testUserEmail,
				password: testUserPassword,
				passwordConfirm: testUserPassword,
				nombre: "Usuario Login Test",
			});
			usuarioTestId = nuevoUsuario.id;

			// Cerrar sesión de admin
			logout();

			// Intentar login con el nuevo usuario
			const resultado = await login(testUserEmail, testUserPassword);

			expect(resultado).toBeDefined();
			expect(resultado.token).toBeDefined();
			expect(resultado.usuario.email).toBe(testUserEmail);
			expect(estaSesionActiva()).toBe(true);

			// Cerrar sesión del usuario de prueba
			logout();

			// Volver a autenticarse como admin para cleanup
			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
		});
	});

	describe("Manejo de errores", () => {
		test("debería manejar error de red al intentar login", async () => {
			// Este test verifica que los errores se propagan correctamente
			await expect(login("invalid", "invalid")).rejects.toThrow();
		});

		test("debería limpiar sesión después de logout incluso con error", () => {
			logout(); // Primera vez
			expect(estaSesionActiva()).toBe(false);

			logout(); // Segunda vez sin sesión
			expect(estaSesionActiva()).toBe(false);
		});
	});

	describe("register - Registrar Usuario", () => {
		test("debería registrar un nuevo usuario correctamente", async () => {
			// Autenticarse como admin para poder eliminar después
			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			logout();

			// Crear datos de usuario único
			const timestamp = Date.now();
			testUserEmail = `testregister${timestamp}@test.com`;
			testUserPassword = "Test1234";

			// Registrar nuevo usuario
			const resultado = await register(testUserEmail, testUserPassword, testUserPassword, "Usuario Test");

			// Guardar ID para cleanup
			usuarioTestId = resultado.usuario.id;

			// Verificar que retorna los datos correctos
			expect(resultado).toBeDefined();
			expect(resultado.token).toBeDefined();
			expect(resultado.usuario).toBeDefined();
			expect(resultado.usuario.email).toBe(testUserEmail);
			expect(resultado.usuario.nombre).toBe("Usuario Test");
			expect(typeof resultado.token).toBe("string");
			expect(resultado.token.length).toBeGreaterThan(0);

			// Verificar que inicia sesión automáticamente
			expect(estaSesionActiva()).toBe(true);
			expect(obtenerUsuarioActual().email).toBe(testUserEmail);
		});

		test("debería fallar si las contraseñas no coinciden", async () => {
			const timestamp = Date.now();
			testUserEmail = `testregister${timestamp}@test.com`;

			await expect(register(testUserEmail, "Test1234", "Different1234", "Usuario Test")).rejects.toThrow();
		});

		test("debería fallar con email duplicado", async () => {
			// Autenticarse como admin
			await login(TEST_USER.EMAIL, TEST_USER.PASSWORD);
			logout();

			// Crear primer usuario
			const timestamp = Date.now();
			testUserEmail = `testregister${timestamp}@test.com`;
			testUserPassword = "Test1234";

			const resultado = await register(testUserEmail, testUserPassword, testUserPassword, "Usuario Test 1");
			usuarioTestId = resultado.usuario.id;

			logout();

			// Intentar crear otro usuario con el mismo email
			await expect(register(testUserEmail, testUserPassword, testUserPassword, "Usuario Test 2")).rejects.toThrow();
		});

		test("debería fallar con email inválido", async () => {
			await expect(register("emailinvalido", "Test1234", "Test1234", "Usuario Test")).rejects.toThrow();
		});

		test("debería fallar con contraseña muy corta", async () => {
			const timestamp = Date.now();
			testUserEmail = `testregister${timestamp}@test.com`;

			await expect(register(testUserEmail, "123", "123", "Usuario Test")).rejects.toThrow();
		});

		test("debería fallar con nombre vacío", async () => {
			const timestamp = Date.now();
			testUserEmail = `testregister${timestamp}@test.com`;

			await expect(register(testUserEmail, "Test1234", "Test1234", "")).rejects.toThrow();
		});

		test("el usuario registrado debería poder cerrar e iniciar sesión nuevamente", async () => {
			// Registrar usuario
			const timestamp = Date.now();
			testUserEmail = `testregister${timestamp}@test.com`;
			testUserPassword = "Test1234";

			const resultado = await register(testUserEmail, testUserPassword, testUserPassword, "Usuario Test");
			usuarioTestId = resultado.usuario.id;

			// Verificar sesión activa después de registro
			expect(estaSesionActiva()).toBe(true);

			// Cerrar sesión
			logout();
			expect(estaSesionActiva()).toBe(false);

			// Iniciar sesión con las mismas credenciales
			const loginResult = await login(testUserEmail, testUserPassword);

			expect(loginResult).toBeDefined();
			expect(loginResult.usuario.email).toBe(testUserEmail);
			expect(estaSesionActiva()).toBe(true);
		});
	});
});
