# Prompts usados para la práctica

## Claude

```text
A partir de este diagrama de clases, generame todos los casos de uso teniendo como ejemplo esto:
Un usuario sin estar autentificado debe poder ver los datos básicos de la lista de proyectos más populares en el sitio
Un usuario sin estar autentificado debe poder ver todos los datos de un proyecto,que incluyen también las últimas actualizaciones sobre el mismo.
Un usuario debe poder hacer login y logout en la aplicación
Un usuario debe poder darse de alta, editar su perfil y darse de baja
Un usuario autentificado debe poder elegir una modalidad de apoyo y apoyar un proyecto con esa cantidad
El usuario que ha creado un proyecto, si está autentificado debe poder gestionar actualizaciones (noticias) sobre el estado del mismo (operaciones: crear, ver, modificar, borrar)
El usuario que ha creado un proyecto, si está autentificado debe poder gestionar (crear, ver, modificar y borrar) modalidades de apoyo (descripción, cantidad que se pide, recompensa obtenida a cambio...)
```

```text
claude, generame una imagen para una pagina de composiciones de tft, hazmela tipo logo
```

```text
ahora hazme uno tipico de perfil, de cuando no estas logeado
```

```text
Explicame como puedo cambiar los estilos de ul y li y componentes que hayan dentro como por ejemplo img
```

```text
como pongo 
<p>
<input>
<p>
<input>
con css que se vean uno debajo de otro y que el contenedor que tiene las 4 cosas que es un section sea del dataño justo de sus hijos
```

```text
como hago que el footer siempre este al final de la pagina incluso cuando el contenido no llega
```

```text
como puedo crear un archivo de constantes de css y conmo lo importo para usarlo. css y html puro tiene mi proyecto
```

```text
explicame que es lo de :root y por que las variables empiezan por --
```

```text
hazme un archivito de variables.css con una paleta de colores a lo grisacea bonita. es para una pagina de tft. los botones en azul son bonitos
```

```text
hazme ahora un global.css a partir de las variables. es para un "estilo" general de todas las paginas
```

## Copilot(Claude Sonnet 4)

```text
En base al esquema en mermaid que hay en README.md creame del tft 15 una composicion con 3 personajes y sus sinergias, ten también en cuenta componentes.html para rellenar la información
```

```text
Prompts varios para ajustar el css en los componentes de view
```

## Copilot(GPT-5)

```text
Varios prompts para ajustar el css de los "componentes"
```

```text
Hazme el html puro de una barra de composiciones que tenga filtrado por personajes dentro de la composición, no quiero ni css ni javascript
```

```text
Dame el css para que este formulario tenga un formato similar al de el resto de archivos css
```
