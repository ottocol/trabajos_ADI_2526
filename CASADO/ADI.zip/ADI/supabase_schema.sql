-- Schema de base de datos para Supabase
-- Basado en las migraciones de PocketBase

-- ============================================
-- EXTENSIONES
-- ============================================
-- Habilitar UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- TABLA: Usuario
-- ============================================
-- Nota: Los usuarios se gestionan con Supabase Auth
-- Esta tabla extiende la información de auth.users
CREATE TABLE IF NOT EXISTS "Usuario" (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    avatar TEXT,
    fecha_registro TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para Usuario
CREATE INDEX IF NOT EXISTS idx_usuario_email ON "Usuario"(email);

-- ============================================
-- TABLA: Sinergia
-- ============================================
CREATE TABLE IF NOT EXISTS "Sinergia" (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre_sinergia TEXT NOT NULL,
    imagen TEXT,
    personajes UUID[] DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para Sinergia
CREATE INDEX IF NOT EXISTS idx_sinergia_nombre ON "Sinergia"(nombre_sinergia);
CREATE INDEX IF NOT EXISTS idx_sinergia_personajes ON "Sinergia" USING GIN(personajes);

-- ============================================
-- TABLA: Personaje
-- ============================================
CREATE TABLE IF NOT EXISTS "Personaje" (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre TEXT NOT NULL UNIQUE,
    imagen TEXT,
    coste INTEGER DEFAULT 0,
    sinergias UUID[] DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para Personaje
CREATE INDEX IF NOT EXISTS idx_personaje_nombre ON "Personaje"(nombre);
CREATE INDEX IF NOT EXISTS idx_personaje_sinergias ON "Personaje" USING GIN(sinergias);

-- ============================================
-- TABLA: Composicion
-- ============================================
CREATE TABLE IF NOT EXISTS "Composicion" (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre TEXT NOT NULL,
    personajes UUID[] DEFAULT '{}',
    usuario UUID REFERENCES "Usuario"(id) ON DELETE CASCADE,
    tasa_de_victorias NUMERIC(5,2) DEFAULT 0,
    posicion_promedio NUMERIC(5,2) DEFAULT 0,
    tasa_de_seleccion NUMERIC(5,2) DEFAULT 0,
    tasa_top_4 NUMERIC(5,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para Composicion
CREATE INDEX IF NOT EXISTS idx_composicion_nombre ON "Composicion"(nombre);
CREATE INDEX IF NOT EXISTS idx_composicion_usuario ON "Composicion"(usuario);
CREATE INDEX IF NOT EXISTS idx_composicion_personajes ON "Composicion" USING GIN(personajes);

-- ============================================
-- TRIGGERS PARA UPDATED_AT
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_usuario_updated_at BEFORE UPDATE ON "Usuario"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_sinergia_updated_at BEFORE UPDATE ON "Sinergia"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_personaje_updated_at BEFORE UPDATE ON "Personaje"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_composicion_updated_at BEFORE UPDATE ON "Composicion"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================

-- Habilitar RLS en todas las tablas
ALTER TABLE "Usuario" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Sinergia" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Personaje" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Composicion" ENABLE ROW LEVEL SECURITY;

-- ============================================
-- POLÍTICAS PARA Usuario
-- ============================================

-- Los usuarios pueden leer todos los usuarios (para búsquedas, etc.)
CREATE POLICY "Usuarios pueden leer todos los usuarios"
    ON "Usuario" FOR SELECT
    USING (true);

-- Los usuarios solo pueden actualizar su propio perfil
CREATE POLICY "Usuarios pueden actualizar su propio perfil"
    ON "Usuario" FOR UPDATE
    USING (auth.uid() = id);

-- Los usuarios pueden insertar su propio registro (después de registro en Auth)
CREATE POLICY "Usuarios pueden insertar su propio registro"
    ON "Usuario" FOR INSERT
    WITH CHECK (auth.uid() = id);

-- Solo los propios usuarios pueden eliminar su cuenta
CREATE POLICY "Usuarios pueden eliminar su propia cuenta"
    ON "Usuario" FOR DELETE
    USING (auth.uid() = id);

-- ============================================
-- POLÍTICAS PARA Sinergia
-- ============================================

-- Todos pueden leer sinergias
CREATE POLICY "Todos pueden leer sinergias"
    ON "Sinergia" FOR SELECT
    USING (true);

-- Solo usuarios autenticados pueden crear sinergias
CREATE POLICY "Usuarios autenticados pueden crear sinergias"
    ON "Sinergia" FOR INSERT
    WITH CHECK (auth.role() = 'authenticated');

-- Solo usuarios autenticados pueden actualizar sinergias
CREATE POLICY "Usuarios autenticados pueden actualizar sinergias"
    ON "Sinergia" FOR UPDATE
    USING (auth.role() = 'authenticated');

-- Solo usuarios autenticados pueden eliminar sinergias
CREATE POLICY "Usuarios autenticados pueden eliminar sinergias"
    ON "Sinergia" FOR DELETE
    USING (auth.role() = 'authenticated');

-- ============================================
-- POLÍTICAS PARA Personaje
-- ============================================

-- Todos pueden leer personajes
CREATE POLICY "Todos pueden leer personajes"
    ON "Personaje" FOR SELECT
    USING (true);

-- Solo usuarios autenticados pueden crear personajes
CREATE POLICY "Usuarios autenticados pueden crear personajes"
    ON "Personaje" FOR INSERT
    WITH CHECK (auth.role() = 'authenticated');

-- Solo usuarios autenticados pueden actualizar personajes
CREATE POLICY "Usuarios autenticados pueden actualizar personajes"
    ON "Personaje" FOR UPDATE
    USING (auth.role() = 'authenticated');

-- Solo usuarios autenticados pueden eliminar personajes
CREATE POLICY "Usuarios autenticados pueden eliminar personajes"
    ON "Personaje" FOR DELETE
    USING (auth.role() = 'authenticated');

-- ============================================
-- POLÍTICAS PARA Composicion
-- ============================================

-- Todos pueden leer composiciones
CREATE POLICY "Todos pueden leer composiciones"
    ON "Composicion" FOR SELECT
    USING (true);

-- Solo usuarios autenticados pueden crear composiciones
CREATE POLICY "Usuarios autenticados pueden crear composiciones"
    ON "Composicion" FOR INSERT
    WITH CHECK (auth.role() = 'authenticated');

-- Los usuarios solo pueden actualizar sus propias composiciones
CREATE POLICY "Usuarios pueden actualizar sus propias composiciones"
    ON "Composicion" FOR UPDATE
    USING (auth.uid() = usuario);

-- Los usuarios solo pueden eliminar sus propias composiciones
CREATE POLICY "Usuarios pueden eliminar sus propias composiciones"
    ON "Composicion" FOR DELETE
    USING (auth.uid() = usuario);

-- ============================================
-- STORAGE BUCKET PARA AVATARES
-- ============================================
-- Nota: Esto debe ejecutarse en el dashboard de Supabase o mediante SQL
-- Crear bucket para avatares
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

-- Políticas para el bucket de avatares
CREATE POLICY "Los avatares son públicos"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'avatars');

CREATE POLICY "Los usuarios pueden subir su propio avatar"
    ON storage.objects FOR INSERT
    WITH CHECK (
        bucket_id = 'avatars' 
        AND (storage.foldername(name))[1] = auth.uid()::text
    );

CREATE POLICY "Los usuarios pueden actualizar su propio avatar"
    ON storage.objects FOR UPDATE
    USING (
        bucket_id = 'avatars' 
        AND (storage.foldername(name))[1] = auth.uid()::text
    );

CREATE POLICY "Los usuarios pueden eliminar su propio avatar"
    ON storage.objects FOR DELETE
    USING (
        bucket_id = 'avatars' 
        AND (storage.foldername(name))[1] = auth.uid()::text
    );

-- ============================================
-- FUNCIÓN PARA CREAR PERFIL AUTOMÁTICAMENTE
-- ============================================
-- Trigger para crear automáticamente un perfil cuando se registra un usuario
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public."Usuario" (id, email, nombre, fecha_registro)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'nombre', split_part(NEW.email, '@', 1)),
        NOW()
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger que se ejecuta después de crear un usuario en Auth
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================
-- COMENTARIOS Y DOCUMENTACIÓN
-- ============================================
COMMENT ON TABLE "Usuario" IS 'Extiende la información de usuarios de Supabase Auth';
COMMENT ON TABLE "Sinergia" IS 'Sinergias del juego TFT';
COMMENT ON TABLE "Personaje" IS 'Personajes/Campeones del juego TFT';
COMMENT ON TABLE "Composicion" IS 'Composiciones de personajes creadas por usuarios';
