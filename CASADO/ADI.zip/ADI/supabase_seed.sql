-- Script de Seeding para Supabase
-- Crea datos iniciales necesarios para desarrollo y pruebas

-- ============================================
-- CREAR USUARIO DE PRUEBAS
-- ============================================
-- Este usuario se usa en los tests automatizados
-- Email: test@test.com
-- Password: test1234

-- IMPORTANTE: Ejecuta esto en el SQL Editor de Supabase Dashboard
-- O usa la autenticación de Supabase para crear el usuario manualmente

-- Nota: Los usuarios en Supabase se crean mediante Auth, no directamente en la tabla Usuario
-- Puedes crear el usuario de pruebas de dos formas:

-- OPCIÓN 1: Crear manualmente desde el Dashboard
-- 1. Ve a Authentication → Users en el Dashboard de Supabase
-- 2. Click en "Add user" → "Create new user"
-- 3. Email: test@test.com
-- 4. Password: test1234
-- 5. Confirma el usuario

-- OPCIÓN 2: Usar la función signup (no recomendado en producción)
-- Este enfoque crea el usuario directamente en auth.users

-- Insertar usuario de pruebas en auth.users (solo para desarrollo local)
-- ADVERTENCIA: Esto solo funciona con acceso directo a la base de datos
-- En Supabase cloud, usa el Dashboard o la función de registro de la aplicación

DO $$
DECLARE
    test_user_id UUID;
BEGIN
    -- Verificar si el usuario ya existe
    SELECT id INTO test_user_id 
    FROM auth.users 
    WHERE email = 'test@test.com';
    
    IF test_user_id IS NULL THEN
        -- Generar un UUID para el usuario
        test_user_id := gen_random_uuid();
        
        -- Insertar en auth.users
        INSERT INTO auth.users (
            instance_id,
            id,
            aud,
            role,
            email,
            encrypted_password,
            email_confirmed_at,
            created_at,
            updated_at,
            raw_app_meta_data,
            raw_user_meta_data,
            is_super_admin,
            confirmation_token,
            email_change_token_new,
            recovery_token
        ) VALUES (
            '00000000-0000-0000-0000-000000000000',
            test_user_id,
            'authenticated',
            'authenticated',
            'test@test.com',
            crypt('test1234', gen_salt('bf')),
            NOW(),
            NOW(),
            NOW(),
            '{"provider":"email","providers":["email"]}',
            '{"nombre":"Usuario Test"}',
            FALSE,
            '',
            '',
            ''
        );
        
        -- El trigger handle_new_user() creará automáticamente el perfil en la tabla Usuario
        
        RAISE NOTICE 'Usuario de pruebas creado: test@test.com';
    ELSE
        RAISE NOTICE 'Usuario de pruebas ya existe: test@test.com';
    END IF;
END $$;

-- ============================================
-- DATOS DE EJEMPLO (OPCIONAL)
-- ============================================

-- Puedes descomentar las siguientes secciones para crear datos de ejemplo

/*
-- Crear algunas sinergias de ejemplo
INSERT INTO "Sinergia" (nombre_sinergia, imagen) VALUES
    ('Guardián', 'https://example.com/guardian.png'),
    ('Hechicero', 'https://example.com/hechicero.png'),
    ('Guerrero', 'https://example.com/guerrero.png')
ON CONFLICT DO NOTHING;

-- Crear algunos personajes de ejemplo
INSERT INTO "Personaje" (nombre, coste, imagen) VALUES
    ('Campeón 1', 1, 'https://example.com/champion1.png'),
    ('Campeón 2', 2, 'https://example.com/champion2.png'),
    ('Campeón 3', 3, 'https://example.com/champion3.png')
ON CONFLICT (nombre) DO NOTHING;
*/

-- ============================================
-- VERIFICACIÓN
-- ============================================

-- Verificar que el usuario fue creado
SELECT 
    u.id,
    u.email,
    u.email_confirmed_at,
    u.created_at,
    usr.nombre,
    usr.fecha_registro
FROM auth.users u
LEFT JOIN "Usuario" usr ON usr.id = u.id
WHERE u.email = 'test@test.com';
