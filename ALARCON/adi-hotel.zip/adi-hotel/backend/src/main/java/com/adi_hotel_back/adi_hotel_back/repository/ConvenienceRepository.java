package com.adi_hotel_back.adi_hotel_back.repository;

import com.adi_hotel_back.adi_hotel_back.model.Convenience;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ConvenienceRepository extends JpaRepository<Convenience, Long> {
    Optional<Convenience> findByName(String name);
}
