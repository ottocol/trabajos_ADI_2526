package com.adi_hotel_back.adi_hotel_back.repository;

import com.adi_hotel_back.adi_hotel_back.model.RoomType;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RoomTypeRepository extends JpaRepository<RoomType, Long> {
    Optional<RoomType> findByName(String name);

    @Query("SELECT rt FROM RoomType rt")
    List<RoomType> findMostBooked(Pageable pageable);
}
