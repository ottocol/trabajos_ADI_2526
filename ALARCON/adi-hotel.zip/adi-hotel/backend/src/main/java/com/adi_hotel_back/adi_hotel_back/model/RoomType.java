package com.adi_hotel_back.adi_hotel_back.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "room_type")
public class RoomType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String name;

    @Column(nullable = false)
    private Integer capacity;

    @Column(name = "view_type")
    private String viewType;

    private String description;

    @Column(name = "base_price", nullable = false, precision = 10, scale = 2)
    private BigDecimal basePrice;

    @OneToMany(mappedBy = "roomType", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private Set<Photo> photos = new HashSet<>();
    
    @OneToMany(mappedBy = "roomType", cascade = CascadeType.ALL)
    @JsonManagedReference
    private Set<Room> rooms = new HashSet<>();

    @ManyToMany
    @JoinTable(
        name = "room_type_convenience",
        joinColumns = @JoinColumn(name = "room_type_id"),
        inverseJoinColumns = @JoinColumn(name = "amenity_id")
    )
    private Set<Convenience> conveniences = new HashSet<>();

    public RoomType() {
    }

    public RoomType(String name, Integer capacity, String viewType, String description, BigDecimal basePrice) {
        this.name = name;
        this.capacity = capacity;
        this.viewType = viewType;
        this.description = description;
        this.basePrice = basePrice;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public String getViewType() {
        return viewType;
    }

    public void setViewType(String viewType) {
        this.viewType = viewType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(BigDecimal basePrice) {
        this.basePrice = basePrice;
    }

    public Set<Photo> getPhotos() {
        return photos;
    }

    public void setPhotos(Set<Photo> photos) {
        this.photos = photos;
    }
    
    public Set<Room> getRooms() {
        return rooms;
    }

    public void setRooms(Set<Room> rooms) {
        this.rooms = rooms;
    }

    public void addPhoto(Photo photo) {
        this.photos.add(photo);
        photo.setRoomType(this);
    }

    public void removePhoto(Photo photo) {
        this.photos.remove(photo);
        photo.setRoomType(null);
    }

    public Set<Convenience> getConveniences() {
        return conveniences;
    }

    public void setConveniences(Set<Convenience> conveniences) {
        this.conveniences = conveniences;
    }
}
