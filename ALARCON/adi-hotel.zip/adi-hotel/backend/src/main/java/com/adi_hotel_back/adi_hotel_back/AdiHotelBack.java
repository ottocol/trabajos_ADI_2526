package com.adi_hotel_back.adi_hotel_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdiHotelBack {

	public static void main(String[] args) {
		SpringApplication.run(AdiHotelBack.class, args);
	}

}
