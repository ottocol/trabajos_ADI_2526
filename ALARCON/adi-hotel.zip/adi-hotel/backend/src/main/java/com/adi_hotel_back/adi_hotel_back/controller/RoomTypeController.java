package com.adi_hotel_back.adi_hotel_back.controller;

import com.adi_hotel_back.adi_hotel_back.dto.MessageResponse;
import com.adi_hotel_back.adi_hotel_back.dto.RoomTypeAvailabilityResponse;
import com.adi_hotel_back.adi_hotel_back.dto.RoomTypeResponse;
import com.adi_hotel_back.adi_hotel_back.model.RoomType;
import com.adi_hotel_back.adi_hotel_back.repository.RoomTypeRepository;
import com.adi_hotel_back.adi_hotel_back.service.RoomAvailabilityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/room-types")
@Tag(name = "Room Types", description = "Room Type Management")
public class RoomTypeController {

    @Autowired
    private RoomTypeRepository roomTypeRepository;

    @Autowired
    private RoomAvailabilityService availabilityService;

    // READ ALL - GET /api/room-types
    @GetMapping
    public ResponseEntity<?> getAllRoomTypes() {
        List<RoomType> roomTypes = roomTypeRepository.findAll();
        List<RoomTypeResponse> responses = roomTypes.stream()
                .map(RoomTypeResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(responses);
    }

    // READ ONE - GET /api/room-types/{id}
    @GetMapping("/{id}")
    public ResponseEntity<?> getRoomTypeById(@PathVariable Long id) {
        Optional<RoomType> roomTypeOpt = roomTypeRepository.findById(id);
        if (!roomTypeOpt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new MessageResponse("Error: Room Type not found"));
        }
        return ResponseEntity.ok(new RoomTypeResponse(roomTypeOpt.get()));
    }

    // READ ONE WITH AVAILABILITY - GET /api/room-types/{id}/availability
    @Operation(summary = "Get room type with current availability",
               description = "Returns room type details plus real-time availability count for today. Ideal for SSR pages that need fresh data.")
    @GetMapping("/{id}/availability")
    public ResponseEntity<?> getRoomTypeWithAvailability(@PathVariable Long id) {
        Optional<RoomType> roomTypeOpt = roomTypeRepository.findById(id);
        if (!roomTypeOpt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new MessageResponse("Error: Room Type not found"));
        }

        int availableCount = availabilityService.getAvailableCountForRoomType(id);
        int totalCount = availabilityService.getTotalCountForRoomType(id);

        RoomTypeAvailabilityResponse response = new RoomTypeAvailabilityResponse(roomTypeOpt.get(), availableCount);
        response.setTotalCount(totalCount);

        return ResponseEntity.ok(response);
    }

    // TOP BOOKED - GET /api/room-types/top-booked
    @GetMapping("/top-booked")
    public ResponseEntity<?> getTopBookedRoomTypes() {
        Pageable topThree = PageRequest.of(0, 3);
        List<RoomType> roomTypes = roomTypeRepository.findMostBooked(topThree);
        List<RoomTypeResponse> responses = roomTypes.stream()
                .map(RoomTypeResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(responses);
    }
}
