package com.adi_hotel_back.adi_hotel_back.dto;

import com.adi_hotel_back.adi_hotel_back.model.RoomType;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class RoomTypeAvailabilityResponse {
    private Long id;
    private String name;
    private Integer capacity;
    private String viewType;
    private String description;
    private BigDecimal basePrice;
    private List<PhotoResponse> photos;
    private List<ConvenienceResponse> conveniences;
    private int availableCount;
    private int totalCount;
    private String bookingUrl;

    public RoomTypeAvailabilityResponse() {}

    public RoomTypeAvailabilityResponse(RoomType roomType, int availableCount) {
        this.id = roomType.getId();
        this.name = roomType.getName();
        this.capacity = roomType.getCapacity();
        this.viewType = roomType.getViewType();
        this.description = roomType.getDescription();
        this.basePrice = roomType.getBasePrice();
        this.photos = roomType.getPhotos() != null 
                ? roomType.getPhotos().stream().map(PhotoResponse::new).collect(Collectors.toList())
                : List.of();
        this.conveniences = roomType.getConveniences() != null
                ? roomType.getConveniences().stream().map(ConvenienceResponse::new).collect(Collectors.toList())
                : List.of();
        this.availableCount = availableCount;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    public String getViewType() { return viewType; }
    public void setViewType(String viewType) { this.viewType = viewType; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getBasePrice() { return basePrice; }
    public void setBasePrice(BigDecimal basePrice) { this.basePrice = basePrice; }
    public List<PhotoResponse> getPhotos() { return photos; }
    public void setPhotos(List<PhotoResponse> photos) { this.photos = photos; }
    public List<ConvenienceResponse> getConveniences() { return conveniences; }
    public void setConveniences(List<ConvenienceResponse> conveniences) { this.conveniences = conveniences; }
    public int getAvailableCount() { return availableCount; }
    public void setAvailableCount(int availableCount) { this.availableCount = availableCount; }

    public int getTotalCount() { return totalCount; }
    public void setTotalCount(int totalCount) { this.totalCount = totalCount; }

    public String getBookingUrl() { return bookingUrl; }
    public void setBookingUrl(String bookingUrl) { this.bookingUrl = bookingUrl; }
}
