package com.adi_hotel_back.adi_hotel_back.repository;

import com.adi_hotel_back.adi_hotel_back.model.Room;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface RoomRepository extends JpaRepository<Room, Long> {
    Optional<Room> findByRoomNumber(String roomNumber);

    Boolean existsByRoomNumber(String roomNumber);


    @Query("SELECT r FROM Room r JOIN r.roomType rt WHERE rt.name = :type")
    List<Room> findByType(@Param("type") String type);

    List<Room> findByFloor(String floor);

    @Query("SELECT r FROM Room r JOIN r.roomType rt WHERE rt.capacity >= :capacity")
    List<Room> findByCapacityGreaterThanEqual(@Param("capacity") Integer capacity);

    // Advanced search with pagination
    @Query("SELECT r FROM Room r JOIN r.roomType rt WHERE " +
           "(:type IS NULL OR rt.name = :type) AND " +
           "(:floor IS NULL OR r.floor = :floor) AND " +
           "(:minCapacity IS NULL OR rt.capacity >= :minCapacity) AND " +
           "(:viewType IS NULL OR rt.viewType = :viewType)")
    Page<Room> findByFilters(
            @Param("type") String type,
            @Param("floor") String floor,
            @Param("minCapacity") Integer minCapacity,
            @Param("viewType") String viewType,
            Pageable pageable
    );
}
