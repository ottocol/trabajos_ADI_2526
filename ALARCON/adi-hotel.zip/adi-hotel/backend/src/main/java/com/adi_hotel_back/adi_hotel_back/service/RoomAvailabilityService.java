package com.adi_hotel_back.adi_hotel_back.service;

import com.adi_hotel_back.adi_hotel_back.dto.RoomTypeAvailabilityResponse;
import com.adi_hotel_back.adi_hotel_back.model.Room;
import com.adi_hotel_back.adi_hotel_back.model.RoomType;
import com.adi_hotel_back.adi_hotel_back.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class RoomAvailabilityService {

    @Autowired
    private RoomRepository roomRepository;

    /**
     * Verifica si una habitación está disponible en un rango de fechas
     *
     * @param roomId ID de la habitación
     * @param checkInDate Fecha de entrada (inclusiva)
     * @param checkOutDate Fecha de salida (exclusiva)
     * @return true
     */
    public boolean isRoomAvailable(Long roomId, LocalDate checkInDate, LocalDate checkOutDate) {
        return true;
    }

    /**
     * Obtiene lista de habitaciones disponibles en un rango de fechas
     *
     * @param checkInDate Fecha de entrada
     * @param checkOutDate Fecha de salida
     * @return Lista de habitaciones disponibles
     */
    public List<Room> getAvailableRooms(LocalDate checkInDate, LocalDate checkOutDate) {
        List<Room> allRooms = roomRepository.findAll();

        return allRooms.stream()
            .filter(room -> isRoomAvailable(room.getId(), checkInDate, checkOutDate))
            .collect(Collectors.toList());
    }

    /**
     * Obtiene el número de habitaciones disponibles HOY para un tipo de habitación.
     *
     * @param roomTypeId ID del tipo de habitación
     * @return Número de habitaciones disponibles hoy
     */
    public int getAvailableCountForRoomType(Long roomTypeId) {
        LocalDate today = LocalDate.now();
        LocalDate tomorrow = today.plusDays(1);

        List<Room> roomsOfType = roomRepository.findAll().stream()
                .filter(room -> room.getRoomType().getId().equals(roomTypeId))
                .collect(Collectors.toList());

        return (int) roomsOfType.stream()
                .filter(room -> isRoomAvailable(room.getId(), today, tomorrow))
                .count();
    }

    /**
     * Obtiene el número total de habitaciones físicas de un tipo.
     *
     * @param roomTypeId ID del tipo de habitación
     * @return Número total de habitaciones de ese tipo
     */
    public int getTotalCountForRoomType(Long roomTypeId) {
        return (int) roomRepository.findAll().stream()
                .filter(room -> room.getRoomType().getId().equals(roomTypeId))
                .count();
    }

    /**
     * Obtiene disponibilidad agrupada por Tipo de Habitación
     *
     * @param checkInDate Fecha de entrada
     * @param checkOutDate Fecha de salida
     * @return Lista de tipos de habitación disponibles con sus cantidades
     */
    public List<RoomTypeAvailabilityResponse> getAvailableRoomTypes(LocalDate checkInDate, LocalDate checkOutDate) {
        List<Room> availableRooms = getAvailableRooms(checkInDate, checkOutDate);

        // Agrupamos las habitaciones físicas por su tipo
        Map<RoomType, Long> counts = availableRooms.stream()
            .collect(Collectors.groupingBy(Room::getRoomType, Collectors.counting()));

        // Convertimos el mapa a una lista de DTOs
        return counts.entrySet().stream()
            .map(entry -> new RoomTypeAvailabilityResponse(entry.getKey(), entry.getValue().intValue()))
            .collect(Collectors.toList());
    }
}
