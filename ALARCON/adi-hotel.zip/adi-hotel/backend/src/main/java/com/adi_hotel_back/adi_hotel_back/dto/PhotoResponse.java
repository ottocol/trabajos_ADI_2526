package com.adi_hotel_back.adi_hotel_back.dto;

import com.adi_hotel_back.adi_hotel_back.model.Photo;

public class PhotoResponse {
    private Long id;
    private String url;
    private boolean isMain;

    public PhotoResponse(Photo photo) {
        this.id = photo.getId();
        this.url = photo.getUrl();
        this.isMain = photo.isMain();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isMain() {
        return isMain;
    }

    public void setMain(boolean main) {
        isMain = main;
    }
}
