package com.adi_hotel_back.adi_hotel_back.dto;

import com.adi_hotel_back.adi_hotel_back.model.RoomType;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RoomTypeResponse {

    private Long id;
    private String name;
    private Integer capacity;
    private String viewType;
    private String description;
    private BigDecimal basePrice;
    private List<PhotoResponse> photos;
    private List<ConvenienceResponse> conveniences;

    public RoomTypeResponse() {
    }

    public RoomTypeResponse(RoomType roomType) {
        this.id = roomType.getId();
        this.name = roomType.getName();
        this.capacity = roomType.getCapacity();
        this.viewType = roomType.getViewType();
        this.description = roomType.getDescription();
        this.basePrice = roomType.getBasePrice();
        this.photos = roomType.getPhotos() != null 
                ? roomType.getPhotos().stream().map(PhotoResponse::new).collect(Collectors.toList())
                : new ArrayList<>();
        this.conveniences = roomType.getConveniences() != null
                ? roomType.getConveniences().stream().map(ConvenienceResponse::new).collect(Collectors.toList())
                : new ArrayList<>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public String getViewType() {
        return viewType;
    }

    public void setViewType(String viewType) {
        this.viewType = viewType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(BigDecimal basePrice) {
        this.basePrice = basePrice;
    }

    public List<PhotoResponse> getPhotos() {
        return photos;
    }

    public void setPhotos(List<PhotoResponse> photos) {
        this.photos = photos;
    }

    public List<ConvenienceResponse> getConveniences() {
        return conveniences;
    }

    public void setConveniences(List<ConvenienceResponse> conveniences) {
        this.conveniences = conveniences;
    }
}
