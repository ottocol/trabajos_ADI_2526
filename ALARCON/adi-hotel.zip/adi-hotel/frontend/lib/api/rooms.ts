import { apiRequest } from "@/lib/api";
import { RoomTypeResponse, RoomTypeWithAvailability } from "@/lib/types";

/**
 * ESTRATEGIA: ISR (Incremental Static Regeneration)
 *
 * Obtiene todas las habitaciones con revalidación cada 60 segundos.
 * La primera visita sirve HTML cacheado, después de 60s
 * la siguiente petición triggerea regeneración en background.
 */
export async function getAllRoomTypes(): Promise<RoomTypeResponse[]> {
  // ISR: Revalidar cada 60 segundos
  return apiRequest<RoomTypeResponse[]>("/room-types", {
    method: "GET",
    next: { revalidate: 60 },
  });
}

/**
 * ESTRATEGIA: SSG (Static Site Generation)
 *
 * Obtiene las 3 habitaciones más populares para la Home.
 * Los datos se obtienen una sola vez durante el build.
 */
export async function getFeaturedRooms(): Promise<RoomTypeResponse[]> {
  // SSG: Cache permanente, se genera en build time
  return apiRequest<RoomTypeResponse[]>("/room-types/top-booked", {
    method: "GET",
    cache: "force-cache",
  });
}

/**
 * ESTRATEGIA: SSR (Server-Side Rendering)
 *
 * Obtiene detalles de una habitación CON DISPONIBILIDAD EN TIEMPO REAL.
 * Usamos cache: 'no-store' para garantizar datos frescos en cada request.
 *
 * ¿Por qué SSR y no ISR?
 * - La disponibilidad cambia constantemente (reservas nuevas, cancelaciones)
 * - Mostrar datos obsoletos podría causar overbooking
 * - El usuario necesita saber si puede reservar AHORA
 */
export async function getRoomTypeById(
  roomTypeId: string,
): Promise<RoomTypeWithAvailability> {
  // SSR: Sin caché, datos frescos en cada request
  return apiRequest<RoomTypeWithAvailability>(
    `/room-types/${roomTypeId}/availability`,
    {
      method: "GET",
      cache: "no-store",
    },
  );
}
