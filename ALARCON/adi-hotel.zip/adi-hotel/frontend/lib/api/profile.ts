import { apiRequest } from "@/lib/api";
import type {
  UserProfileResponse,
  UpdateProfileRequest,
  changePasswordRequest,
  MessageResponse,
} from "@/lib/types";

/**
 * Get authenticated user's profile
 */
export async function getUserProfile(): Promise<UserProfileResponse> {
  return apiRequest<UserProfileResponse>("/user/profile", {
    method: "GET",
  });
}

/**
 * Update profile info
 */
export async function updateUserProfile(
  data: UpdateProfileRequest
): Promise<MessageResponse> {
  return apiRequest<MessageResponse>("/user/profile", {
    method: "PUT",
    body: JSON.stringify(data),
  });
}

/**
 * Change user password
 */
export async function changePassword(
  data: changePasswordRequest
): Promise<MessageResponse> {
  return apiRequest<MessageResponse>("/user/change-password", {
    method: "POST",
    body: JSON.stringify(data),
  });
}
