import { apiRequest } from "../api";
import type { LoginRequest, LoginResponse } from "../types";

/**
 * Login user with email and password
 */
export async function loginUser(
  credentials: LoginRequest,
): Promise<LoginResponse> {
  return apiRequest<LoginResponse>("/auth/signin", {
    method: "POST",
    body: JSON.stringify(credentials),
  });
}

/**
 * Logout user and clear httpOnly cookie
 */
export async function logoutUser(): Promise<void> {
  await apiRequest<void>("/auth/signout", {
    method: "POST",
  });
}
