import type { ApiError } from "./types";

// Use different URLs for server-side (Docker service name) vs client-side (localhost)
const getApiBaseUrl = () =>
  typeof window === "undefined"
    ? process.env.API_URL || process.env.NEXT_PUBLIC_API_URL || "http://backend:8080/api"
    : process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api";

interface ApiRequestOptions extends Omit<RequestInit, 'next'> {
  /**
   * Next.js specific fetch options for caching strategies
   * - { revalidate: number } for ISR
   */
  next?: { revalidate?: number };
}

/**
 * Base API request function with configurable caching strategies
 *
 * Cache strategies (Next.js 16):
 * - cache: 'force-cache' → SSG (Static Site Generation)
 * - cache: 'no-store' → SSR (Server-Side Rendering)
 * - next: { revalidate: N } → ISR (Incremental Static Regeneration)
 */
export async function apiRequest<T>(
  endpoint: string,
  options: ApiRequestOptions = {}
): Promise<T> {
  const { next, ...fetchOptions } = options;

  // Normalize headers to a Headers instance to avoid TS issues
  const merged = new Headers(fetchOptions.headers || {});
  if (!merged.has("Content-Type")) {
    merged.set("Content-Type", "application/json");
  }

  const config: RequestInit & { next?: { revalidate?: number } } = {
    ...fetchOptions,
    headers: merged,
    credentials: typeof window === "undefined" ? undefined : "include",
  };

  // Add Next.js specific options (ISR revalidation)
  if (next) {
    config.next = next;
  }

  const response = await fetch(`${getApiBaseUrl()}${endpoint}`, config);

  // Handle non-JSON responses (like 204 No Content)
  if (response.status === 204) {
    return {} as T;
  }

  const contentType = response.headers.get("content-type") || "";
  const isJson = contentType.includes("application/json");
  const data: unknown = isJson ? await response.json() : {};

  if (!response.ok) {
    const payload = (data ?? {}) as {
      message?: string;
      errors?: Record<string, string[]>;
    };

    const error: ApiError = {
      message: payload.message || "An error occurred",
      status: response.status,
      errors: payload.errors,
    };
    throw error;
  }

  return data as T;
}
