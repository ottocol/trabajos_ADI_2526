export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  id: number;
  email: string;
  role: string;
}

export interface PhotoResponse {
  id: number;
  url: string;
  isMain: boolean;
}

export interface ConvenienceResponse {
  id: number;
  name: string;
  description: string;
  icon: string;
}

export interface RoomTypeResponse {
  id: number;
  name: string;
  capacity: number;
  viewType: string;
  description: string;
  basePrice: number;
  photos: PhotoResponse[];
  conveniences: ConvenienceResponse[];
}

export interface RoomTypeWithAvailability extends RoomTypeResponse {
  availableCount: number;
  totalCount: number;
}

export interface ApiError {
  message: string;
  status: number;
  errors?: Record<string, string[]>;
}

export interface UserProfileResponse {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  address?: string;
  totalBookings: number;
  totalSpent: number;
  activeBookings: number;
}

export interface UpdateProfileRequest {
  firstName: string;
  lastName: string;
  phone?: string;
  address?: string;
}

export interface changePasswordRequest {
  currentPassword: string;
  newPassword: string;
}

export interface MessageResponse {
  message: string;
}
