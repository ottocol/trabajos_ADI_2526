/**
 * ESTRATEGIA: ISR (Incremental Static Regeneration)
 *
 * Este componente obtiene todas las habitaciones usando `next: { revalidate: 60 }`.
 * Los datos se cachean y se regeneran en background cada 60 segundos.
 *
 * Diferencia con SSG (Home):
 * - SSG usa `cache: 'force-cache'` → datos NUNCA se actualizan sin rebuild
 * - ISR usa `next: { revalidate: 60 }` → datos se actualizan cada 60s automáticamente
 *
 * Diferencia con SSR (Detalle habitación):
 * - SSR usa `cache: 'no-store'` → datos frescos en CADA request (más lento)
 * - ISR sirve cacheado (rápido) y regenera en background
 */

import RoomTypesList from "@/components/shared/RoomTypesList";
import { getAllRoomTypes } from "@/lib/api/rooms";

export default async function CatalogRooms() {
  // ISR implementado en el método getAllRoomTypes
  const roomTypes = await getAllRoomTypes();

  return (
    <RoomTypesList
      title="Catálogo de Habitaciones"
      subtitle="Descubre todas nuestras opciones de alojamiento"
      roomTypes={roomTypes}
      emptyMessage="No hay habitaciones disponibles en este momento"
    />
  );
}
