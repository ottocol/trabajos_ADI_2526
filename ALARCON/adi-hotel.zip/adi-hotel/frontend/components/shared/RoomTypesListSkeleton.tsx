import RoomTypeCard from "@/components/shared/RoomTypeCard";

interface RoomTypesListSkeletonProps {
  title: string;
  count?: number;
  variant?: "default" | "compact";
}

export default function RoomTypesListSkeleton({
  title,
  count = 3,
  variant = "default",
}: RoomTypesListSkeletonProps) {
  return (
    <section className="px-4 py-4 md:py-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 text-center">
          <h2 className="mb-4 font-light text-2xl md:text-3xl lg:text-4xl">
            {title}
          </h2>
        </div>

        {/* Skeletons grid */}
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: count }).map((_, i) => (
            <RoomTypeCard key={i} loading />
          ))}
        </div>
      </div>
    </section>
  );
}
