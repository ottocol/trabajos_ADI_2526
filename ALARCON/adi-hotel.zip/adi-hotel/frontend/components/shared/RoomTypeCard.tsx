import Image from "next/image";
import Link from "next/link";
import { Skeleton } from "@/components/shared/skeleton";
import { RoomTypeResponse } from "@/lib/types";
import { Users, ArrowRight } from "lucide-react";

interface RoomTypeCardProps {
  roomType?: RoomTypeResponse;
  loading?: boolean;
}

export default function RoomTypeCard({
  roomType,
  loading = false,
}: RoomTypeCardProps) {
  // Skeleton state
  if (loading) {
    return (
      <div className="relative aspect-3/4 rounded-2xl overflow-hidden">
        <Skeleton className="absolute inset-0" />
      </div>
    );
  }

  if (!roomType) return null;

  // Select photo to show
  const mainPhoto = roomType.photos.find((p) => p.isMain) || roomType.photos[0];

  // Build photo URL
  const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080";
  const imageUrl = mainPhoto
    ? `${API_BASE}${mainPhoto.url}`
    : "/images/placeholder.png";

  return (
    <Link
      href={`/rooms/${roomType.id}`}
      className="group relative aspect-3/4 rounded-2xl overflow-hidden block"
    >
      {/* Image */}
      <Image
        src={imageUrl}
        alt={roomType.name}
        fill
        className="object-cover transition-transform duration-500 group-hover:scale-110"
        unoptimized
      />

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-linear-to-t from-black/90 via-black/40 to-black/10" />

      {/* Content overlay */}
      <div className="absolute inset-x-0 bottom-0 p-6 text-white">
        {/* Title */}
        <h3 className="text-2xl font-semibold mb-2">{roomType.name}</h3>

        {/* Description - truncated */}
        <p className="text-white/70 text-sm line-clamp-2 mb-3">
          {roomType.description}
        </p>

        {/* Price and capacity */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-1.5 text-white/80 text-sm">
            <Users className="h-4 w-4" />
            <span>
              {roomType.capacity}{" "}
              {roomType.capacity === 1 ? "persona" : "personas"}
            </span>
          </div>
          <div className="text-white/90">
            <span className="text-lg font-medium">{roomType.basePrice}€</span>
            <span className="text-sm text-white/60 ml-1">/noche</span>
          </div>
        </div>

        {/* Button - appears on hover */}
        <div className="flex items-center gap-2 text-emerald-400 font-medium opacity-0 translate-y-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-y-0">
          <span>Ver detalles</span>
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </div>
      </div>
    </Link>
  );
}
