import FadeIn from "@/components/shared/FadeIn";
import RoomTypeCard from "@/components/shared/RoomTypeCard";
import { RoomTypeResponse } from "@/lib/types";

interface RoomTypesListProps {
  title: string;
  subtitle?: string;
  roomTypes: RoomTypeResponse[];
  emptyMessage?: string;
  disableAnimation?: boolean;
}

export default function RoomTypesList({
  title,
  subtitle,
  roomTypes,
  emptyMessage = "No hay habitaciones disponibles",
  disableAnimation = false,
}: RoomTypesListProps) {
  const emptyContent = (
    <section className="px-4 py-4 md:py-8">
      <div className="mx-auto max-w-7xl text-center">
        <h2 className="mb-4 font-light text-2xl md:text-3xl lg:text-4xl">
          {title}
        </h2>
        <p className="text-gray-600">{emptyMessage}</p>
      </div>
    </section>
  );

  const successContent = (
    <section className="px-4 py-4 md:py-8">
      <div className="mx-auto max-w-7xl">
        {/* Title */}
        <div className="mb-8 text-center">
          <h2 className="mb-4 font-light text-2xl md:text-3xl lg:text-4xl">
            {title}
          </h2>
          {subtitle && (
            <p className="mx-auto max-w-3xl font-light text-xl text-gray-600">
              {subtitle}
            </p>
          )}
        </div>

        {/* Rooms grid */}
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {roomTypes.map((roomType) => (
            <RoomTypeCard key={roomType.id} roomType={roomType} />
          ))}
        </div>
      </div>
    </section>
  );

  // Empty state
  if (roomTypes.length === 0) {
    return disableAnimation ? (
      emptyContent
    ) : (
      <FadeIn delay={0.1}>{emptyContent}</FadeIn>
    );
  }

  // Success state
  return disableAnimation ? (
    successContent
  ) : (
    <FadeIn delay={0.1}>{successContent}</FadeIn>
  );
}
