import Logo from "@/components/layout/header/Logo";
import Navigation from "@/components/layout/header/Navigation";
import { navItems } from "@/components/layout/header/navConfig";

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Logo />
          <Navigation items={navItems} />
        </div>
      </div>
    </header>
  );
}
