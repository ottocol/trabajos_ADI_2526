import { Home, BedDouble, UserCircle, LucideIcon } from "lucide-react";

export interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
}

export const navItems: NavItem[] = [
  { href: "/", label: "Inicio", icon: Home },
  { href: "/rooms", label: "Habitaciones", icon: BedDouble },
  { href: "/profile", label: "Perfil", icon: UserCircle },
];
