import { NavItem } from "@/components/layout/header/navConfig";
import Link from "next/link";

interface NavigationProps {
  items: NavItem[];
}

export default function Navigation({ items }: NavigationProps) {
  return (
    <nav className="hidden md:flex items-center gap-6">
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            className="flex items-center gap-2 text-gray-700 px-4 py-2 rounded-lg transition duration-75 hover:text-white hover:[background:var(--primary-gradient)]"
          >
            <Icon className="w-5 h-5" />
            <span>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
