import Link from "next/link";
import { Hotel } from "lucide-react";

export default function Logo() {
  return (
    <Link href="/" className="flex items-center gap-3">
      <div className="w-10 h-10 bg-primary-gradient rounded-lg flex items-center justify-center">
        <Hotel className="text-white" />
      </div>
      <div>
        <h1 className="text-lg text-gray-900">ADI Hotel</h1>
        <p className="text-xs text-gray-500">Estrategias de renderizado</p>
      </div>
    </Link>
  );
}
