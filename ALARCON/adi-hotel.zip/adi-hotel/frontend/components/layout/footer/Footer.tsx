export default function Footer() {
  return (
    <footer className="border-t border-gray-200 text-gray-700">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-end">
          {/* Hotel info */}
          <div>
            <h3 className="text-gray-900 font-semibold mb-3">ADI Hotel</h3>
            <p className="text-sm">Calle inventada, 123, España</p>
            <p className="text-sm mt-2">Tel: +34 952 123 456</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
