import RoomTypesList from "@/components/shared/RoomTypesList";
import { getFeaturedRooms } from "@/lib/api/rooms";

/**
 * ESTRATEGIA: SSG (Static Site Generation)
 *
 * Este componente obtiene las habitaciones más populares usando cache: 'force-cache'.
 * Los datos se obtienen una sola vez durante `next build` y se sirven como HTML estático.
 */
export default async function Rooms() {
  const roomTypes = await getFeaturedRooms();

  return (
    <RoomTypesList
      title="Habitaciones"
      subtitle="Explora algunas de nuestras mejores habitaciones"
      roomTypes={roomTypes}
    />
  );
}
