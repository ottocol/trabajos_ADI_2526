import Image from "next/image";
import Link from "next/link";
import { Star } from "lucide-react";
import { Button } from "@/components/shared/button";

export default function Hero() {
  return (
    <section className="w-full min-h-150 bg-linear-to-b from-emerald-50 to-white">
      <div className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="flex flex-col justify-center order-2 lg:order-1">
            <div className="flex items-center gap-2 mb-6">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className="w-5 h-5 fill-yellow-400 text-yellow-400"
                />
              ))}
              <span className="ml-2 text-yellow-500 font-medium">
                Hotel 5 Estrellas
              </span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight text-emerald-500">
              Tu escape perfecto te espera
            </h1>

            <p className="text-lg md:text-xl text-gray-700 mb-8 leading-relaxed">
              Descubre un refugio de tranquilidad donde cada momento está
              diseñado para renovar tu espíritu. Vive una experiencia única de
              descanso y bienestar.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                asChild
                size="lg"
                variant="gradient"
                className="px-8 py-6 text-lg rounded-xl font-semibold"
              >
                <Link href="/rooms">Explorar habitaciones</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                disabled
                className="px-8 py-6 text-lg rounded-xl font-semibold"
              >
                Contactar
              </Button>
            </div>
          </div>

          <div className="relative order-1 lg:order-2">
            <div className="relative h-100 lg:h-125 rounded-2xl overflow-hidden shadow-2xl">
              <Image
                src="/images/hero/hotel.jpg"
                alt="Hotel de lujo"
                fill
                className="object-cover"
                priority
                unoptimized
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
