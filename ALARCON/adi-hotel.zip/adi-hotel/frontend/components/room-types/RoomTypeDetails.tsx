"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { useState } from "react";
import { Button } from "@/components/shared/button";
import {
  Users,
  MapPin,
  Wifi,
  Wind,
  Shield,
  Tv,
  Wine,
  Projector,
  PenTool,
  Volume2,
  Waves,
  Blinds,
  Eye,
  Check,
  LucideIcon,
  Calendar,
} from "lucide-react";
import { RoomTypeWithAvailability } from "@/lib/types";

interface RoomTypeDetailsProps {
  roomType: RoomTypeWithAvailability;
}

// Icon mapping for convenience icons from backend
const iconMap: Record<string, LucideIcon> = {
  wifi_icon: Wifi,
  tv_icon: Tv,
  ac_icon: Wind,
  minibar_icon: Wine,
  projector_icon: Projector,
  whiteboard_icon: PenTool,
  speaker_icon: Volume2,
  jacuzzi_icon: Waves,
  balcony_icon: Blinds,
  sea_view_icon: Eye,
  safe_icon: Shield,
};

// Helper function to get icon component
const getConvenienceIcon = (iconName: string): LucideIcon => {
  return iconMap[iconName] || Check;
};

export default function RoomTypeDetails({ roomType }: RoomTypeDetailsProps) {
  const [imageError, setImageError] = useState(false);

  // Select photo to show
  const mainPhoto = roomType.photos.find((p) => p.isMain) || roomType.photos[0];

  // Build photo URL
  const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080";
  const imageUrl =
    mainPhoto && !imageError
      ? `${API_BASE}${mainPhoto.url}`
      : "/images/placeholder.png";

  return (
    <div className="w-full">
      {/* Hero image with overlay */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="relative w-full h-[60vh] min-h-100"
      >
        <Image
          src={imageUrl}
          alt={roomType.name}
          fill
          unoptimized
          priority
          onError={() => setImageError(true)}
          className="object-cover"
        />

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-linear-to-t from-black/80 via-black/30 to-transparent" />

        <div className="absolute inset-x-0 bottom-0 p-8 md:p-12 text-white">
          <div className="max-w-4xl mx-auto">
            {/* Meta info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="flex items-center gap-4 mb-4"
            >
              <div className="flex items-center gap-1.5 text-white/80">
                <Users className="h-5 w-5" />
                <span>
                  Hasta {roomType.capacity}{" "}
                  {roomType.capacity === 1 ? "persona" : "personas"}
                </span>
              </div>
              {roomType.viewType && (
                <div className="flex items-center gap-1.5 text-white/80">
                  <MapPin className="h-5 w-5" />
                  <span>Vista {roomType.viewType}</span>
                </div>
              )}
            </motion.div>

            {/* Title */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold mb-2"
            >
              {roomType.name}
            </motion.h1>
          </div>
        </div>
      </motion.div>

      {/* Price card with availability indicator */}
      <div className="max-w-4xl mx-auto px-4 md:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mb-8"
        >
          <div className="bg-white rounded-2xl shadow-xl p-6">
            {/* Availability indicator */}
            <div className="mb-4 pb-4 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">
                  Disponibilidad en tiempo real
                </span>
                <div
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${
                    roomType.availableCount > 0
                      ? "bg-emerald-50 text-emerald-700"
                      : "bg-red-50 text-red-700"
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      roomType.availableCount > 0
                        ? "bg-emerald-500 animate-pulse"
                        : "bg-red-500"
                    }`}
                  />
                  {roomType.availableCount > 0 ? (
                    <span>
                      {roomType.availableCount} de {roomType.totalCount}{" "}
                      disponibles
                    </span>
                  ) : (
                    <span>Sin disponibilidad</span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <p className="text-gray-500 text-sm mb-1">Precio por noche</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-emerald-600">
                    {roomType.basePrice}€
                  </span>
                  <span className="text-gray-500">/noche</span>
                </div>
              </div>
              <Button
                size="lg"
                variant="gradient"
                className="w-full sm:w-auto px-8 py-6 text-lg rounded-xl font-semibold disabled:opacity-50"
                disabled
              >
                <Calendar className="h-5 w-5 mr-2" />
                {roomType.availableCount === 0
                  ? "No disponible"
                  : "Reservar ahora"}
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Description */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mb-10"
        >
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">
            Sobre esta habitación
          </h2>
          <p className="text-gray-600 text-lg leading-relaxed">
            {roomType.description}
          </p>
        </motion.div>

        {/* Characteristics */}
        {roomType.conveniences && roomType.conveniences.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="mb-12"
          >
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">
              Características
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {roomType.conveniences.map((convenience) => {
                const IconComponent = getConvenienceIcon(convenience.icon);
                return (
                  <div
                    key={convenience.id}
                    className="flex items-center gap-3 p-4 rounded-xl bg-gray-50 hover:bg-emerald-50 transition-colors"
                    title={convenience.description}
                  >
                    <div className="shrink-0 w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                      <IconComponent className="h-5 w-5 text-emerald-600" />
                    </div>
                    <span className="text-gray-700 font-medium">
                      {convenience.name}
                    </span>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
