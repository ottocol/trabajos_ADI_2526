"use client";

import { useEffect, useState, useCallback } from "react";
import { motion } from "framer-motion";
import { User, Loader2, LogOut } from "lucide-react";
import { getUserProfile } from "@/lib/api/profile";
import { logoutUser } from "@/lib/api/auth";
import ProfileForm from "@/components/profile/ProfileForm";
import ChangePasswordForm from "@/components/profile/ChangePasswordForm";
import { Button } from "@/components/shared/button";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import type { UserProfileResponse } from "@/lib/types";

export const dynamic = "force-dynamic";

export default function ProfilePage() {
  const [profile, setProfile] = useState<UserProfileResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const fetchProfile = useCallback(async () => {
    try {
      const data = await getUserProfile();
      setProfile(data);
      setError(null);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Error al cargar el perfil"
      );
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  const handleLogout = async () => {
    try {
      await logoutUser();
      toast.success("Sesión cerrada correctamente");
      router.push("/");
    } catch {
      toast.error("Error al cerrar sesión");
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-emerald-600 mx-auto mb-4" />
          <p className="text-gray-500">Cargando perfil...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
            <User className="h-8 w-8 text-red-600" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">
            Error al cargar el perfil
          </h2>
          <p className="text-gray-500 mb-6">{error}</p>
          <Button variant="gradient" onClick={fetchProfile}>
            Intentar de nuevo
          </Button>
        </div>
      </div>
    );
  }

  if (!profile) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero section */}
      <div className="bg-linear-to-br from-emerald-600 via-emerald-500 to-teal-500 text-white">
        <div className="max-w-4xl mx-auto px-4 md:px-8 py-12 md:py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col md:flex-row items-center gap-6"
          >
            {/* Avatar */}
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center ring-4 ring-white/30">
              <span className="text-4xl md:text-5xl font-bold">
                {profile.firstName.charAt(0)}
                {profile.lastName.charAt(0)}
              </span>
            </div>

            {/* Info */}
            <div className="text-center md:text-left flex-1">
              <h1 className="text-3xl md:text-4xl font-bold mb-2">
                {profile.firstName} {profile.lastName}
              </h1>
              <p className="text-emerald-100 text-lg">{profile.email}</p>
            </div>

            {/* Logout button */}
            <Button
              variant="outline"
              onClick={handleLogout}
              className="bg-white/10 border-white/30 text-white hover:bg-white/20 hover:text-white"
            >
              <LogOut className="h-4 w-4" />
              Cerrar sesión
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 md:py-12">
        <div className="grid gap-8">
          {/* Profile form */}
          <ProfileForm profile={profile} onUpdate={fetchProfile} />

          {/* Change password form */}
          <ChangePasswordForm />
        </div>
      </div>
    </div>
  );
}
