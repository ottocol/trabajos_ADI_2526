/**
 * ESTRATEGIA: ISR (Incremental Static Regeneration)
 *
 * Esta página se genera estáticamente pero se revalida cada 60 segundos.
 * - Primera visita: sirve HTML cacheado (rápido como SSG)
 * - Después de 60s: la siguiente visita dispara regeneración en background
 * - El usuario actual ve versión cacheada, el siguiente ve la nueva
 *
 * Usamos `next: { revalidate: 60 }` en el fetch para configurar ISR.
 *
 * Verificación: Ejecutar `npm run build` y observar que esta página
 * aparece con el símbolo ○ (static) pero con revalidación configurada.
 * En runtime, modificar datos y verificar que se actualizan tras 60s.
 */

import { Suspense } from "react";
import RoomTypesListSkeleton from "@/components/shared/RoomTypesListSkeleton";
import CatalogRooms from "@/components/catalog/CatalogRooms";

export default function CatalogPage() {
  return (
    <div className="min-h-screen">
      <Suspense
        fallback={
          <RoomTypesListSkeleton
            title="Catálogo de Habitaciones"
            count={6}
            variant="default"
          />
        }
      >
        <CatalogRooms />
      </Suspense>
    </div>
  );
}
