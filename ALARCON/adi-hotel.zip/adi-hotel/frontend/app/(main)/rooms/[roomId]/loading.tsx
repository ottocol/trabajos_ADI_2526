import { Card, CardContent, CardHeader } from "@/components/shared/card";
import { Skeleton } from "@/components/shared/skeleton";

export default function Loading() {
  return (
    <div className="max-w-4xl px-6 md:px-8 py-6 md:py-8 mx-auto">
      {/* Image skeleton */}
      <Skeleton className="w-full aspect-5/2 rounded-xl mb-8" />

      {/* Details card skeleton */}
      <Card>
        <CardHeader>
          {/* Title */}
          <Skeleton className="h-9 w-2/3 mb-4" />

          {/* Capacity and view type */}
          <div className="flex items-center gap-4">
            <Skeleton className="h-5 w-32" />
            <Skeleton className="h-5 w-24" />
          </div>
        </CardHeader>

        <CardContent>
          {/* Description */}
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-4/5 mb-6" />

          <Skeleton className="h-6 w-32 mb-3" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Skeleton className="h-5 w-36" />
            <Skeleton className="h-5 w-28" />
            <Skeleton className="h-5 w-40" />
            <Skeleton className="h-5 w-32" />
            <Skeleton className="h-5 w-28" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
