"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/shared/card";
import { Button } from "@/components/shared/button";
import { useEffect } from "react";

export default function Error({
  error,
}: {
  error: Error & { digest?: string };
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="max-w-4xl px-6 md:px-8 py-6 md:py-8 mx-auto flex items-center justify-center min-h-[60vh]">
      <Card>
        <CardHeader>
          <CardTitle className="text-3xl mb-2">
            Habitación no disponible
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          <p className="text-gray-600">
            Lo sentimos, no hemos podido encontrar esta habitación.
            Puede que no exista o haya sido eliminada.
          </p>

          <Button onClick={() => window.history.back()} variant="gradient" className="cursor-pointer">
            Volver atrás
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
