/**
 * ESTRATEGIA: SSR (Server-Side Rendering) + Streaming
 *
 * Esta página se renderiza en el servidor en cada request.
 * Usamos fetch con cache: 'no-store' para garantizar datos frescos.
 * El loading.tsx proporciona un skeleton mientras se cargan los datos (Streaming).
 *
 * ¿Por qué SSR aquí?
 * - Necesitamos mostrar la DISPONIBILIDAD EN TIEMPO REAL
 * - Si alguien reserva, el siguiente usuario debe ver el cambio inmediatamente
 * - Evita situaciones de overbooking mostrando siempre datos actualizados
 *
 * Verificación: Ejecutar `npm run build` y observar que esta página
 * aparece con el símbolo λ (dynamic/server) en el output del build.
 */

import { RoomTypeWithAvailability } from "@/lib/types";
import { getRoomTypeById } from "@/lib/api/rooms";
import RoomTypeDetails from "@/components/room-types/RoomTypeDetails";

interface PageProps {
  params: Promise<{ roomId: string }>;
}

export default async function RoomTypePage({ params }: PageProps) {
  const { roomId } = await params;
  const roomType: RoomTypeWithAvailability = await getRoomTypeById(roomId);

  return <RoomTypeDetails roomType={roomType} />;
}
