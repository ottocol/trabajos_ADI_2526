"use client";

import { useEffect } from "react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("Error en catálogo:", error);
  }, [error]);

  return (
    <section className="px-4 py-16 md:py-24">
      <div className="mx-auto max-w-7xl text-center">
        <h2 className="mb-4 font-light text-2xl md:text-3xl">
          Error al cargar el catálogo
        </h2>
        <p className="mb-8 text-gray-600">
          No se pudieron cargar las habitaciones. Por favor, inténtalo de nuevo.
        </p>
        <button
          onClick={reset}
          className="rounded-md bg-gray-900 px-6 py-3 text-white transition-colors hover:bg-gray-800"
        >
          Reintentar
        </button>
      </div>
    </section>
  );
}
