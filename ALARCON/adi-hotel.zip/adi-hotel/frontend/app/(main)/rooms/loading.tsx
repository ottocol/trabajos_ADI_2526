import RoomTypesListSkeleton from "@/components/shared/RoomTypesListSkeleton";

export default function Loading() {
  return (
    <RoomTypesListSkeleton
      title="Catálogo de Habitaciones"
      count={6}
      variant="default"
    />
  );
}
