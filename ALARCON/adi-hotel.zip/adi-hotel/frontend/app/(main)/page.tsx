/**
 * ESTRATEGIA: SSG (Static Site Generation)
 *
 * Esta página se genera en build time y se sirve como HTML estático.
 * Usamos fetch con cache: 'force-cache' para garantizar que los datos
 * se obtienen una sola vez durante la compilación.
 *
 * Verificación: Ejecutar `npm run build` y observar que esta página
 * aparece con el símbolo ○ (static) en el output del build.
 */

import { Suspense } from "react";
import Hero from "@/components/home/Hero";
import Rooms from "@/components/home/Rooms";
import RoomTypesListSkeleton from "@/components/shared/RoomTypesListSkeleton";

export default function Home() {
  return (
    <>
      <Hero />
      <Suspense
        fallback={
          <RoomTypesListSkeleton
            title="Nuestras Habitaciones"
            count={3}
            variant="default"
          />
        }
      >
        <Rooms />
      </Suspense>
    </>
  );
}
