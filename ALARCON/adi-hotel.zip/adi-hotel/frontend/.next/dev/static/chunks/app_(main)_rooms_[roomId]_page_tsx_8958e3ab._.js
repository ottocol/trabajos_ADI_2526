(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_dcadd54a._.js",
  "static/chunks/_6d86ebb8._.js"
],
    source: "dynamic"
});
