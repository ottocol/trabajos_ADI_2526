(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_485b8a3b._.js",
  "static/chunks/_1cda71b1._.js"
],
    source: "dynamic"
});
