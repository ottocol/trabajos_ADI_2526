module.exports = [
"[project]/.next-internal/server/app/(main)/profile/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28main%29_profile_page_actions_7eed678b.js.map