module.exports = [
"[project]/.next-internal/server/app/(main)/rooms/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28main%29_rooms_page_actions_6dd00312.js.map