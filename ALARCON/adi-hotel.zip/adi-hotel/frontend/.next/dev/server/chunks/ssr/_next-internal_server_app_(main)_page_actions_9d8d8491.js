module.exports = [
"[project]/.next-internal/server/app/(main)/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28main%29_page_actions_9d8d8491.js.map