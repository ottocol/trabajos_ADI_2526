module.exports = [
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/(main)/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/(main)/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/(main)/rooms/error.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/(main)/rooms/error.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/(main)/rooms/loading.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/(main)/rooms/loading.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/(main)/rooms/[roomId]/error.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/(main)/rooms/[roomId]/error.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/(main)/rooms/[roomId]/loading.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/(main)/rooms/[roomId]/loading.tsx [app-rsc] (ecmascript)"));
}),
"[project]/lib/api.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "apiRequest",
    ()=>apiRequest
]);
// Use different URLs for server-side (Docker service name) vs client-side (localhost)
const getApiBaseUrl = ()=>("TURBOPACK compile-time truthy", 1) ? process.env.API_URL || ("TURBOPACK compile-time value", "http://localhost:8080/api") || "http://backend:8080/api" : "TURBOPACK unreachable";
async function apiRequest(endpoint, options = {}) {
    const { next, ...fetchOptions } = options;
    // Normalize headers to a Headers instance to avoid TS issues
    const merged = new Headers(fetchOptions.headers || {});
    if (!merged.has("Content-Type")) {
        merged.set("Content-Type", "application/json");
    }
    const config = {
        ...fetchOptions,
        headers: merged,
        credentials: ("TURBOPACK compile-time truthy", 1) ? undefined : "TURBOPACK unreachable"
    };
    // Add Next.js specific options (ISR revalidation)
    if (next) {
        config.next = next;
    }
    const response = await fetch(`${getApiBaseUrl()}${endpoint}`, config);
    // Handle non-JSON responses (like 204 No Content)
    if (response.status === 204) {
        return {};
    }
    const contentType = response.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");
    const data = isJson ? await response.json() : {};
    if (!response.ok) {
        const payload = data ?? {};
        const error = {
            message: payload.message || "An error occurred",
            status: response.status,
            errors: payload.errors
        };
        throw error;
    }
    return data;
}
}),
"[project]/lib/api/rooms.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAllRoomTypes",
    ()=>getAllRoomTypes,
    "getFeaturedRooms",
    ()=>getFeaturedRooms,
    "getRoomTypeById",
    ()=>getRoomTypeById
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-rsc] (ecmascript)");
;
async function getAllRoomTypes() {
    // ISR: Revalidar cada 60 segundos
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["apiRequest"])("/room-types", {
        method: "GET",
        next: {
            revalidate: 60
        }
    });
}
async function getFeaturedRooms() {
    // SSG: Cache permanente, se genera en build time
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["apiRequest"])("/room-types/top-booked", {
        method: "GET",
        cache: "force-cache"
    });
}
async function getRoomTypeById(roomTypeId) {
    // SSR: Sin caché, datos frescos en cada request
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["apiRequest"])(`/room-types/${roomTypeId}/availability`, {
        method: "GET",
        cache: "no-store"
    });
}
}),
"[project]/components/room-types/RoomTypeDetails.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/room-types/RoomTypeDetails.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/room-types/RoomTypeDetails.tsx <module evaluation>", "default");
}),
"[project]/components/room-types/RoomTypeDetails.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/room-types/RoomTypeDetails.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/room-types/RoomTypeDetails.tsx", "default");
}),
"[project]/components/room-types/RoomTypeDetails.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$room$2d$types$2f$RoomTypeDetails$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/room-types/RoomTypeDetails.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$room$2d$types$2f$RoomTypeDetails$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/room-types/RoomTypeDetails.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$room$2d$types$2f$RoomTypeDetails$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/app/(main)/rooms/[roomId]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * ESTRATEGIA: SSR (Server-Side Rendering) + Streaming
 *
 * Esta página se renderiza en el servidor en cada request.
 * Usamos fetch con cache: 'no-store' para garantizar datos frescos.
 * El loading.tsx proporciona un skeleton mientras se cargan los datos (Streaming).
 *
 * ¿Por qué SSR aquí?
 * - Necesitamos mostrar la DISPONIBILIDAD EN TIEMPO REAL
 * - Si alguien reserva, el siguiente usuario debe ver el cambio inmediatamente
 * - Evita situaciones de overbooking mostrando siempre datos actualizados
 *
 * Verificación: Ejecutar `npm run build` y observar que esta página
 * aparece con el símbolo λ (dynamic/server) en el output del build.
 */ __turbopack_context__.s([
    "default",
    ()=>RoomTypePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$rooms$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/rooms.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$room$2d$types$2f$RoomTypeDetails$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/room-types/RoomTypeDetails.tsx [app-rsc] (ecmascript)");
;
;
;
async function RoomTypePage({ params }) {
    const { roomId } = await params;
    const roomType = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$rooms$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getRoomTypeById"])(roomId);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$room$2d$types$2f$RoomTypeDetails$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        roomType: roomType
    }, void 0, false, {
        fileName: "[project]/app/(main)/rooms/[roomId]/page.tsx",
        lineNumber: 29,
        columnNumber: 10
    }, this);
}
}),
"[project]/app/(main)/rooms/[roomId]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/(main)/rooms/[roomId]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__eff6d57e._.js.map