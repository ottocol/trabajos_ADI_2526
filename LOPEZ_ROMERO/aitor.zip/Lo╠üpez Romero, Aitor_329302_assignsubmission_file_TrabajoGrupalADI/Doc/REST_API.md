# REST API - Documentación Técnica

## Descripción General

La implementación en `rest.js` es un servidor **REST API** basado en **Express.js** que expone múltiples endpoints para gestionar usuarios, posts y comentarios.

### Configuración Base
- **Framework**: Express.js
- **Puerto**: 3000
- **URL Base**: `http://localhost:3000`
- **Content-Type**: `application/json`

---

## Arquitectura y Estructura de Endpoints

### Principios REST Implementados

1. **Múltiples endpoints específicos** para cada recurso
2. **Métodos HTTP semánticos** (GET para lectura)
3. **URLs descriptivas** que representan recursos
4. **Códigos de estado HTTP** apropiados
5. **Paginación mediante query parameters**

### Árbol de Endpoints

```
├── /api/usuarios
│   ├── GET          → Todos los usuarios (paginado)
│   ├── /:id         → Usuario específico completo
│   ├── /:id/perfil  → Solo datos de perfil (sin posts)
│   ├── /:id/posts   → Todos los posts del usuario
│   ├── /:id/posts/paginated
│   │   └── GET      → Posts del usuario con paginación
│   ├── /:userId/posts/:postId
│   │   └── GET      → Post específico con autor
│   ├── /:userId/posts/:postId/comentarios
│   │   ├── GET      → Todos los comentarios del post
│   │   └── /:comentarioId
│   │       └── GET  → Comentario específico
│   └── /buscar/nombre
│       └── GET      → Búsqueda por nombre o bio
│
├── /api/estadisticas
│   └── GET          → Estadísticas generales del sistema
│
└── /api/usuarios/ranking/posts
    └── GET          → Ranking de usuarios por actividad
```

---

## Endpoints Detallados

### 1. **Usuarios - Listado General**

```javascript
GET /api/usuarios?limit=10&offset=0
```

**Parámetros Query:**
- `limit` (opcional): Número de registros por página (default: 10)
- `offset` (opcional): Posición inicial (default: 0)

**Respuesta:**
```json
{
  "total": 25,
  "limit": 10,
  "offset": 0,
  "data": [
    {
      "id": "1",
      "nombre": "Juan Pérez",
      "email": "juan@example.com",
      "avatar": "https://...",
      "bio": "Desarrollador...",
      "fechaRegistro": "2024-01-10"
    }
  ]
}
```

**Características:**
- Retorna datos paginados
- Solo incluye información básica del usuario
- No incluye posts ni comentarios (evita transferencia innecesaria)

---

### 2. **Usuario - Detalle Completo**

```javascript
GET /api/usuarios/:id
```

**Parámetros:**
- `id` (requerido): ID del usuario

**Respuesta:**
```json
{
  "id": "1",
  "nombre": "Juan Pérez",
  "email": "juan@example.com",
  "avatar": "https://...",
  "bio": "Desarrollador full-stack",
  "fechaRegistro": "2024-01-10",
  "posts": [
    {
      "id": "post1",
      "titulo": "Mi primer post",
      "contenido": "...",
      "likes": 15,
      "fechaCreacion": "2024-01-11",
      "comentarios": [...]
    }
  ]
}
```

**Nota:** Incluye TODOS los posts y comentarios (potencial overfetching)

---

### 3. **Perfil de Usuario (Sin Posts)**

```javascript
GET /api/usuarios/:id/perfil
```

**Respuesta:**
```json
{
  "id": "1",
  "nombre": "Juan Pérez",
  "email": "juan@example.com",
  "avatar": "https://...",
  "bio": "Desarrollador full-stack",
  "fechaRegistro": "2024-01-10"
}
```

**Razón de existencia:** Evitar overfetching cuando solo necesitas datos básicos

---

### 4. **Posts de Usuario**

```javascript
GET /api/usuarios/:id/posts
```

**Respuesta:**
```json
{
  "usuarioId": "1",
  "nombre": "Juan Pérez",
  "totalPosts": 8,
  "posts": [...]
}
```

---

### 5. **Posts Paginados**

```javascript
GET /api/usuarios/:id/posts/paginated?limit=5&offset=0
```

**Respuesta:**
```json
{
  "usuarioId": "1",
  "nombre": "Juan Pérez",
  "totalPosts": 8,
  "limit": 5,
  "offset": 0,
  "posts": [...]
}
```

---

### 6. **Post Específico**

```javascript
GET /api/usuarios/:userId/posts/:postId
```

**Respuesta:**
```json
{
  "usuarioId": "1",
  "usuarioNombre": "Juan Pérez",
  "post": {
    "id": "post1",
    "titulo": "Mi primer post",
    "contenido": "...",
    "likes": 15,
    "fechaCreacion": "2024-01-11",
    "comentarios": [...]
  }
}
```

---

### 7. **Comentarios de un Post**

```javascript
GET /api/usuarios/:userId/posts/:postId/comentarios
```

**Respuesta:**
```json
{
  "postId": "post1",
  "postTitulo": "Mi primer post",
  "totalComentarios": 3,
  "comentarios": [
    {
      "id": "1",
      "texto": "Excelente post!",
      "autor": "María García",
      "fechaCreacion": "2024-01-12"
    }
  ]
}
```

---

### 8. **Comentario Específico**

```javascript
GET /api/usuarios/:userId/posts/:postId/comentarios/:comentarioId
```

**Respuesta:**
```json
{
  "usuarioId": "1",
  "postId": "post1",
  "comentario": {
    "id": "1",
    "texto": "Excelente post!",
    "autor": "María García",
    "fechaCreacion": "2024-01-12"
  }
}
```

---

### 9. **Búsqueda por Nombre**

```javascript
GET /api/usuarios/buscar/nombre?q=juan
```

**Parámetros:**
- `q` (requerido): Término de búsqueda

**Búsqueda en:**
- Campo `nombre`
- Campo `bio`

**Respuesta:**
```json
{
  "query": "juan",
  "resultados": 2,
  "data": [...]
}
```

---

### 10. **Estadísticas Generales**

```javascript
GET /api/estadisticas
```

**Respuesta:**
```json
{
  "totalUsuarios": 25,
  "totalPosts": 145,
  "totalComentarios": 487,
  "totalLikes": 2341,
  "promedioPostsPorUsuario": "5.80"
}
```

**Cálculos realizados:**
- Suma de todos los usuarios
- Suma de todos los posts en el sistema
- Suma de todos los comentarios
- Suma de todos los likes
- Promedio de posts por usuario

---

### 11. **Ranking de Usuarios**

```javascript
GET /api/usuarios/ranking/posts
```

**Respuesta:**
```json
{
  "ranking": [
    {
      "id": "1",
      "nombre": "Juan Pérez",
      "totalPosts": 12,
      "totalLikes": 287
    },
    {
      "id": "2",
      "nombre": "María García",
      "totalPosts": 8,
      "totalLikes": 156
    }
  ]
}
```

**Ordenamiento:** Por cantidad de posts (descendente)

---

## Manejo de Errores

### Códigos de Estado HTTP

| Código  | Significado                        | Ejemplo 
|---------|------------------------------------|-----------------------------
| **200** | OK - Recurso encontrado            | Usuario existe 
| **400** | Bad Request - Parámetros inválidos | Falta parámetro requerido 
| **404** | Not Found - Recurso no existe      | Usuario no encontrado 

### Estructura de Errores

```javascript
{
  "error": "Usuario no encontrado"
}
```

### Ejemplos de Errores

```javascript
// Error 404 - Usuario no existe
GET /api/usuarios/999
→ 404 { "error": "Usuario no encontrado" }

// Error 400 - Parámetro requerido
GET /api/usuarios/buscar/nombre  (sin parámetro q)
→ 400 { "error": "Parámetro de búsqueda requerido" }

// Error 404 - Endpoint inexistente
GET /api/inexistente
→ 404 { "error": "Endpoint no encontrado" }
```

---

## Paginación

### Implementación

```javascript
const limit = parseInt(req.query.limit) || 10;    // Default: 10
const offset = parseInt(req.query.offset) || 0;   // Default: 0

const datosPaginados = datos.slice(offset, offset + limit);
```

### Uso

```
GET /api/usuarios?limit=5&offset=10
     ↓
Retorna registros 10-14 (5 registros a partir del offset 10)

GET /api/usuarios?limit=5&offset=15
     ↓
Retorna registros 15-19
```

### Respuesta Paginada

```json
{
  "total": 100,           // Total de registros en BD
  "limit": 5,             // Registros solicitados
  "offset": 10,           // Posición inicial
  "data": [...]           // Datos paginados
}
```

---

## Búsqueda y Filtrado

### Búsqueda por Nombre

```javascript
GET /api/usuarios/buscar/nombre?q=juan

// Busca en:
// - usuario.nombre.toLowerCase().includes(q)
// - usuario.bio.toLowerCase().includes(q)
```

### Característica de Búsqueda

- **Case-insensitive** (mayúsculas/minúsculas)
- Búsqueda **substring** (no necesita coincidencia exacta)
- Búsqueda **en múltiples campos** (nombre y bio)

---

## Cálculos y Agregaciones

### Estadísticas

```javascript
app.get('/api/estadisticas', (req, res) => {
  const totalUsuarios = usuarios.length;
  
  const totalPosts = usuarios.reduce(
    (sum, u) => sum + u.posts.length, 0
  );
  
  const totalComentarios = usuarios.reduce(
    (sum, u) => sum + u.posts.reduce(
      (postSum, p) => postSum + p.comentarios.length, 0
    ), 0
  );
  
  const totalLikes = usuarios.reduce(
    (sum, u) => sum + u.posts.reduce(
      (postSum, p) => postSum + p.likes, 0
    ), 0
  );
  
  const promedio = (totalPosts / totalUsuarios).toFixed(2);
});
```

### Ranking

```javascript
const ranking = usuarios
  .map(u => ({
    id: u.id,
    nombre: u.nombre,
    totalPosts: u.posts.length,
    totalLikes: u.posts.reduce((sum, p) => sum + p.likes, 0)
  }))
  .sort((a, b) => b.totalPosts - a.totalPosts);
```

---

## Problemas Inherentes de REST

### 1. Overfetching

Cuando obtienes un usuario, recibes TODOS sus datos:

```javascript
GET /api/usuarios/1
→ id, nombre, email, avatar, bio, fechaRegistro, posts[], comentarios[]

// Pero si solo necesitas el nombre y email... ¡recibiste más de lo necesario!
```

**Solución en REST:** Crear endpoints específicos como `/perfil`

---

### 2. Underfetching

Para obtener usuario + posts + comentarios, necesitas **3 requests**:

```javascript
1. GET /api/usuarios/1              → Usuario
2. GET /api/usuarios/1/posts        → Posts
3. GET /api/usuarios/1/posts/1/comentarios → Comentarios
```

**Problema:** Latencia acumulada de múltiples viajes de red

---

### 3. Proliferación de Endpoints

Para cada variación de datos necesitas un endpoint nuevo:

```javascript
GET /api/usuarios                   // Básico
GET /api/usuarios/:id               // Completo
GET /api/usuarios/:id/perfil        // Sin posts
GET /api/usuarios/:id/posts         // Solo posts
GET /api/usuarios/:id/posts/paginated  // Posts con paginación
// ... más endpoints
```

**Resultado:** API con docenas de endpoints para el mismo recurso

---

## Ventajas de REST

**Caching HTTP nativo** - Los navegadores entienden GET/POST/PUT/DELETE  
**Simplicidad** - Fácil de entender y documentar  
**Herramientas estándar** - Postman, curl, navegadores web  
**Escalabilidad** - Ampliamente usado y documentado  
**Métodos semánticos** - GET/POST/PUT/DELETE tienen significado claro

---

## Conclusión

REST es una arquitectura **bien establecida y predecible** que funciona bien para APIs simples y bien definidas. Sin embargo, en aplicaciones complejas con múltiples tipos de clientes y datos altamente relacionados, sus limitaciones (overfetching, underfetching, proliferación de endpoints) se hacen evidentes.
