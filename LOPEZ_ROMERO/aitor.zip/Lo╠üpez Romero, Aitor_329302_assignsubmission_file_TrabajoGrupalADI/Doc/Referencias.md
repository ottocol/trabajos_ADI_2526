## Bibliografía

https://www.ibm.com/es-es/think/topics/graphql-vs-rest-api
https://aws.amazon.com/es/compare/the-difference-between-graphql-and-rest/


Páginas de las que se han sacado menos recursos (principalmente elementos visuales):

https://davidwalsh.name/getting-started-with-graphql
https://medium.com/@manraj.saini123/what-is-rest-api-f8e4eb941351


## Uso de IA

Principalmente se ha utilizado la IA para completar código empezado con más casos y de tal manera ampliar el alcance del programa. También se ha usado para limpiar nuestra documentación. A continuación se muestran algunas de las interacciones con Copilot en Visual Studio Code:

"Genera un ejemplo sencillo de una API GraphQL e javascript"

La respuesta a esto fue un código simple que ayudó con el entendimiento de cómo funciona GraphQL para poder expandir y aplicar a nuestro caso.

"Por favor amplía un poco estos archivos para que su funcionamiento sea más completo y con una mayor cantidad de datos y opciones. Crea además un documento en el que expliques los cambios que has hecho en una carpeta Doc."

La respuesta a esto fueron varios endpoints añadidos a Rest y lo correspondiente en GraphQL para reflejarlo, seguido de un documento que simplemente explicaba los cambios que Copilot realizó, para mayor facilidad de entendimiento y alteración de aspectos que no nos agradaran.

"Completa el código de CompareApis con todas las peticiones que veas relevantes. Puedes consultar el documento de comparativa para algunas peticiones específicas. El objetivo es tener una buena cantidad de peticiones diferentes y que ninguna de ellas sea irrelevante para la comparación entre los modelos, mostrando tanto peticiones correctas como con errores, para mostrar todo tipo de diferencias."

La respuesta a esto fue rellenar el deslpegable con varias opciones más, algunas de las cuales eran innecesarias o estaban mal, cosa que se arregló posteriormente, como un caso en el que se pedía el usuario, los posts y los comentarios como si esto implicara más de una solicitud en REST, a pesar de que el endpoint de usuario de REST ya da todos esos datos.