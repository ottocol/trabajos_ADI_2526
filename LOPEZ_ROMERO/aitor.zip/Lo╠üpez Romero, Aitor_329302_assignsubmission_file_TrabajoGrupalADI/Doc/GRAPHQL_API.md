# GraphQL API - Documentación Técnica

## Descripción General

La implementación en `graphql.js` es un servidor **GraphQL API** basado en **Express.js** que proporciona un **único endpoint** con un schema fuertemente tipado y auto-documentado.

### Configuración Base
- **Framework**: Express.js + express-graphql
- **Puerto**: 4000
- **Endpoint**: `http://localhost:4000/graphql`
- **GraphiQL IDE**: `http://localhost:4000/graphql` (interfaz interactiva)
- **Método HTTP**: POST (exclusivamente)

---

## Arquitectura y Estructura

### Principios GraphQL Implementados

1. **Un único endpoint** para todas las operaciones
2. **Schema fuertemente tipado** con definición clara
3. **Cliente especifica qué datos necesita** (evita overfetching)
4. **Una sola query para obtener datos relacionados** (evita underfetching)
5. **Introspección automática** del schema
6. **Queries y Mutations** claramente separadas

### Estructura del Schema

```
query {
  ├── usuario(id: ID!): Usuario
  ├── usuarios(limit: Int = 10, offset: Int = 0): [Usuario!]!
  ├── post(usuarioId: ID!, postId: ID!): PostConAutor
  ├── buscarUsuarios(q: String!): ResultadoBusqueda
  ├── estadisticas: Estadisticas!
  ├── usuarioMasActivo: Usuario!
  └── topUsuarios(limit: Int = 5): [Usuario!]!
}

mutation {
  └── agregarComentario(
        usuarioId: ID!,
        postId: ID!,
        texto: String!,
        autor: String!
      ): Post
}
```

---

## Tipos Definidos

### Tipo: `Comentario`

```graphql
type Comentario {
  id: ID!
  texto: String!
  autor: String!
  fechaCreacion: String!
}
```

**Campos:**
- `id`: Identificador único (requerido)
- `texto`: Contenido del comentario (requerido)
- `autor`: Nombre del autor (requerido)
- `fechaCreacion`: Fecha en formato ISO (requerido)

---

### Tipo: `Post`

```graphql
type Post {
  id: ID!
  titulo: String!
  contenido: String!
  likes: Int!
  fechaCreacion: String!
  comentarios: [Comentario!]!
}
```

**Campos:**
- `id`: Identificador único (requerido)
- `titulo`: Título del post (requerido)
- `contenido`: Cuerpo del post (requerido)
- `likes`: Número de likes (requerido)
- `fechaCreacion`: Fecha en formato ISO (requerido)
- `comentarios`: Array de comentarios (requerido, nunca nulo)

---

### Tipo: `Usuario`

```graphql
type Usuario {
  id: ID!
  nombre: String!
  email: String!
  avatar: String!
  bio: String!
  fechaRegistro: String!
  posts: [Post!]!
  totalPosts: Int!
  totalLikes: Int!
}
```

**Campos:**
- `id`: Identificador único (requerido)
- `nombre`: Nombre del usuario (requerido)
- `email`: Email del usuario (requerido)
- `avatar`: URL del avatar (requerido)
- `bio`: Biografía del usuario (requerido)
- `fechaRegistro`: Fecha de registro (requerido)
- `posts`: Array de posts del usuario (requerido)
- `totalPosts`: Contador de posts (calculado)
- `totalLikes`: Suma total de likes en todos los posts (calculado)

---

### Tipo: `PostConAutor`

```graphql
type PostConAutor {
  id: ID!
  titulo: String!
  contenido: String!
  likes: Int!
  fechaCreacion: String!
  autor: Usuario!
  comentarios: [Comentario!]!
}
```

**Diferencia con `Post`:**
- Incluye el objeto `Usuario` completo como `autor`
- Permite obtener información del autor sin request adicional

---

### Tipo: `Estadisticas`

```graphql
type Estadisticas {
  totalUsuarios: Int!
  totalPosts: Int!
  totalComentarios: Int!
  totalLikes: Int!
  usuarioMasActivo: Usuario!
  postMasPopular: PostConAutor!
}
```

**Datos retornados:**
- Contadores agregados
- Usuario con mayor número de posts
- Post con más likes

---

### Tipo: `ResultadoBusqueda`

```graphql
type ResultadoBusqueda {
  query: String!
  resultados: Int!
  usuarios: [Usuario!]!
}
```

**Estructura:**
- `query`: Término de búsqueda usado
- `resultados`: Número de coincidencias
- `usuarios`: Array con usuarios encontrados

---

## Queries (Lectura de Datos)

### Query: `usuario`

```graphql
query {
  usuario(id: "1") {
    id
    nombre
    email
    posts {
      titulo
      likes
    }
  }
}
```

**Parámetros:**
- `id: ID!` (requerido)

**Característica:** El cliente selecciona SOLO los campos necesarios

---

### Query: `usuarios`

```graphql
query {
  usuarios(limit: 10, offset: 0) {
    id
    nombre
    email
  }
}
```

**Parámetros:**
- `limit: Int = 10` (opcional, default 10)
- `offset: Int = 0` (opcional, default 0)

**Ventaja:** Paginación integrada en el schema con valores por defecto

---

### Query: `post`

```graphql
query {
  post(usuarioId: "1", postId: "post1") {
    titulo
    contenido
    likes
    autor {
      nombre
      email
    }
    comentarios {
      texto
      autor
    }
  }
}
```

**Parámetros:**
- `usuarioId: ID!` (requerido)
- `postId: ID!` (requerido)

**Retorna:** `PostConAutor` (incluye el autor completo)

---

### Query: `buscarUsuarios`

```graphql
query {
  buscarUsuarios(q: "juan") {
    query
    resultados
    usuarios {
      id
      nombre
      bio
    }
  }
}
```

**Parámetros:**
- `q: String!` (requerido)

**Busca en:**
- Campo `nombre`
- Campo `bio`
- Campo `email`

---

### Query: `estadisticas`

```graphql
query {
  estadisticas {
    totalUsuarios
    totalPosts
    totalComentarios
    totalLikes
    usuarioMasActivo {
      nombre
      totalPosts
    }
    postMasPopular {
      titulo
      likes
      autor {
        nombre
      }
    }
  }
}
```

**Sin parámetros**

**Retorna:**
- Contadores del sistema
- Usuario más activo con detalles
- Post más popular con autor

---

### Query: `usuarioMasActivo`

```graphql
query {
  usuarioMasActivo {
    nombre
    totalPosts
    totalLikes
  }
}
```

**Resultado:** Usuario con mayor número de posts

---

### Query: `topUsuarios`

```graphql
query {
  topUsuarios(limit: 5) {
    id
    nombre
    totalLikes
    posts {
      titulo
    }
  }
}
```

**Parámetros:**
- `limit: Int = 5` (opcional)

**Ordenamiento:** Por total de likes (descendente)

---

## Mutations (Modificación de Datos)

### Mutation: `agregarComentario`

```graphql
mutation {
  agregarComentario(
    usuarioId: "1"
    postId: "post1"
    texto: "Excelente post!"
    autor: "María García"
  ) {
    id
    titulo
    comentarios {
      id
      texto
      autor
      fechaCreacion
    }
  }
}
```

**Parámetros:**
- `usuarioId: ID!` (requerido)
- `postId: ID!` (requerido)
- `texto: String!` (requerido)
- `autor: String!` (requerido)

**Retorna:** El post actualizado con todos sus comentarios

**Lógica:**
```javascript
1. Encuentra el usuario
2. Encuentra el post en ese usuario
3. Crea un nuevo comentario con ID auto-generado
4. Añade la fecha actual (ISO format)
5. Inserta el comentario en el array
6. Retorna el post actualizado
```

---

## Validación y Tipado

### Tipado Fuerte del Schema

```graphql
type Usuario {
  id: ID!              // ← ! = Requerido, nunca nulo
  nombre: String!      // ← String requerido
  posts: [Post!]!      // ← Array requerido con elementos no-nulos
}

type Query {
  usuario(id: ID!): Usuario  // ← Parámetro requerido, retorna Usuario
  usuarios(limit: Int = 10): [Usuario!]!  // ← Con default
}
```

### Validación Automática

GraphQL valida automáticamente:
- Tipos de parámetros
- Campos requeridos vs opcionales
- Estructura de la query
- Existencia de campos
- Valores por defecto

**Ejemplo de error validado:**
```graphql
query {
  usuario(id: 123)  # ← Error: ID! espera String, recibe Int
}
```

---

## Manejo de Errores

### Estructura de Respuesta

**Caso exitoso:**
```json
{
  "data": {
    "usuario": {
      "id": "1",
      "nombre": "Juan Pérez"
    }
  }
}
```

**Caso con error:**
```json
{
  "data": null,
  "errors": [
    {
      "message": "Usuario no encontrado",
      "locations": [{"line": 2, "column": 3}],
      "path": ["usuario"]
    }
  ]
}
```

**Nota:** GraphQL siempre retorna **HTTP 200**, los errores van en el body

### Manejo de Nulls

```javascript
usuario: ({ id }) => {
  const usuario = usuarios.find(u => u.id === id);
  return usuario ? enriquecerUsuario(usuario) : null;
  // ↑ Retorna null si no existe (válido en GraphQL)
}
```

---

## Cálculos Incorporados

### Enriquecimiento de Usuario

```javascript
function enriquecerUsuario(usuario) {
  return {
    ...usuario,
    totalPosts: usuario.posts.length,
    totalLikes: usuario.posts.reduce((sum, p) => sum + p.likes, 0)
  };
}
```

**Calcula automáticamente:**
- `totalPosts`: Cuenta de posts del usuario
- `totalLikes`: Suma total de likes en todos sus posts

**Ventaja:** Los campos calculados están disponibles en cualquier query que use `Usuario`

---

## GraphiQL IDE

### Acceso

```
http://localhost:4000/graphql
```

### Características

- **Autocompletado** de queries y campos
- **Documentación automática** del schema
- **Validación en tiempo real** mientras escribes
- **Historial** de queries ejecutadas
- **Variables** para parametrizar queries

### Ejemplo en GraphiQL

```graphql
# Variables
{
  "usuarioId": "1",
  "limite": 5
}

# Query
query ObtenerDatos($usuarioId: ID!, $limite: Int!) {
  usuario(id: $usuarioId) {
    nombre
    posts(limit: $limite) {
      titulo
    }
  }
}
```

---

## Ventajas de GraphQL

**Un único endpoint** - Simplicidad de deploy y routing  
**Sin overfetching** - El cliente pide exactamente qué necesita  
**Sin underfetching** - Una query obtiene datos relacionados  
**Tipado fuerte** - Validación automática  
**Introspección automática** - Cliente descubre capacidades  
**Desarrollo eficiente** - GraphiQL para pruebas interactivas  
**Flexible** - Mismo schema para múltiples clientes con necesidades diferentes  

---

## Limitaciones de GraphQL

**Caching HTTP más complejo** - POST no es cacheable por defecto  
**Curva de aprendizaje** - Más complejo que REST  
**Over-querying posible** - Sin límites, cliente puede hacer queries costosas  
**Monitoreo diferente** - No usa códigos HTTP para errores  

---

## Conclusión

GraphQL es una **arquitectura moderna y flexible** que brilla en aplicaciones complejas con múltiples clientes. Su tipado fuerte, validación automática e introspección la hacen ideal para desarrollo ágil. Sin embargo, requiere mayor complejidad en el servidor y un cambio de mentalidad en el cliente.
