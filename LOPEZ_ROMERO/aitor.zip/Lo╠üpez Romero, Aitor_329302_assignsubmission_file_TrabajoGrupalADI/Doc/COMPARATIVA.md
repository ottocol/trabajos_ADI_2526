# REST vs GraphQL - Análisis Comparativo

## 📊 Resumen Ejecutivo

| Aspecto                      | REST                      | GraphQL 
|------------------------------|---------------------------|-------------------------
| **Endpoints**                | Múltiples (11+)           | Un único `/graphql` 
| **Patrón**                   | Múltiples URLs/métodos    | Un URL, queries/mutations 
| **Overfetching**             | Común                     | Evitado 
| **Underfetching**            | Múltiples requests        | Una request 
| **Tipado**                   | No garantizado            | Fuertemente tipado 
| **Validación**               | Manual en cada endpoint   | Automática 
| **Complejidad servidor**     | Simple                    | Moderada 
| **Complejidad cliente**      | Simple                    | Moderada 
| **Caching HTTP**             | Nativo                    | Requerida configuración 
| **Documentación**            | Manual (OpenAPI/Swagger)  | Automática (Introspección) 
| **Aprendizaje**              | Fácil                     | Curva de aprendizaje 
| **Escalabilidad**            | Bien para APIs simples    | Mejor para APIs complejas 

---

## Arquitectura

### REST: Enfoque de Recursos y URLs

```
Usuario 1
    ├── GET /api/usuarios/1                    ← Detalles
    ├── GET /api/usuarios/1/perfil             ← Solo perfil
    ├── GET /api/usuarios/1/posts              ← Posts
    ├── GET /api/usuarios/1/posts/paginated    ← Posts pagados
    └── GET /api/usuarios/1/posts/1            ← Post específico
        └── GET /api/usuarios/1/posts/1/comentarios
```

**Modelo:** Jerárquico basado en URLs

### GraphQL: Enfoque de Schema y Resolvers

```
/graphql (POST)
    ├── Query
    │   ├── usuario(id: ID!)
    │   ├── usuarios(limit, offset)
    │   ├── post(usuarioId, postId)
    │   ├── buscarUsuarios(q)
    │   └── ...
    └── Mutation
        └── agregarComentario(...)
```

**Modelo:** Plano basado en schema tipado

---

## Comparación de Operaciones Comunes

### 1. Obtener Usuario + Posts + Comentarios

#### REST: 3 Requests

```bash
# Request 1: Obtener usuario
GET /api/usuarios/1
Response: Usuario completo + TODOS los posts + comentarios

# Request 2: Posts con paginación
GET /api/usuarios/1/posts/paginated?limit=5&offset=0
Response: Primeros 5 posts

# Request 3: Comentarios de un post
GET /api/usuarios/1/posts/post1/comentarios
Response: Todos los comentarios
```

**Problema:** 3 viajes de red, múltiples datos innecesarios

#### GraphQL: 1 Request

```graphql
query {
  usuario(id: "1") {
    nombre
    email
    posts(limit: 5) {
      titulo
      comentarios {
        texto
        autor
      }
    }
  }
}
```

**Ventaja:** Un viaje de red, datos exactos solicitados

---

### 2. Obtener Solo Nombre del Usuario

#### REST: Overfetching

```bash
GET /api/usuarios/1
Response: {
  id, nombre, email, avatar, bio, fechaRegistro,
  posts: [ ... ],
  ...más datos innecesarios
}
```

**Desperdicio:** Recibes 10 campos + posts cuando necesitas solo nombre

#### GraphQL: Preciso

```graphql
query {
  usuario(id: "1") {
    nombre
  }
}
```

**Eficiente:** Solo el campo solicitado

---

### 3. Obtener Datos Relacionados en Múltiples Niveles

#### REST: Underfetching

```bash
# Para obtener usuario + posts + comentarios + autor de cada comentario:

1. GET /api/usuarios/1
2. GET /api/usuarios/1/posts
3. Para cada post: GET /api/usuarios/1/posts/{id}/comentarios
4. Para cada comentario: ¿Necesitas autor? POST adicional...

Total: 3+ requests, N requests por post
```

#### GraphQL: Una Query

```graphql
query {
  usuario(id: "1") {
    nombre
    posts {
      titulo
      comentarios {
        texto
        autor
        # Acceso directo a autor anidado
      }
    }
  }
}
```

**Eficiente:** Todo en una query, sin requests adicionales

---

## Problemas de REST Evidentes

### 1. **Proliferación de Endpoints**

En la implementación REST actual:

```
GET /api/usuarios                      (listado)
GET /api/usuarios/:id                  (detalle)
GET /api/usuarios/:id/perfil           (solo perfil)
GET /api/usuarios/:id/posts            (todos los posts)
GET /api/usuarios/:id/posts/paginated  (posts paginados)
GET /api/usuarios/:userId/posts/:postId (post específico)
GET /api/usuarios/:userId/posts/:postId/comentarios (comentarios)
GET /api/usuarios/:userId/posts/:postId/comentarios/:comentarioId (comentario)
GET /api/usuarios/buscar/nombre        (búsqueda)
GET /api/estadisticas                  (estadísticas)
GET /api/usuarios/ranking/posts        (ranking)
```

**Total: 11 endpoints para un dominio simple (usuario-posts-comentarios)**

### 2. **Overfetching Común**

```javascript
// Cliente solo necesita:
GET /api/usuarios
→ { id, nombre }

// Pero recibe:
{
  id, nombre, email, avatar, bio, fechaRegistro,
  posts: [ { id, titulo, contenido, likes, fechaCreacion, comentarios: [...] } ]
}
```

**Impacto:**
- Mayor consumo de ancho de banda
- Mayor latencia
- Más datos almacenados en caché del cliente

### 3. **Underfetching Frecuente**

Para un dashboard que necesite:
- Usuario actual
- Sus 5 últimos posts
- Comentarios de cada post
- Autor de cada comentario

REST requiere:
```
1 + 1 + 5 + (desconocido) = Mínimo 7+ requests
```

GraphQL requiere:
```
1 request
```

---

## Ventajas de GraphQL en Acción

### 1. **Un Único Endpoint**

```javascript
// Todo pasa por:
POST http://localhost:4000/graphql

// Mismo endpoint para:
- Lectura de usuario
- Lectura de posts
- Crear comentarios
- Buscar usuarios
- Obtener estadísticas
```

### 2. **Validación Automática**

GraphQL detecta automáticamente:

```graphql
# Tipo incorrecto
query {
  usuario(id: 123)  ← Error: ID! espera String, no Int
}

# Campo inexistente
query {
  usuario(id: "1") {
    nombreCompleto  ← Error: Campo no existe en Usuario
  }
}

# Parámetro requerido
query {
  buscarUsuarios {  ← Error: Parámetro 'q' es requerido
    usuarios { nombre }
  }
}
```

REST no valida automáticamente - depende de cada endpoint

### 3. **Documentación Automática**

GraphQL ofrece **introspección**:

```graphql
# Descubrir qué campos tiene Usuario
query {
  __type(name: "Usuario") {
    name
    fields {
      name
      type { name kind }
    }
  }
}
```

REST requiere:
- Documentación manual (OpenAPI/Swagger)
- Mantenimiento por separado
- Puede desincronizarse del código

## Casos de Uso

### REST es más apropiado cuando:

**Datos principalmente estáticos**
- Catálogos de productos
- Documentos inmutables
- Datos de referencia

**Múltiples clientes con necesidades similares**
- Aplicaciones CRUD simples
- APIs públicas estándar

**Simplicidad**
- Prototipados rápidos
- Equipos pequeños
- Presupuesto limitado

### GraphQL es más apropiado cuando:

**Múltiples clientes con necesidades diferentes**
- Web (desktop)
- Mobile (diferentes pantallas)
- Smartwatch (datos mínimos)

**Datos altamente relacionados**
- Redes sociales (usuario → posts → comentarios)
- E-commerce (producto → reviews → usuarios)
- Aplicaciones complejas

**Cambios frecuentes de requisitos**
- Startups iterando rápido
- Desarrollo ágil
- Productos en evolución

---

## Implementación: Comparación Técnica

### Servidor REST

```javascript
const express = require('express');
const app = express();

// Cada variación requiere un endpoint nuevo
app.get('/api/usuarios', (req, res) => {
  // Lógica de listado
});

app.get('/api/usuarios/:id', (req, res) => {
  // Lógica de detalle
});

app.get('/api/usuarios/:id/perfil', (req, res) => {
  // Lógica de perfil
});

// ... más endpoints
```

**Escalabilidad:** Lineal con número de variaciones

### Servidor GraphQL

```javascript
const schema = buildSchema(`
  type Query {
    usuario(id: ID!): Usuario
    usuarios(limit: Int, offset: Int): [Usuario!]!
    post(usuarioId: ID!, postId: ID!): PostConAutor
    buscarUsuarios(q: String!): ResultadoBusqueda
    estadisticas: Estadisticas!
  }
`);

const root = {
  usuario: ({ id }) => { /* lógica */ },
  usuarios: ({ limit, offset }) => { /* lógica */ },
  post: ({ usuarioId, postId }) => { /* lógica */ },
  buscarUsuarios: ({ q }) => { /* lógica */ },
  estadisticas: () => { /* lógica */ }
};
```

**Escalabilidad:** Logarítmica - agregar un campo a GraphQL es trivial

---

## Seguridad y Validación

### REST: Validación Manual

```javascript
app.get('/api/usuarios/buscar/nombre', (req, res) => {
  const q = req.query.q?.toLowerCase();
  if (!q) {  // ← Validación manual
    return res.status(400).json({ error: 'Parámetro requerido' });
  }
  
  // Validación de permisos manual
  if (!usuarioEstaAutenticado(req)) {
    return res.status(401).json({ error: 'No autorizado' });
  }
  // ... más validación
});
```

### GraphQL: Validación Automática

```graphql
type Query {
  buscarUsuarios(q: String!): ResultadoBusqueda
  # ↑ El ! indica que q es requerido
  # GraphQL rechaza automáticamente queries sin q
}
```

**Ventaja:** Menos código, menos errores

---

## Escalabilidad del Código

### REST: Escala con Endpoints

```
Endpoints: 5 → 10 → 20 → 50 → 100
LOC por endpoint: ~20-50
Total LOC: 100 → 500 → 1000 → 2500 → 5000
```

### GraphQL: Escala con Resolvers

```
Resolvers: 5 → 10 → 20 → 50 → 100
LOC por resolver: ~10-30 (más simple)
Total LOC: 50 → 300 → 600 → 1500 → 3000
```

**GraphQL es más escalable en código**

---

## Curva de Aprendizaje

### REST

- **Fácil de aprender**
- Métodos HTTP: GET, POST, PUT, DELETE
- URLs predictibles
- Ideal para principiantes

### GraphQL

- **Curva moderada**
- Conceptos nuevos: Schema, Queries, Mutations
- Resolvers y data loaders
- Requiere cambio de mentalidad
- Compensa a largo plazo

---

## Conclusión

### Elige REST para:
- Datos principalmente estáticos o simples
- Clientes con necesidades similares
- Equipo prefiere simplicidad

### Elige GraphQL para:
- Datos altamente relacionados y complejos
- Múltiples clientes con necesidades diferentes
- Ancho de banda es limitado
- Desarrollo rápido e iterativo

Ambas arquitecturas son válidas y la "mejor" depende de los requisitos específicos del proyecto y el equipo.
