/**
 * SERVIDOR GraphQL vs REST
 * 
 * Este archivo implementa una API GraphQL que demuestra cómo diffiere de REST:
 * 
 * VENTAJAS DE GraphQL SOBRE REST:
 * - Un único endpoint (/graphql) en lugar de múltiples rutas
 * - El cliente especifica exactamente qué datos necesita (evita overfetching)
 * - Evita underfetching: una sola query puede obtener datos relacionados
 * - Introspección automática del schema
 * - Validación incorporada en el schema
 * - Queries y Mutations claramente separadas
 * 
 * EN REST: múltiples endpoints como GET /usuarios, GET /usuarios/:id/posts, etc.
 * EN GraphQL: todo pasa por POST /graphql con una query que describe qué se necesita
 */

const express = require('express');
const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');
const { usuarios } = require('../Data/data');

const schema = buildSchema(`
  type Comentario {
    id: ID!
    texto: String!
    autor: String!
    fechaCreacion: String!
  }

  type Post {
    id: ID!
    titulo: String!
    contenido: String!
    likes: Int!
    fechaCreacion: String!
    comentarios: [Comentario!]!
  }

  type Usuario {
    id: ID!
    nombre: String!
    email: String!
    avatar: String!
    bio: String!
    fechaRegistro: String!
    posts: [Post!]!
    totalPosts: Int!
    totalLikes: Int!
  }

  type PostConAutor {
    id: ID!
    titulo: String!
    contenido: String!
    likes: Int!
    fechaCreacion: String!
    autor: Usuario!
    comentarios: [Comentario!]!
  }

  type Estadisticas {
    totalUsuarios: Int!
    totalPosts: Int!
    totalComentarios: Int!
    totalLikes: Int!
    usuarioMasActivo: Usuario!
    postMasPopular: PostConAutor!
  }

  type ResultadoBusqueda {
    query: String!
    resultados: Int!
    usuarios: [Usuario!]!
  }

  type Query {
    usuario(id: ID!): Usuario
    usuarios(limit: Int = 10, offset: Int = 0): [Usuario!]!
    post(usuarioId: ID!, postId: ID!): PostConAutor
    buscarUsuarios(q: String!): ResultadoBusqueda
    estadisticas: Estadisticas!
    usuarioMasActivo: Usuario!
    topUsuarios(limit: Int = 5): [Usuario!]!
  }

  type Mutation {
    agregarComentario(usuarioId: ID!, postId: ID!, texto: String!, autor: String!): Post
  }
`);

const root = {
  // ====== QUERIES ======
  
  usuario: ({ id }) => {
    const usuario = usuarios.find(u => u.id === id);
    return usuario ? enriquecerUsuario(usuario) : null;
  },

  usuarios: ({ limit = 10, offset = 0 }) => {
    return usuarios.slice(offset, offset + limit).map(enriquecerUsuario);
  },

  post: ({ usuarioId, postId }) => {
    const usuario = usuarios.find(u => u.id === usuarioId);
    if (!usuario) return null;
    
    const post = usuario.posts.find(p => p.id === postId);
    if (!post) return null;
    
    return {
      ...post,
      autor: enriquecerUsuario(usuario)
    };
  },

  buscarUsuarios: ({ q }) => {
    const queryLower = q.toLowerCase();
    const resultados = usuarios.filter(u =>
      u.nombre.toLowerCase().includes(queryLower) ||
      u.bio.toLowerCase().includes(queryLower) ||
      u.email.toLowerCase().includes(queryLower)
    );
    
    return {
      query: q,
      resultados: resultados.length,
      usuarios: resultados.map(enriquecerUsuario)
    };
  },

  estadisticas: () => {
    const totalUsuarios = usuarios.length;
    const totalPosts = usuarios.reduce((sum, u) => sum + u.posts.length, 0);
    const totalComentarios = usuarios.reduce((sum, u) =>
      sum + u.posts.reduce((postSum, p) => postSum + p.comentarios.length, 0), 0
    );
    const totalLikes = usuarios.reduce((sum, u) =>
      sum + u.posts.reduce((postSum, p) => postSum + p.likes, 0), 0
    );

    // Usuario más activo
    const usuarioMasActivo = enriquecerUsuario(
      usuarios.reduce((max, u) =>
        u.posts.length > max.posts.length ? u : max
      )
    );

    // Post más popular
    let postMasPopular = null;
    let autorPostPopular = null;
    let maxLikes = -1;

    usuarios.forEach(usuario => {
      usuario.posts.forEach(post => {
        if (post.likes > maxLikes) {
          maxLikes = post.likes;
          postMasPopular = post;
          autorPostPopular = usuario;
        }
      });
    });

    return {
      totalUsuarios,
      totalPosts,
      totalComentarios,
      totalLikes,
      usuarioMasActivo,
      postMasPopular: {
        ...postMasPopular,
        autor: enriquecerUsuario(autorPostPopular)
      }
    };
  },

  usuarioMasActivo: () => {
    const usuarioMasActivo = usuarios.reduce((max, u) =>
      u.posts.length > max.posts.length ? u : max
    );
    return enriquecerUsuario(usuarioMasActivo);
  },

  topUsuarios: ({ limit = 5 }) => {
    return usuarios
      .map(enriquecerUsuario)
      .sort((a, b) => b.totalLikes - a.totalLikes)
      .slice(0, limit);
  },

  // ====== MUTATIONS ======

  agregarComentario: ({ usuarioId, postId, texto, autor }) => {
    const usuario = usuarios.find(u => u.id === usuarioId);
    if (!usuario) return null;

    const post = usuario.posts.find(p => p.id === postId);
    if (!post) return null;

    const nuevoComentario = {
      id: String(Math.max(...post.comentarios.map(c => parseInt(c.id)), 0) + 1),
      texto,
      autor,
      fechaCreacion: new Date().toISOString().split('T')[0]
    };

    post.comentarios.push(nuevoComentario);
    return post;
  }
};

// Función auxiliar para enriquecer usuarios con cálculos
function enriquecerUsuario(usuario) {
  return {
    ...usuario,
    totalPosts: usuario.posts.length,
    totalLikes: usuario.posts.reduce((sum, p) => sum + p.likes, 0)
  };
}

const app = express();

app.use('/graphql', graphqlHTTP({
  schema,
  rootValue: root,
  graphiql: true
}));

app.listen(4000, () => {
  console.log('GraphQL API en http://localhost:4000/graphql');
  console.log('GraphiQL disponible en http://localhost:4000/graphql');
});
