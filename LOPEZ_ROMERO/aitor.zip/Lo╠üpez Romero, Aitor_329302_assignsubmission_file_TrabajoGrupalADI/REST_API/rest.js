/**
 * SERVIDOR REST API
 * 
 * Este archivo implementa una API REST que demuestra principios RESTful:
 * 
 * CARACTERÍSTICAS DE REST:
 * - Múltiples endpoints organizados por recursos (/usuarios, /posts, /comentarios)
 * - Métodos HTTP semánticos (GET para lectura, POST/PUT/DELETE para modificación)
 * - URLs descriptivas que representan recursos
 * - Respuestas estructuradas con códigos HTTP apropiados
 * - Paginación mediante parámetros query (limit, offset)
 * - Búsqueda y filtrado específicos por endpoint
 * 
 * DESAFÍOS DE REST vs GraphQL:
 * - Overfetching: el cliente recibe más datos de los que necesita
 * - Underfetching: requiere múltiples requests para datos relacionados
 * - Versionado de API necesario para cambios en la estructura
 * 
 * EN REST: GET /api/usuarios/1/posts obtiene todos los datos del post
 * EN GraphQL: permite seleccionar solo los campos específicos necesarios
 */

const express = require('express');
const { usuarios } = require('../Data/data');

const app = express();
const PORT = 3000;

app.use(express.json());

// ====== ENDPOINTS DE USUARIOS (RUTAS ESPECÍFICAS PRIMERO) ======

// Obtener todos los usuarios (con paginación opcional)
app.get('/api/usuarios', (req, res) => {
  const limit = parseInt(req.query.limit) || 10;
  const offset = parseInt(req.query.offset) || 0;
  
  const usuariosPaginados = usuarios.slice(offset, offset + limit);
  res.json({
    total: usuarios.length,
    limit,
    offset,
    data: usuariosPaginados.map(u => ({
      id: u.id,
      nombre: u.nombre,
      email: u.email,
      avatar: u.avatar,
      bio: u.bio,
      fechaRegistro: u.fechaRegistro
    }))
  });
});

// Buscar usuarios por nombre (ANTES DE :id)
app.get('/api/usuarios/buscar/nombre', (req, res) => {
  const q = req.query.q?.toLowerCase();
  if (!q) {
    return res.status(400).json({ error: 'Parámetro de búsqueda requerido' });
  }
  
  const resultados = usuarios.filter(u => 
    u.nombre.toLowerCase().includes(q) ||
    u.bio.toLowerCase().includes(q)
  );
  
  res.json({
    query: q,
    resultados: resultados.length,
    data: resultados
  });
});

// Ranking de usuarios por posts (ANTES DE :id)
app.get('/api/usuarios/ranking/posts', (req, res) => {
  const ranking = usuarios
    .map(u => ({
      id: u.id,
      nombre: u.nombre,
      totalPosts: u.posts.length,
      totalLikes: u.posts.reduce((sum, p) => sum + p.likes, 0)
    }))
    .sort((a, b) => b.totalPosts - a.totalPosts);
  
  res.json({ ranking });
});

// Obtener usuario completo por ID (DESPUÉS DE RUTAS ESPECÍFICAS)
app.get('/api/usuarios/:id', (req, res) => {
  const usuario = usuarios.find(u => u.id === req.params.id);
  if (!usuario) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  res.json(usuario);
});

// Obtener solo posts de un usuario
app.get('/api/usuarios/:id/posts', (req, res) => {
  const usuario = usuarios.find(u => u.id === req.params.id);
  if (!usuario) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  res.json({
    usuarioId: usuario.id,
    nombre: usuario.nombre,
    totalPosts: usuario.posts.length,
    posts: usuario.posts
  });
});

// Obtener perfil específico (sin posts)
app.get('/api/usuarios/:id/perfil', (req, res) => {
  const usuario = usuarios.find(u => u.id === req.params.id);
  if (!usuario) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  const { id, nombre, email, avatar, bio, fechaRegistro } = usuario;
  res.json({ id, nombre, email, avatar, bio, fechaRegistro });
});

// ====== ENDPOINTS DE POSTS ======

// Obtener posts de un usuario específico con paginación
app.get('/api/usuarios/:id/posts/paginated', (req, res) => {
  const usuario = usuarios.find(u => u.id === req.params.id);
  if (!usuario) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  
  const limit = parseInt(req.query.limit) || 5;
  const offset = parseInt(req.query.offset) || 0;
  
  const postsPaginados = usuario.posts.slice(offset, offset + limit);
  
  res.json({
    usuarioId: usuario.id,
    nombre: usuario.nombre,
    totalPosts: usuario.posts.length,
    limit,
    offset,
    posts: postsPaginados
  });
});

// Obtener un post específico
app.get('/api/usuarios/:userId/posts/:postId', (req, res) => {
  const usuario = usuarios.find(u => u.id === req.params.userId);
  if (!usuario) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  
  const post = usuario.posts.find(p => p.id === req.params.postId);
  if (!post) {
    return res.status(404).json({ error: 'Post no encontrado' });
  }
  
  res.json({
    usuarioId: usuario.id,
    usuarioNombre: usuario.nombre,
    post
  });
});

// ====== ENDPOINTS DE COMENTARIOS ======

// Obtener comentarios de un post
app.get('/api/usuarios/:userId/posts/:postId/comentarios', (req, res) => {
  const usuario = usuarios.find(u => u.id === req.params.userId);
  if (!usuario) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  
  const post = usuario.posts.find(p => p.id === req.params.postId);
  if (!post) {
    return res.status(404).json({ error: 'Post no encontrado' });
  }
  
  res.json({
    postId: post.id,
    postTitulo: post.titulo,
    totalComentarios: post.comentarios.length,
    comentarios: post.comentarios
  });
});

// Obtener un comentario específico
app.get('/api/usuarios/:userId/posts/:postId/comentarios/:comentarioId', (req, res) => {
  const usuario = usuarios.find(u => u.id === req.params.userId);
  if (!usuario) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  
  const post = usuario.posts.find(p => p.id === req.params.postId);
  if (!post) {
    return res.status(404).json({ error: 'Post no encontrado' });
  }
  
  const comentario = post.comentarios.find(c => c.id === req.params.comentarioId);
  if (!comentario) {
    return res.status(404).json({ error: 'Comentario no encontrado' });
  }
  
  res.json({
    usuarioId: usuario.id,
    postId: post.id,
    comentario
  });
});

// ====== ENDPOINTS ESTADÍSTICAS ======

// Obtener estadísticas generales
app.get('/api/estadisticas', (req, res) => {
  const totalUsuarios = usuarios.length;
  const totalPosts = usuarios.reduce((sum, u) => sum + u.posts.length, 0);
  const totalComentarios = usuarios.reduce((sum, u) => 
    sum + u.posts.reduce((postSum, p) => postSum + p.comentarios.length, 0), 0
  );
  const totalLikes = usuarios.reduce((sum, u) => 
    sum + u.posts.reduce((postSum, p) => postSum + p.likes, 0), 0
  );
  
  res.json({
    totalUsuarios,
    totalPosts,
    totalComentarios,
    totalLikes,
    promedioPostsPorUsuario: (totalPosts / totalUsuarios).toFixed(2)
  });
});

// ====== MANEJO DE ERRORES ======

app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint no encontrado' });
});

app.listen(PORT, () => {
  console.log(`REST API en http://localhost:${PORT}`);
  console.log(`Documentación disponible en http://localhost:${PORT}/api`);
});
