module.exports = {
  usuarios: [
    {
      id: "1",
      nombre: "Juan García",
      email: "juan@email.com",
      avatar: "https://avatar.example.com/juan.jpg",
      bio: "Desarrollador Full Stack y apasionado por los videojuegos",
      fechaRegistro: "2023-01-15",
      posts: [
        {
          id: "10",
          titulo: "Introducción a FGO",
          contenido: "El botón de Skip funciona sorprendentemente bien. En este post exploro las mejores estrategias para optimizar tu tiempo de juego.",
          likes: 120,
          fechaCreacion: "2024-01-10",
          comentarios: [
            { id: "100", texto: "Buen post", autor: "Luis", fechaCreacion: "2024-01-11" },
            { id: "101", texto: "Muy útil, gracias!", autor: "María", fechaCreacion: "2024-01-12" }
          ]
        },
        {
          id: "11",
          titulo: "Express.js Tips and Tricks",
          contenido: "Descubre los mejores tips para optimizar tus aplicaciones Express. Desde middleware personalizado hasta estrategias de caché.",
          likes: 85,
          fechaCreacion: "2024-01-20",
          comentarios: [
            { id: "102", texto: "Excelente tutorial", autor: "Carlos", fechaCreacion: "2024-01-21" }
          ]
        }
      ]
    },
    {
      id: "2",
      nombre: "María López",
      email: "maria@email.com",
      avatar: "https://avatar.example.com/maria.jpg",
      bio: "Diseñadora UX/UI y amante del diseño web",
      fechaRegistro: "2023-03-20",
      posts: [
        {
          id: "20",
          titulo: "Principios de Diseño Web Moderno",
          contenido: "Los principios fundamentales del diseño web responsivo y accesible. Aprende cómo crear interfaces que funcionen en todos los dispositivos.",
          likes: 200,
          fechaCreacion: "2024-02-01",
          comentarios: [
            { id: "103", texto: "Muy inspirador", autor: "Juan García", fechaCreacion: "2024-02-02" },
            { id: "104", texto: "Excelente análisis", autor: "Pedro", fechaCreacion: "2024-02-03" },
            { id: "105", texto: "Me encantó", autor: "Ana", fechaCreacion: "2024-02-04" }
          ]
        },
        {
          id: "21",
          titulo: "Paletas de colores para 2024",
          contenido: "Exploro las tendencias de color más importantes para este año. Desde tonos naturales hasta colores vibrantes.",
          likes: 156,
          fechaCreacion: "2024-02-15",
          comentarios: [
            { id: "106", texto: "Me encantaron los colores", autor: "Sofia", fechaCreacion: "2024-02-16" }
          ]
        }
      ]
    },
    {
      id: "3",
      nombre: "Carlos Rodríguez",
      email: "carlos@email.com",
      avatar: "https://avatar.example.com/carlos.jpg",
      bio: "Backend Developer especializado en APIs REST y GraphQL",
      fechaRegistro: "2023-06-10",
      posts: [
        {
          id: "30",
          titulo: "GraphQL vs REST: Un análisis profundo",
          contenido: "Comparativa detallada entre GraphQL y REST. Ventajas, desventajas y cuándo usar cada uno en tus proyectos.",
          likes: 320,
          fechaCreacion: "2024-03-01",
          comentarios: [
            { id: "107", texto: "Perfecto análisis", autor: "Juan García", fechaCreacion: "2024-03-02" },
            { id: "108", texto: "Me aclaró muchas dudas", autor: "David", fechaCreacion: "2024-03-03" }
          ]
        }
      ]
    },
    {
      id: "4",
      nombre: "Ana Martínez",
      email: "ana@email.com",
      avatar: "https://avatar.example.com/ana.jpg",
      bio: "Especialista en DevOps y arquitectura cloud",
      fechaRegistro: "2023-08-22",
      posts: [
        {
          id: "40",
          titulo: "Docker y Kubernetes en producción",
          contenido: "Guía completa para desplegar aplicaciones con Docker y Kubernetes. Mejores prácticas y configuración.",
          likes: 275,
          fechaCreacion: "2024-03-15",
          comentarios: [
            { id: "109", texto: "Muy práctico", autor: "Pedro", fechaCreacion: "2024-03-16" },
            { id: "110", texto: "Excelente", autor: "Luis", fechaCreacion: "2024-03-17" }
          ]
        }
      ]
    }
  ]
};
