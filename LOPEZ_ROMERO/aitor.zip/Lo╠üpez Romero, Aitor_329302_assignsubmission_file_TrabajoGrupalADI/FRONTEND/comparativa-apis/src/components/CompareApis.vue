<script setup>
import { computed, ref } from 'vue'
import {
  gqlEstadisticas, gqlUsuario, restEstadisticas, restUsuario,
  gqlPerfilUsuario, restPerfilUsuario,
  restPostsUsuario, restComentariosPost,
  gqlBuscarUsuarios, restBuscarUsuarios,
  gqlTopUsuarios, restRankingUsuarios,
  gqlUsuarioMasActivo,
  gqlErrorCampoInexistente, restUsuarioInexistente,
  gqlErrorTipoIncorrecto
} from '@/services/countTime.js'

const operation = ref('estadisticas')
const usuarioId = ref('1')
const searchQuery = ref('desarrollador')

const loading = ref(false)
const restResult = ref(null)
const gqlResult = ref(null)
const restRequest = ref('')
const gqlRequest = ref('')

const operations = [
  {
    id: 'estadisticas',
    label: 'Estadísticas generales',
    description: 'Obtener datos agregados del sistema'
  },
  {
    id: 'usuario-completo',
    label: 'Usuario completo (con posts)',
    description: 'Usuario + todos sus posts'
  },
  {
    id: 'usuario-perfil-only',
    label: 'Solo perfil del usuario',
    description: 'Demuestra OVERFETCHING: REST trae posts innecesarios'
  },
  {
    id: 'busqueda',
    label: 'Buscar usuarios',
    description: 'Búsqueda por nombre'
  },
  {
    id: 'ranking',
    label: 'Top usuarios por actividad',
    description: 'Usuarios ordenados por likes'
  },
  {
    id: 'usuario-activo',
    label: 'Usuario más activo',
    description: 'El usuario con más posts'
  },
  {
    id: 'error-inexistente',
    label: 'Usuario inexistente (error)',
    description: 'Demuestra manejo de errores'
  },
  {
    id: 'error-campo-gql',
    label: 'Campo inexistente (GraphQL)',
    description: 'GraphQL detecta automáticamente campos no válidos'
  },
  {
    id: 'error-tipo-gql',
    label: 'Tipo incorrecto (GraphQL)',
    description: 'GraphQL valida tipos automáticamente'
  }
]

const needsUserId = computed(() => ['usuario-completo', 'usuario-perfil-only'].includes(operation.value))
const needsSearchQuery = computed(() => operation.value === 'busqueda')

function getStatusColor(status) {
  if (!status) return '#d32f2f'
  if (status >= 200 && status < 300) return '#28a745'
  if (status >= 400) return '#d97706'
  if (status >= 300 && status < 400) return '#0969da'
  return '#0969da'
}

async function run() {
  loading.value = true
  restResult.value = null
  gqlResult.value = null
  restRequest.value = ''
  gqlRequest.value = ''

  try {
    const promises = []

    // REST
    switch (operation.value) {
      case 'estadisticas':
        restRequest.value = 'GET /api/estadisticas'
        promises.push(restEstadisticas())
        break
      case 'usuario-completo':
        restRequest.value = `GET /api/usuarios/${usuarioId.value}`
        promises.push(restUsuario(usuarioId.value))
        break
      case 'usuario-perfil-only':
        restRequest.value = `GET /api/usuarios/${usuarioId.value}/perfil`
        promises.push(restPerfilUsuario(usuarioId.value))
        break
      case 'busqueda':
        restRequest.value = `GET /api/usuarios/buscar/nombre?q=${searchQuery.value}`
        promises.push(restBuscarUsuarios(searchQuery.value))
        break
      case 'ranking':
        restRequest.value = 'GET /api/usuarios/ranking/posts'
        promises.push(restRankingUsuarios())
        break
      case 'usuario-activo':
        restRequest.value = '(No existe endpoint directo)'
        promises.push(Promise.resolve({ ok: false, status: null, data: { message: 'No hay endpoint que devuelva el usuario más activo directamente. Requeriría obtener todos los usuarios y procesarlos en cliente.' }, ms: 0 }))
        break
      case 'error-inexistente':
        restRequest.value = 'GET /api/usuarios/999'
        promises.push(restUsuarioInexistente())
        break
      case 'error-campo-gql':
      case 'error-tipo-gql':
        restRequest.value = '(N/A - Solo GraphQL valida esto)'
        promises.push(Promise.resolve({ ok: true, status: 200, data: { message: 'REST no valida automáticamente.' }, ms: 0 }))
        break
    }

    // GraphQL
    switch (operation.value) {
      case 'estadisticas':
        gqlRequest.value = `query {
  estadisticas {
    totalUsuarios
    totalPosts
    totalComentarios
    totalLikes
    usuarioMasActivo { id nombre totalPosts totalLikes }
    postMasPopular { id titulo likes autor { id nombre } }
  }
}`
        promises.push(gqlEstadisticas())
        break
      case 'usuario-completo':
        gqlRequest.value = `query {
  usuario(id: "${usuarioId.value}") {
    id nombre email bio fechaRegistro totalPosts totalLikes
    posts { id titulo likes fechaCreacion }
  }
}`
        promises.push(gqlUsuario(usuarioId.value))
        break
      case 'usuario-perfil-only':
        gqlRequest.value = `query {
  usuario(id: "${usuarioId.value}") {
    id nombre email bio fechaRegistro
  }
}`
        promises.push(gqlPerfilUsuario(usuarioId.value))
        break
      case 'busqueda':
        gqlRequest.value = `query {
  buscarUsuarios(q: "${searchQuery.value}") {
    query resultados
    usuarios { id nombre email bio }
  }
}`
        promises.push(gqlBuscarUsuarios(searchQuery.value))
        break
      case 'ranking':
        gqlRequest.value = `query {
  topUsuarios(limit: 5) {
    id nombre totalLikes totalPosts
  }
}`
        promises.push(gqlTopUsuarios(5))
        break
      case 'usuario-activo':
        gqlRequest.value = `query {
  usuarioMasActivo {
    id nombre totalPosts totalLikes
  }
}`
        promises.push(gqlUsuarioMasActivo())
        break
      case 'error-inexistente':
        gqlRequest.value = `query {
  usuario(id: "999") {
    id nombre email
  }
}`
        promises.push(gqlUsuario('999'))
        break
      case 'error-campo-gql':
        gqlRequest.value = `query {
  usuario(id: "1") {
    nombre
    nombreCompleto
  }
}`
        promises.push(gqlErrorCampoInexistente())
        break
      case 'error-tipo-gql':
        gqlRequest.value = `query {
  usuario(id: 123) {
    id nombre
  }
}`
        promises.push(gqlErrorTipoIncorrecto())
        break
    }

    const [rest, gql] = await Promise.all(promises)

    restResult.value = rest
    gqlResult.value = gql
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <section style="display: grid; gap: 24px; font-family: system-ui, -apple-system, sans-serif; padding: 20px; max-width: 1400px; margin: 0 auto; min-height: 100vh;">
    <h1 style="margin: 0; color: var(--color-heading);">Comparativa REST vs GraphQL</h1>

    <div style="display: grid; gap: 16px; background: var(--color-surface); padding: 20px; border-radius: 12px; border: 1px solid var(--color-border);">
      <label style="display: grid; gap: 8px;">
        <strong style="color: var(--color-heading); font-size: 14px;">Operación</strong>
        <select v-model="operation" style="padding: 10px 12px; font-size: 14px; background: var(--color-background); color: var(--color-text); border: 1px solid var(--color-border); border-radius: 6px; cursor: pointer;">
          <option v-for="op in operations" :key="op.id" :value="op.id">
            {{ op.label }}
          </option>
        </select>
        <small style="color: var(--color-text-secondary); font-size: 12px;">
          {{ operations.find(o => o.id === operation)?.description }}
        </small>
      </label>

      <label v-if="needsUserId" style="display: grid; gap: 8px;">
        <strong style="color: var(--color-heading); font-size: 14px;">ID Usuario</strong>
        <input v-model="usuarioId" type="text" style="padding: 10px 12px; font-size: 14px; background: var(--color-background); color: var(--color-text); border: 1px solid var(--color-border); border-radius: 6px;" />
        <small style="color: var(--color-text-secondary); font-size: 12px;">Intenta con: 1, 2, 3, 4, o 999 (inexistente)</small>
      </label>

      <label v-if="needsSearchQuery" style="display: grid; gap: 8px;">
        <strong style="color: var(--color-heading); font-size: 14px;">Búsqueda</strong>
        <input v-model="searchQuery" type="text" style="padding: 10px 12px; font-size: 14px; background: var(--color-background); color: var(--color-text); border: 1px solid var(--color-border); border-radius: 6px;" placeholder="Ej: desarrollador" />
      </label>

      <button
        @click="run"
        :disabled="loading"
        style="
          padding: 12px 16px;
          background: #0969da;
          color: white;
          border: none;
          border-radius: 6px;
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
          transition: background 0.2s;
        "
        @mouseenter="!loading && (this.style.background = '#0860ca')"
        @mouseleave="!loading && (this.style.background = '#0969da')"
      >
        {{ loading ? 'Ejecutando...' : 'Ejecutar comparación' }}
      </button>
    </div>

    <!-- Peticiones -->
    <div v-if="restRequest || gqlRequest" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
      <div v-if="restRequest" style="border: 1px solid var(--color-border); border-radius: 12px; padding: 16px; background: var(--color-surface);">
        <h3 style="margin: 0 0 8px 0; font-size: 14px; color: var(--color-heading);">REST Request</h3>
        <pre style="margin: 0; background: var(--color-background); padding: 12px; border-radius: 6px; font-size: 11px; border: 1px solid var(--color-border); color: #d97706; overflow-x: auto;">{{ restRequest }}</pre>
      </div>
      <div v-if="gqlRequest" style="border: 1px solid var(--color-border); border-radius: 12px; padding: 16px; background: var(--color-surface);">
        <h3 style="margin: 0 0 8px 0; font-size: 14px; color: var(--color-heading);">GraphQL Query</h3>
        <pre style="margin: 0; background: var(--color-background); padding: 12px; border-radius: 6px; font-size: 11px; border: 1px solid var(--color-border); color: #28a745; overflow-x: auto;">{{ gqlRequest }}</pre>
      </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; flex: 1; min-height: 400px;">
      <!-- REST -->
      <article style="border: 1px solid var(--color-border); border-radius: 12px; padding: 16px; background: var(--color-surface); display: flex; flex-direction: column; overflow: hidden;">
        <h2 style="margin: 0 0 16px 0; font-size: 18px; color: var(--color-heading);">REST</h2>

        <div v-if="restResult" style="display: flex; flex-direction: column; gap: 12px; flex: 1; overflow: hidden;">
          <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
            <span :style="{ padding: '4px 10px', borderRadius: '4px', fontSize: '12px', fontWeight: '600', background: getStatusColor(restResult.status), color: 'white' }">
              {{ restResult.status || 'Error' }}
            </span>
            <span style="padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 600; background: #6c757d; color: white;">
              {{ restResult.ms.toFixed(2) }} ms
            </span>
            <span v-if="restResult.note" style="font-size: 12px; color: #d97706; font-weight: 500;">
              {{ restResult.note }}
            </span>
          </div>

          <div v-if="restResult.error" style="background: #fee; border-left: 4px solid #d32f2f; padding: 10px; border-radius: 6px;">
            <strong style="color: #d32f2f; display: block; margin-bottom: 4px;">Error</strong>
            <pre style="margin: 0; font-size: 11px; overflow-x: auto; color: var(--color-text);">{{ restResult.error }}</pre>
          </div>

          <pre
            v-else
            style="
              background: var(--color-background);
              padding: 12px;
              border-radius: 6px;
              font-size: 11px;
              overflow: auto;
              margin: 0;
              border: 1px solid var(--color-border);
              color: var(--color-text);
              flex: 1;
            "
          >{{ JSON.stringify(restResult.data, null, 2) }}</pre>
        </div>

        <p v-else style="color: var(--color-text-secondary); font-size: 14px; margin: 0;">Sin ejecutar.</p>
      </article>

      <!-- GraphQL -->
      <article style="border: 1px solid var(--color-border); border-radius: 12px; padding: 16px; background: var(--color-surface); display: flex; flex-direction: column; overflow: hidden;">
        <h2 style="margin: 0 0 16px 0; font-size: 18px; color: var(--color-heading);">GraphQL</h2>

        <div v-if="gqlResult" style="display: flex; flex-direction: column; gap: 12px; flex: 1; overflow: hidden;">
          <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
            <span :style="{ padding: '4px 10px', borderRadius: '4px', fontSize: '12px', fontWeight: '600', background: getStatusColor(gqlResult.status), color: 'white' }">
              {{ gqlResult.status || 'Error' }}
            </span>
            <span style="padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 600; background: #6c757d; color: white;">
              {{ gqlResult.ms.toFixed(2) }} ms
            </span>
          </div>

          <div v-if="gqlResult.data?.errors" style="background: #fee; border-left: 4px solid #d32f2f; padding: 10px; border-radius: 6px; flex-shrink: 0;">
            <strong style="color: #d32f2f; display: block; margin-bottom: 4px;">Errores de validación</strong>
            <pre style="margin: 0; font-size: 11px; overflow-x: auto; color: var(--color-text);">{{
              gqlResult.data.errors.map((e) => e.message).join('\n')
            }}</pre>
          </div>

          <div v-if="gqlResult.error" style="background: #fee; border-left: 4px solid #d32f2f; padding: 10px; border-radius: 6px; flex-shrink: 0;">
            <strong style="color: #d32f2f; display: block; margin-bottom: 4px;">Error</strong>
            <pre style="margin: 0; font-size: 11px; overflow-x: auto; color: var(--color-text);">{{ gqlResult.error }}</pre>
          </div>

          <pre
            v-else
            style="
              background: var(--color-background);
              padding: 12px;
              border-radius: 6px;
              font-size: 11px;
              overflow: auto;
              margin: 0;
              border: 1px solid var(--color-border);
              color: var(--color-text);
              flex: 1;
            "
          >{{ JSON.stringify(gqlResult.data, null, 2) }}</pre>
        </div>

        <p v-else style="color: var(--color-text-secondary); font-size: 14px; margin: 0;">Sin ejecutar.</p>
      </article>
    </div>
  </section>
</template>

<style scoped>
button:hover:not(:disabled) {
  background: #0860ca !important;
}

button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

section {
  max-width: 100%;
}
</style>