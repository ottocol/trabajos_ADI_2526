async function timedJsonFetch(url, options) {
  const t0 = performance.now()
  let res
  let body

  try {
    res = await fetch(url, options)
    body = await res.json()
  } catch (e) {
    const t1 = performance.now()
    return { ok: false, ms: t1 - t0, error: String(e), data: null, status: null }
  }

  const t1 = performance.now()
  return { ok: res.ok, ms: t1 - t0, status: res.status, data: body, error: null }
}

// ===== REST =====

// Estadísticas generales
export async function restEstadisticas() {
  return timedJsonFetch('/api/estadisticas')
}

// Obtener usuario completo (OVERFETCHING: trae posts y comentarios)
export async function restUsuario(id) {
  return timedJsonFetch(`/api/usuarios/${encodeURIComponent(id)}`)
}

// Solo obtener el perfil del usuario (sin posts)
export async function restPerfilUsuario(id) {
  return timedJsonFetch(`/api/usuarios/${encodeURIComponent(id)}/perfil`)
}

// Obtener posts de un usuario
export async function restPostsUsuario(id) {
  return timedJsonFetch(`/api/usuarios/${encodeURIComponent(id)}/posts`)
}

// Obtener comentarios de un post específico
export async function restComentariosPost(userId, postId) {
  return timedJsonFetch(
    `/api/usuarios/${encodeURIComponent(userId)}/posts/${encodeURIComponent(postId)}/comentarios`
  )
}

// Buscar usuarios por nombre
export async function restBuscarUsuarios(query) {
  return timedJsonFetch(
    `/api/usuarios/buscar/nombre?q=${encodeURIComponent(query)}`
  )
}

// Ranking de usuarios por posts
export async function restRankingUsuarios() {
  return timedJsonFetch('/api/usuarios/ranking/posts')
}

// Operación con error: usuario inexistente
export async function restUsuarioInexistente() {
  return timedJsonFetch('/api/usuarios/999')
}

// ===== GraphQL =====

// Estadísticas generales
export async function gqlEstadisticas() {
  const query = `
    query {
      estadisticas {
        totalUsuarios
        totalPosts
        totalComentarios
        totalLikes
        usuarioMasActivo { id nombre totalPosts totalLikes }
        postMasPopular { id titulo likes autor { id nombre } }
      }
    }
  `
  return timedJsonFetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
  })
}

// Obtener usuario con posts (GraphQL permite seleccionar exactamente qué campos)
export async function gqlUsuario(id) {
  const query = `
    query ($id: ID!) {
      usuario(id: $id) {
        id
        nombre
        email
        bio
        fechaRegistro
        totalPosts
        totalLikes
        posts { id titulo likes fechaCreacion }
      }
    }
  `
  return timedJsonFetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables: { id } }),
  })
}

// Solo obtener el perfil sin posts (evita overfetching)
export async function gqlPerfilUsuario(id) {
  const query = `
    query ($id: ID!) {
      usuario(id: $id) {
        id
        nombre
        email
        bio
        fechaRegistro
      }
    }
  `
  return timedJsonFetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables: { id } }),
  })
}

// Usuario con posts y comentarios anidados (demuestra evitar underfetching)
export async function gqlUsuarioConComentarios(id) {
  const query = `
    query ($id: ID!) {
      usuario(id: $id) {
        id
        nombre
        posts {
          id
          titulo
          likes
          comentarios {
            id
            texto
            autor
            fechaCreacion
          }
        }
      }
    }
  `
  return timedJsonFetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables: { id } }),
  })
}

// Buscar usuarios
export async function gqlBuscarUsuarios(q) {
  const query = `
    query ($q: String!) {
      buscarUsuarios(q: $q) {
        query
        resultados
        usuarios {
          id
          nombre
          email
          bio
        }
      }
    }
  `
  return timedJsonFetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables: { q } }),
  })
}

// Top usuarios por actividad
export async function gqlTopUsuarios(limit = 5) {
  const query = `
    query ($limit: Int!) {
      topUsuarios(limit: $limit) {
        id
        nombre
        totalLikes
        totalPosts
      }
    }
  `
  return timedJsonFetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables: { limit } }),
  })
}

// Usuario más activo
export async function gqlUsuarioMasActivo() {
  const query = `
    query {
      usuarioMasActivo {
        id
        nombre
        totalPosts
        totalLikes
      }
    }
  `
  return timedJsonFetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
  })
}

// Operación con error: campo inexistente
export async function gqlErrorCampoInexistente() {
  const query = `
    query {
      usuario(id: "1") {
        nombre
        nombreCompleto
      }
    }
  `
  return timedJsonFetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
  })
}

// Operación con error: variable con tipo incorrecto
export async function gqlErrorTipoIncorrecto() {
  const query = `
    query ($id: ID!) {
      usuario(id: $id) {
        id
        nombre
      }
    }
  `
  return timedJsonFetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables: { id: 123 } }),
  })
}