<script setup>
import CompareApis from './components/CompareApis.vue'
</script>

<template>
  <main style="width: 100%; margin: 0 auto; padding: 24px;">
    <CompareApis />
  </main>
</template>