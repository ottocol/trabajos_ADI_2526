import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import Button from '../ui/Button';

const Navbar = () => {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to={isAuthenticated ? '/events' : '/'} className="flex items-center">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
              EventHub
            </h1>
          </Link>

          {/* Navigation Links */}
          {isAuthenticated && (
            <div className="flex items-center space-x-6">
              <Link
                to="/events"
                className="text-gray-700 hover:text-primary-600 font-medium transition-colors"
              >
                Events
              </Link>
              <Link
                to="/my-bookings"
                className="text-gray-700 hover:text-primary-600 font-medium transition-colors"
              >
                My Bookings
              </Link>
              <Link
                to="/create-event"
                className="text-gray-700 hover:text-primary-600 font-medium transition-colors"
              >
                Create Event
              </Link>

              {/* User info and logout */}
              <div className="flex items-center space-x-4 ml-6 pl-6 border-l border-gray-300">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-primary-600 to-secondary-600 rounded-full flex items-center justify-center">
                    <span className="text-white font-medium text-sm">
                      {user?.username?.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <span className="text-gray-700 font-medium">{user?.username}</span>
                </div>
                <Button variant="outline" onClick={logout}>
                  Logout
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
