const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <h3 className="text-lg font-semibold mb-4 bg-gradient-to-r from-primary-400 to-secondary-400 bg-clip-text text-transparent">
              EventHub
            </h3>
            <p className="text-gray-400 text-sm">
              A modern event management platform built with microservices
              architecture.
            </p>
          </div>

          {/* Microservices */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Microservices</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>🔐 Auth Service (Node.js)</li>
              <li>📅 Event Service (Ruby on Rails)</li>
              <li>🎟️ Booking Service (Python/FastAPI)</li>
            </ul>
          </div>

          {/* Tech Stack */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Frontend Stack</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>⚛️ React 18</li>
              <li>🎨 Tailwind CSS</li>
              <li>⚡ Vite</li>
              <li>🐳 Docker & Nginx</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-800 text-center">
          <p className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} EventHub. Built with microservices
            architecture.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
