import { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { createBooking } from '../../services/bookingService';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Alert from '../ui/Alert';
import { formatDate } from '../../utils/formatters';

const BookingModal = ({ isOpen, onClose, event, onSuccess }) => {
  const { user } = useAuth();
  const [numTickets, setNumTickets] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (numTickets < 1) {
      setError('Number of tickets must be at least 1');
      return;
    }

    if (numTickets > event.capacity) {
      setError(`Number of tickets cannot exceed event capacity (${event.capacity})`);
      return;
    }

    setLoading(true);

    try {
      await createBooking(event.id, numTickets);
      setSuccess(true);

      // Close modal after 2 seconds
      setTimeout(() => {
        onSuccess();
        handleClose();
      }, 2000);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create booking');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setNumTickets(1);
    setError('');
    setSuccess(false);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Reserve Tickets">
      {success ? (
        <Alert type="success" message="Booking created successfully!" />
      ) : (
        <>
          {/* Event details */}
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-lg text-gray-900 mb-2">
              {event.name}
            </h3>
            <div className="space-y-1 text-sm text-gray-600">
              <p>
                <span className="font-medium">Date:</span> {formatDate(event.date)}
              </p>
              <p>
                <span className="font-medium">Location:</span> {event.location}
              </p>
              <p>
                <span className="font-medium">Available capacity:</span> {event.capacity}
              </p>
            </div>
          </div>

          {error && (
            <Alert type="error" message={error} onClose={() => setError('')} />
          )}

          <form onSubmit={handleSubmit}>
            <Input
              label="Number of Tickets"
              name="numTickets"
              type="number"
              value={numTickets}
              onChange={(e) => setNumTickets(parseInt(e.target.value) || 1)}
              required
              disabled={loading}
              placeholder="1"
            />

            <div className="flex space-x-4 mt-6">
              <Button type="submit" fullWidth disabled={loading}>
                {loading ? 'Booking...' : 'Confirm Booking'}
              </Button>
              <Button
                type="button"
                variant="outline"
                fullWidth
                disabled={loading}
                onClick={handleClose}
              >
                Cancel
              </Button>
            </div>
          </form>
        </>
      )}
    </Modal>
  );
};

export default BookingModal;
