import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createEvent } from '../../services/eventService';
import Input from '../ui/Input';
import Button from '../ui/Button';
import Alert from '../ui/Alert';

const CreateEventForm = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    location: '',
    capacity: '',
    date: '',
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setErrors({});
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name) {
      newErrors.name = 'Event name is required';
    }

    if (!formData.description) {
      newErrors.description = 'Description is required';
    }

    if (!formData.location) {
      newErrors.location = 'Location is required';
    }

    if (!formData.capacity) {
      newErrors.capacity = 'Capacity is required';
    } else if (parseInt(formData.capacity) <= 0) {
      newErrors.capacity = 'Capacity must be greater than 0';
    }

    if (!formData.date) {
      newErrors.date = 'Date is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    setLoading(true);

    try {
      const eventData = {
        name: formData.name,
        description: formData.description,
        location: formData.location,
        capacity: parseInt(formData.capacity),
        date: new Date(formData.date).toISOString(),
      };

      await createEvent(eventData);
      setSuccess(true);

      // Redirect after 2 seconds
      setTimeout(() => {
        navigate('/events');
      }, 2000);
    } catch (err) {
      setErrors({
        general: err.response?.data?.message || 'Failed to create event',
      });
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="max-w-2xl mx-auto">
        <Alert
          type="success"
          message="Event created successfully! Redirecting to events page..."
        />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-8 rounded-xl shadow-md">
        {errors.general && (
          <Alert type="error" message={errors.general} onClose={() => setErrors({})} />
        )}

        <Input
          label="Event Name"
          name="name"
          type="text"
          value={formData.name}
          onChange={handleChange}
          error={errors.name}
          required
          disabled={loading}
          placeholder="e.g., Summer Music Festival"
        />

        <div className="mb-4">
          <label
            htmlFor="description"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            Description <span className="text-red-500">*</span>
          </label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            disabled={loading}
            required
            rows={4}
            placeholder="Describe your event..."
            className={
              errors.description
                ? 'input-field-error resize-none'
                : 'input-field resize-none'
            }
          />
          {errors.description && (
            <p className="mt-1 text-sm text-red-600">{errors.description}</p>
          )}
        </div>

        <Input
          label="Location"
          name="location"
          type="text"
          value={formData.location}
          onChange={handleChange}
          error={errors.location}
          required
          disabled={loading}
          placeholder="e.g., Central Park, New York"
        />

        <Input
          label="Capacity"
          name="capacity"
          type="number"
          value={formData.capacity}
          onChange={handleChange}
          error={errors.capacity}
          required
          disabled={loading}
          placeholder="e.g., 500"
        />

        <Input
          label="Date & Time"
          name="date"
          type="datetime-local"
          value={formData.date}
          onChange={handleChange}
          error={errors.date}
          required
          disabled={loading}
        />

        <div className="flex space-x-4 pt-4">
          <Button type="submit" fullWidth disabled={loading}>
            {loading ? 'Creating...' : 'Create Event'}
          </Button>
          <Button
            type="button"
            variant="outline"
            fullWidth
            disabled={loading}
            onClick={() => navigate('/events')}
          >
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
};

export default CreateEventForm;
