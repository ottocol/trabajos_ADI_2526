const Card = ({ children, className = '', onClick }) => {
  const clickableClass = onClick ? 'cursor-pointer' : '';

  return (
    <div className={`card ${clickableClass} ${className}`} onClick={onClick}>
      {children}
    </div>
  );
};

export default Card;
