import { createContext, useState, useEffect } from 'react';
import * as authService from '../services/authService';
import { getUser, getToken } from '../utils/storage';

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  // Check for existing session on mount
  useEffect(() => {
    const checkAuth = async () => {
      const token = getToken();
      const savedUser = getUser();

      if (token && savedUser) {
        setUser(savedUser);
        setIsAuthenticated(true);
      }

      setLoading(false);
    };

    checkAuth();
  }, []);

  // Login handler
  const login = async (username, password) => {
    try {
      const data = await authService.login(username, password);

      if (data.success) {
        setUser(data.user);
        setIsAuthenticated(true);
        return { success: true };
      }

      return { success: false, message: data.message || 'Login failed' };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'An error occurred during login',
      };
    }
  };

  // Register handler
  const register = async (username, password) => {
    try {
      const data = await authService.register(username, password);

      if (data.success) {
        // Auto-login after registration
        return await login(username, password);
      }

      return { success: false, message: data.message || 'Registration failed' };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'An error occurred during registration',
      };
    }
  };

  // Logout handler
  const logout = () => {
    authService.logout();
    setUser(null);
    setIsAuthenticated(false);
  };

  const value = {
    user,
    isAuthenticated,
    loading,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
