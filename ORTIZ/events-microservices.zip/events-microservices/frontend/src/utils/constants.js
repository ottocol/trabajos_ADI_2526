export const API_URLS = {
  AUTH: import.meta.env.VITE_AUTH_SERVICE_URL || 'http://localhost:3000',
  EVENT: import.meta.env.VITE_EVENT_SERVICE_URL || 'http://localhost:3001',
  BOOKING: import.meta.env.VITE_BOOKING_SERVICE_URL || 'http://localhost:8000',
};

export const STORAGE_KEYS = {
  TOKEN: 'events_app_token',
  USER: 'events_app_user',
};

export const ROUTES = {
  LANDING: '/',
  EVENTS: '/events',
  MY_BOOKINGS: '/my-bookings',
  CREATE_EVENT: '/create-event',
};
