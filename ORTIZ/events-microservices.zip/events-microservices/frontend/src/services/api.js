import axios from 'axios';
import { API_URLS } from '../utils/constants';
import { getToken, clearAuthData } from '../utils/storage';

// Create axios instances for each service
const createApiInstance = (baseURL) => {
  const instance = axios.create({
    baseURL,
    headers: {
      'Content-Type': 'application/json',
    },
  });

  // Request interceptor: Add JWT token to requests
  instance.interceptors.request.use(
    (config) => {
      const token = getToken();
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  // Response interceptor: Handle errors globally
  instance.interceptors.response.use(
    (response) => response,
    (error) => {
      // Auto-logout on 401/403
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        clearAuthData();
        window.location.href = '/';
      }
      return Promise.reject(error);
    }
  );

  return instance;
};

// API instances for each service
export const authApi = createApiInstance(API_URLS.AUTH);
export const eventApi = createApiInstance(API_URLS.EVENT);
export const bookingApi = createApiInstance(API_URLS.BOOKING);
