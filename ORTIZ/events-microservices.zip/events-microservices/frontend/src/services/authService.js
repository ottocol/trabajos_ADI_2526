import { authApi } from './api';
import { setToken, setUser, clearAuthData, getToken } from '../utils/storage';

// Register new user
export const register = async (username, password) => {
  const response = await authApi.post('/register', {
    username,
    password,
  });
  return response.data;
};

// Login user
export const login = async (username, password) => {
  const response = await authApi.post('/login', {
    username,
    password,
  });

  if (response.data.success && response.data.token) {
    setToken(response.data.token);
    setUser(response.data.user);
  }

  return response.data;
};

// Get current user
export const getCurrentUser = async () => {
  const response = await authApi.get('/me');
  return response.data;
};

// Logout
export const logout = () => {
  clearAuthData();
};

// Check if user is authenticated
export const isAuthenticated = () => {
  return !!getToken();
};
