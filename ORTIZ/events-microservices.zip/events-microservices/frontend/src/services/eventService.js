import { eventApi } from './api';

// Get all events
export const getAllEvents = async () => {
  const response = await eventApi.get('/events');
  return response.data;
};

// Get event by ID
export const getEventById = async (id) => {
  const response = await eventApi.get(`/events/${id}`);
  return response.data;
};

// Create new event (requires authentication)
export const createEvent = async (eventData) => {
  const response = await eventApi.post('/events', {
    event: eventData,
  });
  return response.data;
};
