import { bookingApi } from './api';

// Create new booking
export const createBooking = async (eventId, numTickets) => {
  const response = await bookingApi.post('/bookings', {
    event_id: eventId,
    num_tickets: numTickets,
  });
  return response.data;
};

// Get all bookings for a user
export const getUserBookings = async () => {
  const response = await bookingApi.get('/bookings');
  return response.data;
};
