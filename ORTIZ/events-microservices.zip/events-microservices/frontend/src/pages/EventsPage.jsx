import Layout from '../components/layout/Layout';
import EventList from '../components/events/EventList';
import { useEvents } from '../hooks/useEvents';

const EventsPage = () => {
  const { events, loading, error, refetch } = useEvents();

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Available Events</h1>
            <p className="text-gray-600 mt-2">
              Discover and book tickets for upcoming events
            </p>
          </div>
        </div>

        <EventList
          events={events}
          loading={loading}
          error={error}
          onBookingSuccess={refetch}
        />
      </div>
    </Layout>
  );
};

export default EventsPage;
