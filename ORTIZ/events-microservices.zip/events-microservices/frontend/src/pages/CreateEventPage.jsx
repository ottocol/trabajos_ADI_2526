import Layout from '../components/layout/Layout';
import CreateEventForm from '../components/events/CreateEventForm';

const CreateEventPage = () => {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Create New Event</h1>
          <p className="text-gray-600 mt-2">
            Fill in the details below to create your event
          </p>
        </div>

        <CreateEventForm />
      </div>
    </Layout>
  );
};

export default CreateEventPage;
