import Layout from '../components/layout/Layout';
import BookingList from '../components/bookings/BookingList';
import { useAuth } from '../hooks/useAuth';
import { useBookings } from '../hooks/useBookings';

const MyBookingsPage = () => {
  const { user } = useAuth();
  const { bookings, loading, error } = useBookings();

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">My Bookings</h1>
          <p className="text-gray-600 mt-2">View and manage your event bookings</p>
        </div>

        <BookingList bookings={bookings} loading={loading} error={error} />
      </div>
    </Layout>
  );
};

export default MyBookingsPage;
