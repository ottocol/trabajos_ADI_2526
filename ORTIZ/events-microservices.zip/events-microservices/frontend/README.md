# EventHub - Plataforma de Gestión de Eventos

Frontend React para el sistema de microservicios EventHub. Gestiona autenticación, eventos y reservas.

## 🚀 Despliegue Rápido

### Requisitos
- Docker y Docker Compose instalados

### Desplegar Toda la Aplicación

```bash
# Desde el directorio raíz del proyecto
cd events-microservices

# Construir e iniciar todos los servicios
docker compose up --build -d

# Verificar que todos los servicios están corriendo
docker compose ps
```

### Poblar las Bases de Datos

**IMPORTANTE**: Ejecutar los seeds en este orden exacto:

```bash
# 1. Seed de usuarios (admin y usuario)
docker compose exec auth-service node seed.js

# 2. Seed de eventos (30 eventos en español) - DEBE ejecutarse antes que bookings
docker compose exec event-service bin/rails db:seed

# 3. Seed de reservas (depende de los eventos creados en el paso anterior)
docker compose exec booking-service python seed.py
```

## 🌐 Acceso a los Servicios

- **Frontend**: http://localhost
- **Auth Service**: http://localhost:3000
- **Event Service**: http://localhost:3001
- **Booking Service**: http://localhost:8000

## 👤 Usuarios de Prueba

| Usuario | Contraseña |
|---------|------------|
| admin   | admin123   |
| usuario | usuario123 |

## 🛑 Detener los Servicios

```bash
docker compose down

# Para eliminar también los volúmenes
docker compose down -v
```

## 📦 Stack Tecnológico

- **Frontend**: React 18 + Vite + Tailwind CSS
- **Auth**: Node.js + Express + JWT (RS256)
- **Events**: Ruby on Rails 8
- **Bookings**: Python + FastAPI
- **Despliegue**: Docker + Nginx

## 🔧 Desarrollo Local (Frontend)

```bash
cd frontend

# Instalar dependencias
npm install

# Crear archivo .env
cp .env.example .env

# Iniciar servidor de desarrollo
npm run dev
```

El frontend estará disponible en http://localhost:5173

## 📝 Variables de Entorno

El archivo `.env` debe contener:

```env
VITE_AUTH_SERVICE_URL=http://localhost:3000
VITE_EVENT_SERVICE_URL=http://localhost:3001
VITE_BOOKING_SERVICE_URL=http://localhost:8000
```

## 🐛 Solución de Problemas

**Si algún servicio falla al iniciar:**
```bash
# Ver logs del servicio específico
docker compose logs [nombre-servicio]

# Ejemplos:
docker compose logs auth-service
docker compose logs event-service
docker compose logs booking-service
docker compose logs frontend
```

**Para reconstruir un servicio específico:**
```bash
docker compose up --build -d [nombre-servicio]
```

**Si necesitas resetear todo:**
```bash
# Detener y eliminar todo (contenedores, volúmenes, redes)
docker compose down -v

# Reconstruir desde cero
docker compose up --build -d

# Volver a ejecutar seeds (EN ORDEN)
docker compose exec auth-service node seed.js
docker compose exec event-service bin/rails db:seed
docker compose exec booking-service python seed.py
```

**Si ves "Event not found" en My Bookings:**
- Las reservas están apuntando a eventos que no existen
- Solución: Ejecutar los seeds en el orden correcto (eventos ANTES que reservas)
