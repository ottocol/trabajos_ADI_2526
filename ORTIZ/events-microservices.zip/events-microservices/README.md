# events-microservices
Trabajo grupal para ADI. Realizado por Christian Ortiz, Jesús Parra y Alex Sabater.

## Enlace al [video](https://youtu.be/uZA5CAGI90Y)

## Auth Service

### Base URL
```
http://localhost:3000
```

### Routes

#### POST /register
Register a new user.

**Request:**
```json
{
  "username": "string",
  "password": "string"
}
```

**Response (201):**
```json
{
  "success": true,
  "message": "User registered successfully"
}
```

**Response (409 - Username exists):**
```json
{
  "success": false,
  "message": "Username already exists"
}
```

---

#### POST /login
Authenticate a user and receive a JWT token.

**Request:**
```json
{
  "username": "string",
  "password": "string"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "User logged in successfully",
  "token": "...",
  "user": {
    "id": 1,
    "username": "string"
  }
}
```

**Response (401 - Invalid credentials):**
```json
{
  "success": false,
  "message": "Invalid credentials"
}
```

---

#### GET /me
Get the current authenticated user's information.

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "success": true,
  "user": {
    "id": 1,
    "username": "string"
  }
}
```

**Response (401 - No token):**
```json
{
  "success": false,
  "message": "Access token required"
}
```

**Response (403 - Invalid token):**
```json
{
  "success": false,
  "message": "Invalid or expired token"
}
```

---

#### GET /public-key
Get the RSA public key for JWT verification (used by other microservices).

**Response (200):**
```
-----BEGIN PUBLIC KEY-----
...
-----END PUBLIC KEY-----
```

---

### JWT Details

- **Algorithm**: RS256 (RSA with SHA-256)
- **Expiration**: 24 hours
- **Payload**: `{ id: <user_id> }`

---

## Event Service

### Base URL
```
http://localhost:3001
```

### Routes

#### GET /events
Get a list of all events.

**Authentication**: Not required

**Response (200):**
```json
[
  {
    "id": 1,
    "name": "Tech Conference 2025",
    "description": "Annual technology conference",
    "location": "Convention Center",
    "capacity": 500,
    "date": "2025-03-15T10:00:00.000Z",
    "created_at": "2025-01-01T12:00:00.000Z",
    "updated_at": "2025-01-01T12:00:00.000Z"
  }
]
```

---

#### GET /events/:id
Get details of a specific event.

**Authentication**: Not required

**Response (200):**
```json
{
  "id": 1,
  "name": "Tech Conference 2025",
  "description": "Annual technology conference",
  "location": "Convention Center",
  "capacity": 500,
  "date": "2025-03-15T10:00:00.000Z",
  "created_at": "2025-01-01T12:00:00.000Z",
  "updated_at": "2025-01-01T12:00:00.000Z"
}
```

**Response (404 - Event not found):**
```json
{
  "error": "Event not found"
}
```

---

#### POST /events
Create a new event.

**Authentication**: Required (JWT token from Auth Service)

**Headers:**
```
Authorization: Bearer <token>
Content-Type: application/json
```

**Request:**
```json
{
  "event": {
    "name": "Tech Conference 2025",
    "description": "Annual technology conference",
    "location": "Convention Center",
    "capacity": 500,
    "date": "2025-03-15T10:00:00.000Z"
  }
}
```

**Response (201):**
```json
{
  "id": 1,
  "name": "Tech Conference 2025",
  "description": "Annual technology conference",
  "location": "Convention Center",
  "capacity": 500,
  "date": "2025-03-15T10:00:00.000Z",
  "created_at": "2025-01-01T12:00:00.000Z",
  "updated_at": "2025-01-01T12:00:00.000Z"
}
```

**Response (401 - No token or invalid token):**
```json
{
  "error": "Missing or invalid authorization header"
}
```

**Response (422 - Validation errors):**
```json
{
  "errors": [
    "Name can't be blank",
    "Capacity must be greater than 0"
  ]
}
```

---

### Validation Rules

- **name**: Required
- **description**: Required
- **location**: Required
- **capacity**: Required, must be a positive integer
- **date**: Required
