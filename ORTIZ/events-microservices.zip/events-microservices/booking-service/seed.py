import random
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from main import BookingModel, Base

# Configuración de base de datos
SQLALCHEMY_DATABASE_URL = "sqlite:///./bookings.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Asegurar que las tablas existen
Base.metadata.create_all(bind=engine)

def seed_bookings():
    print("Iniciando seeding de reservas...")

    db = SessionLocal()

    try:
        # Limpiar reservas existentes
        print("Limpiando reservas existentes...")
        db.query(BookingModel).delete()
        db.commit()

        # Crear reservas de muestra
        # Generaremos reservas para los usuarios ID 1 (admin) y 2 (usuario)
        # y para los eventos ID 31-60 (los IDs reales en la base de datos)
        bookings_data = []

        # Eventos populares que tendrán más reservas (ajustados al rango 31-60)
        popular_events = [31, 32, 35, 39, 40, 43, 47]  # IDs de eventos populares

        # Cada usuario reserva entre 3-7 eventos
        for user_id in [1, 2]:  # Solo 2 usuarios
            num_bookings = random.randint(3, 7)

            # Seleccionar eventos aleatorios para este usuario (IDs 31-60)
            available_events = list(range(31, 61))  # 30 eventos con IDs 31-60
            random.shuffle(available_events)

            for i in range(num_bookings):
                event_id = available_events[i]

                # Eventos populares obtienen más tickets reservados
                if event_id in popular_events:
                    num_tickets = random.randint(1, 6)  # 1-6 tickets
                else:
                    num_tickets = random.randint(1, 3)  # 1-3 tickets

                # Algunas reservas pueden estar canceladas o pendientes
                status_weights = [("confirmed", 0.85), ("pending", 0.1), ("cancelled", 0.05)]
                status = random.choices(
                    [s[0] for s in status_weights],
                    weights=[s[1] for s in status_weights]
                )[0]

                bookings_data.append({
                    "user_id": user_id,
                    "event_id": event_id,
                    "num_tickets": num_tickets,
                    "status": status
                })

        # Agregar algunas reservas extra para eventos populares
        for event_id in popular_events:
            # 3-8 reservas adicionales por evento popular
            for _ in range(random.randint(3, 8)):
                user_id = random.randint(1, 2)  # Solo usuarios 1 o 2
                num_tickets = random.randint(1, 4)
                status = random.choices(
                    ["confirmed", "pending"],
                    weights=[0.9, 0.1]
                )[0]

                bookings_data.append({
                    "user_id": user_id,
                    "event_id": event_id,
                    "num_tickets": num_tickets,
                    "status": status
                })

        # Crear reservas en la base de datos
        print(f"Creando {len(bookings_data)} reservas...")
        for booking_data in bookings_data:
            booking = BookingModel(**booking_data)
            db.add(booking)

        db.commit()

        # Imprimir resumen
        total_bookings = db.query(BookingModel).count()
        confirmed_bookings = db.query(BookingModel).filter(BookingModel.status == "confirmed").count()
        pending_bookings = db.query(BookingModel).filter(BookingModel.status == "pending").count()
        cancelled_bookings = db.query(BookingModel).filter(BookingModel.status == "cancelled").count()

        print("\n✅ ¡Seeding completado!")
        print(f"Total de reservas: {total_bookings}")
        print(f"  - Confirmadas: {confirmed_bookings}")
        print(f"  - Pendientes: {pending_bookings}")
        print(f"  - Canceladas: {cancelled_bookings}")

        # Imprimir estadísticas por usuario
        print("\nReservas por usuario:")
        for user_id in [1, 2]:
            user_bookings = db.query(BookingModel).filter(BookingModel.user_id == user_id).count()
            print(f"  Usuario {user_id}: {user_bookings} reservas")

        # Imprimir estadísticas de eventos populares
        print("\nEstadísticas de eventos populares:")
        for event_id in popular_events[:5]:
            event_bookings = db.query(BookingModel).filter(BookingModel.event_id == event_id).count()
            total_tickets = sum([b.num_tickets for b in db.query(BookingModel).filter(BookingModel.event_id == event_id).all()])
            print(f"  Evento {event_id}: {event_bookings} reservas, {total_tickets} tickets")

    except Exception as e:
        print(f"Error durante el seeding: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    seed_bookings()
