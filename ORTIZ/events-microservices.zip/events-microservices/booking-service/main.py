from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from typing import List, Optional
from uuid import uuid4
from sqlalchemy import create_engine, Column, String, Integer, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
import requests
import jwt
import os

# --- Configuration ---
AUTH_SERVICE_URL = os.getenv("AUTH_SERVICE_URL", "http://localhost:3000")
EVENT_SERVICE_URL = os.getenv("EVENT_SERVICE_URL", "http://localhost:3001")
PUBLIC_KEY = None

def get_public_key():
    global PUBLIC_KEY
    if PUBLIC_KEY:
        return PUBLIC_KEY
    try:
        response = requests.get(f"{AUTH_SERVICE_URL}/public-key")
        if response.status_code == 200:
            PUBLIC_KEY = response.text
            return PUBLIC_KEY
    except Exception as e:
        print(f"Error fetching public key: {e}")
    return None

# --- Database Setup ---
SQLALCHEMY_DATABASE_URL = "sqlite:///./bookings.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

class BookingModel(Base):
    __tablename__ = "bookings"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, index=True)
    event_id = Column(Integer)
    num_tickets = Column(Integer)
    status = Column(String, default="confirmed")

Base.metadata.create_all(bind=engine)

class BookingCreate(BaseModel):
    event_id: int
    num_tickets: int = 1

class Booking(BookingCreate):
    id: int
    user_id: int
    status: str

    class Config:
        from_attributes = True

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def get_current_user_id(token: str = Depends(oauth2_scheme)):
    public_key = get_public_key()
    if not public_key:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Could not retrieve public key for authentication",
        )
    
    try:
        payload = jwt.decode(token, public_key, algorithms=["RS256"])
        user_id = payload.get("id")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return user_id
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

# Endpoints
app = FastAPI(title="Booking Service", version="1.0.0")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

@app.get("/")
def read_root():
    return {"service": "Booking Service", "status": "running", "db": "sqlite"}

@app.post("/bookings", response_model=Booking, status_code=201)
def create_booking(booking: BookingCreate, user_id: int = Depends(get_current_user_id), db: Session = Depends(get_db)):
    # Check event capacity
    try:
        response = requests.get(f"{EVENT_SERVICE_URL}/events/{booking.event_id}")
        if response.status_code == 404:
            raise HTTPException(status_code=404, detail="Event not found")
        if response.status_code != 200:
             raise HTTPException(status_code=502, detail="Error fetching event details")
        
        event_data = response.json()
        total_capacity = event_data.get("capacity", 0)
        
        # Calculate current bookings
        booked_tickets = db.query(func.sum(BookingModel.num_tickets)).filter(BookingModel.event_id == booking.event_id).scalar() or 0
        
        if booked_tickets + booking.num_tickets > total_capacity:
            raise HTTPException(status_code=400, detail="Not enough tickets available")

    except requests.RequestException:
        raise HTTPException(status_code=503, detail="Event service unavailable")

    db_booking = BookingModel(
        user_id=user_id,
        event_id=booking.event_id,
        num_tickets=booking.num_tickets,
        status="confirmed"
    )
    db.add(db_booking)
    db.commit()
    db.refresh(db_booking)
    return db_booking

@app.get("/bookings", response_model=List[Booking])
def get_my_bookings(user_id: int = Depends(get_current_user_id), db: Session = Depends(get_db)):
    bookings = db.query(BookingModel).filter(BookingModel.user_id == user_id).all()
    return bookings
