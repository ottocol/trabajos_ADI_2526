# Arquitectura del Sistema

Este diagrama representa la arquitectura de microservicios implementada, destacando la separación de contextos y los flujos principales.

```mermaid
graph LR
    %% Estilos
    classDef client fill:#2d3748,stroke:#4a5568,stroke-width:2px,color:#fff;
    classDef auth fill:#c6f6d5,stroke:#276749,stroke-width:2px;
    classDef event fill:#fed7d7,stroke:#9b2c2c,stroke-width:2px;
    classDef booking fill:#bee3f8,stroke:#2c5282,stroke-width:2px;
    classDef db fill:#fefcbf,stroke:#b7791f,stroke-width:2px;

    Client(Frontend SPA<br/>React):::client

    subgraph Auth_Ctx [Identity Context]
        Auth(Auth Service<br/>Node.js):::auth
        DB_Auth[(users.db)]:::db
        Auth --- DB_Auth
    end

    subgraph Event_Ctx [Events Context]
        Events(Event Service<br/>Ruby on Rails):::event
        DB_Events[(events.sqlite3)]:::db
        Events --- DB_Events
    end

    subgraph Booking_Ctx [Booking Context]
        Bookings(Booking Service<br/>Python + FastAPI):::booking
        DB_Book[(bookings.db)]:::db
        Bookings --- DB_Book
    end
    
    %% Flujos de negocio
    Client -->|Login| Auth
    Client -->|Browse Events| Events
    Client -->|Create Booking| Bookings

    %% Dependencias internas
    Bookings -.->|Fetch Public Key| Auth
    Bookings -->|Check Capacity| Events
    Events -.->|Fetch Public Key| Auth
```

## Descripción de Componentes

1.  **Frontend (SPA)**: Actúa como orquestador visual. El usuario interactúa con la interfaz y esta realiza peticiones HTTP a los distintos servicios expuestos.
2.  **Auth Service (Node.js)**: Autoridad de identidad. Gestiona el registro y login, emitiendo tokens JWT. Es dueño de `users.db`.
3.  **Event Service (Rails)**: Gestiona el catálogo de eventos. Es dueño de `events.sqlite3`.
4.  **Booking Service (Python)**: Gestiona las transacciones de reserva.
    *   **Autenticación:** Descarga la clave pública del Auth Service para validar JWTs sin estado.
    *   **Consistencia:** Consulta síncronamente al Event Service para validar aforo antes de confirmar una reserva en `bookings.db`.
