# Limpiar eventos existentes
puts "Limpiando eventos existentes..."
Event.destroy_all

# Crear eventos
puts "Creando eventos..."

events_data = [
  {
    name: "Conferencia de Tecnología 2025",
    description: "Conferencia anual sobre las últimas innovaciones en IA, computación en la nube y desarrollo de software. Únete a líderes de la industria y haz networking con profesionales de todo el mundo.",
    location: "Centro de Convenciones, Madrid",
    capacity: 5000,
    date: 3.months.from_now
  },
  {
    name: "Festival de Rock Verano",
    description: "Festival de música rock de tres días con más de 50 bandas en múltiples escenarios. Encabezado por bandas legendarias y artistas emergentes. ¡Food trucks, camping y mucho más!",
    location: "Parque del Retiro, Madrid",
    capacity: 15000,
    date: 4.months.from_now
  },
  {
    name: "Competición de Startups",
    description: "Observa cómo startups innovadoras presentan sus ideas ante un panel de capitalistas de riesgo. Networking con emprendedores e inversores. El ganador recibe 100K€ en financiación inicial.",
    location: "Hub de Innovación, Barcelona",
    capacity: 300,
    date: 1.month.from_now
  },
  {
    name: "Exposición de Arte Moderno",
    description: "Exposición exclusiva con obras de artistas contemporáneos. Incluye pinturas, esculturas e instalaciones de arte digital. Recepción con vino y queso incluida.",
    location: "Museo Reina Sofía, Madrid",
    capacity: 800,
    date: 2.months.from_now
  },
  {
    name: "Maratón Benéfica",
    description: "Maratón anual benéfica apoyando hospitales infantiles locales. Opciones de 5K, 10K y maratón completo. Todos los ingresos van a caridad.",
    location: "Casa de Campo, Madrid",
    capacity: 10000,
    date: 2.months.from_now + 15.days
  },
  {
    name: "Festival de Gastronomía y Vino",
    description: "Celebra la excelencia culinaria con más de 100 chefs y 200 bodegas. Demostraciones de cocina, catas de vino y comida gourmet de todo el mundo.",
    location: "La Rioja",
    capacity: 5000,
    date: 3.months.from_now + 10.days
  },
  {
    name: "Concierto de Música Clásica",
    description: "La Orquesta Sinfónica interpreta las sinfonías completas de Beethoven durante tres veladas. Director de renombre mundial liderando músicos virtuosos.",
    location: "Auditorio Nacional, Madrid",
    capacity: 2800,
    date: 1.month.from_now + 20.days
  },
  {
    name: "Feria de Empleo Tech",
    description: "Reúnete con gerentes de contratación de más de 200 empresas tecnológicas. Trae tu CV y prepárate para entrevistas in situ. Posiciones desde junior hasta senior.",
    location: "Palacio de Congresos, Valencia",
    capacity: 3000,
    date: 1.month.from_now + 10.days
  },
  {
    name: "Festival Internacional de Cine",
    description: "Celebración de una semana del cine independiente de todo el mundo. Estrenos con alfombra roja, sesiones de preguntas y respuestas con directores, y ceremonia de premios.",
    location: "Sitges, Barcelona",
    capacity: 2000,
    date: 5.months.from_now
  },
  {
    name: "Noche de Jazz Bajo las Estrellas",
    description: "Concierto de jazz al aire libre con artistas ganadores del Grammy. Trae una manta y disfruta de jazz suave en un hermoso entorno al aire libre. Comida y bebidas disponibles.",
    location: "Parque de la Ciutadella, Barcelona",
    capacity: 8000,
    date: 2.months.from_now + 5.days
  },
  {
    name: "Cumbre de Blockchain y Cripto",
    description: "Inmersión profunda en tecnología blockchain, mercados de criptomonedas e innovaciones DeFi. Paneles de expertos, talleres y oportunidades de networking.",
    location: "IFEMA, Madrid",
    capacity: 4000,
    date: 4.months.from_now + 15.days
  },
  {
    name: "Noche de Comedia Extravaganza",
    description: "Espectáculo de stand-up con 10 humoristas destacados. Ríete toda la noche con esta hilarante selección de talento cómico.",
    location: "Teatro Lara, Madrid",
    capacity: 450,
    date: 3.weeks.from_now
  },
  {
    name: "Convención de Gaming 2025",
    description: "¡La experiencia definitiva de gaming! Prueba juegos no lanzados, conoce desarrolladores, torneos de esports, concursos de cosplay y merchandising exclusivo.",
    location: "Feria de Valencia",
    capacity: 12000,
    date: 6.months.from_now
  },
  {
    name: "Retiro de Yoga y Bienestar",
    description: "Retiro de bienestar de fin de semana con clases de yoga, sesiones de meditación, tratamientos de spa y comidas gourmet saludables. Todos los niveles bienvenidos.",
    location: "Sierra de Gredos, Ávila",
    capacity: 150,
    date: 2.months.from_now + 8.days
  },
  {
    name: "Semana de la Moda Primavera",
    description: "Descubre las últimas tendencias de diseñadores destacados. Desfiles, encuentros con diseñadores y oportunidades exclusivas de compra.",
    location: "Palacio de Cibeles, Madrid",
    capacity: 6000,
    date: 3.months.from_now + 20.days
  },
  {
    name: "Feria de Ciencias e Innovación",
    description: "Proyectos de ciencias estudiantiles, demostraciones de robótica y exhibiciones interactivas. Inspirando a la próxima generación de científicos e ingenieros.",
    location: "CosmoCaixa, Barcelona",
    capacity: 2500,
    date: 1.month.from_now + 15.days
  },
  {
    name: "Festival de Música Electrónica",
    description: "Festival de EDM de dos días con DJs de fama mundial pinchando hasta el amanecer. Múltiples escenarios, espectáculos de luces e instalaciones de arte inmersivo.",
    location: "Circuit de Barcelona-Catalunya",
    capacity: 25000,
    date: 5.months.from_now + 10.days
  },
  {
    name: "Feria del Libro y Lecturas",
    description: "Conoce a autores bestsellers, asiste a firmas de libros y descubre nuevas obras literarias. Paneles sobre escritura, publicación y narrativa.",
    location: "Casa del Lector, Madrid",
    capacity: 1000,
    date: 2.months.from_now + 12.days
  },
  {
    name: "Festival de Cervezas Artesanales",
    description: "Degusta cervezas artesanales de más de 100 cervecerías. Música en vivo, maridajes y talleres de elaboración. Mayores de 18 años.",
    location: "Matadero Madrid",
    capacity: 5000,
    date: 4.months.from_now + 5.days
  },
  {
    name: "Taller de Fotografía",
    description: "Taller intensivo de fotografía cubriendo retrato, paisaje y fotografía callejera. Instrucción práctica de fotógrafos galardonados.",
    location: "Centro de Fotografía, Bilbao",
    capacity: 50,
    date: 6.weeks.from_now
  },
  {
    name: "Cumbre Medioambiental 2025",
    description: "Líderes globales discuten cambio climático, sostenibilidad y energía renovable. Talleres sobre tecnología verde y política ambiental.",
    location: "Palacio Euskalduna, Bilbao",
    capacity: 3500,
    date: 7.months.from_now
  },
  {
    name: "Estreno Musical de Broadway",
    description: "Estreno mundial de un nuevo musical. Experimenta una noche inolvidable de teatro con actuaciones y producción impresionantes.",
    location: "Teatro Real, Madrid",
    capacity: 1700,
    date: 5.weeks.from_now
  },
  {
    name: "Expo de Fitness y Culturismo",
    description: "Competiciones de fitness, demostraciones de entrenamientos, seminarios de nutrición y conoce atletas profesionales. Stands con el último equipo de fitness.",
    location: "Palacio de Deportes, Madrid",
    capacity: 8000,
    date: 3.months.from_now + 18.days
  },
  {
    name: "Cumbre de Inteligencia Artificial",
    description: "Explora el futuro de la IA con investigadores líderes y pioneros de la industria. Talleres de deep learning, paneles de ética en IA y showcases de startups.",
    location: "Campus Científico, Granada",
    capacity: 2000,
    date: 4.months.from_now + 8.days
  },
  {
    name: "Taller de Ciencias para Niños",
    description: "Actividades científicas prácticas para niños de 6-12 años. Construye robots, realiza experimentos y aprende sobre espacio, química y física.",
    location: "Museo de Ciencias, Valencia",
    capacity: 200,
    date: 1.month.from_now + 5.days
  },
  {
    name: "Competición de Baile Salsa",
    description: "Competición internacional de salsa con bailarines de más de 20 países. Clases gratuitas para principiantes antes del evento principal.",
    location: "Playa de la Barceloneta, Barcelona",
    capacity: 1200,
    date: 3.months.from_now + 7.days
  },
  {
    name: "Showcase de Realidad Virtual",
    description: "Prueba los últimos juegos de RV, experiencias educativas y tours virtuales. Experimenta lo último en tecnología inmersiva.",
    location: "Espacio Fundación Telefónica, Madrid",
    capacity: 2500,
    date: 2.months.from_now + 20.days
  },
  {
    name: "Festival de Barbacoa y Cerveza",
    description: "El maridaje perfecto de cervezas artesanales y barbacoa de campeonato. Música country en vivo, juegos al aire libre y actividades familiares.",
    location: "Parque del Oeste, Madrid",
    capacity: 6000,
    date: 5.months.from_now + 12.days
  },
  {
    name: "Conferencia de Marketing Digital",
    description: "Aprende las últimas estrategias en SEO, marketing en redes sociales, creación de contenido y analíticas. Networking con profesionales del marketing.",
    location: "Hotel Meliá Castilla, Madrid",
    capacity: 4500,
    date: 3.months.from_now + 25.days
  },
  {
    name: "Ballet Clásico - El Lago de los Cisnes",
    description: "El Ballet Nacional presenta El Lago de los Cisnes con bailarines de clase mundial y orquesta en vivo. Una velada de elegancia y arte atemporal.",
    location: "Palau de les Arts, Valencia",
    capacity: 2400,
    date: 2.months.from_now + 18.days
  }
]

events_data.each do |event_data|
  event = Event.create!(event_data)
  puts "Creado: #{event.name} - #{event.location} (#{event.date.strftime('%d de %B de %Y')})"
end

puts "\n✅ ¡Seeding completado!"
puts "Total de eventos creados: #{Event.count}"
