require 'jwt'
require 'net/http'
require 'json'

module JwtAuthenticatable
    extend ActiveSupport::Concern

    # Cache duration for public key (1 hour)
    PUBLIC_KEY_CACHE_DURATION = 1.hour

    def authenticate_jwt!
        auth_header = request.headers['Authorization']

        if auth_header.nil? || !auth_header.start_with?('Bearer ')
            render json: { error: 'Missing or invalid authorization header' }, status: :unauthorized
        return
    end

    token = auth_header.split(' ')[1]

        begin
            public_key = fetch_public_key_cached
            decoded_token = JWT.decode(token, public_key, true, algorithm: 'RS256')
            @current_user = decoded_token[0]
        rescue JWT::DecodeError => e
            render json: { error: "Invalid token: #{e.message}" }, status: :unauthorized
        rescue => e
            render json: { error: "Authentication error: #{e.message}" }, status: :unauthorized
        end
    end

  private

  def fetch_public_key_cached
    # Use Rails cache to store the public key
    Rails.cache.fetch('auth_service_public_key', expires_in: PUBLIC_KEY_CACHE_DURATION) do
      fetch_public_key_from_server
    end
  end

  def fetch_public_key_from_server
    auth_server_url = ENV['AUTH_SERVER_URL'] || 'http://auth-service:3000/public-key'

    uri = URI(auth_server_url)
    response = Net::HTTP.get_response(uri)

    if response.is_a?(Net::HTTPSuccess)
      public_key_pem = response.body
      OpenSSL::PKey::RSA.new(public_key_pem)
    else
      raise "Failed to fetch public key: #{response.code}"
    end
  end
end
