class Event < ApplicationRecord
    validates :name, presence: true
    validates :description, presence: true
    validates :location, presence: true
    validates :capacity, presence: true, numericality: { greater_than: 0, only_integer: true }
    validates :date, presence: true
end
