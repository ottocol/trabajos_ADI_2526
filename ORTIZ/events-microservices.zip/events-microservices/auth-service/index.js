const express = require("express");
const cors = require("cors");

const { createTables } = require("./db");
const routes = require("./routes");

const PORT = 3000;
const corsOptions = {
    optionsSuccessStatus: 200,
};

const app = express();

app.use(express.json());
app.use(cors(corsOptions));

app.use("/", routes);

createTables()
    .then(() => {
        app.listen(PORT, () => {
            console.log("Server started on port 3000");
        });
    })
    .catch((err) => {
        console.error(`Could not create tables: ${err}`);
        process.exit(1);
    });
