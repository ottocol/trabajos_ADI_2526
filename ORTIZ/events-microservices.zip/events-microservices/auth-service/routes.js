const express = require('express');
const { createUser, getUserByUsername, getUserById, verifyPassword } = require('./db');
const { generateToken, verifyToken, getPublicKey } = require('./utils');

const router = express.Router();

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ success: false, message: 'Access token required' });
    }

    try {
        const decoded = verifyToken(token);
        req.userId = decoded.id;
        next();
    } catch (error) {
        return res.status(403).json({ success: false, message: 'Invalid or expired token' });
    }
};

router.post('/register', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ success: false, message: 'Username and password are required' });
        }

        if (typeof username !== 'string' || typeof password !== 'string') {
            return res.status(400).json({ success: false, message: 'Username and password must be strings' });
        }

        const existingUser = await getUserByUsername(username);

        if (existingUser) {
            return res.status(409).json({ success: false, message: 'Username already exists' });
        }

        await createUser(username, password);

        return res.status(201).json({ success: true, message: 'User registered successfully' });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ success: false, message: 'Failed to register user' });
    }
});

router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ success: false, message: 'Username and password are required' });
        }

        if (typeof username !== 'string' || typeof password !== 'string') {
            return res.status(400).json({ success: false, message: 'Username and password must be strings' });
        }

        const user = await getUserByUsername(username);

        if (!user) {
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        const isValidPassword = await verifyPassword(password, user.password);

        if (!isValidPassword) {
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        const token = generateToken(user.id);

        return res.status(200).json({
            success: true,
            message: 'User logged in successfully',
            token,
            user: { id: user.id, username: user.username }
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ success: false, message: 'Failed to log in user' });
    }
});

router.get('/me', authenticateToken, async (req, res) => {
    try {
        const user = await getUserById(req.userId);

        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        return res.status(200).json({
            success: true,
            user: { id: user.id, username: user.username }
        });
    } catch (error) {
        console.error('Get user error:', error);
        return res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

router.get('/public-key', (req, res) => {
    try {
        const publicKey = getPublicKey();
        return res.status(200).send(publicKey);
    } catch (error) {
        console.error('Public key error:', error);
        return res.status(500).json({ success: false, message: 'Failed to retrieve public key' });
    }
});

module.exports = router;
