const { createUser, getUserByUsername } = require('./db');

const users = [
    { username: 'admin', password: 'admin123' },
    { username: 'usuario', password: 'usuario123' }
];

const seedUsers = async () => {
    console.log('Iniciando seeding de usuarios...');

    let created = 0;
    let skipped = 0;

    for (const userData of users) {
        try {
            const existingUser = await getUserByUsername(userData.username);

            if (existingUser) {
                console.log(`Usuario ${userData.username} ya existe, saltando...`);
                skipped++;
            } else {
                await createUser(userData.username, userData.password);
                created++;
            }
        } catch (error) {
            console.error(`Error creando usuario ${userData.username}:`, error.message);
        }
    }

    console.log('\n¡Seeding completado!');
    console.log(`Creados: ${created} usuarios`);
    console.log(`Saltados: ${skipped} usuarios`);
    console.log(`Total: ${users.length} usuarios`);

    process.exit(0);
};

seedUsers();
