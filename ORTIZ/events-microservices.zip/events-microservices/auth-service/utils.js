const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");
const { generateKeyPairSync } = require("crypto");

const KEYS_DIR = path.join(__dirname, "keys");
const PUBLIC_KEY_PATH = path.join(KEYS_DIR, "public.key");
const PRIVATE_KEY_PATH = path.join(KEYS_DIR, "private.key");

const ensureKeysExist = () => {
    if (!fs.existsSync(KEYS_DIR)) {
        fs.mkdirSync(KEYS_DIR, { recursive: true, mode: 0o755 });
    }

    const keysExist =
        fs.existsSync(PUBLIC_KEY_PATH) && fs.existsSync(PRIVATE_KEY_PATH);

    if (!keysExist) {
        console.log("Generating new RSA key pair...");
        const { publicKey, privateKey } = generateKeyPairSync("rsa", {
            modulusLength: 2048,
            publicKeyEncoding: {
                type: "spki",
                format: "pem",
            },
            privateKeyEncoding: {
                type: "pkcs8",
                format: "pem",
            },
        });

        fs.writeFileSync(PUBLIC_KEY_PATH, publicKey, { mode: 0o644 });
        fs.writeFileSync(PRIVATE_KEY_PATH, privateKey, { mode: 0o600 });
        console.log("RSA key pair generated successfully");
    }
};

ensureKeysExist();

let JWT_PUBLIC_KEY = null;
let JWT_PRIVATE_KEY = null;

const loadKeys = () => {
    if (!JWT_PUBLIC_KEY || !JWT_PRIVATE_KEY) {
        try {
            JWT_PUBLIC_KEY = fs.readFileSync(PUBLIC_KEY_PATH, "utf8");
            JWT_PRIVATE_KEY = fs.readFileSync(PRIVATE_KEY_PATH, "utf8");
            console.log("RSA keys loaded successfully");
        } catch (err) {
            console.error("Error loading keys:", err);
            throw new Error("Failed to load RSA keys");
        }
    }
};

const generateToken = (id) => {
    loadKeys();
    return jwt.sign({ id }, JWT_PRIVATE_KEY, {
        algorithm: "RS256",
        expiresIn: "24h",
    });
};

const verifyToken = (token) => {
    loadKeys();
    return jwt.verify(token, JWT_PUBLIC_KEY, { algorithms: ["RS256"] });
};

const decodeToken = (token) => {
    return jwt.decode(token);
};

const getPublicKey = () => {
    loadKeys();
    return JWT_PUBLIC_KEY;
};

module.exports = { generateToken, verifyToken, decodeToken, getPublicKey };
