const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcryptjs");

const db = new sqlite3.Database("users.db", (err) => {
    if (err) {
        console.error(err.message);
    } else {
        console.log("Connected to SQlite database");
    }
});

const createTables = () => {
    return new Promise((resolve, reject) => {
        // Check if users table exists
        db.get(
            `SELECT name FROM sqlite_master WHERE type='table' AND name='users'`,
            (err, row) => {
                if (err) {
                    console.error("Error checking tables:", err);
                    reject(err);
                    return;
                }

                if (row) {
                    console.log("Database tables already exist");
                    resolve();
                } else {
                    // Create the table
                    db.run(
                        `
                      CREATE TABLE users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT NOT NULL UNIQUE,
                        password TEXT NOT NULL
                      )
                    `,
                        (err) => {
                            if (err) {
                                console.error("Error creating tables:", err);
                                reject(err);
                            } else {
                                console.log(
                                    "Database tables created successfully",
                                );
                                resolve();
                            }
                        },
                    );
                }
            },
        );
    });
};

const createUser = async (username, password) => {
    return new Promise(async (resolve, reject) => {
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        db.run(
            `
            INSERT INTO users (username, password)
            VALUES (?, ?)
        `,
            [username, hashedPassword],
            function (err) {
                if (err) {
                    console.error("Error creating user:", err);
                    reject(err);
                } else {
                    console.log(`User ${username} created successfully`);
                    resolve({ id: this.lastID, username });
                }
            },
        );
    });
};

const getUserByUsername = (username) => {
    return new Promise((resolve, reject) => {
        db.get(
            `SELECT * FROM users WHERE username = ?`,
            [username],
            (err, row) => {
                if (err) {
                    console.error(err);
                    reject(err);
                } else {
                    resolve(row);
                }
            },
        );
    });
};

const getUserById = (id) => {
    return new Promise((resolve, reject) => {
        db.get(
            `SELECT id, username FROM users WHERE id = ?`,
            [id],
            (err, row) => {
                if (err) {
                    console.error(err);
                    reject(err);
                } else {
                    resolve(row);
                }
            },
        );
    });
};

const verifyPassword = async (plainPassword, hashedPassword) => {
    return await bcrypt.compare(plainPassword, hashedPassword);
};

module.exports = {
    createTables,
    createUser,
    getUserByUsername,
    getUserById,
    verifyPassword,
};
