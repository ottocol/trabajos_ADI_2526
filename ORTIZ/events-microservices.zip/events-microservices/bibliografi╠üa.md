# Bibliografía utilizada

- [Microservices](https://microservices.io/patterns/microservices.html)
- [JWT](https://jwt.io/)
- [Microservices Architecture - Martin Fowler](https://martinfowler.com/articles/microservices.html)
- [The CAP Theorem](https://en.wikipedia.org/wiki/CAP_theorem)
- [The Twelve-Factor App](https://12factor.net/)
- [JWT Best Practices – Auth0](https://auth0.com/blog/a-look-at-the-latest-draft-for-jwt-bcp/)
- [Docker Documentation](https://docs.docker.com/compose/)
- [Ruby on Rails Guides](https://guides.rubyonrails.org)
