import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4';
import { ApolloServerPluginLandingPageLocalDefault } from '@apollo/server/plugin/landingPage/default';
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import graphqlUploadExpress from 'graphql-upload/graphqlUploadExpress.mjs';
import { typeDefs } from './schema/index.js';
import { resolvers } from './resolvers/index.js';
import { pb } from './config/pb.js';

const app = express();
const PORT = 4000;

// Context function to extract user from authorization header
const context = async ({ req }) => {
  const token = req.headers.authorization || '';
  
  try {
    if (token) {
      const cleanToken = token.replace('Bearer ', '').trim();
      
      if (cleanToken) {
        pb.authStore.save(cleanToken);
        
        // Validate the token by refreshing the auth
        try {
          // This will throw if token is invalid
          await pb.collection('users').authRefresh();
          
          if (pb.authStore.isValid && pb.authStore.model) {
            console.log('✅ User authenticated:', pb.authStore.model.id, pb.authStore.model.email);
            return { user: pb.authStore.model };
          }
        } catch (refreshErr) {
          console.log('❌ Token validation failed:', refreshErr.message);
          pb.authStore.clear();
        }
      }
    }
  } catch (err) {
    console.log('❌ Auth error:', err.message);
    pb.authStore.clear();
  }
  
  return { user: null };
};

// Create Apollo Server
const server = new ApolloServer({
  typeDefs,
  resolvers,
  plugins: [ApolloServerPluginLandingPageLocalDefault()],
  formatError: (error) => {
    console.error('GraphQL Error:', error);
    return {
      message: error.message,
      code: error.extensions?.code || 'INTERNAL_SERVER_ERROR',
      path: error.path
    };
  },
  introspection: true
});

// Start server
await server.start();

// GraphQL endpoint with file upload support
app.use(
  '/graphql',
  cors(),
  graphqlUploadExpress({ maxFileSize: 10000000, maxFiles: 10 }),
  bodyParser.json(),
  expressMiddleware(server, { context })
);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'GraphQL server is running' });
});

app.listen(PORT, () => {
  console.log(`GraphQL Server ready at http://localhost:${PORT}/graphql`);
  console.log(`Health check at http://localhost:${PORT}/health`);
});
