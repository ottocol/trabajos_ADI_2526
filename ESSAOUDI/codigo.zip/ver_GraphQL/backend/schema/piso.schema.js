export const pisoSchema = `#graphql
  # Piso type
  type Piso {
    id: ID!
    titulo: String!
    descripcion: String
    direccion: String!
    ciudad: String
    cp: String
    precio: Float!
    num_habit: Int
    superficie: Float
    propietario_id: String!
    propietario: User
    imagen: [String]
    primeraImagen: String
    created: String
    updated: String
  }

  # Paginated response
  type PaginatedPisos {
    items: [Piso!]!
    page: Int!
    perPage: Int!
    totalItems: Int!
    totalPages: Int!
  }

  # Input types
  input PisoInput {
    titulo: String!
    descripcion: String
    direccion: String!
    ciudad: String
    cp: String
    precio: Float!
    num_habit: Int
    superficie: Float
    propietario_id: String
  }

  extend type Query {
    pisos(page: Int, perPage: Int, ciudad: String, precioMin: Float, precioMax: Float, num_habit: Int): PaginatedPisos!
    piso(id: ID!): Piso
    misAnuncios(page: Int, perPage: Int): [Piso!]!
    pisosAdmin(page: Int, perPage: Int, searchText: String): PaginatedPisos!
  }

  extend type Mutation {
    createPiso(input: PisoInput!, imagen: Upload): Piso!
    updatePiso(id: ID!, input: PisoInput!, imagenes: [Upload]): Piso!
    deletePiso(id: ID!): SuccessResponse!
  }
`;
