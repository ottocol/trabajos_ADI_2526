import { authSchema } from './auth.schema.js';
import { userSchema } from './user.schema.js';
import { pisoSchema } from './piso.schema.js';
import { comentarioSchema } from './comentario.schema.js';
import { reservaSchema } from './reserva.schema.js';


const baseSchema = `#graphql
  type Query {
    _empty: String
  }

  type Mutation {
    _empty: String
  }
`;

// todo los schemas
export const typeDefs = [
  baseSchema,
  authSchema,
  userSchema,
  pisoSchema,
  comentarioSchema,
  reservaSchema
];
