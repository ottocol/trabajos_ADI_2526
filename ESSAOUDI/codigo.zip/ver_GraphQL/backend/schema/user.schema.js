export const userSchema = `#graphql
  # User type
  type User {
    id: ID!
    username: String!
    email: String
    nombre: String
    apellidos: String
    telefono: String
    tel: String
    rol: String!
    image: [String]
    created: String
    updated: String
  }

  # Paginated response
  type PaginatedUsers {
    items: [User!]!
    page: Int!
    perPage: Int!
    totalItems: Int!
    totalPages: Int!
  }

  # Input types
  input UserInput {
    username: String
    email: String
    password: String
    passwordConfirm: String
    oldPassword: String
    nombre: String
    apellidos: String
    telefono: String
    tel: String
    rol: String
  }

  type SuccessResponse {
    success: Boolean!
    message: String
  }

  extend type Query {
    users(page: Int, perPage: Int, searchText: String, rol: String): PaginatedUsers!
    user(id: ID!): User
  }

  extend type Mutation {
    createUser(input: UserInput!): User!
    updateUser(id: ID!, input: UserInput!): User!
    deleteUser(id: ID!): SuccessResponse!
    deleteMyAccount: SuccessResponse!
    updatePerfil(id: ID!, input: UserInput!): User!
  }
`;
