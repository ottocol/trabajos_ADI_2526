export const comentarioSchema = `#graphql
  # Comentario type
  type Comentario {
    id: ID!
    piso_id: String!
    usuario_id: String!
    valoracion: Float!
    coment: String
    created: String
    updated: String
    usuario: User
    piso: Piso
  }

  # Paginated response
  type PaginatedComentarios {
    items: [Comentario!]!
    page: Int!
    perPage: Int!
    totalItems: Int!
    totalPages: Int!
  }

  # Input types
  input ComentarioInput {
    piso_id: String!
    valoracion: Float!
    coment: String
  }

  extend type Query {
    comentarios(page: Int, perPage: Int, piso_id: String): PaginatedComentarios!
    comentario(id: ID!): Comentario
  }

  extend type Mutation {
    createComentario(input: ComentarioInput!): Comentario!
    updateComentario(id: ID!, input: ComentarioInput!): Comentario!
    deleteComentario(id: ID!): SuccessResponse!
  }
`;
