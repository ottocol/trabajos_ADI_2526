export const authSchema = `#graphql
  scalar Upload

  # Auth response
  type AuthResponse {
    user: User!
    token: String!
  }

  # Input types
  input RegisterInput {
    username: String!
    email: String!
    password: String!
    passwordConfirm: String!
    nombre: String
    apellidos: String
    tel: String
    rol: String
    image: Upload
  }

  input LoginInput {
    email: String!
    password: String!
  }

  extend type Query {
    me: User
  }

  extend type Mutation {
    register(input: RegisterInput!): AuthResponse!
    login(input: LoginInput!): AuthResponse!
    logout: SuccessResponse!
  }
`;
