export const reservaSchema = `#graphql
  # Reserva type
  type Reserva {
    id: ID!
    piso_id: String!
    inquilino_id: String!
    fecha_inc: String!
    fecha_fin: String!
    estado: String!
    created: String
    updated: String
    piso: Piso
    inquilino: User
    tituloPiso: String
    direccion: String
    ciudad: String
    imagenPiso: String
  }

  # Paginated response
  type PaginatedReservas {
    items: [Reserva!]!
    page: Int!
    perPage: Int!
    totalItems: Int!
    totalPages: Int!
  }

  # Input types
  input ReservaInput {
    piso_id: String!
    fecha_inc: String!
    fecha_fin: String!
  }

  extend type Query {
    reservas(page: Int, perPage: Int, limit: Int): PaginatedReservas!
    misReservas(page: Int, perPage: Int): [Reserva!]!
    reserva(id: ID!): Reserva
  }

  extend type Mutation {
    createReserva(input: ReservaInput!): Reserva!
    updateReserva(id: ID!, estado: String): Reserva!
    cancelarReserva(id: ID!): SuccessResponse!
    deleteReserva(id: ID!): SuccessResponse!
  }
`;
