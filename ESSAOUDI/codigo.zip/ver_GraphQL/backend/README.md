# GraphQL Backend - ADI Project

Este es el backend GraphQL para el proyecto de comparación API REST vs GraphQL.

## Instalación

```bash
npm install
```

## Ejecutar

```bash
# Modo desarrollo
npm run dev

# Modo producción
npm start
```

El servidor estará disponible en:
- GraphQL Playground: http://localhost:4000/graphql
- Health check: http://localhost:4000/health

## Requisitos

- PocketBase corriendo en http://127.0.0.1:8090
- Node.js 18+


## Ejemplos si quereis ver que el backend funciona, porque todavia no tenelos el frontend hecho

### Register
```graphql
mutation {
  register(input: {
    username: "test"
    email: "test@test.com"
    password: "12345678"
    passwordConfirm: "12345678"
    nombre: "Test"
    rol: "inquilino"
  }) {
    user {
      id
      username
      email
    }
    token
  }
}
```

### Login
```graphql
mutation {
  login(input: {
    email: "test@test.com"
    password: "12345678"
  }) {
    user {
      id
      username
      email
      rol
    }
    token
  }
}
```

### Listar pisos con filtros
```graphql
query {
  pisos(page: 1, perPage: 10, ciudad: "Alicante") {
    items {
      id
      titulo
      precio
      direccion
      ciudad
      primeraImagen
    }
    totalItems
    totalPages
  }
}
```
### Listar reservas
query {
  reservas(page: 1, perPage: 5) {
    items {
      id
      fecha_inc
      fecha_fin
      estado
      piso {
        titulo
      }
    }
  }
}