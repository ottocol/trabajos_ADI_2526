import { pb } from '../config/pb.js';
import { GraphQLError } from 'graphql';

export const authResolvers = {
  Query: {
    me: async (_, __, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }
      return context.user;
    }
  },

  Mutation: {
    register: async (_, { input }) => {
      try {
        if (input.password !== input.passwordConfirm) {
          throw new GraphQLError('Passwords do not match');
        }

        // Prepare payload for PocketBase
        const createPayload = { ...input };
        if (input.role && !input.rol) createPayload.rol = input.role;

        // If image is present, pass as file
        let user;
        try {
          if (input.image) {
            // PocketBase file fields expect an array, even for a single file
            user = await pb.collection('users').create({
              ...createPayload,
              image: [input.image]
            });
          } else {
            user = await pb.collection('users').create(createPayload);
          }
        } catch (pbErr) {
          console.error('PocketBase create error:', pbErr);
          if (pbErr?.response) {
            console.error('PocketBase error response:', JSON.stringify(pbErr.response, null, 2));
          }
          throw new GraphQLError('PocketBase error: ' + (pbErr?.message || pbErr));
        }

        // Auto-login
        const authData = await pb.collection('users').authWithPassword(input.email, input.password);

        return {
          user: authData.record,
          token: authData.token
        };
      } catch (err) {
        console.error('Registration failed:', err);
        throw new GraphQLError('Registration failed: ' + err.message);
      }
    },

    login: async (_, { input }) => {
      try {
        const authData = await pb.collection('users').authWithPassword(input.email, input.password);
        return {
          user: authData.record,
          token: authData.token
        };
      } catch (err) {
        throw new GraphQLError('Login failed: ' + err.message);
      }
    },

    logout: async () => {
      pb.authStore.clear();
      return { success: true, message: 'Logged out successfully' };
    }
  }
};
