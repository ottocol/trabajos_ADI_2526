import { pb } from '../config/pb.js';
import { GraphQLError } from 'graphql';

export const pisoResolvers = {
  Query: {
    pisos: async (_, { page = 1, perPage = 10, ciudad, precioMin, precioMax, num_habit }) => {
      try {
        const conditions = [];

        if (ciudad) conditions.push(`ciudad ~ "${ciudad}"`);
        if (precioMin) conditions.push(`precio >= ${precioMin}`);
        if (precioMax) conditions.push(`precio <= ${precioMax}`);
        if (num_habit) conditions.push(`num_habit = ${num_habit}`);

        const filter = conditions.length > 0 ? conditions.join(' && ') : '';

        const result = await pb.collection('pisos').getList(page, perPage, {
          filter,
          sort: '-created',
          expand: 'propietario_id',
          $autoCancel: false
        });

        // Add primeraImagen field
        const items = result.items.map(piso => ({
          ...piso,
          primeraImagen: piso.imagen && piso.imagen.length > 0
            ? `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${piso.id}/${encodeURIComponent(piso.imagen[0])}`
            : null,
          propietario: piso.expand?.propietario_id
        }));

        return {
          items,
          page: result.page,
          perPage: result.perPage,
          totalItems: result.totalItems,
          totalPages: result.totalPages
        };
      } catch (err) {
        throw new GraphQLError('Error fetching pisos: ' + err.message);
      }
    },

    piso: async (_, { id }) => {
      try {
        const piso = await pb.collection('pisos').getOne(id, { expand: 'propietario_id' });
        return {
          ...piso,
          primeraImagen: piso.imagen && piso.imagen.length > 0
            ? `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${piso.id}/${encodeURIComponent(piso.imagen[0])}`
            : null,
          propietario: piso.expand?.propietario_id
        };
      } catch (err) {
        throw new GraphQLError('Piso not found: ' + err.message);
      }
    },

    misAnuncios: async (_, { page = 1, perPage = 50 }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const result = await pb.collection('pisos').getList(page, perPage, {
          filter: `propietario_id = "${context.user.id}"`,
          sort: '-created'
        });

        return result.items.map(piso => ({
          ...piso,
          primeraImagen: piso.imagen && piso.imagen.length > 0
            ? `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${piso.id}/${encodeURIComponent(piso.imagen[0])}`
            : null
        }));
      } catch (err) {
        throw new GraphQLError('Error fetching user pisos: ' + err.message);
      }
    },

    pisosAdmin: async (_, { page = 1, perPage = 10, searchText = '' }) => {
      try {
        const filter = searchText
          ? `(titulo ~ "${searchText}" || ciudad ~ "${searchText}" || direccion ~ "${searchText}")`
          : '';

        const result = await pb.collection('pisos').getList(page, perPage, {
          filter,
          sort: '-created',
          expand: 'propietario_id',
          $autoCancel: false
        });

        const items = result.items.map(piso => ({
          ...piso,
          primeraImagen: piso.imagen && piso.imagen.length > 0
            ? `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${piso.id}/${encodeURIComponent(piso.imagen[0])}`
            : null,
          propietario: piso.expand?.propietario_id
        }));

        return {
          items,
          page: result.page,
          perPage: result.perPage,
          totalItems: result.totalItems,
          totalPages: result.totalPages
        };
      } catch (err) {
        throw new GraphQLError('Error fetching pisos admin: ' + err.message);
      }
    }
  },

  Mutation: {
    createPiso: async (_, { input }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const isAdmin = context.user.rol === 'admin';
        const pisoData = {
          ...input,
          propietario_id: isAdmin && input.propietario_id ? input.propietario_id : context.user.id
        };

        return await pb.collection('pisos').create(pisoData);
      } catch (err) {
        throw new GraphQLError('Error creating piso: ' + err.message);
      }
    },

    updatePiso: async (_, { id, input }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const piso = await pb.collection('pisos').getOne(id);
        const isAdmin = context.user.rol === 'admin';

        if (!isAdmin && piso.propietario_id !== context.user.id) {
          throw new GraphQLError('Not authorized to update this piso', {
            extensions: { code: 'FORBIDDEN' }
          });
        }

        return await pb.collection('pisos').update(id, input);
      } catch (err) {
        throw new GraphQLError('Error updating piso: ' + err.message);
      }
    },

    deletePiso: async (_, { id }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const piso = await pb.collection('pisos').getOne(id);
        const isAdmin = context.user.rol === 'admin';

        if (!isAdmin && piso.propietario_id !== context.user.id) {
          throw new GraphQLError('Not authorized to delete this piso', {
            extensions: { code: 'FORBIDDEN' }
          });
        }

        // 1. ELIMINAR TODAS LAS RESERVAS DE ESTE PISO
        try {
          const reservas = await pb.collection('reservas').getFullList({
            filter: `piso_id = "${id}"`,
            $autoCancel: false
          });
          
          for (const reserva of reservas) {
            await pb.collection('reservas').delete(reserva.id);
          }
          console.log(`✅ Eliminadas ${reservas.length} reservas del piso ${id}`);
        } catch (reservaErr) {
          console.log('No hay reservas o error eliminándolas:', reservaErr.message);
        }

        //ELIMINAR TODOS LOS COMENTARIOS DE ESTE PISO
        try {
          const comentarios = await pb.collection('comentarios').getFullList({
            filter: `piso_id = "${id}"`,
            $autoCancel: false
          });
          
          for (const comentario of comentarios) {
            await pb.collection('comentarios').delete(comentario.id);
          }
          console.log(`✅ Eliminados ${comentarios.length} comentarios del piso ${id}`);
        } catch (comentarioErr) {
          console.log('No hay comentarios o error eliminándolos:', comentarioErr.message);
        }

        // AHORA ELIMINAR EL PISO
        await pb.collection('pisos').delete(id);
        
        return { 
          success: true, 
          message: 'Piso eliminado correctamente junto con sus reservas y comentarios' 
        };
      } catch (err) {
        console.error('Error completo eliminando piso:', err);
        throw new GraphQLError('Error deleting piso: ' + err.message);
      }
    }

    
  }
};
