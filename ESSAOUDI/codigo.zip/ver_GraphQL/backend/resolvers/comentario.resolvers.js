import { pb } from '../config/pb.js';
import { GraphQLError } from 'graphql';

export const comentarioResolvers = {
  Query: {
    comentarios: async (_, { page = 1, perPage = 10, piso_id }) => {
      try {
        const filter = piso_id ? `piso_id = "${piso_id}"` : '';

        const result = await pb.collection('comentarios').getList(page, perPage, {
          filter,
          sort: '-created',
          expand: 'usuario_id,piso_id',
          $autoCancel: false
        });

        const items = result.items.map(com => ({
          ...com,
          usuario: com.expand?.usuario_id,
          piso: com.expand?.piso_id
        }));

        return {
          items,
          page: result.page,
          perPage: result.perPage,
          totalItems: result.totalItems,
          totalPages: result.totalPages
        };
      } catch (err) {
        throw new GraphQLError('Error fetching comentarios: ' + err.message);
      }
    },

    comentario: async (_, { id }) => {
      try {
        const com = await pb.collection('comentarios').getOne(id, { expand: 'usuario_id,piso_id' });
        return {
          ...com,
          usuario: com.expand?.usuario_id,
          piso: com.expand?.piso_id
        };
      } catch (err) {
        throw new GraphQLError('Comentario not found: ' + err.message);
      }
    }
  },

  Mutation: {
    createComentario: async (_, { input }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const comentarioData = {
          ...input,
          usuario_id: context.user.id
        };

        return await pb.collection('comentarios').create(comentarioData);
      } catch (err) {
        throw new GraphQLError('Error creating comentario: ' + err.message);
      }
    },

    updateComentario: async (_, { id, input }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const comentario = await pb.collection('comentarios').getOne(id);

        if (comentario.usuario_id !== context.user.id) {
          throw new GraphQLError('Not authorized to update this comment', {
            extensions: { code: 'FORBIDDEN' }
          });
        }

        return await pb.collection('comentarios').update(id, input);
      } catch (err) {
        throw new GraphQLError('Error updating comentario: ' + err.message);
      }
    },

    deleteComentario: async (_, { id }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const comentario = await pb.collection('comentarios').getOne(id);
        const isAdmin = context.user.rol === 'admin';

        if (!isAdmin && comentario.usuario_id !== context.user.id) {
          throw new GraphQLError('Not authorized to delete this comment', {
            extensions: { code: 'FORBIDDEN' }
          });
        }

        await pb.collection('comentarios').delete(id);
        return { success: true, message: 'Comentario deleted successfully' };
      } catch (err) {
        throw new GraphQLError('Error deleting comentario: ' + err.message);
      }
    }
  }
};
