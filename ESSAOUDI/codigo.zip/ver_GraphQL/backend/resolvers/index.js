import { authResolvers } from './auth.resolvers.js';
import { userResolvers } from './user.resolvers.js';
import { pisoResolvers } from './piso.resolvers.js';
import { comentarioResolvers } from './comentario.resolvers.js';
import { reservaResolvers } from './reserva.resolvers.js';

// Merge all resolvers
export const resolvers = {
  Query: {
    ...authResolvers.Query,
    ...userResolvers.Query,
    ...pisoResolvers.Query,
    ...comentarioResolvers.Query,
    ...reservaResolvers.Query
  },
  Mutation: {
    ...authResolvers.Mutation,
    ...userResolvers.Mutation,
    ...pisoResolvers.Mutation,
    ...comentarioResolvers.Mutation,
    ...reservaResolvers.Mutation
  },
  User: {
    ...userResolvers.User
  },
  Piso: {
    ...pisoResolvers.Piso
  },
  Reserva: {
    ...reservaResolvers.Reserva
  },
  Comentario: {
    ...comentarioResolvers.Comentario
  }
};
