import { pb } from '../config/pb.js';
import { GraphQLError } from 'graphql';

export const reservaResolvers = {
  Query: {
    reservas: async (_, { page = 1, perPage = 50, limit }) => {
      try {
        const actualPerPage = limit || perPage;
        const result = await pb.collection('reservas').getList(page, actualPerPage, {
          sort: '-created',
          expand: 'piso_id,inquilino_id',
          $autoCancel: false
        });

        const items = result.items.map(res => ({
          ...res,
          piso: res.expand?.piso_id,
          inquilino: res.expand?.inquilino_id
        }));

        if (limit) {
          return { items, page: 1, perPage: limit, totalItems: items.length, totalPages: 1 };
        }

        return {
          items,
          page: result.page,
          perPage: result.perPage,
          totalItems: result.totalItems,
          totalPages: result.totalPages
        };
      } catch (err) {
        throw new GraphQLError('Error fetching reservas: ' + err.message);
      }
    },

    misReservas: async (_, { page = 1, perPage = 50 }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const result = await pb.collection('reservas').getList(page, perPage, {
          filter: `inquilino_id = "${context.user.id}"`,
          sort: '-created',
          expand: 'piso_id'
        });

        return result.items.map(reserva => {
          const piso = reserva.expand?.piso_id || {};
          let imagenPiso = null;

          if (Array.isArray(piso.imagen) && piso.imagen.length > 0) {
            imagenPiso = `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${piso.id}/${encodeURIComponent(piso.imagen[0])}`;
          }

          return {
            ...reserva,
            tituloPiso: piso.titulo || 'Piso sin título',
            direccion: piso.direccion || '',
            ciudad: piso.ciudad || '',
            imagenPiso,
            piso
          };
        });
      } catch (err) {
        throw new GraphQLError('Error fetching mis reservas: ' + err.message);
      }
    },

    reserva: async (_, { id }) => {
      try {
        const res = await pb.collection('reservas').getOne(id, { expand: 'piso_id,inquilino_id' });
        return {
          ...res,
          piso: res.expand?.piso_id,
          inquilino: res.expand?.inquilino_id
        };
      } catch (err) {
        throw new GraphQLError('Reserva not found: ' + err.message);
      }
    }
  },

  Mutation: {
    createReserva: async (_, { input }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const reservaData = {
          ...input,
          inquilino_id: context.user.id,
          estado: 'pendiente'
        };

        return await pb.collection('reservas').create(reservaData);
      } catch (err) {
        throw new GraphQLError('Error creating reserva: ' + err.message);
      }
    },

    updateReserva: async (_, { id, estado }) => {
      try {
        return await pb.collection('reservas').update(id, { estado });
      } catch (err) {
        throw new GraphQLError('Error updating reserva: ' + err.message);
      }
    },

    cancelarReserva: async (_, { id }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        const reserva = await pb.collection('reservas').getOne(id);

        if (reserva.inquilino_id !== context.user.id) {
          throw new GraphQLError('Not authorized to cancel this reserva', {
            extensions: { code: 'FORBIDDEN' }
          });
        }

        if (reserva.estado === 'cancelada') {
          throw new GraphQLError('Reserva already cancelled');
        }

        if (reserva.estado === 'completada') {
          throw new GraphQLError('Cannot cancel completed reserva');
        }

        await pb.collection('reservas').update(id, {
          estado: 'cancelada'
        });

        return { success: true, message: 'Reserva cancelled successfully' };
      } catch (err) {
        throw new GraphQLError('Error cancelling reserva: ' + err.message);
      }
    },

    deleteReserva: async (_, { id }) => {
      try {
        await pb.collection('reservas').delete(id);
        return { success: true, message: 'Reserva deleted successfully' };
      } catch (err) {
        throw new GraphQLError('Error deleting reserva: ' + err.message);
      }
    }
  }
};
