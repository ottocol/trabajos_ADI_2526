import { pb } from '../config/pb.js';
import { GraphQLError } from 'graphql';

export const userResolvers = {
  User: {
    // Normalize image field to always be an array
    image: (parent) => {
      if (!parent.image) return [];
      if (Array.isArray(parent.image)) return parent.image;
      if (typeof parent.image === 'string') {
        return parent.image ? [parent.image] : [];
      }
      return [];
    },
    // Normalize telefono field
    telefono: (parent) => {
      return parent.telefono || parent.tel || '';
    }
  },

  Query: {
    users: async (_, { page = 1, perPage = 20, searchText = '', rol = '' }) => {
      try {
        let filter = '';
        const conditions = [];

        if (searchText) {
          conditions.push(`(username ~ "${searchText}" || nombre ~ "${searchText}" || email ~ "${searchText}")`);
        }
        if (rol) {
          conditions.push(`rol = "${rol}"`);
        }

        if (conditions.length > 0) {
          filter = conditions.join(' && ');
        }

        const result = await pb.collection('users').getList(page, perPage, {
          filter,
          sort: '-created',
          $autoCancel: false
        });

        return {
          items: result.items,
          page: result.page,
          perPage: result.perPage,
          totalItems: result.totalItems,
          totalPages: result.totalPages
        };
      } catch (err) {
        throw new GraphQLError('Error fetching users: ' + err.message);
      }
    },

    user: async (_, { id }) => {
      try {
        return await pb.collection('users').getOne(id);
      } catch (err) {
        throw new GraphQLError('User not found: ' + err.message);
      }
    }
  },

  Mutation: {
    createUser: async (_, { input }) => {
      try {
        return await pb.collection('users').create(input);
      } catch (err) {
        throw new GraphQLError('Error creating user: ' + err.message);
      }
    },

    updateUser: async (_, { id, input }) => {
      try {
        return await pb.collection('users').update(id, input);
      } catch (err) {
        throw new GraphQLError('Error updating user: ' + err.message);
      }
    },

    deleteUser: async (_, { id }, context) => {
      if (!context.user || context.user.rol !== 'admin') {
        throw new GraphQLError('Not authorized. Admin only.', {
          extensions: { code: 'FORBIDDEN' }
        });
      }
      
      try {
        // 1. ELIMINAR TODOS LOS PISOS DE ESTE USUARIO (con sus relaciones)
        try {
          const pisosUsuario = await pb.collection('pisos').getFullList({
            filter: `propietario_id = "${id}"`,
            $autoCancel: false
          });
          
          for (const piso of pisosUsuario) {
            // Eliminar reservas del piso
            const reservasPiso = await pb.collection('reservas').getFullList({
              filter: `piso_id = "${piso.id}"`,
              $autoCancel: false
            });
            
            for (const reserva of reservasPiso) {
              await pb.collection('reservas').delete(reserva.id);
            }
            
            // Eliminar comentarios del piso
            const comentariosPiso = await pb.collection('comentarios').getFullList({
              filter: `piso_id = "${piso.id}"`,
              $autoCancel: false
            });
            
            for (const comentario of comentariosPiso) {
              await pb.collection('comentarios').delete(comentario.id);
            }
            
            // Ahora eliminar el piso
            await pb.collection('pisos').delete(piso.id);
          }
          console.log(`✅ Eliminados ${pisosUsuario.length} pisos del usuario ${id}`);
        } catch (pisoErr) {
          console.log('No hay pisos o error eliminándolos:', pisoErr.message);
        }

        // 2. ELIMINAR RESERVAS DONDE EL USUARIO ES INQUILINO
        try {
          const reservasInquilino = await pb.collection('reservas').getFullList({
            filter: `inquilino_id = "${id}"`,
            $autoCancel: false
          });
          
          for (const reserva of reservasInquilino) {
            await pb.collection('reservas').delete(reserva.id);
          }
          console.log(`✅ Eliminadas ${reservasInquilino.length} reservas como inquilino del usuario ${id}`);
        } catch (reservaErr) {
          console.log('No hay reservas como inquilino o error eliminándolas:', reservaErr.message);
        }

        // 3. ELIMINAR COMENTARIOS DEL USUARIO
        try {
          const comentariosUsuario = await pb.collection('comentarios').getFullList({
            filter: `usuario_id = "${id}"`,
            $autoCancel: false
          });
          
          for (const comentario of comentariosUsuario) {
            await pb.collection('comentarios').delete(comentario.id);
          }
          console.log(`✅ Eliminados ${comentariosUsuario.length} comentarios del usuario ${id}`);
        } catch (comentarioErr) {
          console.log('No hay comentarios o error eliminándolos:', comentarioErr.message);
        }

        // 4. AHORA SÍ ELIMINAR EL USUARIO
        await pb.collection('users').delete(id);
        
        return { 
          success: true, 
          message: 'Usuario eliminado correctamente con todos sus datos relacionados' 
        };
        
      } catch (err) {
        throw new GraphQLError('Error deleting user: ' + err.message);
      }
    },

    deleteMyAccount: async (_, __, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      try {
        await pb.collection('users').delete(context.user.id);
        pb.authStore.clear();
        return { success: true, message: 'Account deleted successfully' };
      } catch (err) {
        throw new GraphQLError('Error deleting account: ' + err.message);
      }
    },

    updatePerfil: async (_, { id, input }, context) => {
      if (!context.user) {
        throw new GraphQLError('Not authenticated', {
          extensions: { code: 'UNAUTHENTICATED' }
        });
      }

      if (context.user.id !== id) {
        throw new GraphQLError('Cannot update another user profile', {
          extensions: { code: 'FORBIDDEN' }
        });
      }

      try {
        return await pb.collection('users').update(id, input);
      } catch (err) {
        throw new GraphQLError('Error updating profile: ' + err.message);
      }
    }
  }
};
