<template>
  <div class="reserva-view">
    <!-- Header -->
    <header class="site-header">
      <div class="logo">
        <img :src="logoImg" alt="Logo rentEase">
      </div>
      <div class="header-buttons">
        <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <!-- Contenido Principal -->
    <div class="reserva-container">
      <h2 class="reserva-title">Reservar Piso</h2>

      <!-- Estados de carga -->
      <div v-if="loading" class="loading-state">
        <p>Cargando información del piso...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
        <router-link to="/" class="btn btn-primary">Volver al inicio</router-link>
      </div>

      <template v-else>
        <!-- Información del piso -->
        <div class="info-piso">
          <div class="info-group">
            <span class="info-label">Piso</span>
            <div class="info-value">{{ piso.titulo }}</div>
          </div>
          <div class="info-group">
            <span class="info-label">Dirección</span>
            <div class="info-value">{{ piso.direccion }}</div>
          </div>
          <div class="info-group">
            <span class="info-label">Precio por noche</span>
            <div class="info-value">{{ formatPrecio(piso.precio) }}</div>
          </div>
        </div>

        <!-- Formulario de reserva -->
        <form @submit.prevent="confirmarReserva">
          <div class="form-group">
            <label class="form-label">Fecha de inicio</label>
            <input 
              type="date" 
              class="form-input" 
              v-model="fechaInicio" 
              :min="minDate"
              required
            >
          </div>
          
          <div class="form-group">
            <label class="form-label">Fecha de fin</label>
            <input 
              type="date" 
              class="form-input" 
              v-model="fechaFin" 
              :min="fechaInicio || minDate"
              required
            >
          </div>
          
          <div class="precio-total">
            {{ precioTotalText }}
          </div>
          
          <div class="reserva-actions">
            <button 
              type="submit" 
              class="btn-confirmar"
              :disabled="!fechaInicio || !fechaFin || diffDays <= 0 || enviando"
            >
              {{ enviando ? 'Procesando...' : 'Confirmar Reserva' }}
            </button>
            <router-link to="/" class="btn-cancelar">Cancelar</router-link>
          </div>
        </form>
      </template>
    </div>

    <!-- Footer -->
    <footer class="site-footer">
      <p>&copy; 2025 rentEase. Todos los derechos reservados.</p>
      <p>Contacto | Política de privacidad</p>
    </footer>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { getPisoById } from '@/services/pisos.service'
import { createReserva } from '@/services/reservas.service'
import logoImg from '@/images/rentEase_logo.jpg'

const route = useRoute()
const router = useRouter()

// Datos reactivos
const piso = ref({
  id: '',
  titulo: '',
  direccion: '',
  precio: 0
})
const fechaInicio = ref('')
const fechaFin = ref('')
const loading = ref(false)
const enviando = ref(false)
const error = ref(null)

// Fecha mínima (hoy)
const minDate = computed(() => {
  return new Date().toISOString().split('T')[0]
})

// Cálculo de días y precio total
const diffDays = computed(() => {
  if (!fechaInicio.value || !fechaFin.value) return 0
  
  const inicio = new Date(fechaInicio.value)
  const fin = new Date(fechaFin.value)
  const diffTime = fin - inicio
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
})

const precioTotal = computed(() => {
  return diffDays.value > 0 ? diffDays.value * piso.value.precio : 0
})

const precioTotalText = computed(() => {
  if (diffDays.value <= 0) return 'Total: 0 €'
  return `Total: ${precioTotal.value} € (${diffDays.value} noches)`
})

// Formatear precio
const formatPrecio = (precio) => {
  return precio ? `${precio} €` : '0 €'
}

// Cargar información del piso desde GraphQL
const cargarPiso = async () => {
  loading.value = true
  error.value = null
  
  try {
    const pisoId = route.params.id
    const pisoData = await getPisoById(pisoId)
    
    piso.value = {
      id: pisoData.id,
      titulo: pisoData.titulo || 'Piso sin título',
      direccion: pisoData.direccion || 'Dirección no disponible',
      precio: pisoData.precio || 0
    }
    
  } catch (err) {
    console.error('Error cargando piso:', err)
    error.value = 'Error al cargar la información del piso.'
  }
  
  loading.value = false
}

// Confirmar reserva
const confirmarReserva = async () => {
  if (diffDays.value <= 0) {
    alert('Las fechas seleccionadas no son válidas')
    return
  }

  enviando.value = true

  try {
    const userId = localStorage.getItem('userId')
    const authToken = localStorage.getItem('token')
    
    console.log('🔑 Token encontrado:', !!authToken)
    console.log('👤 User ID:', userId)
    
    if (!userId || !authToken) {
      alert('No estás autenticado. Por favor, inicia sesión nuevamente.')
      router.push('/login')
      return
    }

    const datosReserva = {
      piso_id: piso.value.id,
      fecha_inc: `${fechaInicio.value}T12:00:00.000Z`,
      fecha_fin: `${fechaFin.value}T12:00:00.000Z`
    }

    console.log('📤 Enviando reserva:', datosReserva)

    const reservaCreada = await createReserva(datosReserva)
    console.log('✅ Reserva creada exitosamente:', reservaCreada)
    
    alert('¡Reserva realizada correctamente! Estado: pendiente')
    router.push('/mis-reservas')

  } catch (err) {
    console.error('💥 Error completo creando reserva:', err)
    alert(`Error al realizar la reserva: ${err.message}`)
  }
  
  enviando.value = false
}

// Desconectar
const desconectar = () => {
  localStorage.removeItem('userId')
  localStorage.removeItem('token')
  localStorage.removeItem('currentUser')
  localStorage.removeItem('userRole')
  router.push('/')
}

// Watch para recalcular cuando cambian las fechas
watch([fechaInicio, fechaFin], () => {
  if (fechaInicio.value && fechaFin.value) {
    const inicio = new Date(fechaInicio.value)
    const fin = new Date(fechaFin.value)
    
    if (fin < inicio) {
      fechaFin.value = fechaInicio.value
    }
  }
})

// Verificar autenticación al cargar
onMounted(() => {
  const token = localStorage.getItem('token')
  const userId = localStorage.getItem('userId')
  
  console.log('🔍 Verificando autenticación al cargar:')
  console.log('Token:', token)
  console.log('User ID:', userId)
  
  if (!token || !userId) {
    alert('Debes iniciar sesión para realizar una reserva')
    router.push('/login')
    return
  }
  
  cargarPiso()
})
</script>

<style scoped>
.reserva-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
}

.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
  position: static;
  top: 0;
}

.logo img {
  height: 60px;
}

.header-buttons .btn {
  margin-left: 1rem;
  padding: 0.5rem 1rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  background: none;
  cursor: pointer;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover {
  background-color: #0056b3;
  color: white;
}

.reserva-container {
  background: white;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  width: 75%;
  max-width: 600px;
  margin: 2rem auto;
}

.reserva-title {
  text-align: center;
  margin-bottom: 1.5rem;
  color: #333;
}

.info-piso {
  background: #f8f9fa;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1.5rem;
  border-left: 4px solid #007bff;
}

.info-group {
  margin-bottom: 0.5rem;
}

.info-label {
  display: block;
  margin-bottom: 0.2rem;
  color: #555;
  font-weight: bold;
}

.info-value {
  color: #333;
}

.form-group {
  margin-bottom: 1rem;
}

.form-label {
  display: block;
  margin-bottom: 0.5rem;
  color: #333;
  font-weight: bold;
}

.form-input {
  width: 100%;
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
  box-sizing: border-box;
}

.form-input:focus {
  outline: none;
  border-color: #007bff;
}

.precio-total {
  background: #e7f3ff;
  padding: 1rem;
  border-radius: 6px;
  text-align: center;
  font-size: 1.2rem;
  font-weight: bold;
  color: #007bff;
  margin: 1.5rem 0;
}

.reserva-actions {
  display: flex;
  gap: 1rem;
  margin-top: 1.5rem;
}

.btn-confirmar {
  flex: 2;
  padding: 0.75rem 1.5rem;
  background: #28a745;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 1rem;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  text-align: center;
}

.btn-confirmar:hover:not(:disabled) {
  background: #218838;
}

.btn-confirmar:disabled {
  background: #6c757d;
  cursor: not-allowed;
}

.btn-cancelar {
  flex: 1;
  padding: 0.75rem 1.5rem;
  background: #6c757d;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 1rem;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  text-align: center;
}

.btn-cancelar:hover {
  background: #545b62;
}

.site-footer {
  background-color: #f1f1f1;
  color: #333;
  text-align: center;
  padding: 20px 0;
  font-size: 0.9rem;
  border-top: 1px solid #ccc;
}

.site-footer a {
  color: #007bff;
  text-decoration: none;
  margin: 0 5px;
}

.site-footer a:hover {
  text-decoration: underline;
}

.loading-state,
.error-state {
  text-align: center;
  padding: 3rem;
  color: #666;
}

.error-state {
  color: #dc3545;
}

.error-state .btn {
  margin-top: 1rem;
}

@media (max-width: 768px) {
  .reserva-container {
    width: 90%;
    padding: 1rem;
  }
  
  .reserva-actions {
    flex-direction: column;
  }
  
  .header-buttons {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .header-buttons .btn {
    margin-left: 0;
  }
}

@media (max-width: 480px) {
  .site-header {
    flex-direction: column;
    gap: 1rem;
    padding: 1rem;
  }
  
  .header-buttons {
    width: 100%;
    justify-content: center;
  }
}
</style>
