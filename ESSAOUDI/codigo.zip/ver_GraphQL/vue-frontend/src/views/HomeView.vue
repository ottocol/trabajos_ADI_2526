﻿<template>
  <div class="home-view">
    <AppHeader>
      <template #buttons>
        <router-link to="/login" class="btn">Login</router-link>
        <router-link to="/registro" class="btn btn-primary">Registrar</router-link>
      </template>
    </AppHeader>

    <div class="main-layout">
      <main class="anuncios-container">

        <template v-if="loading">
          <p>Cargando pisos...</p>
        </template>

        <template v-else-if="items.length === 0">
          <p>No hay pisos disponibles.</p>
        </template>

        <template v-else>
          <div class="cards-grid">
            <div v-for="(item, idx) in items" :key="item.id" class="anuncio-card">
              
              <img :src="getImage(item, idx)"
                   :alt="item.titulo"
                   class="anuncio-img">

              <div class="anuncio-info">
                <h3 class="titulo">{{ item.titulo }}</h3>

                <p class="descripcion" v-if="item.descripcion">
                  {{ item.descripcion }}
                </p>

                <p><strong>Dirección:</strong> {{ item.direccion }}</p>

                <p class="precio">
                  {{ formatPrice(item.precio) }}
                </p>

                <router-link 
                  :to="{ name: 'PisoDetalle', params: { id: item.id }}"
                  class="btn-ver-detalle">
                  Ver Detalles
                </router-link>
              </div>

            </div>
          </div>
        </template>

        <!-- Pagination controls -->
        <div v-if="!loading && items.length" style="display:flex; gap:8px; align-items:center; justify-content:center; margin:18px 0">
          <button class="btn" :disabled="page <= 1" @click="goPrev">Anterior</button>
          <div> Página {{ page }} de {{ totalPages }}  {{ totalItems }} pisos </div>
          <button class="btn" :disabled="page >= totalPages" @click="goNext">Siguiente</button>
        </div>

      </main>

      <FiltersPanel />
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref, onMounted, provide } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { usePisosStore } from '@/stores/pisos'
import { getPisos } from '@/services'
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import FiltersPanel from '@/components/Layout/FiltersPanel.vue'

const router = useRouter()
const authStore = useAuthStore()
const pisosStore = usePisosStore()

const items = ref([])
const loading = ref(false)
const page = ref(1)
const perPage = ref(9)
const totalPages = ref(1)
const totalItems = ref(0)


function formatPrice(p) {
  return p ? `${p} € / noche` : ''
}

function getImage(item, idx = 0) {
  // Check for primeraImagen first
  if (item.primeraImagen) {
    return item.primeraImagen
  }
  
  // Check for imagen array
  if (item.imagen && item.imagen.length > 0) {
    const imgs = Array.isArray(item.imagen) ? item.imagen : item.imagen.split(',')
    return imgs[0]
  }

  const localImages = [
    '/images/house1.jpg',
    '/images/villa1.jpg',
    '/images/piso-ejemplo.jpeg',
    '/images/3.jpg'
  ]
  return localImages[idx % localImages.length]
}

const cargarPisos = async (filtrosAplicados = {}) => {
  loading.value = true
  try {
    // Construir filtros para GraphQL 
    const filters = {}
    if (filtrosAplicados.ciudad) filters.ciudad = filtrosAplicados.ciudad
    
    if (filtrosAplicados.precioMin) filters.precioMin = parseFloat(filtrosAplicados.precioMin)
    if (filtrosAplicados.precioMax) filters.precioMax = parseFloat(filtrosAplicados.precioMax)
    
    if (filtrosAplicados.habitaciones) filters.num_habit = parseInt(filtrosAplicados.habitaciones)
    
    if (filtrosAplicados.banos) filters.banos = parseInt(filtrosAplicados.banos)
    
    if (filtrosAplicados.disponible !== undefined) filters.disponible = filtrosAplicados.disponible

    console.log('🔍 Filtros enviados a GraphQL:', filters)
    
    const result = await getPisos(page.value, perPage.value, filters)

    items.value = result.items || []
    page.value = result.page || page.value
    perPage.value = result.perPage || perPage.value
    totalItems.value = result.totalItems || 0
    totalPages.value = result.totalPages || 1
    
    console.log('📊 Resultados recibidos:', {
      itemsCount: items.value.length,
      page: page.value,
      totalItems: totalItems.value
    })
  } catch (err) {
    console.error('❌ Error cargando pisos:', err)
    items.value = []
  }
  loading.value = false
}

const manejarCambioFiltros = (nuevosFiltros) => {
  console.log('📡 Filtros recibidos en HomeView:', nuevosFiltros)
  page.value = 1
  cargarPisos(nuevosFiltros)
}

provide('onFiltrosChange', manejarCambioFiltros)


// Handle Mis Reservas button click
const handleMisReservas = () => {
  if (authStore.isAuthenticated) {
    router.push('/mis-reservas')
  } else {
    router.push('/login')
  }
}

onMounted(() => {
  cargarPisos()
})

// pagination helpers
function goPrev() { 
  if (page.value > 1) { 
    page.value -= 1
    cargarPisos(filtros.value) 
  } 
}

function goNext() { 
  if (page.value < totalPages.value) { 
    page.value += 1
    cargarPisos(filtros.value) 
  } 
}
</script>

<style scoped>
.main-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 300px;
  gap: 1.5rem;
  align-items: start;
}

.cards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 18px;
  padding: 8px 8px;
  box-sizing: border-box;
  width: 100%;
}

.anuncios-container {
  display: block;
  width: 100%;
  padding: 0;
  box-sizing: border-box;
}

.anuncio-card {
  background: #ffffff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0px 4px 14px rgba(0,0,0,0.1);
  transition: .25s;
}

.anuncio-card:hover {
  transform: translateY(-4px);
  box-shadow: 0px 6px 18px rgba(0,0,0,0.15);
}

.anuncio-img {
  width: 100%;
  height: 170px;
  object-fit: cover;
  display: block;
}

.anuncio-info {
  padding: 12px;
}

.titulo {
  margin: 0 0 8px;
  font-size: 1.15em;
}

.descripcion {
  color: #555;
  margin-bottom: 10px;
}

.precio {
  font-weight: bold;
  color: #2185d0;
  font-size: 1.05em;
  margin: 10px 0;
}

.btn-ver-detalle {
  display: inline-block;
  padding: 8px 12px;
  background: #2185d0;
  color: white;
  border-radius: 6px;
  text-decoration: none;
}

.btn-ver-detalle:hover {
  background: #1678c2;
}

@media (max-width: 800px) {
  .main-layout {
    grid-template-columns: 1fr;
  }
  .cards-grid {
    grid-template-columns: 1fr;
  }
}

@media (min-width: 1100px) {
  .cards-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
</style>
