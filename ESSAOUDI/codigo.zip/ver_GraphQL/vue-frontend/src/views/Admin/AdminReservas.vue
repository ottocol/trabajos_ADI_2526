<template>
  <AdminLayout>
    <template #default>
      <div class="admin-reservas">
        <div v-if="showEdit" style="position:fixed; top:8px; right:8px; z-index:200001; background:#0f0; color:#000; padding:6px 8px; border-radius:4px; font-weight:700">EDIT OPEN</div>
        <h1>Reservas — Gestión</h1>
        <p>Lista de reservas.</p>
        <div class="actions">
            <button class="btn" @click="load">Refrescar</button>
            <button class="btn" @click="openCreateModal">Crear reserva</button>
          </div>

          <table class="res-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Piso</th>
                <th>Inquilino</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="r in reservas" :key="r.id">
                <td>{{ r.id }}</td>
                <td>{{ r.piso_id || r.piso || r.pisoId || '-' }}</td>
                <td>{{ r.inquilino_id || r.usuario_id || r.user || '-' }}</td>
                <td>{{ r.estado || r.status || '-' }}</td>
                <td>
                  <button type="button" class="btn" @click.stop="showDetails(r)">Ver</button>
                  <button type="button" class="btn" @click.stop="openEdit(r)">Actualizar</button>
                  <button type="button" class="btn btn-danger" @click.stop="remove(r)">Eliminar</button>
                </td>
              </tr>
            </tbody>
          </table>

          <!-- Details modal -->
          <div v-if="selectedReserva" class="modal-backdrop" @click.self="closeDetails">
            <div class="modal">
              <button class="close" @click="closeDetails">×</button>
              <h3>Reserva — {{ selectedReserva.id }}</h3>
              <div class="modal-body">
                <table class="details-table">
                  <tbody>
                    <tr v-for="(val, key) in reservaDetails" :key="key">
                      <th>{{ key }}</th>
                      <td>{{ formatValue(val) }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              
            </div>
          </div>

          <!-- Create modal -->
          <div v-if="showCreate" class="modal-backdrop" @click.self="closeCreateModal">
            <div class="modal">
              <button class="close" @click="closeCreateModal">×</button>
              <h3>Crear Reserva</h3>
              <div class="modal-body">
                <form @submit.prevent="submitCreate">
                  <div class="form-row"><label>Piso</label>
                    <select v-model="reservaForm.piso_id" required>
                      <option value="">-- seleccionar piso --</option>
                      <option v-for="p in pisos" :key="p.id" :value="p.id">{{ p.titulo || p.id }}</option>
                    </select>
                  </div>
                  <div class="form-row"><label>Inquilino (usuario)</label>
                    <select v-model="reservaForm.inquilino_id" required>
                      <option value="">-- seleccionar inquilino --</option>
                      <option v-for="u in inquilinos" :key="u.id" :value="u.id">{{ u.username || u.nombre || u.id }}</option>
                    </select>
                  </div>
                  <div class="form-row"><label>Fecha inicio</label><input type="date" v-model="reservaForm.fecha_inc" required /></div>
                  <div class="form-row"><label>Fecha fin</label><input type="date" v-model="reservaForm.fecha_fin" required /></div>
                  <div class="form-row"><label>Estado</label>
                    <select v-model="reservaForm.estado">
                      <option value="pendiente">pendiente</option>
                      <option value="confirmada">confirmada</option>
                      <option value="cancelada">cancelada</option>
                      <option value="completada">completada</option>
                    </select>
                  </div>
                  <div style="margin-top:12px; display:flex; gap:8px; align-items:center">
                    <button class="btn btn-primary" type="submit" :disabled="creating">Crear</button>
                    <button class="btn" type="button" @click="closeCreateModal">Cancelar</button>
                    <div v-if="createError" class="muted" style="color:#a00">{{ createError }}</div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          
          <!-- Edit modal (separate) -->
          <div v-if="showEdit" class="modal-backdrop" @click.self="closeEdit">
            <div class="modal">
              <button class="close" @click="closeEdit">×</button>
              <h3>Actualizar Reserva — {{ editForm.id }}</h3>
              <div class="modal-body">
                <form @submit.prevent="submitEdit">
                  <div class="form-row"><label>Fecha inicio</label><input type="date" v-model="editForm.fecha_inc" required /></div>
                  <div class="form-row"><label>Fecha fin</label><input type="date" v-model="editForm.fecha_fin" required /></div>
                  <div class="form-row"><label>Estado</label>
                    <select v-model="editForm.estado">
                      <option value="pendiente">pendiente</option>
                      <option value="confirmada">confirmada</option>
                      <option value="cancelada">cancelada</option>
                      <option value="completada">completada</option>
                    </select>
                  </div>
                  <div style="margin-top:12px; display:flex; gap:8px; align-items:center">
                    <button class="btn btn-primary" type="submit" :disabled="editing">Guardar</button>
                    <button class="btn" type="button" @click="closeEdit">Cancelar</button>
                    <div v-if="editError" class="muted" style="color:#a00">{{ editError }}</div>
                  </div>
                </form>
              </div>
            </div>
          </div>

      </div>
    </template>
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted, computed, watch, nextTick } from 'vue'
import AdminLayout from '@/components/Layout/AdminLayout.vue'
import { graphqlRequest } from '@/services/graphql'
const reservas = ref([])
const loading = ref(false)
const selectedReserva = ref(null)
const showCreate = ref(false)
const creating = ref(false)
const createError = ref('')
const reservaForm = ref({ piso_id: '', inquilino_id: '', fecha_inc: '', fecha_fin: '', estado: 'pendiente' })
const pisos = ref([])
const inquilinos = ref([])
const showEdit = ref(false)
const editing = ref(false)
const editError = ref('')
const editForm = ref({ id: '', fecha_inc: '', fecha_fin: '', estado: 'pendiente' })

async function load() {
  loading.value = true
  try {
    const query = `
      query GetReservas {
        reservas(page: 1, perPage: 100) {
          items {
            id
            piso_id
            inquilino_id
            fecha_inc
            fecha_fin
            estado
          }
        }
      }
    `
    
    const data = await graphqlRequest(query)
    if (data && data.reservas) {
      reservas.value = data.reservas.items || []
    } else {
      reservas.value = []
    }
  } catch (e) {
    console.error('Error loading reservas', e)
    reservas.value = []
  }
  loading.value = false
}

async function remove(r) {
  if (!confirm('Eliminar reserva ' + r.id + '?')) return
  try {
    const mutation = `
      mutation DeleteReserva($id: ID!) {
        deleteReserva(id: $id) {
          success
          message
        }
      }
    `
    
    const data = await graphqlRequest(mutation, { id: r.id })
    if (data && data.deleteReserva && data.deleteReserva.success) {
      await load()
    } else {
      alert('Error eliminando')
    }
  } catch (e) { console.error(e); alert('Error eliminando') }
}

function formatValue(v) {
  if (v === null || v === undefined) return '-'
  if (typeof v === 'object') return JSON.stringify(v)
  return String(v)
}

const reservaDetails = computed(() => {
  const r = selectedReserva.value || {}
  const src = r.record ? { ...r.record, ...r } : r
  const exclude = new Set(['expand', 'collectionId', 'collection_name', 'collectionName', 'imagen', 'record'])
  return Object.keys(src)
    .filter(k => !exclude.has(k))
    .reduce((acc, k) => { acc[k] = src[k]; return acc }, {})
})

function closeDetails() { selectedReserva.value = null }

async function showDetails(r) {
  try {
    console.log('showDetails called for', r && r.id)
    if (showEdit.value) {
      console.log('showDetails skipped because edit modal is open')
      return
    }
    
    const query = `
      query GetReserva($id: ID!) {
        reserva(id: $id) {
          id
          piso_id
          inquilino_id
          fecha_inc
          fecha_fin
          estado
          created
          updated
        }
      }
    `
    
    const data = await graphqlRequest(query, { id: r.id })
    
    if (data && data.reserva) {
      selectedReserva.value = data.reserva
    } else {
      alert('Error cargando detalles: Reserva no encontrada')
    }
  } catch (e) { 
    console.error(e); 
    alert('Error cargando detalles: ' + e.message) 
  }
}

function openCreateModal() {
  createError.value = ''
  reservaForm.value = { piso_id: '', inquilino_id: '', fecha_inc: '', fecha_fin: '', estado: 'pendiente' }
  
  // Query GraphQL para obtener pisos
  const pisosQuery = `
    query GetPisos {
      pisos(page: 1, perPage: 1000) {
        items {
          id
          titulo
        }
      }
    }
  `
  
  // Query GraphQL para obtener inquilinos
  const usuariosQuery = `
    query GetInquilinos {
      users(page: 1, perPage: 1000) {
        items {
          id
          nombre
          username
        }
      }
    }
  `
  
  // Cargar pisos
  graphqlRequest(pisosQuery).then(data => {
    pisos.value = data?.pisos?.items || []
  }).catch(() => { pisos.value = [] })
  
  // Cargar inquilinos
  graphqlRequest(usuariosQuery).then(data => {
    inquilinos.value = data?.users?.items || []
  }).catch(() => { inquilinos.value = [] })
  
  showCreate.value = true
}

function closeCreateModal() { showCreate.value = false }

async function submitCreate() {
  try {
    createError.value = ''
    if (!reservaForm.value.piso_id || !reservaForm.value.inquilino_id || !reservaForm.value.fecha_inc || !reservaForm.value.fecha_fin) {
      createError.value = 'Completa los campos obligatorios'
      return
    }
    creating.value = true
    
    const mutation = `
      mutation CreateReserva($input: ReservaInput!) {
        createReserva(input: $input) {
          id
          piso_id
          inquilino_id
          fecha_inc
          fecha_fin
          estado
        }
      }
    `
    
    const input = {
      piso_id: reservaForm.value.piso_id,
      fecha_inc: reservaForm.value.fecha_inc,
      fecha_fin: reservaForm.value.fecha_fin
    }
    
    const data = await graphqlRequest(mutation, { input })
    
    if (data && data.createReserva) {
      await load()
      closeCreateModal()
    } else {
      createError.value = 'Error creando reserva'
    }
  } catch (e) { 
    createError.value = e?.message || String(e) 
  }
  finally { 
    creating.value = false 
  }
}

onMounted(load)

async function openEdit(r) {
  console.log('openEdit called for', r && r.id)
  editError.value = ''
  // Prefer using already-fetched details if available
  let data = null
  if (selectedReserva.value && selectedReserva.value.id === r.id) {
    data = selectedReserva.value
  } else {
    try {
      const query = `
        query GetReserva($id: ID!) {
          reserva(id: $id) {
            id
            fecha_inc
            fecha_fin
            estado
          }
        }
      `
      data = await graphqlRequest(query, { id: r.id })
    } catch (e) { console.warn('Error fetching reserva for edit', e) }
  }

  // Extract fields from whatever shape we have (record or direct)
  const src = data && data.record ? { ...data.record, ...data } : (data || r || {})
  console.log('openEdit: data ->', data)
  console.log('openEdit: src ->', src)
  const normalizeDate = (v) => {
    if (!v) return ''
    // If ISO datetime, take YYYY-MM-DD part
    if (typeof v === 'string' && v.includes('T')) return v.split('T')[0]
    // If already YYYY-MM-DD or Date object
    if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) return v
    try { const d = new Date(v); if (!isNaN(d)) return d.toISOString().split('T')[0] } catch(e) {}
    return ''
  }

  editForm.value = {
    id: r.id,
    fecha_inc: normalizeDate(src.fecha_inc || src.fechaInicio || src.fecha_inicio),
    fecha_fin: normalizeDate(src.fecha_fin || src.fechaFin || src.fecha_fin),
    estado: src.estado || src.status || 'pendiente'
  }
  console.log('openEdit: editForm ->', editForm.value)

  // Close details view if open so modals don't overlap
  selectedReserva.value = null
  showEdit.value = true

  // debug: after DOM update, log how many modal backdrops exist
  nextTick(() => {
    try {
      console.log('DOM modal-backdrop count:', document.querySelectorAll('.modal-backdrop').length)
      const mb = document.querySelector('.modal-backdrop')
      if (mb) console.log('modal-backdrop computed display:', window.getComputedStyle(mb).display, 'visible:', window.getComputedStyle(mb).visibility)
    } catch (e) { console.log('dom debug error', e) }
  })
}

function closeEdit() {
  console.log('closeEdit called — closing edit modal')
  console.trace()
  showEdit.value = false
}

async function submitEdit() {
  try {
    editError.value = ''
    if (!editForm.value.fecha_inc || !editForm.value.fecha_fin) { 
      editError.value = 'Fechas requeridas'; 
      return 
    }
    editing.value = true
    
    const mutation = `
      mutation UpdateReserva($id: ID!, $estado: String) {
        updateReserva(id: $id, estado: $estado) {
          id
          piso_id
          inquilino_id
          fecha_inc
          fecha_fin
          estado
        }
      }
    `
    
    const data = await graphqlRequest(mutation, { 
      id: editForm.value.id, 
      estado: editForm.value.estado 
    })
    
    if (data && data.updateReserva) {
      await load()
      closeEdit()
    } else {
      editError.value = 'Error actualizando reserva'
    }
  } catch (e) { 
    editError.value = e?.message || String(e) 
  }
  finally { 
    editing.value = false 
  }
}

// Debug watches to observe modal state changes
watch(showEdit, (v) => console.log('DEBUG showEdit ->', v))
watch(selectedReserva, (v) => console.log('DEBUG selectedReserva ->', v && v.id ? v.id : v))
</script>

<style scoped>
.admin-reservas { max-width: 1100px; margin: 18px auto }
.res-table th, .res-table td { padding: 8px 10px; border-bottom: 1px solid #eee }

/* Modal styles (self-contained) */
.modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.4); display:flex; align-items:center; justify-content:center; z-index:99999 }
.modal { background: white; border-radius:8px; padding:16px; width:720px; max-width:95%; position:relative; z-index:100000 }
.modal h3 { margin:0 0 12px }
.modal .close { position:absolute; right:8px; top:8px; background:transparent; border:0; font-size:20px }
.modal .modal-body { max-height:70vh; overflow:auto }
.details-table th { text-align:left; padding:6px 8px; width:160px; vertical-align:top }
.details-table td { padding:6px 8px }
/* Add spacing between action buttons in table rows */
.res-table td > .btn { margin-right: 8px }
</style>