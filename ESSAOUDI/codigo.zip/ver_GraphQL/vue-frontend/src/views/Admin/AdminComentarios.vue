<template>
  <AdminLayout>
    <template #default>
      <div class="admin-comentarios">
        <h1>Comentarios — Gestión</h1>
        <p>Lista de comentarios.</p>
        <div class="actions">
          <div style="display:flex; gap:10px; align-items:center; flex-wrap:nowrap;">
            <input v-model="searchId" placeholder="Buscar por ID de comentario" style="padding:6px; width:220px;" />
            <input v-model="filterPiso" placeholder="Filtrar por piso_id" style="padding:6px; width:220px;" />
            <input v-model="filterInquilino" placeholder="Filtrar por usuario_id" style="padding:6px; width:220px;" />
            <button class="btn" @click="applyFilters">Buscar</button>
            <button class="btn" @click="clearFilters">Limpiar</button>
            <button class="btn" @click="load">Refrescar</button>
          </div>
        </div>

        <table class="c-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Usuario</th>
              <th>Piso</th>
              <th>Contenido</th>
              <th>Valoración</th>
              <th>Creado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="c in comentarios" :key="c.id">
              <td>{{ c.id || '-' }}</td>
              <td>
                {{
                  c.usuario_id || 
                  (c.usuario && (c.usuario.username || c.usuario.nombre || c.usuario.email)) ||
                  '-'
                }}
              </td>
              <td>
                {{
                  c.piso_id || 
                  (c.piso && c.piso.titulo) ||
                  '-'
                }}
              </td>
              <td class="muted">{{ c.coment || '-' }}</td>
              <td>
                {{ c.valoracion ? c.valoracion + '/5' : '-' }}
              </td>
              <td>{{ formatDate(c.created) }}</td>
              <td>
                <button class="btn btn-danger" @click="remove(c)">Eliminar</button>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- Pagination controls -->
        <div class="pagination" style="display:flex; gap:8px; align-items:center; margin-top:12px">
          <button class="btn" :disabled="page <= 1" @click="goPrev">Anterior</button>
          <div> Página {{ page }} de {{ totalPages }} — {{ totalItems }} comentarios </div>
          <button class="btn" :disabled="page >= totalPages" @click="goNext">Siguiente</button>
        </div>
      </div>
    </template>
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import AdminLayout from '@/components/Layout/AdminLayout.vue'
import { graphqlRequest } from '@/services/graphql'

const comentarios = ref([])
const loading = ref(false)
const searchId = ref('')
const filterPiso = ref('')
const filterInquilino = ref('')
const page = ref(1)
const perPage = ref(10)
const totalPages = ref(1)
const totalItems = ref(0)

function formatDate(v) {
  if (!v) return '-'
  try {
    const d = new Date(v)
    if (isNaN(d.getTime())) return String(v)
    return d.toLocaleString()
  } catch (e) { return String(v) }
}

async function load() {
  loading.value = true
  try {
    // Construir variables para la query GraphQL
    const variables = {
      page: page.value,
      perPage: perPage.value
    }
    
    // Solo añadir filtro si hay valor
    if (filterPiso.value) {
      variables.piso_id = filterPiso.value
    }
    
    const query = `
      query GetComentarios($page: Int, $perPage: Int, $piso_id: String) {
        comentarios(page: $page, perPage: $perPage, piso_id: $piso_id) {
          items {
            id
            piso_id
            usuario_id
            coment
            valoracion
            created
            updated
            usuario {
              id
              username
              nombre 
            }
            piso {
              id
              titulo
            }
          }
          page
          perPage
          totalItems
          totalPages
        }
      }
    `
    
    console.log('🔍 Ejecutando query GraphQL para comentarios...')
    const data = await graphqlRequest(query, variables)
    console.log('📥 Respuesta GraphQL:', data)
    
    if (data && data.comentarios) {
      comentarios.value = data.comentarios.items || []
      page.value = data.comentarios.page || page.value
      perPage.value = data.comentarios.perPage || perPage.value
      totalItems.value = data.comentarios.totalItems || totalItems.value
      totalPages.value = data.comentarios.totalPages || totalPages.value
      
      console.log(`📊 ${comentarios.value.length} comentarios cargados`)
      
      // Filtrar por searchId en el cliente si se especificó
      if (searchId.value) {
        comentarios.value = comentarios.value.filter(c => 
          c.id && c.id.includes(searchId.value)
        )
      }
      
      // Filtrar por usuario_id en el cliente si se especificó
      if (filterInquilino.value) {
        comentarios.value = comentarios.value.filter(c => 
          c.usuario_id && c.usuario_id.includes(filterInquilino.value)
        )
      }
    } else {
      console.log('ℹ️ No se encontraron comentarios')
      comentarios.value = []
      totalItems.value = 0
      totalPages.value = 1
    }
  } catch (e) {
    console.error('💥 Error loading comentarios:', e)
    console.error('💥 Error message:', e.message)
    comentarios.value = []
  }
  loading.value = false
}

function applyFilters() {
  page.value = 1
  load()
}

function clearFilters() {
  searchId.value = ''
  filterPiso.value = ''
  filterInquilino.value = ''
  page.value = 1
  load()
}

function goPrev() {
  if (page.value > 1) { page.value -= 1; load() }
}

function goNext() {
  if (page.value < totalPages.value) { page.value += 1; load() }
}

async function remove(c) {
  if (!confirm('Eliminar comentario ' + c.id + '?')) return
  try {
    const mutation = `
      mutation DeleteComentario($id: ID!) {
        deleteComentario(id: $id) {
          success
          message
        }
      }
    `
    
    console.log(`🗑️ Eliminando comentario ${c.id}...`)
    const data = await graphqlRequest(mutation, { id: c.id })
    
    if (data && data.deleteComentario && data.deleteComentario.success) {
      console.log('✅ Comentario eliminado')
      await load()
    } else {
      alert('Error eliminando: ' + (data?.deleteComentario?.message || 'Error desconocido'))
    }
  } catch (e) { 
    console.error('💥 Error eliminando comentario:', e)
    alert('Error eliminando') 
  }
}

onMounted(() => {
  console.log('🎯 Componente AdminComentarios montado')
  load()
})
</script>

<style scoped>
.admin-comentarios { max-width: 1100px; margin: 18px auto }
.c-table th, .c-table td { padding: 8px 10px; border-bottom: 1px solid #eee }
</style>