<template>
  <div class="users-admin">
    <h2>Gestión de Usuarios</h2>
    <p>Listado y acciones sobre los usuarios. Esta es una vista placeholder; implementar CRUD aquí.</p>
    <div>
      <button class="btn" @click="refresh">Refrescar</button>
    </div>
    <div v-if="loading">Cargando usuarios...</div>
    <ul v-else>
        <li v-for="u in users" :key="u.id">
            {{ u.nombre || u.username || u.id }} 
            ({{ u.email }}) - 
            <strong>{{ u.rol || u.role || '—' }}</strong>
        </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { graphqlRequest } from '@/services/graphql'
const users = ref([])
const loading = ref(false)

async function loadUsers() {
  loading.value = true
  try {
    const query = `
      query GetUsers {
        users(page: 1, perPage: 100) {
          items {
            id
            nombre
            apellidos
            username
            email
            rol
            telefono
            created
          }
          totalItems
        }
      }
    `
    
    const data = await graphqlRequest(query)
    
    if (data && data.users) {
      users.value = data.users.items || []
    } else {
      users.value = []
    }
  } catch (e) {
    console.error('Error loading users', e)
    users.value = []
  }
  loading.value = false
}

function refresh() { loadUsers() }
onMounted(loadUsers)
</script>

<style scoped>
.users-admin { max-width: 900px; margin: 18px auto; }
</style>
