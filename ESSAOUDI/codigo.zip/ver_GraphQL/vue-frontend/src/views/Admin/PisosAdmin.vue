<template>
  <AdminLayout>
    <template #default>
      <div class="pisos-admin">
        <h2>Gestión de Pisos</h2>
        <p>Placeholder para la gestión de pisos (crear, editar, eliminar).</p>
        <div class="top-actions">
          <button class="btn" @click="refresh">Refrescar</button>
          <button class="btn" @click="openCreatePisoModal">Crear anuncio</button>
        </div>
        <div v-if="selectedPiso" class="modal-backdrop" @click.self="closeDetails">
          <div class="modal">
            <button class="close" @click="closeDetails" aria-label="Cerrar">×</button>
            <div class="modal-header">
              <h3>Piso — {{ selectedPiso.id || '-' }}</h3>
              <div class="meta">{{ selectedPiso.titulo || selectedPiso.nombre || '' }}</div>
            </div>
            <div class="modal-body">
              <div class="modal-grid">
                <div class="modal-image" v-if="imageUrl">
                  <img :src="imageUrl" alt="Imagen del piso" />
                </div>
                <div class="modal-info">
                  <table class="details-table">
                    <tbody>
                      <tr v-for="(val, key) in pisoDetails" :key="key">
                        <th>{{ key }}</th>
                        <td>{{ formatValue(val) }}</td>
                      </tr>
                    </tbody>
                  </table>
                    
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Create Piso Modal -->
        <div v-if="showCreate" class="modal-backdrop" @click.self="closeCreatePisoModal">
          <div class="modal">
            <button class="close" @click="closeCreatePisoModal" aria-label="Cerrar">×</button>
            <h3>Crear Piso</h3>
            <div class="modal-body">
              <form @submit.prevent="submitCreatePisoModal">
                <div class="form-row"><label>Título</label><input v-model="pisoFormModal.titulo" required /></div>
                <div class="form-row"><label>Dirección</label><input v-model="pisoFormModal.direccion" /></div>
                <div class="form-row"><label>Ciudad</label><input v-model="pisoFormModal.ciudad" /></div>
                <div class="form-row"><label>CP</label><input v-model="pisoFormModal.cp" /></div>
                <div class="form-row"><label>Precio</label><input v-model.number="pisoFormModal.precio" type="number" /></div>
                <div class="form-row"><label>Habitaciones</label><input v-model.number="pisoFormModal.num_habit" type="number" /></div>
                <div class="form-row"><label>Superficie</label><input v-model.number="pisoFormModal.superficie" type="number" /></div>
                <div class="form-row"><label>Descripción</label><textarea v-model="pisoFormModal.descripcion"></textarea></div>
                <div class="form-row"><label>Propietario</label>
                  <select v-model="pisoFormModal.propietario_id">
                    <option value="">-- seleccionar propietario --</option>
                    <option v-for="u in propietarios" :key="u.id" :value="u.id">{{ u.username || u.nombre || u.email || u.id }}</option>
                  </select>
                </div>
                <div class="form-row"><label>Imágenes (máx. 5)</label>
                  <input type="file" accept="image/*" multiple @change="onCreateImagesChange" />
                  <div class="image-previews" v-if="pisoImageFiles && pisoImageFiles.length">
                    <div class="preview" v-for="(p, idx) in pisoImageFiles" :key="idx">
                      <img :src="p.preview" alt="preview" />
                      <button type="button" class="btn btn-small" @click="removeImage(idx)">Eliminar</button>
                    </div>
                  </div>
                </div>

                <div style="margin-top:12px; display:flex; gap:8px; align-items:center">
                  <button class="btn btn-primary" type="submit" :disabled="creating">{{ creating ? 'Creando...' : 'Crear' }}</button>
                  <button class="btn" type="button" @click="closeCreatePisoModal">Cancelar</button>
                  <div v-if="createError" class="muted" style="color:#a00">{{ createError }}</div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div v-if="loading">Cargando pisos...</div>
        <div v-else>
          <table class="users-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Dirección</th>
                <th>Ciudad</th>
                <th>Propietario</th>
                <th>Precio</th>
                <th>Habit.</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="p in pisos" :key="p.id">
                <td>{{ p.id }}</td>
                <td>{{ p.titulo || '-' }}</td>
                <td>{{ p.direccion || '-' }}</td>
                <td>{{ p.ciudad || '-' }}</td>
                <td>
                  {{ p.propietario?.username || p.propietario?.nombre || p.propietario_id || '-' }}
                </td>
                <td>{{ p.precio !== undefined ? p.precio : '-' }}</td>
                <td>{{ p.num_habit || '-' }}</td>
                <td>
                  <button class="btn" @click="showDetails(p)">Detalles</button>
                  <button class="btn btn-danger" @click="removePiso(p)">Eliminar</button>
                </td>
              </tr>
            </tbody>
          </table>
          <!-- Pagination controls -->
          <div class="pagination" style="display:flex; gap:8px; align-items:center; margin-top:12px">
            <button class="btn" :disabled="page <= 1" @click="goPrev">Anterior</button>
            <div> Página {{ page }} de {{ totalPages }} — {{ totalItems }} pisos </div>
            <button class="btn" :disabled="page >= totalPages" @click="goNext">Siguiente</button>
          </div>
        </div>
      </div>
    </template>
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, computed } from 'vue'
import AdminLayout from '@/components/Layout/AdminLayout.vue'
import { graphqlRequest } from '@/services/graphql'

const pisos = ref([])
const loading = ref(false)
const page = ref(1)
const perPage = ref(10)
const totalPages = ref(1)
const totalItems = ref(0)

async function loadPisos() {
  loading.value = true
  try {
    const query = `
      query GetPisosAdmin($page: Int, $perPage: Int) {
        pisos(page: $page, perPage: $perPage) {
          items {
            id
            titulo
            descripcion
            direccion
            ciudad
            cp
            precio
            num_habit
            superficie
            imagen
            primeraImagen
            propietario_id
            created
            updated
            propietario {
              id
              username
              nombre
            }
          }
          page
          perPage
          totalItems
          totalPages
        }
      }
    `
    
    const data = await graphqlRequest(query, { 
      page: page.value, 
      perPage: perPage.value 
    })
    
    if (data && data.pisos) {
      pisos.value = data.pisos.items || []
      page.value = data.pisos.page || page.value
      perPage.value = data.pisos.perPage || perPage.value
      totalItems.value = data.pisos.totalItems || totalItems.value
      totalPages.value = data.pisos.totalPages || totalPages.value
    } else {
      pisos.value = []
      totalItems.value = 0
      totalPages.value = 1
    }
  } catch (e) {
    console.error('Error loading pisos', e)
    pisos.value = []
  }
  loading.value = false
}

function refresh() { loadPisos() }
onMounted(loadPisos)

function goPrev() { if (page.value > 1) { page.value -= 1; loadPisos() } }
function goNext() { if (page.value < totalPages.value) { page.value += 1; loadPisos() } }

const selectedPiso = ref(null)

// Create piso modal state
const showCreate = ref(false)
const creating = ref(false)
const createError = ref('')
const pisoFormModal = ref({ titulo:'', direccion:'', ciudad:'', cp:'', precio:0, num_habit:1, superficie:0, descripcion:'', propietario_id: '' })
const pisoImageFiles = ref([]) // array of { file, preview }
const propietarios = ref([])

function openCreatePisoModal() {
  createError.value = ''
  pisoImageFiles.value.forEach(p => { try { URL.revokeObjectURL(p.preview) } catch {} })
  pisoImageFiles.value = []
  pisoFormModal.value = { titulo:'', direccion:'', ciudad:'', cp:'', precio:0, num_habit:1, superficie:0, descripcion:'', propietario_id: '' }
  
  // Cargar propietarios con GraphQL
  const query = `
    query GetPropietarios {
      users(rol: "propietario", page: 1, perPage: 1000) {
        items {
          id
          username
          nombre
        }
      }
    }
  `
  
  graphqlRequest(query).then(data => {
    propietarios.value = data?.users?.items || []
  }).catch(() => { propietarios.value = [] })
  
  showCreate.value = true
}

function closeCreatePisoModal() { showCreate.value = false }

function onCreateImagesChange(e) {
  const fl = e.target && e.target.files ? Array.from(e.target.files) : []
  if (!fl.length) return
  const max = 5
  const existing = pisoImageFiles.value.length
  const allowed = Math.max(0, max - existing)
  const take = fl.slice(0, allowed)
  take.forEach(f => {
    const preview = URL.createObjectURL(f)
    pisoImageFiles.value.push({ file: f, preview })
  })
}

function removeImage(idx) {
  const it = pisoImageFiles.value[idx]
  if (it && it.preview) try { URL.revokeObjectURL(it.preview) } catch {}
  pisoImageFiles.value.splice(idx, 1)
}

async function submitCreatePisoModal() {
  try {
    createError.value = ''
    if (!pisoFormModal.value.titulo) { createError.value = 'Título requerido'; return }
    creating.value = true

    const input = {
      titulo: pisoFormModal.value.titulo,
      direccion: pisoFormModal.value.direccion || '',
      ciudad: pisoFormModal.value.ciudad || '',
      cp: pisoFormModal.value.cp || '',
      precio: Number(pisoFormModal.value.precio) || 0,
      num_habit: Number(pisoFormModal.value.num_habit) || 1,
      superficie: Number(pisoFormModal.value.superficie) || 0,
      descripcion: pisoFormModal.value.descripcion || '',
      propietario_id: pisoFormModal.value.propietario_id || ''
    }
    
    const mutation = `
      mutation CreatePiso($input: PisoInput!) {
        createPiso(input: $input) {
          id
          titulo
          descripcion
          direccion
          ciudad
          cp
          precio
          num_habit
          superficie
          imagen
        }
      }
    `
    
    console.log(' Creando piso via GraphQL...', input)
    const data = await graphqlRequest(mutation, { input })
    
    if (!data || !data.createPiso) {
      createError.value = 'Error creando piso: respuesta vacía'
      return
    }
    
    const created = data.createPiso
    console.log('✅ Piso creado:', created)
        
    // Limpiar previews
    pisoImageFiles.value.forEach(p => { try { URL.revokeObjectURL(p.preview) } catch {} })
    pisoImageFiles.value = []
    
    // Refrescar lista y cerrar modal
    await loadPisos()
    closeCreatePisoModal()
    
  } catch (err) {
    console.error('💥 Error creando piso:', err)
    createError.value = err?.message || String(err)
  } finally {
    creating.value = false
  }
}

function closeDetails() { selectedPiso.value = null }

// Close modal on Escape
function onKeydown(e) { if (e.key === 'Escape' && selectedPiso.value) closeDetails() }
onMounted(() => window.addEventListener('keydown', onKeydown))
onBeforeUnmount(() => window.removeEventListener('keydown', onKeydown))

function formatValue(v) {
  if (v === null || v === undefined) return '-'
  if (typeof v === 'object') return JSON.stringify(v)
  return String(v)
}

const pisoDetails = computed(() => {
  const p = selectedPiso.value || {}
  const src = p.record ? { ...p.record, ...p } : p
  const exclude = new Set(['expand', 'collectionId', 'collection_name', 'collectionName', 'imagen'])
  return Object.keys(src)
    .filter(k => !exclude.has(k))
    .reduce((acc, k) => { acc[k] = src[k]; return acc }, {})
})

// Mostrar primera imagen
const imageUrl = computed(() => {
  const p = selectedPiso.value || {}
  const arr = (p.record && p.record.imagen) || p.imagen || null
  if (!arr) return null
  const first = Array.isArray(arr) ? arr[0] : (typeof arr === 'string' ? arr : null)
  if (!first) return null
  if (typeof first === 'string' && (first.startsWith('http://') || first.startsWith('https://') || first.startsWith('/')))
    return first

  const PB_BASE = 'http://127.0.0.1:8090'
  const collection = p.collectionName || p.collection || p.collection_name || 'pisos'
  const recordId = p.id || (p.record && p.record.id) || ''
  if (!recordId) return null
  return `${PB_BASE.replace(/\/$/, '')}/api/files/${collection}/${recordId}/${encodeURIComponent(first)}`
})

async function showDetails(p) {
  try {
    const query = `
      query GetPiso($id: ID!) {
        piso(id: $id) {
          id
          titulo
          descripcion
          direccion
          ciudad
          cp
          precio
          num_habit
          superficie
          imagen
          primeraImagen
          propietario_id
          created
          updated
          propietario {
            id
            username
            nombre
          }
        }
      }
    `
    
    const data = await graphqlRequest(query, { id: p.id })
    
    if (data && data.piso) {
      selectedPiso.value = data.piso
    } else {
      alert('Error cargando detalles: Piso no encontrado')
    }
  } catch (e) {
    console.error('Error cargando detalles:', e)
    alert('Error cargando detalles: ' + e.message)
  }
}

async function removePiso(p) {
  if (!confirm(`⚠️ ¿Eliminar piso "${p.titulo || p.id}"?\n\nEsto también eliminará:\n• Todas las reservas de este piso\n• Todos los comentarios de este piso\n\nEsta acción no se puede deshacer.`)) return
  
  try {
    const mutation = `
      mutation DeletePiso($id: ID!) {
        deletePiso(id: $id) {
          success
          message
        }
      }
    `
    
    console.log(` Eliminando piso ${p.id} con todas sus relaciones...`)
    const data = await graphqlRequest(mutation, { id: p.id })
    
    if (data && data.deletePiso && data.deletePiso.success) {
      alert('✅ Piso eliminado correctamente\n\nSe han eliminado todas las reservas y comentarios asociados.')
      await loadPisos()
    } else {
      alert('❌ Error eliminando piso: ' + (data?.deletePiso?.message || 'Error desconocido'))
    }
  } catch (e) {
    console.error('Error eliminando piso:', e)
    
    // Mensaje más específico
    if (e.message.includes('Not authenticated') || e.message.includes('UNAUTHENTICATED')) {
      alert('❌ No estás autenticado. Inicia sesión nuevamente.')
    } else if (e.message.includes('Not authorized') || e.message.includes('FORBIDDEN')) {
      alert('❌ No tienes permiso para eliminar este piso.')
    } else {
      alert('❌ Error eliminando piso: ' + e.message)
    }
  }
}


</script>

<style scoped>
.pisos-admin { max-width: 1000px; margin: 18px auto; }

.users-table { width:100%; border-collapse: collapse }
.users-table th, .users-table td { padding: 8px 10px; border-bottom: 1px solid #eee }
.users-table th { text-align:left }

.details-table { width:100%; border-collapse: collapse }
.details-table th { text-align:left; padding:6px 8px; width:160px; vertical-align:top }
.details-table td { padding:6px 8px }

/* Modal popup styles */
.modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1100;
  padding: 20px;
}
.modal {
  background: #fff;
  border-radius: 8px;
  max-width: 900px;
  width: 100%;
  max-height: 90vh;
  overflow: auto;
  box-shadow: 0 10px 30px rgba(0,0,0,0.3);
  position: relative;
  padding: 18px;
}
.modal-header { display:flex; align-items:baseline; justify-content:space-between; gap:12px }
.modal-header h3 { margin:0 }
.modal .meta { color:#666; font-size:0.95rem }
.modal-grid { display:flex; gap:16px; align-items:flex-start }
.modal-image { flex:0 0 320px }
.modal-image img { width:100%; height:auto; border-radius:6px; object-fit:cover }
.modal-info { flex:1 1 auto }
.close { position:absolute; top:10px; right:12px; background:transparent; border:none; font-size:22px; cursor:pointer }

@media (max-width:720px) {
  .modal-grid { flex-direction:column }
  .modal-image { flex: none; width:100% }
}

.users-table td > .btn { margin-right: 8px }
.pisos-admin > div > .btn { margin-right: 8px }

.image-previews { display:flex; gap:8px; margin-top:8px; flex-wrap:wrap }
.image-previews .preview { position:relative; width:100px; height:80px; border:1px solid #eee; border-radius:6px; overflow:hidden; display:flex; align-items:center; justify-content:center }
.image-previews .preview img { width:100%; height:100%; object-fit:cover }
.btn-small { padding:4px 6px; font-size:12px; position:absolute; right:6px; top:6px; background:rgba(0,0,0,0.6); color:#fff; border:none; border-radius:4px; cursor:pointer }
</style>