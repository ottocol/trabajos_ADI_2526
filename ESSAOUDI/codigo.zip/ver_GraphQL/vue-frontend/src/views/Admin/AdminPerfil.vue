<template>
  <AdminLayout>
    <div class="profile-container">
      <h2 class="profile-title">Perfil (Admin)</h2>

      <div v-if="loading" class="loading-state">
        <p>Cargando datos del perfil...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
      </div>

      <template v-else>
        <div class="profile-group">
          <span class="profile-label">Nombre</span>
          <div class="profile-value">{{ perfil.nombre || 'No especificado' }}</div>
        </div>

        <div class="profile-group">
          <span class="profile-label">Apellidos</span>
          <div class="profile-value">{{ perfil.apellidos || 'No especificado' }}</div>
        </div>

        <div class="profile-group">
          <span class="profile-label">Email</span>
          <div class="profile-value">{{ perfil.email || 'No especificado' }}</div>
        </div>

        <div class="profile-group">
          <span class="profile-label">Teléfono</span>
          <div class="profile-value">{{ perfil.telefono || 'No especificado' }}</div>
        </div>

        <div class="profile-group">
          <span class="profile-label">Rol</span>
          <div class="profile-value">{{ getRolTexto(perfil.rol) }}</div>
        </div>

        <div class="profile-actions">
          <router-link to="/editar-perfil" class="btn-edit">Editar Perfil</router-link>
          <router-link :to="getRutaInicio()" class="btn-back">Volver al Inicio</router-link>
        </div>

        <div class="danger-zone">
          <p class="danger-warning">Eliminar la cuenta del admin es irreversible. Proceda con extrema precaución.</p>
          <div style="margin-top:12px; display:flex; gap:8px; justify-content:center">
            <button class="btn-danger" :disabled="eliminando" @click="confirmarEliminarCuenta">
              {{ eliminando ? 'Eliminando...' : 'Eliminar Mi Cuenta (Admin)' }}
            </button>
          </div>
        </div>
      </template>
    </div>
  </AdminLayout>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue'
import AdminLayout from '@/components/Layout/AdminLayout.vue'
import { useRouter } from 'vue-router'
import { graphqlRequest } from '@/services/graphql'
const router = useRouter()
const perfil = reactive({})
const loading = ref(false)
const error = ref('')

const formatFecha = (fecha) => {
  if (!fecha) return ''
  return new Date(fecha).toLocaleDateString('es-ES')
}

const getRolTexto = (rol) => {
  const roles = {
    'inquilino': 'Inquilino',
    'propietario': 'Propietario',
    'admin': 'Administrador'
  }
  return roles[rol] || rol || 'No especificado'
}

const getRutaInicio = () => {
  const rol = perfil.rol || localStorage.getItem('userRole')
  if (rol === 'inquilino') return { name: 'inquilino' }
  if (rol === 'propietario') return { name: 'propietario' }
  return { name: 'admin' }
}

const eliminando = ref(false)

// Función para eliminar la cuenta (similar a Perfil.vue)
const eliminarCuenta = async () => {
  eliminando.value = true
  try {
    // Mutation GraphQL para eliminar cuenta propia
    const mutation = `
      mutation DeleteMyAccount {
        deleteMyAccount {
          success
          message
        }
      }
    `
    
    const data = await graphqlRequest(mutation)
    
    if (data && data.deleteMyAccount && data.deleteMyAccount.success) {
      // Limpieza local y redirección
      localStorage.removeItem('userId')
      localStorage.removeItem('currentUser')
      localStorage.removeItem('userRole')
      localStorage.removeItem('pb_token')
      localStorage.removeItem('token')
      window.location.href = '/'
    } else {
      throw new Error(data?.deleteMyAccount?.message || 'Error al eliminar cuenta')
    }
  } catch (err) {
    console.error('Error eliminando cuenta (admin):', err)
    error.value = 'Error al eliminar la cuenta: ' + (err.message || err)
  } finally {
    eliminando.value = false
  }
}

const confirmarEliminarCuenta = () => {
  if (confirm('¿Estás SEGURO de que quieres eliminar TU CUENTA DE ADMIN? Esta acción es irreversible.')) {
    if (confirm('Esta es la última confirmación: ¿Eliminar cuenta de admin ahora?')) {
      eliminarCuenta()
    }
  }
}

const cargarPerfil = async () => {
  loading.value = true
  try {
    let userId = localStorage.getItem('userId')
    if (!userId) {
      const currentUser = localStorage.getItem('currentUser')
      if (currentUser) {
        const userData = JSON.parse(currentUser)
        userId = userData.id
      }
    }

    if (!userId) throw new Error('Usuario no identificado')

    // Query GraphQL para obtener perfil
    const query = `
      query GetUser($id: ID!) {
        user(id: $id) {
          id
          nombre
          apellidos
          email
          username
          telefono
          tel
          rol
          image
          created
        }
      }
    `
    
    const data = await graphqlRequest(query, { id: userId })
    
    if (data && data.user) {
      Object.assign(perfil, {
        id: data.user.id,
        nombre: data.user.nombre || 'No especificado',
        apellidos: data.user.apellidos || 'No especificado',
        email: data.user.email || 'No especificado',
        telefono: data.user.telefono || data.user.tel || 'No especificado',
        rol: data.user.rol || 'admin',
        fechaRegistro: data.user.created
      })
    } else {
      throw new Error('Usuario no encontrado')
    }
  } catch (err) {
    error.value = 'Error al cargar los datos del perfil.'
    const currentUser = localStorage.getItem('currentUser')
    if (currentUser) {
      const userData = JSON.parse(currentUser)
      Object.assign(perfil, {
        nombre: userData.nombre || 'Usuario',
        apellidos: userData.apellidos || '',
        email: userData.email || '',
        telefono: userData.telefono || userData.tel || '',
        rol: userData.rol || 'admin'
      })
      error.value = ''
    }
  } finally {
    loading.value = false
  }
}

onMounted(() => { cargarPerfil() })
</script>

<style scoped>
/* reuse same styles as Perfil for container */
.profile-container { background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 70%; max-width: 700px; margin: 2rem auto; }
.profile-title { text-align: center; margin-bottom: 1.5rem; color: #333; }
.profile-group { margin-bottom: 1rem }
.profile-label { display: block; margin-bottom: 0.3rem; color: #555; font-weight: bold }
.profile-value { width: 100%; padding: 0.7rem; border: 1px solid #ccc; border-radius: 8px; background: #f8f9fa; color: #333 }
.profile-actions { display:flex; gap:1rem; margin-top:1.5rem }
.btn-edit, .btn-back { flex:1; padding:0.8rem; color:white; text-align:center; border-radius:8px }
.btn-edit { background:#007bff }
.btn-back { background:#6c757d }
.danger-zone { margin-top:2rem; padding:1.5rem; border:2px solid #dc3545; border-radius:8px; background:#f8d7da }
.danger-warning { color:#721c24 }
</style>
