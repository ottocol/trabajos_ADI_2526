<template>
  <div class="mis-anuncios-view">
    <AppHeader>
      <template #left>
        <router-link to="/perfil">
          <img :src="avatarSrc" alt="avatar" class="user-avatar-small" />
        </router-link>
      </template>

      <template #right>
        <router-link to="/mis-anuncios" class="btn">Mis Anuncios</router-link>
        <router-link to="/mis-solicitudes" class="btn">Mis Solicitudes</router-link>
        <router-link to="/perfil" class="btn">Perfil</router-link>
        <button @click="desconectar" class="btn btn-danger">Desconectar</button>
      </template>
    </AppHeader>

    <div class="anuncios-container">
      <h2 class="anuncios-title">Mis anuncios</h2>
      
      <div class="crear-anuncio-container">
        <router-link to="/crear-anuncio" class="btn btn-primary">+ Crear un anuncio</router-link>
      </div>

      <!-- Estados de carga -->
      <div v-if="loading" class="loading-state">
        <p>Cargando anuncios...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
      </div>

      <div v-else-if="anuncios.length === 0" class="empty-state">
        <p>No tienes anuncios creados.</p>
        <router-link to="/crear-anuncio" class="btn btn-primary">Crear mi primer anuncio</router-link>
      </div>

      <!-- Lista de anuncios -->
      <div v-else class="anuncios-list">
        <div v-for="anuncio in anuncios" :key="anuncio.id" class="anuncio-card">
          <div class="anuncio-img">
            <img 
              :src="getAnuncioImage(anuncio)" 
              :alt="anuncio.titulo"
              @error="handleImageError"
            >
          </div>
          
          <div class="anuncio-columns">
            <!-- Columna 1 -->
            <div class="info-column">
              <div class="info-item">
                <span class="info-label">Piso:</span>
                <span class="info-value">{{ anuncio.titulo }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Dirección:</span>
                <span class="info-value">{{ anuncio.direccion }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Ciudad:</span>
                <span class="info-value">{{ anuncio.ciudad }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Código postal:</span>
                <span class="info-value">{{ anuncio.cp }}</span>
              </div>
            </div>

            <!-- Columna 2 -->
            <div class="info-column">
              <div class="info-item">
                <span class="info-label">Descripción:</span>
                <span class="info-value descripcion-text">{{ anuncio.descripcion }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Precio por noche:</span>
                <span class="info-value precio">{{ formatPrice(anuncio.precio) }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Número de Habitaciones:</span>
                <span class="info-value">{{ anuncio.num_habit }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Superficie:</span>
                <span class="info-value">{{ anuncio.superficie }} m²</span>
              </div>
            </div>

            <!-- Columna 3 -->
            <div class="info-column">
              <div class="info-item">
                <span class="info-label">Creado:</span>
                <span class="info-value">{{ formatFecha(anuncio.created) }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Actualizado:</span>
                <span class="info-value">{{ formatFecha(anuncio.updated) }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Propietario:</span>
                <span class="info-value">{{ anuncio.propietario?.nombre || 'No especificado' }}</span>
              </div>
              <div class="info-item action-item">
                <router-link 
                  :to="{ name: 'ActualizarAnuncio', params: { id: anuncio.id } }" 
                  class="btn btn-primary"
                >
                  Actualizar
                </router-link>
              </div>
              <div class="info-item action-item">
                <button 
                  @click="confirmarEliminar(anuncio)" 
                  class="btn btn-danger"
                >
                  Eliminar
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <router-link :to="{ name: 'propietario' }" class="volver-link">
        Volver a la página de inicio
      </router-link>
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { graphqlRequest } from '@/services/graphql'
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import pisoEjemplo from '@/images/piso-ejemplo.jpeg'
import villa1 from '@/images/villa1.jpg'
import house1 from '@/images/house1.jpg'
import randomAvatar from '@/images/users/random.png'

const router = useRouter()
const anuncios = ref([])
const loading = ref(false)
const error = ref(null)
const avatarSrc = ref(randomAvatar)

function loadAvatar() {
  try {
    const raw = localStorage.getItem('currentUser')
    if (!raw) return
    const u = JSON.parse(raw)
    if (u.avatarUrl) { 
      avatarSrc.value = u.avatarUrl
      return 
    }
    if (u.image) {
      if (Array.isArray(u.image) && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image[0]}`
        return
      }
      if (typeof u.image === 'string' && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image}`
        return
      }
    }
  } catch (e) {
    console.error('Error loading avatar:', e)
  }
}

// Formatear precio
const formatPrice = (precio) => {
  return precio ? `${precio.toLocaleString('es-ES')} €` : '0 €'
}

// Formatear fecha
const formatFecha = (fechaString) => {
  if (!fechaString) return 'No disponible'
  
  try {
    const fecha = new Date(fechaString)
    return fecha.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  } catch (e) {
    return fechaString
  }
}

// Obtener imagen del anuncio
const getAnuncioImage = (anuncio) => {
  if (anuncio.primeraImagen) return anuncio.primeraImagen
  
  if (anuncio.imagen && anuncio.imagen.length > 0) {
    const imgs = Array.isArray(anuncio.imagen) ? anuncio.imagen : anuncio.imagen.split(',')
    if (imgs[0]) {
      // Si es una URL de PocketBase
      if (imgs[0].startsWith('http://127.0.0.1:8090')) {
        return imgs[0]
      }
      // Si es solo un nombre de archivo
      return `http://127.0.0.1:8090/api/files/pisos/${anuncio.id}/${imgs[0]}`
    }
  }
  
  // Imágenes por defecto
  const defaultImages = {
    'apartamento': pisoEjemplo,
    'villa': villa1,
    'casa': house1
  }
  return defaultImages[anuncio.tipo] || pisoEjemplo
}

// Manejar error de imagen
const handleImageError = (event) => {
  event.target.src = pisoEjemplo
}

// Cargar mis anuncios usando GraphQL
const cargarMisAnuncios = async () => {
  loading.value = true
  error.value = null
  
  try {
    const token = localStorage.getItem('token')
    console.log('🔑 Token para MisAnuncios:', token ? `Encontrado (${token.substring(0, 20)}...)` : 'NO encontrado')

    // Query CORREGIDA - SIN el campo "estado" que no está en el schema
    const query = `
      query GetMisAnuncios {
        misAnuncios(page: 1, perPage: 50) {
          id
          titulo
          descripcion
          direccion
          ciudad
          cp
          precio
          num_habit
          superficie
          imagen
          primeraImagen
          propietario_id
          created
          updated
          propietario {
            id
            nombre
            email
          }
        }
      }
    `
    
    console.log('🚀 Ejecutando query GraphQL para MisAnuncios...')
    
    const data = await graphqlRequest(query)
    console.log('✅ Datos recibidos para MisAnuncios:', data)
    
    if (data && data.misAnuncios) {
      anuncios.value = Array.isArray(data.misAnuncios) ? data.misAnuncios : []
      console.log(`📊 ${anuncios.value.length} anuncios cargados`)
      
      if (anuncios.value.length > 0) {
        console.log('🔍 Primer anuncio:', {
          id: anuncios.value[0].id,
          titulo: anuncios.value[0].titulo,
          ciudad: anuncios.value[0].ciudad
        })
      }
    } else {
      anuncios.value = []
      console.log('ℹ️ No se encontraron anuncios')
    }

  } catch (err) {
    console.error('💥 Error cargando anuncios:', err)
    error.value = 'Error al cargar anuncios: ' + err.message
    
    if (err.message.includes('autenticado') || err.message.includes('401') || err.message.includes('403')) {
      error.value += '. Por favor, inicia sesión nuevamente.'
    }
  } finally {
    loading.value = false
    console.log('🏁 Carga de anuncios completada')
  }
}

// Confirmar eliminación
const confirmarEliminar = (anuncio) => {
  if (confirm(`¿Estás seguro de que quieres eliminar el anuncio "${anuncio.titulo}"?`)) {
    eliminarAnuncio(anuncio.id)
  }
}

// Eliminar anuncio usando GraphQL Mutation
const eliminarAnuncio = async (anuncioId) => {
  try {
    // Mutation CORREGIDA - según tu schema debe ser "deletePiso"
    const mutation = `
      mutation EliminarAnuncio($id: ID!) {
        deletePiso(id: $id) {
          success
          message
        }
      }
    `
    
    console.log(`🗑️ Intentando eliminar anuncio ${anuncioId}...`)
    
    const data = await graphqlRequest(mutation, { id: anuncioId })
    
    if (data && data.deletePiso && data.deletePiso.success) {
      anuncios.value = anuncios.value.filter(a => a.id !== anuncioId)
      alert('Anuncio eliminado correctamente')
      console.log('✅ Anuncio eliminado')
    } else {
      alert('Error al eliminar el anuncio')
    }
  } catch (err) {
    console.error('💥 Error eliminando anuncio:', err)
    alert('Error al eliminar el anuncio: ' + err.message)
  }
}

// Desconectar
const desconectar = () => {
  localStorage.removeItem('token')
  localStorage.removeItem('userId')
  localStorage.removeItem('currentUser')
  localStorage.removeItem('userRole')
  router.push('/')
}

onMounted(() => {
  console.log('🎯 Componente MisAnuncios montado')
  loadAvatar()
  window.addEventListener('storage', loadAvatar)
  cargarMisAnuncios()
})
</script>

<style scoped>
.mis-anuncios-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
  display: flex;
  flex-direction: column;
}

/* Contenedor general */
.anuncios-container {
  width: 100%;
  max-width: 1200px;
  margin: 2rem auto;
  padding: 1rem;
  flex: 1;
  display: flex;
  flex-direction: column;
}

.anuncios-title {
  text-align: center;
  margin-bottom: 2rem;
  color: #333;
  font-size: 2rem;
}

.crear-anuncio-container {
  text-align: center;
  margin-bottom: 2rem;
}

/* Tarjeta de anuncio */
.anuncio-card {
  display: flex;
  align-items: flex-start;
  gap: 1.5rem;
  width: 100%;
  padding: 1.5rem;
  border-radius: 12px;
  margin-bottom: 1.5rem;
  border-left: 5px solid #007bff;
  box-shadow: 0 3px 10px rgba(0,0,0,0.08);
  background: #fff;
  min-height: 220px;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.anuncio-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

/* Imagen */
.anuncio-img {
  flex-shrink: 0;
  width: 200px;
  height: 170px;
  border-radius: 8px;
  overflow: hidden;
}

.anuncio-img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 8px;
}

/* Contenedor de columnas */
.anuncio-columns {
  flex: 1;
  display: flex;
  gap: 1.5rem;
  justify-content: space-between;
}

/* Columnas de información */
.info-column {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  min-width: 0;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.info-label {
  color: #666;
  font-weight: 600;
  font-size: 0.85rem;
  white-space: nowrap;
}

.info-value {
  color: #333;
  font-size: 0.95rem;
  font-weight: normal;
  line-height: 1.3;
}

.descripcion-text {
  color: #555;
  font-size: 0.9rem;
  line-height: 1.4;
  max-height: 60px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}

.precio {
  color: #28a745;
  font-weight: 700;
  font-size: 1.1rem;
}

/* Columna de acciones */
.action-item {
  margin-top: auto;
  display: flex;
  justify-content: center;
}

/* Botones */
.anuncios-list .btn,
.crear-anuncio-container .btn,
.action-item .btn {
  padding: 0.7rem 1.5rem;
  color: white;
  text-decoration: none;
  text-align: center;
  border-radius: 6px;
  font-size: 0.9rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  min-width: 140px;
  font-weight: 600;
}

.anuncios-list .btn:hover,
.crear-anuncio-container .btn:hover,
.action-item .btn:hover {
  opacity: 0.9;
  transform: translateY(-1px);
}

.anuncios-list .btn-primary,
.crear-anuncio-container .btn-primary,
.action-item .btn-primary {
  background: linear-gradient(to right, #007bff, #0056b3);
}

.anuncios-list .btn-danger,
.crear-anuncio-container .btn-danger,
.action-item .btn-danger {
  background: linear-gradient(to right, #dc3545, #c82333);
}

/* Estados */
.loading-state,
.error-state,
.empty-state {
  text-align: center;
  padding: 3rem;
  color: #666;
  background: white;
  border-radius: 12px;
  margin: 2rem 0;
  width: 100%;
  max-width: 600px;
  align-self: center;
  box-shadow: 0 3px 10px rgba(0,0,0,0.05);
}

.error-state {
  color: #dc3545;
  border-left: 4px solid #dc3545;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  border: 2px dashed #dee2e6;
  background: #fafafa;
}

/* Enlace volver */
.volver-link {
  text-align: center;
  margin-top: 2rem;
  display: inline-block;
  color: #007bff;
  text-decoration: none;
  font-weight: 500;
  padding: 0.8rem 1.5rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  transition: all 0.2s ease;
  align-self: center;
}

.volver-link:hover {
  background: #007bff;
  color: white;
  text-decoration: none;
}

/* Responsive */
@media (max-width: 1100px) {
  .anuncio-columns {
    gap: 1rem;
  }
  
  .anuncio-img {
    width: 180px;
    height: 150px;
  }
}

@media (max-width: 900px) {
  .anuncio-card {
    flex-direction: column;
    gap: 1.5rem;
  }

  .anuncio-img {
    width: 100%;
    max-width: 100%;
    height: 200px;
  }

  .anuncio-columns {
    flex-direction: column;
    gap: 1rem;
  }

  .info-column {
    gap: 1rem;
  }
}

@media (max-width: 768px) {
  .anuncios-container {
    padding: 0.5rem;
  }

  .anuncio-card {
    padding: 1rem;
  }

  .anuncios-title {
    font-size: 1.5rem;
  }

  .btn {
    min-width: auto;
    padding: 0.6rem 1rem;
    width: 100%;
  }
}

@media (max-width: 480px) {
  .anuncios-title {
    font-size: 1.3rem;
  }
  
  .loading-state,
  .error-state,
  .empty-state {
    padding: 2rem 1rem;
  }
  
  .crear-anuncio-container .btn-primary {
    width: 100%;
    max-width: 300px;
  }
}
</style>