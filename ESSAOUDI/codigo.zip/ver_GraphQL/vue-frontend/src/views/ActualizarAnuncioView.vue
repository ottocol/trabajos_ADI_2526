<template>
  <div class="actualizar-anuncio-view">
    <!-- Header integrado -->
    <header class="site-header">
      <div class="logo">
        <img :src="logoImg" alt="Logo rentEase">
      </div>
      <div class="header-buttons">
        <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
        <router-link to="/mis-anuncios" class="btn">Mis Anuncios</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <div class="form-container">
      <h2 class="form-title">Actualizar anuncio</h2>

      <!-- Estados -->
      <div v-if="loading" class="loading-state">
        <p>Cargando datos del anuncio...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
        <button @click="volverAMisAnuncios" class="btn btn-primary">Volver a Mis Anuncios</button>
      </div>

      <div v-else-if="success" class="success-state">
        <p>¡Anuncio actualizado exitosamente! Redirigiendo...</p>
      </div>

      <form v-else @submit.prevent="actualizarAnuncio">
        <div class="form-group">
          <label for="titulo">Título del anuncio</label>
          <input v-model="form.titulo" type="text" id="titulo" required>
        </div>

        <div class="form-group">
          <label for="direccion">Dirección</label>
          <input v-model="form.direccion" type="text" id="direccion" required>
        </div>

        <div class="form-group">
          <label for="ciudad">Ciudad</label>
          <input v-model="form.ciudad" type="text" id="ciudad" required>
        </div>

        <div class="form-group">
          <label for="codigoPostal">Código Postal</label>
          <input v-model="form.cp" type="text" id="codigoPostal" required>
        </div>

        <div class="form-group">
          <label for="descripcion">Descripción</label>
          <textarea v-model="form.descripcion" id="descripcion" rows="4" required></textarea>
        </div>

        <div class="form-group">
          <label for="precio">Precio por noche (€)</label>
          <input v-model="form.precio" type="number" id="precio" min="1" required>
        </div>

        <div class="form-group">
          <label for="habitaciones">Número de habitaciones</label>
          <input v-model="form.num_habit" type="number" id="habitaciones" min="1" required>
        </div>

        <div class="form-group">
          <label for="superficie">Superficie (m²)</label>
          <input v-model="form.superficie" type="number" id="superficie" min="1" required>
        </div>

        <div class="form-group">
          <label for="tipo">Tipo de propiedad</label>
          <select v-model="form.tipo" id="tipo">
            <option value="">Selecciona un tipo</option>
            <option value="apartamento">Apartamento</option>
            <option value="casa">Casa</option>
            <option value="villa">Villa</option>
            <option value="estudio">Estudio</option>
            <option value="loft">Loft</option>
          </select>
        </div>

        <div class="form-group">
          <label for="servicios">Servicios incluidos</label>
          <textarea v-model="form.servicios" id="servicios" rows="3" placeholder="WiFi, Lavadora, Aire acondicionado..."></textarea>
        </div>

        <div class="form-group">
          <label for="estado">Estado del anuncio</label>
          <select v-model="form.estado" id="estado">
            <option value="pendiente">Pendiente</option>
            <option value="activo">Activo</option>
            <option value="inactivo">Inactivo</option>
          </select>
        </div>

        <div class="form-actions">
          <button type="submit" class="btn-primary" :disabled="actualizando">
            {{ actualizando ? 'Actualizando...' : 'Actualizar anuncio' }}
          </button>
          <router-link to="/mis-anuncios" class="btn-cancelar">Cancelar</router-link>
        </div>
      </form>
    </div>

    <!-- Footer integrado -->
    <footer class="site-footer">
      <p>&copy; 2025 rentEase. Todos los derechos reservados.</p>
      <p>Contacto | Política de privacidad</p>
    </footer>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { graphqlRequest } from '@/services/graphql'
import logoImg from '@/images/rentEase_logo.jpg'

const router = useRouter()
const route = useRoute()
const anuncioId = route.params.id

const loading = ref(true)
const actualizando = ref(false)
const error = ref('')
const success = ref(false)

const form = reactive({
  titulo: '',
  direccion: '',
  ciudad: '',
  cp: '',
  descripcion: '',
  precio: '',
  num_habit: '',
  superficie: '',
  tipo: '',
  servicios: '',
  estado: 'pendiente'
})

// Cargar datos del anuncio usando GraphQL
const cargarAnuncio = async () => {
  loading.value = true
  error.value = ''
  
  try {
    // Usar el token correcto
    const token = localStorage.getItem('token')
    
    if (!token) {
      error.value = 'No estás autenticado. Por favor, inicia sesión nuevamente.'
      loading.value = false
      return
    }

    // Verificar que tenemos ID
    if (!anuncioId) {
      throw new Error('No se proporcionó ID del anuncio')
    }

    // Query CORREGIDA según tu schema: piso (NO anuncio)
    const query = `
      query GetPiso($id: ID!) {
        piso(id: $id) {
          id
          titulo
          direccion
          ciudad
          cp
          descripcion
          precio
          num_habit
          superficie
          imagen
          primeraImagen
          propietario_id
          created
          updated
        }
      }
    `

    console.log(`🔍 Cargando piso ${anuncioId}...`)
    
    const data = await graphqlRequest(query, { id: anuncioId })
    
    if (!data || !data.piso) {
      throw new Error('Piso no encontrado o no tienes permiso')
    }

    const piso = data.piso
    
    // Mapear datos del GraphQL al formulario
    form.titulo = piso.titulo || ''
    form.direccion = piso.direccion || ''
    form.ciudad = piso.ciudad || ''
    form.cp = piso.cp || ''
    form.descripcion = piso.descripcion || ''
    form.precio = piso.precio || ''
    form.num_habit = piso.num_habit || ''
    form.superficie = piso.superficie || ''
    // Los campos tipo, servicios y estado no están en el schema, los dejamos vacíos

    console.log('✅ Piso cargado:', { ...piso, imagen: '...' })

  } catch (err) {
    console.error('💥 Error cargando anuncio:', err)
    
    // Manejo específico de errores
    if (err.message.includes('UNAUTHENTICATED') || err.message.includes('autenticado')) {
      error.value = 'Tu sesión ha expirado. Por favor, inicia sesión nuevamente.'
    } else if (err.message.includes('Cannot query field')) {
      error.value = 'Error en la consulta GraphQL. Verifica los campos.'
    } else {
      error.value = 'Error al cargar el anuncio: ' + err.message
    }
  } finally {
    loading.value = false
  }
}

// Validar formulario
const validarFormulario = () => {
  if (!form.titulo.trim()) {
    error.value = 'El título es obligatorio'
    return false
  }
  
  if (!form.direccion.trim()) {
    error.value = 'La dirección es obligatoria'
    return false
  }
  
  if (!form.ciudad.trim()) {
    error.value = 'La ciudad es obligatoria'
    return false
  }
  
  if (!form.precio || form.precio < 1) {
    error.value = 'El precio debe ser mayor a 0'
    return false
  }
  
  if (!form.num_habit || form.num_habit < 1) {
    error.value = 'El número de habitaciones debe ser mayor a 0'
    return false
  }
  
  if (!form.superficie || form.superficie < 1) {
    error.value = 'La superficie debe ser mayor a 0'
    return false
  }
  
  error.value = ''
  return true
}

// Actualizar anuncio usando GraphQL
const actualizarAnuncio = async () => {
  if (!validarFormulario()) return
  
  actualizando.value = true
  error.value = ''
  success.value = false
  
  try {
    const token = localStorage.getItem('token')
    
    if (!token) {
      throw new Error('No estás autenticado. Por favor, inicia sesión nuevamente.')
    }

    // Mutation CORREGIDA según tu schema: updatePiso (NO actualizarAnuncio)
    const mutation = `
      mutation UpdatePiso($id: ID!, $input: PisoInput!) {
        updatePiso(id: $id, input: $input) {
          id
          titulo
          direccion
          ciudad
          cp
          descripcion
          precio
          num_habit
          superficie
          updated
        }
      }
    `

    // Preparar datos según PisoInput de tu schema
    // NOTA: Los campos tipo, servicios y estado no están en PisoInput, así que no los enviamos
    const variables = {
      id: anuncioId,
      input: {
        titulo: form.titulo,
        direccion: form.direccion,
        ciudad: form.ciudad,
        cp: form.cp,
        descripcion: form.descripcion,
        precio: Number(form.precio),
        num_habit: Number(form.num_habit),
        superficie: Number(form.superficie),
        // No incluimos: tipo, servicios, estado (no están en el schema)
      }
    }

    console.log('📤 Actualizando piso via GraphQL:', variables.input)

    const data = await graphqlRequest(mutation, variables)
    
    if (!data || !data.updatePiso) {
      throw new Error('No se recibió respuesta del servidor')
    }

    const resultado = data.updatePiso
    console.log('✅ Piso actualizado via GraphQL:', resultado)

    success.value = true
    
    // Redirigir después de éxito
    setTimeout(() => {
      router.push('/mis-anuncios')
    }, 2000)
    
  } catch (err) {
    console.error('💥 Error actualizando anuncio:', err)
    
    // Manejo específico de errores
    if (err.message.includes('UNAUTHENTICATED') || err.message.includes('autenticado')) {
      error.value = 'Tu sesión ha expirado. Por favor, inicia sesión nuevamente.'
    } else if (err.message.includes('Cannot query field')) {
      error.value = 'Error en la consulta GraphQL. Verifica los campos.'
    } else {
      error.value = err.message || 'Error al actualizar el anuncio. Intenta nuevamente.'
    }
  } finally {
    actualizando.value = false
  }
}

// Navegación
const volverAMisAnuncios = () => {
  router.push('/mis-anuncios')
}

// Desconectar
const desconectar = () => {
  localStorage.removeItem('token')
  localStorage.removeItem('currentUser')
  localStorage.removeItem('userRole')
  router.push('/')
}

onMounted(() => {
  cargarAnuncio()
})
</script>

<style scoped>
.actualizar-anuncio-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
}

.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
  position: static;
  top: 0;
}

.logo img {
  height: 60px;
}

.header-buttons .btn {
  margin-left: 1rem;
  padding: 0.5rem 1rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  background: none;
  cursor: pointer;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover {
  background-color: #0056b3;
  color: white;
}

.form-container {
  background: white;
  padding: 2rem 2.5rem;
  border-radius: 12px;
  box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
  width: 80%;
  max-width: 600px;
  margin: 2rem auto;
}

.form-title {
  text-align: center;
  margin-bottom: 1.5rem;
  font-size: 1.6rem;
  color: #333;
}

.form-group {
  margin-bottom: 1rem;
}

label {
  display: block;
  margin-bottom: 0.3rem;
  color: #555;
  font-size: 0.9rem;
  font-weight: bold;
}

input, select, textarea {
  width: 100%;
  padding: 0.7rem;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 1rem;
  box-sizing: border-box;
}

textarea {
  resize: vertical;
}

input:focus, select:focus, textarea:focus {
  border-color: #007bff;
  outline: none;
}

.form-actions {
  margin-top: 1.5rem;
  display: flex;
  justify-content: space-between;
  gap: 1rem;
}

.btn-primary {
  padding: 0.7rem 1rem;
  border: none;
  border-radius: 6px;
  background-color: #007bff;
  color: white;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  text-align: center;
}

.btn-primary:hover:not(:disabled) {
  background-color: #0056b3;
}

.btn-primary:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
}

.btn-cancelar {
  padding: 0.7rem 1rem;
  border: none;
  border-radius: 6px;
  background-color: #dc3545;
  color: white;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  text-align: center;
}

.btn-cancelar:hover {
  background-color: #a71d2a;
}

.site-footer {
  background-color: #f1f1f1;
  color: #333;
  text-align: center;
  padding: 20px 0;
  font-size: 0.9rem;
  border-top: 1px solid #ccc;
}

.site-footer a {
  color: #007bff;
  text-decoration: none;
  margin: 0 5px;
}

.site-footer a:hover {
  text-decoration: underline;
}

.loading-state,
.error-state,
.success-state {
  text-align: center;
  padding: 2rem;
  color: #666;
  font-size: 1.1rem;
}

.error-state {
  color: #dc3545;
  background: #f8d7da;
  border-radius: 8px;
  margin-bottom: 1rem;
}

.success-state {
  color: #155724;
  background: #d4edda;
  border-radius: 8px;
  margin-bottom: 1rem;
}

@media (max-width: 768px) {
  .form-container {
    width: 90%;
    padding: 1.5rem;
  }
  
  .form-actions {
    flex-direction: column;
  }
  
  .header-buttons {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .header-buttons .btn {
    margin-left: 0;
  }
}

@media (max-width: 480px) {
  .form-container {
    padding: 1rem;
  }
}
</style>