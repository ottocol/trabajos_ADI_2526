<template>
  <div class="login-view">
    <AppHeader>
      <template #buttons>
        <router-link to="/registro" class="btn">Registrar</router-link>
      </template>
    </AppHeader>

    <div class="login-container">
      <h2 class="login-title">Iniciar sesión</h2>
      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label for="email">Correo electrónico</label>
          <input v-model="form.email" type="email" id="email" placeholder="tuemail@ejemplo.com" required>
        </div>

        <div class="form-group">
          <label for="password">Contraseña</label>
          <input v-model="form.password" type="password" id="password" placeholder="********" required>
        </div>

        <button type="submit" class="login-button" :disabled="loading">{{ loading ? 'Entrando...' : 'Entrar' }}</button>
      </form>
      <div v-if="error" class="error">{{ error }}</div>

      <div class="login-footer">
        <p>¿No tienes cuenta? <router-link to="/registro">Regístrate aquí</router-link></p>
      </div>
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()

const form = reactive({
  email: '',
  password: ''
})

const loading = ref(false)
const error = ref(null)

const handleLogin = async () => {
  error.value = null
  loading.value = true
  console.log('handleLogin called', form.email)
  
  try {
    const data = await authStore.login(form.email, form.password)
    
    // Login successful - determine role and redirect
    const role = data.user?.rol ? String(data.user.rol).toLowerCase() : null

    if (role === 'propietario') {
      router.push({ name: 'propietario' })
    } else if (role === 'inquilino') {
      router.push({ name: 'inquilino' })
    } else if (role === 'admin') {
      router.push({ name: 'admin' })
    } else {
      router.push({ name: 'home' })
    }
  } catch (err) {
    console.error('Login failed', err)
    error.value = err.message || 'Error al iniciar sesión'
  } finally {
    loading.value = false
  }
}

</script>

<style scoped>
.error { 
  color: #b00020; 
  margin-top: 0.75rem;
  background: #ffeaea;
  border: 1px solid #f5c6cb;
  border-radius: 8px;
  padding: 1rem;
  text-align: center;
}

.login-button[disabled] { 
  opacity: 0.7;
  cursor: not-allowed;
}

.login-container {
  max-width: 500px;
  margin: 2rem auto;
  padding: 2rem;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.login-title {
  text-align: center;
  margin-bottom: 2rem;
  color: #333;
  font-size: 2rem;
}

.form-group {
  margin-bottom: 1.5rem;
}

label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: bold;
  color: #333;
}

input {
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #ddd;
  border-radius: 4px;
  transition: all 0.3s ease;
  font-size: 1rem;
  box-sizing: border-box;
}

input:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.1);
}

.login-button {
  width: 100%;
  padding: 0.75rem;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.login-button:hover:not(:disabled) {
  background-color: #0056b3;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
}

.login-footer {
  text-align: center;
  margin-top: 2rem;
}

.login-footer a {
  color: #007bff;
  text-decoration: none;
  font-weight: 600;
}

.login-footer a:hover {
  text-decoration: underline;
}
</style>
