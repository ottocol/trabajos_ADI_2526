<template>
  <div class="home-view">
    <AppHeader>
      <template #left>
        <router-link to="/perfil">
          <img :src="avatarSrc" alt="avatar" class="user-avatar-small" />
        </router-link>
      </template>

      <template #right>
        <router-link to="/mis-anuncios" class="btn">Mis Anuncios</router-link>
        <router-link to="/mis-solicitudes" class="btn">Mis Solicitudes</router-link>
        <router-link to="/perfil" class="btn">Perfil</router-link>
        <button class="btn btn-danger" @click="handleLogout" :disabled="loggingOut">Desconectar</button>
      </template>
    </AppHeader>

    <div class="main-layout">
      <FiltersPanel />
      <main class="anuncios-container">

        <div class="debug-box" v-if="debug">
          <p><strong>Debug:</strong> items count = {{ items.length }}</p>
          <pre>{{ JSON.stringify(items, null, 2) }}</pre>
        </div>

        <template v-if="loading">
          <p>Cargando pisos...</p>
        </template>

        <template v-else-if="items.length === 0">
          <p>No hay pisos disponibles.</p>
        </template>

        <template v-else>
          <div class="cards-grid">
            <div v-for="(item, idx) in items" :key="item.id" class="anuncio-card">
              <img :src="getImage(item, idx)"
                   :alt="item.titulo"
                   class="anuncio-img">

              <div class="anuncio-info">
                <h3 class="titulo">{{ item.titulo }}</h3>

                <p class="descripcion" v-if="item.descripcion">
                  {{ item.descripcion }}
                </p>

                <p><strong>Dirección:</strong> {{ item.direccion }}</p>

                <p class="precio">
                  {{ formatPrice(item.precio) }}
                </p>

                <router-link 
                  :to="{ name: 'PisoDetalle', params: { id: item.id }}"
                  class="btn-ver-detalle">
                  Ver Detalles
                </router-link>
              </div>
            </div>
          </div>
        </template>
      </main>
    </div>

    <div v-if="!loading && items.length" style="display:flex; gap:8px; align-items:center; justify-content:center; margin:18px 0">
      <button class="btn" :disabled="page <= 1" @click="goPrev">Anterior</button>
      <div> Página {{ page }} de {{ totalPages }} — {{ totalItems }} pisos </div>
      <button class="btn" :disabled="page >= totalPages" @click="goNext">Siguiente</button>
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref, onMounted, provide } from 'vue' 
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { usePisosStore } from '@/stores/pisos'
import { getPisos } from '@/services'  // <-- Importa el servicio existente
import randomAvatar from '@/images/users/random.png'
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import FiltersPanel from '@/components/Layout/FiltersPanel.vue'

const router = useRouter()
const authStore = useAuthStore()
const pisosStore = usePisosStore()

const loggingOut = ref(false)
const avatarSrc = ref(randomAvatar)
const debug = ref(false)

const items = ref([])
const loading = ref(false)
const page = ref(1)
const perPage = ref(9)
const totalPages = ref(1)
const totalItems = ref(0)
const filtros = ref({})

provide('filtros', filtros)

function loadAvatar() {
  try {
    if (authStore.user && authStore.user.image) {
      const imageArray = authStore.user.image
      if (Array.isArray(imageArray) && imageArray.length > 0) {
        const userId = authStore.user.id
        const filename = imageArray[0]
        // URL de PocketBase para imágenes
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${userId}/${filename}`
      } else {
        avatarSrc.value = randomAvatar
      }
    } else {
      avatarSrc.value = randomAvatar
    }
  } catch (e) {
    console.error('Error loading avatar:', e)
    avatarSrc.value = randomAvatar
  }
}

const handleLogout = async () => {
  loggingOut.value = true
  try {
    await authStore.logout()
    router.push({ name: 'home' })
  } catch (e) {
    console.error('Logout failed', e)
  } finally {
    loggingOut.value = false
  }
}

function formatPrice(p) {
  return p ? `${p} € / noche` : ''
}

function getImage(item, idx = 0) {
  if (item.primeraImagen) {
    return item.primeraImagen
  }
  
  if (item.imagen && item.imagen.length > 0) {
    const imgs = Array.isArray(item.imagen) ? item.imagen : item.imagen.split(',')
    return imgs[0]
  }

  const localImages = [
    '/images/house1.jpg',
    '/images/villa1.jpg',
    '/images/piso-ejemplo.jpeg',
    '/images/3.jpg'
  ]
  return localImages[idx % localImages.length]
}

const cargarPisos = async (filtrosAplicados = {}) => {
  loading.value = true
  try {
    const filters = {}
    
    if (filtrosAplicados.ciudad) filters.ciudad = filtrosAplicados.ciudad
    
    if (filtrosAplicados.precioMin) filters.precioMin = parseFloat(filtrosAplicados.precioMin)
    if (filtrosAplicados.precioMax) filters.precioMax = parseFloat(filtrosAplicados.precioMax)

    if (filtrosAplicados.habitaciones) filters.num_habit = parseInt(filtrosAplicados.habitaciones)
    
    if (filtrosAplicados.banos) filters.banos = parseInt(filtrosAplicados.banos)
    if (filtrosAplicados.disponible !== undefined) filters.disponible = filtrosAplicados.disponible
    
    console.log('🔍 [LoggedIn] Filtros enviados a GraphQL:', filters)
    
    const result = await getPisos(page.value, perPage.value, filters)

    items.value = result.items || []
    page.value = result.page || page.value
    perPage.value = result.perPage || perPage.value
    totalItems.value = result.totalItems || 0
    totalPages.value = result.totalPages || 1
    
    console.log('📊 [LoggedIn] Resultados:', {
      itemsCount: items.value.length,
      page: page.value,
      totalItems: totalItems.value
    })
  } catch (err) {
    console.error('Error cargando pisos:', err)
    items.value = []
  }
  loading.value = false
}

const manejarCambioFiltros = (nuevosFiltros) => {
  filtros.value = nuevosFiltros
  page.value = 1
  cargarPisos(nuevosFiltros)
}

function goPrev() { 
  if (page.value > 1) { 
    page.value -= 1
    cargarPisos(filtros.value) 
  } 
}

function goNext() { 
  if (page.value < totalPages.value) { 
    page.value += 1
    cargarPisos(filtros.value) 
  } 
}

provide('onFiltrosChange', manejarCambioFiltros)

onMounted(async () => {
  // Cargar usuario si es necesario
  if (authStore.isAuthenticated && !authStore.user) {
    await authStore.fetchUser()
  }
  loadAvatar()
  cargarPisos()
})
</script>

<script>
export default {
  data() {
    return { debug: false }
  }
}
</script>

<style scoped>
.main-layout {
  display: grid;
  grid-template-columns: 300px minmax(0, 1fr);
  gap: 1.5rem;
  align-items: start;
}

.cards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 18px;
  padding: 8px 8px;
  box-sizing: border-box;
  width: 100%;
}

.anuncios-container {
  display: block;
  width: 100%;
  padding: 0;
  box-sizing: border-box;
}

.anuncio-card {
  background: #ffffff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0px 4px 14px rgba(0,0,0,0.1);
  transition: .25s;
}

.anuncio-card:hover {
  transform: translateY(-4px);
  box-shadow: 0px 6px 18px rgba(0,0,0,0.15);
}

.anuncio-img {
  width: 100%;
  height: 170px;
  object-fit: cover;
  display: block;
}

.anuncio-info {
  padding: 12px;
}

.titulo {
  margin: 0 0 8px;
  font-size: 1.15em;
}

.descripcion {
  color: #555;
  margin-bottom: 10px;
}

.precio {
  font-weight: bold;
  color: #2185d0;
  font-size: 1.05em;
  margin: 10px 0;
}

.btn-ver-detalle {
  display: inline-block;
  padding: 8px 12px;
  background: #2185d0;
  color: white;
  border-radius: 6px;
  text-decoration: none;
}

.btn-ver-detalle:hover {
  background: #1678c2;
}

.user-avatar-small {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
  cursor: pointer;
}

@media (max-width: 800px) {
  .main-layout {
    grid-template-columns: 1fr;
  }
  .cards-grid {
    grid-template-columns: 1fr;
  }
}

@media (min-width: 1100px) {
  .cards-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
</style>