<template>
  <div class="mis-solicitudes-view">
    <!-- Header -->
    <header class="site-header">
      <div class="logo">
        <img :src="logoImg" alt="Logo rentEase">
      </div>
      <div class="header-buttons">
        <router-link to="/mis-anuncios" class="btn">Mis Anuncios</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <div class="solicitudes-container">
      <h2 class="solicitudes-title"> Mis Solicitudes</h2>

      <!-- Estados de carga y error -->
      <div v-if="loading" class="loading-state">
        <p>Cargando solicitudes...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
        <button @click="cargarSolicitudes" class="btn btn-primary">Reintentar</button>
      </div>

      <div v-else-if="solicitudes.length === 0" class="empty-state">
        <p>No hay solicitudes pendientes</p>
      </div>

      <!-- Lista de solicitudes -->
      <div v-else class="solicitudes-list">
        <div 
          v-for="solicitud in solicitudes" 
          :key="solicitud.id" 
          class="solicitud-card" 
          :class="solicitud.estado"
        >
          <!-- Información de la solicitud -->
          <div class="solicitud-header">
            <div class="solicitud-info">
              <h3 class="piso-titulo">{{ solicitud.tituloPiso || 'Sin título' }}</h3>
              <div class="solicitud-meta">
                <span class="user-info">
                  👤 {{ solicitud.inquilino?.nombre || 'Usuario desconocido' }} • 
                  {{ solicitud.inquilino?.email || 'Sin email' }}
                </span>
                <span class="fechas">
                  📅 {{ formatFecha(solicitud.fecha_inc) }} → {{ formatFecha(solicitud.fecha_fin) }} 
                  ({{ calcularNoches(solicitud.fecha_inc, solicitud.fecha_fin) }} noches)
                </span>
                <span v-if="solicitud.piso?.precio" class="precio">
                  💰 {{ calcularPrecioTotal(solicitud) }}
                </span>
              </div>
            </div>
            
            <!-- Estado y fecha -->
            <div class="solicitud-status">
              <span :class="['estado-badge', getEstadoClass(solicitud.estado)]">
                {{ getEstadoText(solicitud.estado) }}
              </span>
              <div class="fecha-solicitud">
                Solicitado: {{ formatFechaCorta(solicitud.created) }}
              </div>
            </div>
          </div>

          <!-- Información del piso -->
          <div v-if="solicitud.piso" class="piso-info">
            <div class="info-row">
              <span class="info-label">📍 Dirección:</span>
              <span class="info-value">{{ solicitud.piso.direccion }}</span>
            </div>
            <div v-if="solicitud.piso.ciudad" class="info-row">
              <span class="info-label">🏙️ Ciudad:</span>
              <span class="info-value">{{ solicitud.piso.ciudad }}</span>
            </div>
            <div v-if="solicitud.piso.num_habit" class="info-row">
              <span class="info-label">🛏️ Habitaciones:</span>
              <span class="info-value">{{ solicitud.piso.num_habit }}</span>
            </div>
          </div>

          <!-- Acciones según el estado -->
          <div class="solicitud-actions" v-if="solicitud.estado === 'pendiente'">
            <button 
              @click="aprobarSolicitud(solicitud.id)" 
              class="btn btn-success"
              :disabled="procesando === solicitud.id"
            >
               ✅ Aprobar
            </button>
            <button 
              @click="rechazarSolicitud(solicitud.id)" 
              class="btn btn-danger"
              :disabled="procesando === solicitud.id"
            >
               ❌ Rechazar
            </button>
            <router-link 
              v-if="solicitud.piso_id"
              :to="{ name: 'PisoDetalle', params: { id: solicitud.piso_id }}" 
              class="btn btn-outline"
            >
              📋 Ver Anuncio
            </router-link>
            <button 
              @click="verDetalles(solicitud)" 
              class="btn btn-info"
            >
              ℹ️ Detalles
            </button>
          </div>

          <div class="solicitud-actions" v-else-if="solicitud.estado === 'confirmada'">
            <span class="status-text confirmed"> ✅ Confirmada</span>
            <button 
              @click="cancelarReserva(solicitud.id)" 
              class="btn btn-warning"
              :disabled="procesando === solicitud.id"
            >
              🗑️ Cancelar Reserva
            </button>
            <router-link 
              v-if="solicitud.piso_id"
              :to="{ name: 'PisoDetalle', params: { id: solicitud.piso_id }}" 
              class="btn btn-outline"
            >
              📋 Ver Anuncio
            </router-link>
          </div>

          <div class="solicitud-actions" v-else-if="solicitud.estado === 'cancelada'">
            <span class="status-text cancelled"> ❌ Cancelada</span>
            <button 
              @click="eliminarSolicitud(solicitud.id)" 
              class="btn btn-danger"
              :disabled="procesando === solicitud.id"
            >
              🗑️ Eliminar
            </button>
          </div>

          <div class="solicitud-actions" v-else>
            <span class="status-text">Estado: {{ solicitud.estado }}</span>
          </div>
        </div>
      </div>

      <router-link to="/propietario" class="volver-link">← Volver al Inicio</router-link>
    </div>

    <!-- Footer -->
    <footer class="site-footer">
      <p>&copy; 2025 rentEase</p>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { graphqlRequest } from '@/services/graphql'
import logoImg from '@/images/rentEase_logo.jpg'

const router = useRouter()

// Variables reactivas
const solicitudes = ref([])
const loading = ref(false)
const error = ref(null)
const procesando = ref(null)

// Funciones de formato
const formatPrecio = (precio) => {
  const precioNum = Number(precio)
  if (isNaN(precioNum) || precioNum === 0) {
    return 'Precio no disponible'
  }
  return `${precioNum.toFixed(2)} €`
}

const formatFecha = (fecha) => {
  if (!fecha) return 'Sin fecha'
  try {
    return new Date(fecha).toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  } catch {
    return fecha
  }
}

const formatFechaCorta = (fecha) => {
  if (!fecha) return 'Sin fecha'
  try {
    return new Date(fecha).toLocaleDateString('es-ES', { 
      day: '2-digit', 
      month: '2-digit' 
    })
  } catch {
    return fecha
  }
}

// Calcular número de noches
const calcularNoches = (fechaInicio, fechaFin) => {
  if (!fechaInicio || !fechaFin) return 0
  
  try {
    const inicio = new Date(fechaInicio)
    const fin = new Date(fechaFin)
    
    if (isNaN(inicio.getTime()) || isNaN(fin.getTime())) {
      console.error('Fechas inválidas:', fechaInicio, fechaFin)
      return 0
    }
    
    if (fin <= inicio) return 0
    
    const diff = fin.getTime() - inicio.getTime()
    const noches = Math.ceil(diff / (1000 * 3600 * 24))
    
    return noches > 0 ? noches : 0
  } catch (error) {
    console.error('Error calculando noches:', error)
    return 0
  }
}

// Calcular precio total de la reserva
const calcularPrecioTotal = (solicitud) => {
  try {
    const noches = calcularNoches(solicitud.fecha_inc, solicitud.fecha_fin)
    
    // Preferir precio del piso si está disponible
    if (solicitud.piso?.precio) {
      const precioNoche = Number(solicitud.piso.precio)
      const total = noches * precioNoche
      return formatPrecio(total)
    }
    
    // Si no hay precio del piso, mostrar mensaje
    return `Precio por calcular (${noches} noches)`
  } catch {
    return 'Precio no disponible'
  }
}

// Funciones para estados
const getEstadoClass = (estado) => {
  const clases = {
    'pendiente': 'estado-pendiente',
    'confirmada': 'estado-confirmada', 
    'cancelada': 'estado-cancelada',
    'completada': 'estado-completada'
  }
  return clases[estado] || 'estado-pendiente'
}

const getEstadoText = (estado) => {
  const textos = {
    'pendiente': 'Pendiente',
    'confirmada': 'Confirmada',
    'cancelada': 'Cancelada',
    'completada': 'Completada'
  }
  return textos[estado] || estado
}

// Cargar solicitudes del propietario usando GraphQL
const cargarSolicitudes = async () => {
  loading.value = true
  error.value = null
  solicitudes.value = []
  
  try {
    const token = localStorage.getItem('token')
    console.log('🔑 Token para MisSolicitudes:', token ? `Encontrado (${token.substring(0, 20)}...)` : 'NO encontrado')

    if (!token) {
      throw new Error('No estás autenticado. Por favor, inicia sesión.')
    }

    const query = `
      query GetMisSolicitudes {
        misReservas(page: 1, perPage: 50) {
          id
          piso_id
          inquilino_id
          fecha_inc
          fecha_fin
          estado
          created
          updated
          tituloPiso
          direccion
          ciudad
          imagenPiso
          piso {
            id
            titulo
            descripcion
            direccion
            ciudad
            cp
            precio
            num_habit
            superficie
            primeraImagen
          }
          inquilino {
            id
            nombre
            email
            telefono
          }
        }
      }
    `
    
    console.log('🚀 Ejecutando query GraphQL para MisSolicitudes...')
    
    const data = await graphqlRequest(query)
    console.log('✅ Datos recibidos para MisSolicitudes:', data)
    
    if (data && data.misReservas) {
      // Filtrar solo las reservas que pertenecen a pisos del usuario actual
      const userId = localStorage.getItem('userId')
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}')
      
      console.log('👤 Usuario actual:', { userId, currentUser })
      
      solicitudes.value = Array.isArray(data.misReservas) ? data.misReservas : []
      
      // Depuración: mostrar todas las reservas recibidas
      console.log('📋 Todas las reservas recibidas:', solicitudes.value.map(r => ({
        id: r.id,
        piso_id: r.piso_id,
        piso_titulo: r.piso?.titulo,
        estado: r.estado
      })))
      
      console.log(`📊 ${solicitudes.value.length} solicitudes cargadas`)
      
      if (solicitudes.value.length === 0) {
        console.log('ℹ️ No se encontraron solicitudes/reservas')
      }
      
    } else {
      solicitudes.value = []
      console.log('ℹ️ No se encontraron reservas (data.misReservas es undefined)')
    }

  } catch (err) {
    console.error('💥 Error cargando solicitudes:', err)
    error.value = 'Error al cargar las solicitudes: ' + err.message
    
    // Verificar si es error de autenticación
    if (err.message.includes('autenticado') || err.message.includes('401') || 
        err.message.includes('403') || err.message.includes('No estás autenticado')) {
      error.value += '. Por favor, inicia sesión nuevamente.'
      
      // Redirigir a login después de 2 segundos
      setTimeout(() => {
        router.push('/login')
      }, 2000)
    }
    
    // Datos de ejemplo para desarrollo
    if (process.env.NODE_ENV === 'development' && solicitudes.value.length === 0) {
      console.log('🛠️ Modo desarrollo: usando datos de ejemplo')
      solicitudes.value = [
        {
          id: '1',
          piso_id: 'piso123',
          fecha_inc: '2024-12-15',
          fecha_fin: '2024-12-20',
          estado: 'pendiente',
          created: '2024-01-10T10:00:00.000Z',
          tituloPiso: 'Apartamento en Madrid Centro',
          direccion: 'Calle Mayor 123',
          ciudad: 'Madrid',
          piso: {
            id: 'piso123',
            titulo: 'Apartamento en Madrid Centro',
            direccion: 'Calle Mayor 123',
            ciudad: 'Madrid',
            precio: 120,
            num_habit: 2,
            superficie: 75
          },
          inquilino: {
            nombre: 'Juan Pérez',
            email: 'juan@example.com'
          }
        }
      ]
      error.value = null
    }
  } finally {
    loading.value = false
    console.log('🏁 Carga de solicitudes completada')
  }
}

// Ver detalles de la solicitud
const verDetalles = (solicitud) => {
  console.log('🔍 Detalles de la solicitud:', solicitud)
  alert(`Detalles de la reserva:
ID: ${solicitud.id}
Estado: ${solicitud.estado}
Fechas: ${formatFecha(solicitud.fecha_inc)} - ${formatFecha(solicitud.fecha_fin)}
Noches: ${calcularNoches(solicitud.fecha_inc, solicitud.fecha_fin)}
Piso: ${solicitud.tituloPiso || solicitud.piso?.titulo}
Inquilino: ${solicitud.inquilino?.nombre} (${solicitud.inquilino?.email})
Creado: ${formatFecha(solicitud.created)}`)
}

// Acciones sobre las solicitudes usando GraphQL Mutations
const aprobarSolicitud = async (solicitudId) => {
  if (!confirm('¿Estás seguro de que quieres aprobar esta solicitud?')) {
    return
  }

  await actualizarEstadoSolicitud(solicitudId, 'confirmada', '✅ Solicitud aprobada correctamente')
}

const rechazarSolicitud = async (solicitudId) => {
  if (!confirm('¿Estás seguro de que quieres rechazar esta solicitud?')) {
    return
  }

  await actualizarEstadoSolicitud(solicitudId, 'cancelada', '❌ Solicitud rechazada correctamente')
}

const cancelarReserva = async (solicitudId) => {
  if (!confirm('¿Estás seguro de que quieres cancelar esta reserva confirmada?')) {
    return
  }

  await actualizarEstadoSolicitud(solicitudId, 'cancelada', '🗑️ Reserva cancelada correctamente')
}

const eliminarSolicitud = async (solicitudId) => {
  if (!confirm('¿Estás seguro de que quieres eliminar esta solicitud? Esta acción no se puede deshacer.')) {
    return
  }

  procesando.value = solicitudId
  
  try {
    // Mutation GraphQL para eliminar reserva
    const mutation = `
      mutation DeleteReserva($id: ID!) {
        deleteReserva(id: $id) {
          success
          message
        }
      }
    `
    
    console.log(`🗑️ Eliminando solicitud ${solicitudId}...`)
    
    const data = await graphqlRequest(mutation, { id: solicitudId })
    
    if (data && data.deleteReserva && data.deleteReserva.success) {
      // Eliminar del array local
      solicitudes.value = solicitudes.value.filter(s => s.id !== solicitudId)
      alert('🗑️ Solicitud eliminada correctamente')
      console.log('✅ Solicitud eliminada')
    } else {
      throw new Error(data?.deleteReserva?.message || 'Error al eliminar la solicitud')
    }
  } catch (err) {
    console.error('💥 Error eliminando solicitud:', err)
    alert(`Error: ${err.message}`)
  } finally {
    procesando.value = null
  }
}

// Función genérica para actualizar estado con GraphQL
const actualizarEstadoSolicitud = async (solicitudId, nuevoEstado, mensajeExito) => {
  procesando.value = solicitudId
  
  try {
    // Mutation GraphQL para actualizar reserva (según TU schema)
    const mutation = `
      mutation UpdateReserva($id: ID!, $estado: String) {
        updateReserva(id: $id, estado: $estado) {
          id
          piso_id
          inquilino_id
          fecha_inc
          fecha_fin
          estado
        }
      }
    `
    
    console.log(`🔄 Actualizando solicitud ${solicitudId} a estado: ${nuevoEstado}`)
    
    const data = await graphqlRequest(mutation, { 
      id: solicitudId, 
      estado: nuevoEstado 
    })
    
    if (data && data.updateReserva) {
      // Actualizar el estado local de la solicitud
      const solicitudIndex = solicitudes.value.findIndex(s => s.id === solicitudId)
      if (solicitudIndex !== -1) {
        solicitudes.value[solicitudIndex].estado = nuevoEstado
        solicitudes.value[solicitudIndex] = { ...solicitudes.value[solicitudIndex] }
      }
      
      alert(mensajeExito)
      console.log('✅ Estado de reserva actualizado correctamente')
    } else {
      throw new Error('Error al actualizar la reserva')
    }
  } catch (err) {
    console.error('💥 Error actualizando solicitud:', err)
    alert(`Error: ${err.message}`)
  } finally {
    procesando.value = null
  }
}

const desconectar = () => {
  localStorage.removeItem('token')
  localStorage.removeItem('userId')
  localStorage.removeItem('currentUser')
  localStorage.removeItem('userRole')
  router.push('/')
}

// Cargar solicitudes al montar el componente
onMounted(() => {
  console.log('🎯 Componente MisSolicitudes montado')
  cargarSolicitudes()
})
</script>

<style scoped>
.mis-solicitudes-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
}

/* Header */
.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
}

.logo img {
  height: 50px;
}

.header-buttons {
  display: flex;
  gap: 0.8rem;
}

.header-buttons .btn {
  padding: 0.5rem 1rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  background: none;
  cursor: pointer;
}

.header-buttons .btn-active {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover {
  background-color: #0056b3;
  color: white;
}

/* Contenedor principal */
.solicitudes-container {
  background: white;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  width: 90%;
  max-width: 900px;
  margin: 1.5rem auto;
}

.solicitudes-title {
  text-align: center;
  margin-bottom: 1.5rem;
  color: #333;
  font-size: 1.5rem;
}

/* Tarjetas de solicitud */
.solicitud-card {
  background: white;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  border: 1px solid #e0e0e0;
  border-left: 4px solid #007bff;
}

.solicitud-card.pendiente {
  border-left-color: #ffc107;
}

.solicitud-card.confirmada {
  border-left-color: #28a745;
}

.solicitud-card.cancelada {
  border-left-color: #dc3545;
}

/* Header de la solicitud */
.solicitud-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.8rem;
}

.solicitud-info {
  flex: 1;
}

.piso-titulo {
  margin: 0 0 0.5rem 0;
  color: #333;
  font-size: 1.1rem;
  font-weight: bold;
}

.solicitud-meta {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
  font-size: 0.85rem;
  color: #666;
}

.user-info, .fechas, .precio {
  display: block;
}

.precio {
  color: #28a745;
  font-weight: bold;
}

/* Información del piso */
.piso-info {
  background: #f8f9fa;
  padding: 0.8rem;
  border-radius: 6px;
  margin: 0.8rem 0;
  border-left: 3px solid #6c757d;
}

.info-row {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.3rem;
  font-size: 0.85rem;
}

.info-label {
  font-weight: bold;
  color: #495057;
  min-width: 100px;
}

.info-value {
  color: #6c757d;
}

/* Estado de la solicitud */
.solicitud-status {
  text-align: right;
  min-width: 120px;
}

.estado-badge {
  padding: 0.3rem 0.8rem;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: bold;
  text-transform: uppercase;
  display: inline-block;
  margin-bottom: 0.3rem;
}

.estado-pendiente {
  background: #fff3cd;
  color: #856404;
}

.estado-confirmada {
  background: #d4edda;
  color: #155724;
}

.estado-cancelada {
  background: #f8d7da;
  color: #721c24;
}

.fecha-solicitud {
  font-size: 0.75rem;
  color: #999;
}

/* Acciones */
.solicitud-actions {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
  margin-top: 0.8rem;
  padding-top: 0.8rem;
  border-top: 1px dashed #dee2e6;
}

.btn {
  padding: 0.4rem 0.8rem;
  border: none;
  border-radius: 4px;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  font-size: 0.8rem;
}

.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.btn-success {
  background: #28a745;
  color: white;
}

.btn-danger {
  background: #dc3545;
  color: white;
}

.btn-warning {
  background: #ffc107;
  color: #212529;
}

.btn-outline {
  background: transparent;
  border: 1px solid #6c757d;
  color: #6c757d;
}

.btn-primary {
  background: #007bff;
  color: white;
}

.btn-info {
  background: #17a2b8;
  color: white;
}

/* Estados de texto */
.status-text {
  font-weight: bold;
  padding: 0.4rem 0.8rem;
  border-radius: 4px;
  font-size: 0.8rem;
}

.confirmed {
  background: #d4edda;
  color: #155724;
}

.cancelled {
  background: #f8d7da;
  color: #721c24;
}

/* Enlace volver */
.volver-link {
  text-align: center;
  margin-top: 1.5rem;
  display: block;
  color: #007bff;
  text-decoration: none;
  font-weight: bold;
}

.volver-link:hover {
  text-decoration: underline;
}

/* Footer */
.site-footer {
  background: #f1f1f1;
  color: #333;
  text-align: center;
  padding: 1rem;
  font-size: 0.8rem;
  margin-top: 2rem;
}

/* Estados de la página */
.loading-state,
.error-state,
.empty-state {
  text-align: center;
  padding: 2rem;
  color: #666;
}

.error-state {
  color: #dc3545;
}

.empty-state {
  color: #666;
}

/* Responsive */
@media (max-width: 768px) {
  .solicitudes-container {
    width: 95%;
    padding: 1rem;
  }
  
  .solicitud-header {
    flex-direction: column;
    gap: 0.8rem;
  }
  
  .solicitud-status {
    text-align: left;
  }
  
  .solicitud-actions {
    flex-direction: column;
  }
  
  .header-buttons {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .site-header {
    padding: 1rem;
    flex-direction: column;
    gap: 1rem;
  }
}
</style>