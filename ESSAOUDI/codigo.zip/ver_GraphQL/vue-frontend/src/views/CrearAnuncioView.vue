<template>
  <div class="crear-anuncio-view">
    <!-- Header integrado -->
    <header class="site-header">
      <div class="logo">
        <img :src="logoImg" alt="Logo rentEase">
      </div>
      <div class="header-buttons">
        <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
        <router-link to="/mis-anuncios" class="btn">Mis Anuncios</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <div class="form-container">
      <h2 class="form-title">Crear un nuevo anuncio</h2>

      <!-- Estados -->
      <div v-if="loading" class="loading-state">
        <p>Creando anuncio...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
      </div>

      <div v-else-if="success" class="success-state">
        <p>¡Anuncio creado exitosamente! Redirigiendo...</p>
      </div>

      <form v-else @submit.prevent="crearAnuncio">
        <div class="form-group">
          <label for="titulo">Título del anuncio *</label>
          <input v-model="form.titulo" type="text" id="titulo" required>
        </div>

        <div class="form-group">
          <label for="direccion">Dirección *</label>
          <input v-model="form.direccion" type="text" id="direccion" required>
        </div>

        <div class="form-group">
          <label for="ciudad">Ciudad *</label>
          <input v-model="form.ciudad" type="text" id="ciudad" required>
        </div>

        <div class="form-group">
          <label for="codigoPostal">Código Postal *</label>
          <input v-model="form.cp" type="text" id="codigoPostal" required>
        </div>

        <div class="form-group">
          <label for="descripcion">Descripción *</label>
          <textarea v-model="form.descripcion" id="descripcion" rows="4" required></textarea>
        </div>

        <div class="form-group">
          <label for="precio">Precio por noche (€) *</label>
          <input v-model="form.precio" type="number" id="precio" min="1" required>
        </div>

          <div class="form-group">
            <label for="num_habit">Número de habitaciones *</label>
            <input v-model="form.num_habit" type="number" id="num_habit" min="1" required>
          </div>

        <div class="form-group">
          <label for="superficie">Superficie (m²) *</label>
          <input v-model="form.superficie" type="number" id="superficie" min="1" required>
        </div>

        <!-- Sección de imágenes -->
        <div class="form-group">
          <label for="fotos">Fotos del piso (máx. 5)</label>
          <input 
            type="file" 
            id="fotos" 
            accept="image/*" 
            multiple 
            @change="manejarSeleccionArchivos"
            ref="fileInput"
            :disabled="archivosSeleccionados.length >= 5"
          >
          <small class="help-text">Selecciona entre 1 y 5 imágenes (máx. 5MB cada una)</small>
          
          <div v-if="archivosSeleccionados.length > 0" class="archivos-lista">
            <p><strong>Archivos seleccionados:</strong> {{ archivosSeleccionados.length }}/5</p>
            <ul>
              <li v-for="(archivo, index) in archivosSeleccionados" :key="index" class="archivo-item">
                {{ archivo.name }} 
                <button type="button" @click="eliminarArchivo(index)" class="btn-eliminar">×</button>
              </li>
            </ul>
            
            <!-- Vista previa de imágenes -->
            <div v-if="vistasPrevias.length > 0" class="vista-previa-container">
              <h4>Vista previa:</h4>
              <div class="vista-previa-grid">
                <div v-for="(vista, index) in vistasPrevias" :key="index" class="vista-previa-item">
                  <img :src="vista" :alt="`Vista previa ${index + 1}`" class="vista-previa-img">
                  <button type="button" @click="eliminarArchivo(index)" class="btn-eliminar-img">Eliminar</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="form-actions">
          <button type="submit" class="btn-primary" :disabled="creando">
            {{ creando ? 'Creando...' : 'Crear anuncio' }}
          </button>
          <router-link to="/mis-anuncios" class="btn-cancelar">Cancelar</router-link>
        </div>
      </form>
    </div>

    <!-- Footer integrado -->
    <footer class="site-footer">
      <p>&copy; 2025 rentEase. Todos los derechos reservados.</p>
      <p>Contacto | Política de privacidad</p>
    </footer>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { graphqlRequest } from '@/services/graphql'
import logoImg from '@/images/rentEase_logo.jpg'

const router = useRouter()
const loading = ref(false)
const creando = ref(false)
const error = ref('')
const success = ref(false)
const archivosSeleccionados = ref([])
const vistasPrevias = ref([])
const fileInput = ref(null)

const form = reactive({
  titulo: '',
  direccion: '',
  ciudad: '',
  cp: '',
  descripcion: '',
  precio: '',
  num_habit: '',
  superficie: '',
  imagen: []
})

// Manejar selección de archivos
const manejarSeleccionArchivos = (event) => {
  const archivos = Array.from(event.target.files)
  
  // Validar número máximo de archivos
  const totalArchivos = archivosSeleccionados.value.length + archivos.length
  if (totalArchivos > 5) {
    error.value = 'Máximo 5 imágenes permitidas'
    return
  }
  
  // Validar tipos de archivo
  const archivosValidos = archivos.filter(archivo => {
    if (!archivo.type.startsWith('image/')) {
      error.value = `El archivo ${archivo.name} no es una imagen válida`
      return false
    }
    
    // Validar tamaño (máx 5MB)
    if (archivo.size > 5 * 1024 * 1024) {
      error.value = `El archivo ${archivo.name} es demasiado grande (máx 5MB)`
      return false
    }
    
    return true
  })
  
  // Añadir archivos válidos
  archivosSeleccionados.value.push(...archivosValidos)
  
  // Generar vistas previas
  archivosValidos.forEach(archivo => {
    const reader = new FileReader()
    reader.onload = (e) => {
      vistasPrevias.value.push(e.target.result)
    }
    reader.readAsDataURL(archivo)
  })
  
  // Limpiar el input para permitir seleccionar los mismos archivos otra vez
  if (fileInput.value) {
    fileInput.value.value = ''
  }
  
  error.value = ''
}

// Eliminar archivo
const eliminarArchivo = (index) => {
  archivosSeleccionados.value.splice(index, 1)
  vistasPrevias.value.splice(index, 1)
}

// Validar formulario
const validarFormulario = () => {
  if (!form.titulo.trim()) {
    error.value = 'El título es obligatorio'
    return false
  }
  
  if (!form.direccion.trim()) {
    error.value = 'La dirección es obligatoria'
    return false
  }
  
  if (!form.ciudad.trim()) {
    error.value = 'La ciudad es obligatoria'
    return false
  }
  
  if (!form.cp || !String(form.cp).trim()) {
    error.value = 'El código postal es obligatorio'
    return false
  }
  
  if (!form.precio || form.precio < 1) {
    error.value = 'El precio debe ser mayor a 0'
    return false
  }
  
  if (!form.num_habit || Number(form.num_habit) < 1) {
    error.value = 'El número de habitaciones debe ser mayor a 0'
    return false
  }
  
  if (!form.superficie || form.superficie < 1) {
    error.value = 'La superficie debe ser mayor a 0'
    return false
  }
  
  error.value = ''
  return true
}

// Subir imágenes a PocketBase (API REST)
const subirImagenesAPocketBase = async (anuncioId, archivos) => {
  try {
    const token = localStorage.getItem('token')
    
    const formData = new FormData()
    
    // Añadir cada imagen
    archivos.forEach((archivo) => {
      formData.append('imagen', archivo)
    })

    // Usar la API REST de PocketBase para actualizar el anuncio con imágenes
    const response = await fetch(`http://127.0.0.1:8090/api/collections/pisos/records/${anuncioId}`, {
      method: 'PATCH',
      headers: {
        'Authorization': token,
      },
      body: formData
    })

    if (!response.ok) {
      console.warn('⚠️ Las imágenes no se pudieron subir')
      return false
    }

    return true
  } catch (err) {
    console.error('Error subiendo imágenes:', err)
    return false
  }
}

// Crear anuncio usando GraphQL
const crearAnuncio = async () => {
  if (!validarFormulario()) return
  
  creando.value = true
  error.value = ''
  success.value = false
  
  try {
    // Usar el token correcto
    const token = localStorage.getItem('token')
    
    if (!token) {
      throw new Error('No estás autenticado. Por favor, inicia sesión nuevamente.')
    }

    // PRIMERO: Crear el anuncio usando GraphQL Mutation
    // Mutation CORRECTA según tu schema: createPiso
    const mutation = `
      mutation CreatePiso($input: PisoInput!) {
        createPiso(input: $input) {
          id
          titulo
          direccion
          ciudad
          cp
          descripcion
          precio
          num_habit
          superficie
          propietario_id
          created
        }
      }
    `

    // Preparar datos según PisoInput de tu schema
    const variables = {
      input: {
        titulo: form.titulo,
        direccion: form.direccion,
        ciudad: form.ciudad,
        cp: String(form.cp),
        descripcion: form.descripcion,
        precio: parseFloat(form.precio),
        num_habit: parseInt(form.num_habit),
        superficie: parseFloat(form.superficie),
        // propietario_id se asignará automáticamente desde el contexto
      }
    }

    console.log('📤 Creando piso via GraphQL:', variables.input)

    // Ejecutar la mutation GraphQL
    const data = await graphqlRequest(mutation, variables)
    
    if (!data || !data.createPiso) {
      throw new Error('No se recibió respuesta del servidor')
    }

    const pisoCreado = data.createPiso
    console.log('✅ Piso creado via GraphQL:', pisoCreado)

    // SEGUNDO: Si hay imágenes, subirlas usando la API REST de PocketBase
    if (archivosSeleccionados.value.length > 0) {
      console.log('📤 Subiendo imágenes...')
      
      const imagenesSubidas = await subirImagenesAPocketBase(pisoCreado.id, archivosSeleccionados.value)
      
      if (imagenesSubidas) {
        console.log('✅ Imágenes subidas correctamente')
      } else {
        console.warn('⚠️ Las imágenes no se pudieron subir, pero el piso fue creado')
      }
    }

    success.value = true
    
    // Redirigir después de éxito
    setTimeout(() => {
      router.push('/mis-anuncios')
    }, 2000)
    
  } catch (err) {
    console.error('💥 Error creando anuncio:', err)
    
    // Manejo específico de errores
    if (err.message.includes('UNAUTHENTICATED') || err.message.includes('autenticado')) {
      error.value = 'Tu sesión ha expirado. Por favor, inicia sesión nuevamente.'
    } else if (err.message.includes('Cannot query field')) {
      error.value = 'Error en la consulta GraphQL. Verifica los campos.'
    } else {
      error.value = err.message || 'Error al crear el anuncio. Intenta nuevamente.'
    }
  } finally {
    creando.value = false
  }
}

// Desconectar
const desconectar = () => {
  localStorage.removeItem('token')
  localStorage.removeItem('currentUser')
  localStorage.removeItem('userRole')
  router.push('/')
}
</script>

<style scoped>
.crear-anuncio-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
}

/* Header styles */
.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
  position: static;
  top: 0;
}

.logo img {
  height: 60px;
}

.header-buttons .btn {
  margin-left: 1rem;
  padding: 0.5rem 1rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  background: none;
  cursor: pointer;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover {
  background-color: #0056b3;
  color: white;
}

/* Contenedor principal */
.form-container {
  background: white;
  padding: 2rem 2.5rem;
  border-radius: 12px;
  box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
  width: 80%;
  max-width: 700px;
  margin: 2rem auto;
}

.form-title {
  text-align: center;
  margin-bottom: 1.5rem;
  font-size: 1.6rem;
  color: #333;
}

.form-group {
  margin-bottom: 1.5rem;
}

label {
  display: block;
  margin-bottom: 0.3rem;
  color: #555;
  font-size: 0.9rem;
  font-weight: bold;
}

input, select, textarea {
  width: 100%;
  padding: 0.7rem;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 1rem;
  box-sizing: border-box;
}

textarea {
  resize: vertical;
}

input:focus, select:focus, textarea:focus {
  border-color: #007bff;
  outline: none;
}

.help-text {
  color: #666;
  font-size: 0.8rem;
  margin-top: 0.3rem;
  display: block;
}

/* Estilos para archivos */
.archivos-lista {
  margin-top: 1rem;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 8px;
  border: 1px solid #e9ecef;
}

.archivo-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem;
  margin-bottom: 0.5rem;
  background: white;
  border-radius: 4px;
  border: 1px solid #dee2e6;
}

.btn-eliminar {
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 50%;
  width: 24px;
  height: 24px;
  cursor: pointer;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-eliminar:hover {
  background: #c82333;
}

/* Vista previa de imágenes */
.vista-previa-container {
  margin-top: 1rem;
}

.vista-previa-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: 1rem;
  margin-top: 0.5rem;
}

.vista-previa-item {
  text-align: center;
}

.vista-previa-img {
  width: 100%;
  height: 100px;
  object-fit: cover;
  border-radius: 8px;
  border: 2px solid #dee2e6;
}

.btn-eliminar-img {
  margin-top: 0.5rem;
  padding: 0.3rem 0.6rem;
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.8rem;
}

.btn-eliminar-img:hover {
  background: #c82333;
}

/* Acciones del formulario */
.form-actions {
  margin-top: 2rem;
  display: flex;
  justify-content: space-between;
  gap: 1rem;
}

.btn-primary {
  padding: 0.7rem 1rem;
  border: none;
  border-radius: 6px;
  background-color: #007bff;
  color: white;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  text-align: center;
  flex: 1;
}

.btn-primary:hover:not(:disabled) {
  background-color: #0056b3;
}

.btn-primary:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
}

.btn-cancelar {
  padding: 0.7rem 1rem;
  border: none;
  border-radius: 6px;
  background-color: #dc3545;
  color: white;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  text-align: center;
  flex: 1;
}

.btn-cancelar:hover {
  background-color: #a71d2a;
}

/* Footer */
.site-footer {
  background-color: #f1f1f1;
  color: #333;
  text-align: center;
  padding: 20px 0;
  font-size: 0.9rem;
  border-top: 1px solid #ccc;
}

.site-footer a {
  color: #007bff;
  text-decoration: none;
  margin: 0 5px;
}

.site-footer a:hover {
  text-decoration: underline;
}

/* Estados */
.loading-state,
.error-state,
.success-state {
  text-align: center;
  padding: 2rem;
  color: #666;
  font-size: 1.1rem;
}

.error-state {
  color: #dc3545;
  background: #f8d7da;
  border-radius: 8px;
  margin-bottom: 1rem;
}

.success-state {
  color: #155724;
  background: #d4edda;
  border-radius: 8px;
  margin-bottom: 1rem;
}

/* Responsive */
@media (max-width: 768px) {
  .form-container {
    width: 90%;
    padding: 1.5rem;
  }
  
  .form-actions {
    flex-direction: column;
  }
  
  .header-buttons {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .header-buttons .btn {
    margin-left: 0;
  }
  
  .vista-previa-grid {
    grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  }
}

@media (max-width: 480px) {
  .form-container {
    padding: 1rem;
  }
}
</style>