<template>
  <div class="piso-detalle-view">
    <header class="site-header">
      <div class="logo">
        <img :src="logoImg" alt="Logo rentEase">
      </div>
      <div class="header-buttons">
        <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <div class="piso-container">
      <div v-if="loading" class="loading-state">
        <p>Cargando detalles del piso...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
      </div>

      <template v-else-if="piso">
        <!-- Header del piso -->
        <div class="piso-header">
          <h1 class="piso-title">{{ piso.titulo }}</h1>
          <div class="piso-precio">{{ formatPrice(piso.precio) }}</div>
        </div>

        <!-- Galería -->
        <div class="piso-galeria">
          <img 
            :src="getPisoImage(piso)" 
            :alt="piso.titulo" 
            class="piso-img-principal"
            @error="handleImageError"
          >
        </div>
        <div v-if="piso.imagen && piso.imagen.length > 1" class="piso-miniaturas">
          <img 
            v-for="(img, index) in piso.imagen" 
            :key="index"
            :src="getImageUrl(piso.id, img)" 
            :alt="`${piso.titulo} - imagen ${index + 1}`"
            class="miniatura"
            @click="cambiarImagenPrincipal(getImageUrl(piso.id, img))"
            @error="handleThumbnailError"
          >
        </div>

        <!-- Información principal -->
        <div class="piso-info-grid">
          <div class="info-item">
            <span class="icon">📍</span>
            <div>
              <div class="label">Ubicación</div>
              <div class="value">{{ piso.ciudad }}, {{ piso.cp }}</div>
            </div>
          </div>
          
          <div class="info-item">
            <span class="icon">🏠</span>
            <div>
              <div class="label">Dirección</div>
              <div class="value">{{ piso.direccion }}</div>
            </div>
          </div>
          
          <div class="info-item">
            <span class="icon">🛏️</span>
            <div>
              <div class="label">Habitaciones</div>
              <div class="value">{{ piso.num_habit }}</div>
            </div>
          </div>
          
          <div class="info-item">
            <span class="icon">📐</span>
            <div>
              <div class="label">Superficie</div>
              <div class="value">{{ piso.superficie }} m²</div>
            </div>
          </div>
        </div>

        <!-- Descripción -->
        <div class="descripcion-section">
          <h3>Descripción</h3>
          <p class="descripcion-texto">{{ piso.descripcion }}</p>
        </div>

        <!-- Acciones -->
        <div class="piso-actions">
          <router-link :to="`/reservar/${piso.id}`" class="btn-reservar">Reservar Ahora</router-link>
          <router-link to="/inquilino" class="btn-volver">Volver al Inicio</router-link>
        </div>

        <!-- Comentarios -->
        <div class="comentarios-section">
          <h3>Comentarios</h3>
          
          <!-- Formulario -->
          <div v-if="usuarioLogueado" class="comentario-form">
            <textarea 
              v-model="nuevoComentario" 
              placeholder="Comparte tu experiencia..."
              rows="3"
              class="comentario-input"
            ></textarea>
            <button 
              @click="agregarComentario" 
              class="btn-comentar"
              :disabled="!nuevoComentario.trim()"
            >
              Publicar
            </button>
          </div>
          <div v-else class="login-prompt">
            <router-link to="/login">Inicia sesión</router-link> para comentar
          </div>

          <!-- Lista de comentarios -->
          <div class="comentarios-lista">
            <div v-if="cargandoComentarios" class="loading">Cargando comentarios...</div>
            
            <div v-else-if="comentarios.length === 0" class="sin-comentarios">
              Sé el primero en comentar
            </div>
            
            <div v-else class="comentarios">
              <div 
                v-for="comentario in comentarios" 
                :key="comentario.id" 
                class="comentario"
                :class="{ 'propio': esMiComentario(comentario) }"
              >
                <div class="comentario-header">
                  <div class="usuario">
                    <span class="avatar">👤</span>
                    <div>
                      <div class="nombre">{{ obtenerNombreUsuario(comentario) }}</div>
                      <div class="fecha">{{ formatFecha(comentario.created) }}</div>
                    </div>
                  </div>
                  
                  <div v-if="esMiComentario(comentario) && usuarioLogueado" class="acciones">
                    <button @click="iniciarEdicion(comentario)" class="btn-accion">Editar</button>
                    <button @click="eliminarComentario(comentario.id)" class="btn-accion eliminar">Eliminar</button>
                  </div>
                </div>

                <div v-if="editandoId === comentario.id" class="edicion">
                  <textarea v-model="comentarioEditado" rows="2" class="edicion-input"></textarea>
                  <div class="edicion-actions">
                    <button @click="guardarEdicion(comentario.id)" class="btn-guardar">Guardar</button>
                    <button @click="cancelarEdicion" class="btn-cancelar">Cancelar</button>
                  </div>
                </div>
                <div v-else class="contenido">
                  {{ comentario.coment }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>
    </div>

    <footer class="site-footer">
      <p>&copy; 2025 rentEase. Todos los derechos reservados.</p>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { getPisoById } from '@/services/pisos.service'
import { getComentariosByPiso, createComentario, updateComentario, deleteComentario } from '@/services/comentarios.service'
import logoImg from '@/images/rentEase_logo.jpg'
import pisoEjemplo from '@/images/piso-ejemplo.jpeg'

const route = useRoute()
const router = useRouter()

// Estados
const piso = ref(null)
const loading = ref(false)
const error = ref(null)
const imagenPrincipal = ref('')
const comentarios = ref([])
const cargandoComentarios = ref(false)
const nuevoComentario = ref('')
const editandoId = ref(null)
const comentarioEditado = ref('')

// Computed
const usuarioLogueado = computed(() => {
  return localStorage.getItem('token') && localStorage.getItem('userId')
})

const usuarioActual = computed(() => {
  try {
    const userData = localStorage.getItem('currentUser')
    return userData ? JSON.parse(userData) : null
  } catch {
    return null
  }
})

// Funciones básicas
const formatPrice = (precio) => precio ? `${precio} €/noche` : 'Consultar'
const formatFecha = (fecha) => new Date(fecha).toLocaleDateString('es-ES')

const getImageUrl = (pisoId, filename) => {
  return pisoId && filename 
    ? `http://127.0.0.1:8090/api/files/pisos/${pisoId}/${filename}`
    : pisoEjemplo
}

const getPisoImage = (pisoData) => {
  if (imagenPrincipal.value) return imagenPrincipal.value
  if (pisoData.imagen?.[0]) return getImageUrl(pisoData.id, pisoData.imagen[0])
  return pisoEjemplo
}

const handleImageError = (e) => e.target.src = pisoEjemplo
const handleThumbnailError = (e) => e.target.src = pisoEjemplo

const cambiarImagenPrincipal = (nuevaImagen) => {
  imagenPrincipal.value = nuevaImagen
}

// Cargar piso usando GraphQL
const cargarPisoDetalle = async () => {
  loading.value = true
  error.value = null
  try {
    const pisoData = await getPisoById(route.params.id)
    piso.value = pisoData
    await cargarComentarios()
  } catch (err) {
    console.error('Error cargando piso:', err)
    error.value = 'Error al cargar los detalles del piso'
  } finally {
    loading.value = false
  }
}

// Funciones de comentarios usando GraphQL
const cargarComentarios = async () => {
  if (!piso.value?.id) return
  cargandoComentarios.value = true
  try {
    const data = await getComentariosByPiso(piso.value.id)
    comentarios.value = data
  } catch (err) {
    console.error('Error cargando comentarios:', err)
  } finally {
    cargandoComentarios.value = false
  }
}

const agregarComentario = async () => {
  if (!usuarioLogueado.value) {
    alert('Debes iniciar sesión para comentar')
    return
  }
  
  if (!nuevoComentario.value.trim()) return
  
  try {
    await createComentario({
      piso_id: piso.value.id,
      coment: nuevoComentario.value.trim(),
      valoracion: 5 // Default valoracion
    })
    
    nuevoComentario.value = ''
    await cargarComentarios()
  } catch (err) {
    console.error('Error al publicar comentario:', err)
    alert('Error al publicar comentario: ' + err.message)
  }
}

const esMiComentario = (comentario) => {
  return usuarioActual.value && comentario.usuario_id === usuarioActual.value.id
}

const obtenerNombreUsuario = (comentario) => {
  if (comentario.usuario) {
    const usuario = comentario.usuario

    if (usuario.username) return usuario.username
    if (usuario.nombre && usuario.apellidos) return `${usuario.nombre} ${usuario.apellidos}`
    if (usuario.nombre) return usuario.nombre
    if (usuario.email) return usuario.email.split('@')[0]
  }
  
  return `Usuario ${comentario.usuario_id?.substring(0, 8)}...`
}

const iniciarEdicion = (comentario) => {
  if (!usuarioLogueado.value || !esMiComentario(comentario)) return
  editandoId.value = comentario.id
  comentarioEditado.value = comentario.coment
}

const cancelarEdicion = () => {
  editandoId.value = null
  comentarioEditado.value = ''
}

const guardarEdicion = async (comentarioId) => {
  if (!usuarioLogueado.value || !comentarioEditado.value.trim()) return
  
  try {
    const comentarioOriginal = comentarios.value.find(c => c.id === comentarioId)
    await updateComentario(comentarioId, {
      piso_id: comentarioOriginal.piso_id,
      coment: comentarioEditado.value.trim(),
      valoracion: comentarioOriginal.valoracion || 5
    })
    
    editandoId.value = null
    comentarioEditado.value = ''
    await cargarComentarios()
  } catch (err) {
    console.error('Error al actualizar comentario:', err)
    alert('Error al actualizar comentario: ' + err.message)
  }
}

const eliminarComentario = async (comentarioId) => {
  if (!usuarioLogueado.value || !confirm('¿Eliminar comentario?')) return
  
  try {
    await deleteComentario(comentarioId)
    await cargarComentarios()
  } catch (err) {
    console.error('Error al eliminar comentario:', err)
    alert('Error al eliminar comentario: ' + err.message)
  }
}

const desconectar = () => {
  localStorage.removeItem('token')
  localStorage.removeItem('userId')
  localStorage.removeItem('currentUser')
  localStorage.removeItem('userRole')
  router.push('/')
}

onMounted(cargarPisoDetalle)
</script>

<style scoped>
.piso-detalle-view {
  min-height: 100vh;
  background: #f8f9fa;
  font-family: system-ui, sans-serif;
}

.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background: white;
  border-bottom: 1px solid #e5e7eb;
}

.logo img { height: 50px; }

.header-buttons {
  display: flex;
  gap: 1rem;
}

.btn {
  padding: 0.5rem 1rem;
  border: 1px solid #3b82f6;
  border-radius: 6px;
  text-decoration: none;
  color: #3b82f6;
  font-weight: 500;
}

.btn-primary {
  background: #3b82f6;
  color: white;
}

.btn:hover { opacity: 0.9; }

.piso-container {
  max-width: 800px;
  margin: 2rem auto;
  padding: 0 1rem;
}

.piso-header {
  text-align: center;
  margin-bottom: 2rem;
}

.piso-title {
  font-size: 2rem;
  font-weight: bold;
  color: #1f2937;
  margin-bottom: 0.5rem;
}

.piso-precio {
  font-size: 1.5rem;
  color: #059669;
  font-weight: 600;
}

.piso-galeria {
  margin-bottom: 2rem;
}

.piso-img-principal {
  width: 100%;
  height: 400px;
  object-fit: cover;
  border-radius: 12px;
  box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
}

.piso-miniaturas {
  display: flex;
  gap: 0.5rem;
  margin-top: 1rem;
  overflow-x: auto;
  padding: 0.5rem 0;
}

.miniatura {
  width: 80px;
  height: 60px;
  object-fit: cover;
  border-radius: 6px;
  cursor: pointer;
  border: 2px solid transparent;
  transition: all 0.2s ease;
}

.miniatura:hover {
  border-color: #3b82f6;
  transform: scale(1.05);
}

.piso-info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: white;
  border-radius: 8px;
  box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
}

.icon { font-size: 1.5rem; }

.label {
  font-size: 0.875rem;
  color: #6b7280;
  font-weight: 500;
}

.value {
  font-weight: 600;
  color: #1f2937;
}

.descripcion-section {
  background: white;
  padding: 1.5rem;
  border-radius: 8px;
  margin-bottom: 2rem;
}

.descripcion-section h3 {
  margin-bottom: 1rem;
  color: #1f2937;
}

.descripcion-texto {
  line-height: 1.6;
  color: #4b5563;
}

.piso-actions {
  display: flex;
  gap: 1rem;
  justify-content: center;
  margin-bottom: 3rem;
}

.btn-reservar {
  padding: 1rem 2rem;
  background: #059669;
  color: white;
  text-decoration: none;
  border-radius: 8px;
  font-weight: 600;
  transition: all 0.2s;
}

.btn-reservar:hover {
  background: #047857;
  transform: translateY(-1px);
}

.btn-volver {
  padding: 1rem 2rem;
  background: #6b7280;
  color: white;
  text-decoration: none;
  border-radius: 8px;
  font-weight: 600;
}

.btn-volver:hover { background: #4b5563; }

.comentarios-section {
  background: white;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
}

.comentarios-section h3 {
  margin-bottom: 1.5rem;
  color: #1f2937;
}

.comentario-form {
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
}

.comentario-input {
  flex: 1;
  padding: 0.75rem;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  resize: vertical;
}

.comentario-input:focus {
  outline: none;
  border-color: #3b82f6;
}

.btn-comentar {
  padding: 0.75rem 1.5rem;
  background: #3b82f6;
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
}

.btn-comentar:hover:not(:disabled) { background: #2563eb; }
.btn-comentar:disabled { background: #9ca3af; cursor: not-allowed; }

.login-prompt {
  text-align: center;
  padding: 1rem;
  background: #fef3c7;
  border-radius: 6px;
  margin-bottom: 2rem;
}

.login-prompt a {
  color: #3b82f6;
  text-decoration: none;
  font-weight: 500;
}

.comentarios { display: flex; flex-direction: column; gap: 1rem; }

.comentario {
  padding: 1.5rem;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  background: #f9fafb;
}

.comentario.propio {
  background: #f0f9ff;
  border-color: #bae6fd;
}

.comentario-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
}

.usuario {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.avatar { font-size: 1.25rem; }

.nombre {
  font-weight: 600;
  color: #1f2937;
}

.fecha {
  font-size: 0.875rem;
  color: #6b7280;
}

.acciones { display: flex; gap: 0.5rem; }

.btn-accion {
  padding: 0.25rem 0.75rem;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  background: white;
  font-size: 0.875rem;
  cursor: pointer;
}

.btn-accion:hover { background: #f3f4f6; }
.btn-accion.eliminar:hover { background: #fef2f2; color: #dc2626; }

.edicion { margin-top: 1rem; }

.edicion-input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #3b82f6;
  border-radius: 6px;
  resize: vertical;
}

.edicion-actions {
  display: flex;
  gap: 0.5rem;
  margin-top: 0.5rem;
  justify-content: flex-end;
}

.btn-guardar, .btn-cancelar {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 4px;
  font-size: 0.875rem;
  cursor: pointer;
}

.btn-guardar {
  background: #059669;
  color: white;
}

.btn-cancelar {
  background: #6b7280;
  color: white;
}

.contenido {
  line-height: 1.6;
  color: #374151;
}

.loading-state, .error-state, .loading, .sin-comentarios {
  text-align: center;
  padding: 3rem;
  color: #6b7280;
}

.error-state { color: #dc2626; background: #fef2f2; border-radius: 8px; }

.site-footer {
  text-align: center;
  padding: 2rem;
  color: #6b7280;
  border-top: 1px solid #e5e7eb;
}

@media (max-width: 768px) {
  .site-header { padding: 1rem; flex-direction: column; gap: 1rem; }
  .header-buttons { flex-direction: column; width: 100%; }
  .btn { text-align: center; margin: 0; }
  .piso-info-grid { grid-template-columns: 1fr; }
  .piso-actions { flex-direction: column; }
  .comentario-form { flex-direction: column; }
  .comentario-header { flex-direction: column; gap: 1rem; }
  .acciones { align-self: flex-end; }
  .miniatura {
    width: 60px;
    height: 45px;
  }
}
</style>
