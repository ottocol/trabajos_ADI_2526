import { graphqlRequest } from './graphql'

/**
 * Pisos Service
 */

export async function getPisos(page = 1, perPage = 9, filters = {}) {
  const query = `
    query GetPisos($page: Int, $perPage: Int, $ciudad: String, $precioMin: Float, $precioMax: Float, $num_habit: Int) {
      pisos(page: $page, perPage: $perPage, ciudad: $ciudad, precioMin: $precioMin, precioMax: $precioMax, num_habit: $num_habit) {
        items {
          id
          titulo
          descripcion
          direccion
          ciudad
          precio
          num_habit
          superficie
          imagen
          primeraImagen
          created
        }
        page
        perPage
        totalPages
        totalItems
      }
    }
  `
  const variables = { 
    page, 
    perPage,
    ciudad: filters.ciudad || undefined,
    precioMin: filters.precioMin || undefined,
    precioMax: filters.precioMax || undefined,
    num_habit: filters.habitaciones || filters.num_habit || undefined
  }
  const data = await graphqlRequest(query, variables)
  return data.pisos
}

export async function getPisoById(id) {
  const query = `
    query GetPisoById($id: ID!) {
      piso(id: $id) {
        id
        titulo
        descripcion
        direccion
        ciudad
        cp
        precio
        num_habit
        superficie
        imagen
        primeraImagen
        propietario_id
        created
        updated
      }
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.piso
}

export async function createPiso(input) {
  const query = `
    mutation CreatePiso($input: PisoInput!) {
      crearPiso(input: $input) {
        id
        titulo
        descripcion
        direccion
        ciudad
        cp
        precio
        num_habit
        superficie
        imagen
      }
    }
  `
  const data = await graphqlRequest(query, { input })
  return data.crearPiso
}

export async function updatePiso(id, input) {
  const query = `
    mutation UpdatePiso($id: ID!, $input: PisoInput!) {
      actualizarPiso(id: $id, input: $input) {
        id
        titulo
        descripcion
        direccion
        ciudad
        cp
        precio
        num_habit
        superficie
        imagen
      }
    }
  `
  const data = await graphqlRequest(query, { id, input })
  return data.actualizarPiso
}

export async function deletePiso(id) {
  const query = `
    mutation DeletePiso($id: ID!) {
      eliminarPiso(id: $id)
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.eliminarPiso
}
