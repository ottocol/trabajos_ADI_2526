/**
 * Base GraphQL client
 * Handles GraphQL requests with authentication
 */

const GRAPHQL_URL = 'http://localhost:4000/graphql'

/**
 * Check if variables contain File objects
 */
function hasFileUpload(variables) {
  if (!variables) return false
  
  const checkValue = (value) => {
    if (value instanceof File) return true
    if (Array.isArray(value)) return value.some(checkValue)
    if (value && typeof value === 'object') {
      return Object.values(value).some(checkValue)
    }
    return false
  }
  
  return checkValue(variables)
}

/**
 * Make a GraphQL query/mutation request
 * Supports file uploads using multipart/form-data
 */
export async function graphqlRequest(query, variables = {}) {
  const token = localStorage.getItem('token')
  const hasFiles = hasFileUpload(variables)
  
  console.log('GraphQL Request - Token exists:', !!token, 'Token length:', token?.length || 0)
  
  let body
  let headers = {
    'apollo-require-preflight': 'true' // Required for CSRF protection with file uploads
  }
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  if (hasFiles) {
    // Use multipart/form-data for file uploads (GraphQL multipart spec)
    const formData = new FormData()
    
    const operations = {
      query,
      variables: {}
    }
    
    const map = {}
    const fileMap = [] // Store files to append later
    let fileIndex = 0
    
    // Extract files and build map
    const extractFiles = (obj, path = '') => {
      const result = Array.isArray(obj) ? [] : {}
      
      for (const key in obj) {
        const value = obj[key]
        const currentPath = path ? `${path}.${key}` : key
        
        if (value instanceof File) {
          const fileKey = `${fileIndex}`
          map[fileKey] = [`variables.${currentPath}`]
          fileMap.push({ key: fileKey, file: value }) // Store for later
          result[key] = null
          fileIndex++
        } else if (value && typeof value === 'object') {
          result[key] = extractFiles(value, currentPath)
        } else {
          result[key] = value
        }
      }
      
      return result
    }
    
    operations.variables = extractFiles(variables)
    
    // Append in the correct order: operations, map, then files
    formData.append('operations', JSON.stringify(operations))
    formData.append('map', JSON.stringify(map))
    
    // Now append files AFTER operations and map
    fileMap.forEach(({ key, file }) => {
      formData.append(key, file)
    })
    
    body = formData
    // Don't set Content-Type header - browser will set it with boundary
  } else {
    // Regular JSON request
    headers['Content-Type'] = 'application/json'
    body = JSON.stringify({
      query,
      variables
    })
  }

  try {
    const response = await fetch(GRAPHQL_URL, {
      method: 'POST',
      headers,
      body
    })

    const result = await response.json()

    if (result.errors) {
      console.error('GraphQL Errors:', result.errors)
      throw new Error(result.errors[0]?.message || 'GraphQL Error')
    }

    return result.data
  } catch (error) {
    console.error('GraphQL Request Error:', error)
    throw error
  }
}
