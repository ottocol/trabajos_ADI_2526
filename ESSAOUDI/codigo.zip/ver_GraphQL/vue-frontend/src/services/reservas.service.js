import { graphqlRequest } from './graphql'

/**
 * Reservas Service
 */

export async function getReservas(page = 1, perPage = 10) {
  const query = `
    query GetReservas($page: Int, $perPage: Int) {
      reservas(page: $page, perPage: $perPage) {
        items {
          id
          piso_id
          inquilino_id
          fecha_inc
          fecha_fin
          estado
          created
        }
        page
        perPage
        totalPages
        totalItems
      }
    }
  `
  const data = await graphqlRequest(query, { page, perPage })
  return data.reservas
}

export async function getMisReservas(page = 1, perPage = 50) {
  const query = `
    query GetMisReservas($page: Int, $perPage: Int) {
      misReservas(page: $page, perPage: $perPage) {
        id
        piso_id
        inquilino_id
        fecha_inc
        fecha_fin
        estado
        tituloPiso
        direccion
        ciudad
        imagenPiso
        created
      }
    }
  `
  const data = await graphqlRequest(query, { page, perPage })
  return data.misReservas
}

export async function createReserva(input) {
  const query = `
    mutation CreateReserva($input: ReservaInput!) {
      createReserva(input: $input) {
        id
        piso_id
        inquilino_id
        fecha_inc
        fecha_fin
        estado
      }
    }
  `
  const data = await graphqlRequest(query, { input })
  return data.createReserva
}

export async function updateReserva(id, estado) {
  const query = `
    mutation UpdateReserva($id: ID!, $estado: String) {
      updateReserva(id: $id, estado: $estado) {
        id
        piso_id
        inquilino_id
        fecha_inc
        fecha_fin
        estado
      }
    }
  `
  const data = await graphqlRequest(query, { id, estado })
  return data.updateReserva
}

export async function cancelReserva(id) {
  const query = `
    mutation CancelReserva($id: ID!) {
      updateReserva(id: $id, estado: "cancelada") {
        id
        estado
      }
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.updateReserva
}

export async function deleteReserva(id) {
  const query = `
    mutation DeleteReserva($id: ID!) {
      deleteReserva(id: $id) {
        success
        message
      }
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.deleteReserva
}
