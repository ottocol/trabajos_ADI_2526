import { graphqlRequest } from './graphql'

/**
 * Comentarios Service
 */

export async function getComentariosByPiso(pisoId, page = 1, perPage = 50) {
  const query = `
    query GetComentarios($page: Int, $perPage: Int, $piso_id: String) {
      comentarios(page: $page, perPage: $perPage, piso_id: $piso_id) {
        items {
          id
          piso_id
          usuario_id
          coment
          valoracion
          created
          updated
          usuario {
            id
            username
            nombre
            apellidos
            email
          }
        }
        page
        perPage
        totalPages
        totalItems
      }
    }
  `
  const data = await graphqlRequest(query, { page, perPage, piso_id: pisoId })
  return data.comentarios.items
}

export async function createComentario(input) {
  const query = `
    mutation CreateComentario($input: ComentarioInput!) {
      createComentario(input: $input) {
        id
        piso_id
        usuario_id
        coment
        valoracion
        created
      }
    }
  `
  const data = await graphqlRequest(query, { input })
  return data.createComentario
}

export async function updateComentario(id, input) {
  const query = `
    mutation UpdateComentario($id: ID!, $input: ComentarioInput!) {
      updateComentario(id: $id, input: $input) {
        id
        piso_id
        usuario_id
        coment
        valoracion
        created
      }
    }
  `
  const data = await graphqlRequest(query, { id, input })
  return data.updateComentario
}

export async function deleteComentario(id) {
  const query = `
    mutation DeleteComentario($id: ID!) {
      deleteComentario(id: $id) {
        success
        message
      }
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.deleteComentario
}
