import { graphqlRequest } from './graphql'

/**
 * Users Service
 */

export async function getUsers(page = 1, perPage = 10) {
  const query = `
    query GetUsers($page: Int, $perPage: Int) {
      usuarios(page: $page, perPage: $perPage) {
        items {
          id
          nombre
          apellidos
          email
          avatar
          rol
          telefono
          created
        }
        page
        perPage
        totalPages
        totalItems
      }
    }
  `
  const data = await graphqlRequest(query, { page, perPage })
  return data.usuarios
}

export async function getUserById(id) {
  const query = `
    query GetUser($id: ID!) {
      user(id: $id) {
        id
        nombre
        apellidos
        email
        username
        telefono
        rol
        image
        created
      }
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.user
}

export async function updateUser(id, input) {
  const query = `
    mutation UpdateUser($id: ID!, $input: UserInput!) {
      updateUser(id: $id, input: $input) {
        id
        nombre
        apellidos
        email
        username
        telefono
        rol
      }
    }
  `
  const data = await graphqlRequest(query, { id, input })
  return data.updateUser
}

export async function deleteUser(id) {
  const query = `
    mutation DeleteUser($id: ID!) {
      eliminarUsuario(id: $id)
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.eliminarUsuario
}

export async function deleteMyAccount() {
  const query = `
    mutation DeleteMyAccount {
      deleteMyAccount {
        success
        message
      }
    }
  `
  const data = await graphqlRequest(query)
  return data.deleteMyAccount
}
