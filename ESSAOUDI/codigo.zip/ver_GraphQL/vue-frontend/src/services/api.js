﻿/**
 * GraphQL API service
 * Handles all GraphQL requests to the backend
 */

const GRAPHQL_URL = 'http://localhost:4000/graphql'

/**
 * Make a GraphQL query/mutation request
 */
async function graphqlRequest(query, variables = {}) {
  const token = localStorage.getItem('token')
  
  const headers = {
    'Content-Type': 'application/json'
  }
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  try {
    const response = await fetch(GRAPHQL_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        query,
        variables
      })
    })

    const result = await response.json()

    if (result.errors) {
      console.error('GraphQL Errors:', result.errors)
      throw new Error(result.errors[0]?.message || 'GraphQL Error')
    }

    return result.data
  } catch (error) {
    console.error('GraphQL Request Error:', error)
    throw error
  }
}

// ============= AUTH QUERIES & MUTATIONS =============

export async function login(email, password) {
  const query = `
    mutation Login($email: String!, $password: String!) {
      login(email: $email, password: $password) {
        token
        user {
          id
          nombre
          apellidos
          email
          avatar
          rol
        }
      }
    }
  `
  const data = await graphqlRequest(query, { email, password })
  return data.login
}

export async function register(input) {
  const query = `
    mutation Register($input: RegistroInput!) {
      registrar(input: $input) {
        token
        user {
          id
          nombre
          apellidos
          email
          avatar
          rol
        }
      }
    }
  `
  const data = await graphqlRequest(query, { input })
  return data.registrar
}

export async function getCurrentUser() {
  const query = `
    query GetCurrentUser {
      me {
        id
        nombre
        apellidos
        email
        avatar
        rol
        telefono
      }
    }
  `
  const data = await graphqlRequest(query)
  return data.me
}

// ============= PISOS QUERIES & MUTATIONS =============

export async function getPisos(page = 1, perPage = 9, filters = {}) {
  const query = `
    query GetPisos($page: Int, $perPage: Int, $ciudad: String, $precioMin: Float, $precioMax: Float, $num_habit: Int) {
      pisos(page: $page, perPage: $perPage, ciudad: $ciudad, precioMin: $precioMin, precioMax: $precioMax, num_habit: $num_habit) {
        items {
          id
          titulo
          descripcion
          direccion
          ciudad
          precio
          num_habit
          superficie
          imagen
          primeraImagen
          created
        }
        page
        perPage
        totalPages
        totalItems
      }
    }
  `
  const variables = { 
    page, 
    perPage,
    ciudad: filters.ciudad || undefined,
    precioMin: filters.precioMin || undefined,
    precioMax: filters.precioMax || undefined,
    num_habit: filters.habitaciones || filters.num_habit || undefined
  }
  const data = await graphqlRequest(query, variables)
  return data.pisos
}

export async function getPisoById(id) {
  const query = `
    query GetPisoById($id: ID!) {
      piso(id: $id) {
        id
        titulo
        descripcion
        direccion
        ciudad
        cp
        precio
        num_habit
        superficie
        imagen
        primeraImagen
        propietario_id
        created
        updated
      }
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.piso
}

export async function createPiso(input) {
  const query = `
    mutation CreatePiso($input: PisoInput!) {
      crearPiso(input: $input) {
        id
        titulo
        descripcion
        direccion
        precio
        habitaciones
        banos
        disponible
        imagenes
      }
    }
  `
  const data = await graphqlRequest(query, { input })
  return data.crearPiso
}

export async function updatePiso(id, input) {
  const query = `
    mutation UpdatePiso($id: ID!, $input: PisoInput!) {
      actualizarPiso(id: $id, input: $input) {
        id
        titulo
        descripcion
        direccion
        precio
        habitaciones
        banos
        disponible
        imagenes
      }
    }
  `
  const data = await graphqlRequest(query, { id, input })
  return data.actualizarPiso
}

export async function deletePiso(id) {
  const query = `
    mutation DeletePiso($id: ID!) {
      eliminarPiso(id: $id)
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.eliminarPiso
}

// ============= RESERVAS QUERIES & MUTATIONS =============

export async function getReservas(page = 1, perPage = 10) {
  const query = `
    query GetReservas($page: Int, $perPage: Int) {
      reservas(page: $page, perPage: $perPage) {
        items {
          id
          pisoId
          inquilinoId
          fechaInicio
          fechaFin
          estado
          created
        }
        page
        perPage
        totalPages
        totalItems
      }
    }
  `
  const data = await graphqlRequest(query, { page, perPage })
  return data.reservas
}

export async function createReserva(input) {
  const query = `
    mutation CreateReserva($input: ReservaInput!) {
      crearReserva(input: $input) {
        id
        pisoId
        inquilinoId
        fechaInicio
        fechaFin
        estado
      }
    }
  `
  const data = await graphqlRequest(query, { input })
  return data.crearReserva
}

export async function updateReserva(id, input) {
  const query = `
    mutation UpdateReserva($id: ID!, $input: ReservaInput!) {
      actualizarReserva(id: $id, input: $input) {
        id
        pisoId
        inquilinoId
        fechaInicio
        fechaFin
        estado
      }
    }
  `
  const data = await graphqlRequest(query, { id, input })
  return data.actualizarReserva
}

export async function deleteReserva(id) {
  const query = `
    mutation DeleteReserva($id: ID!) {
      eliminarReserva(id: $id)
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.eliminarReserva
}

// ============= COMENTARIOS QUERIES & MUTATIONS =============

export async function getComentariosByPiso(pisoId) {
  const query = `
    query GetComentariosByPiso($pisoId: ID!) {
      comentariosPorPiso(pisoId: $pisoId) {
        id
        pisoId
        usuarioId
        texto
        valoracion
        created
      }
    }
  `
  const data = await graphqlRequest(query, { pisoId })
  return data.comentariosPorPiso
}

export async function createComentario(input) {
  const query = `
    mutation CreateComentario($input: ComentarioInput!) {
      crearComentario(input: $input) {
        id
        pisoId
        usuarioId
        texto
        valoracion
        created
      }
    }
  `
  const data = await graphqlRequest(query, { input })
  return data.crearComentario
}

export async function deleteComentario(id) {
  const query = `
    mutation DeleteComentario($id: ID!) {
      eliminarComentario(id: $id)
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.eliminarComentario
}

// ============= USERS QUERIES (ADMIN) =============

export async function getUsers(page = 1, perPage = 10) {
  const query = `
    query GetUsers($page: Int, $perPage: Int) {
      usuarios(page: $page, perPage: $perPage) {
        items {
          id
          nombre
          apellidos
          email
          avatar
          rol
          telefono
          created
        }
        page
        perPage
        totalPages
        totalItems
      }
    }
  `
  const data = await graphqlRequest(query, { page, perPage })
  return data.usuarios
}

export async function deleteUser(id) {
  const query = `
    mutation DeleteUser($id: ID!) {
      eliminarUsuario(id: $id)
    }
  `
  const data = await graphqlRequest(query, { id })
  return data.eliminarUsuario
}

export default {
  login,
  register,
  getCurrentUser,
  getPisos,
  getPisoById,
  createPiso,
  updatePiso,
  deletePiso,
  getReservas,
  createReserva,
  updateReserva,
  deleteReserva,
  getComentariosByPiso,
  createComentario,
  deleteComentario,
  getUsers,
  deleteUser
}
