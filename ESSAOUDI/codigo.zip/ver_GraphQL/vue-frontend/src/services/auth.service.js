import { graphqlRequest } from './graphql'

/**
 * Authentication Service
 */

export async function login(email, password) {
  const query = `
    mutation Login($input: LoginInput!) {
      login(input: $input) {
        token
        user {
          id
          nombre
          apellidos
          email
          rol
          image
        }
      }
    }
  `
  const data = await graphqlRequest(query, { input: { email, password } })
  return data.login
}

export async function register(input) {
  const query = `
    mutation Register($input: RegisterInput!) {
      register(input: $input) {
        token
        user {
          id
          nombre
          apellidos
          email
          rol
          image
        }
      }
    }
  `
  const data = await graphqlRequest(query, { input })
  return data.register
}

export async function getCurrentUser() {
  const query = `
    query GetCurrentUser {
      me {
        id
        nombre
        apellidos
        email
        rol
        telefono
        image
      }
    }
  `
  const data = await graphqlRequest(query)
  return data.me
}
