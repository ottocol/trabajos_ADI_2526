﻿import { defineStore } from 'pinia'

export const usePisosStore = defineStore('pisos', {
  state: () => ({
    filters: {
      precioMin: null,
      precioMax: null,
      habitaciones: null,
      banos: null,
      disponible: true
    }
  }),

  actions: {
    updateFilters(newFilters) {
      this.filters = { ...this.filters, ...newFilters }
    },

    resetFilters() {
      this.filters = {
        precioMin: null,
        precioMax: null,
        habitaciones: null,
        banos: null,
        disponible: true
      }
    }
  }
})
