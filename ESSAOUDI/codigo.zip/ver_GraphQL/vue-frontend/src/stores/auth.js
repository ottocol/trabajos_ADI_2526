﻿import { defineStore } from 'pinia'
import { login as apiLogin, register as apiRegister, getCurrentUser } from '@/services'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem('token') || null,
    user: null,
    loading: false,
    error: null
  }),

  getters: {
    isAuthenticated: (state) => !!state.token,
    isAdmin: (state) => state.user?.rol === 'admin',
    isPropietario: (state) => state.user?.rol === 'propietario',
    isInquilino: (state) => state.user?.rol === 'inquilino',
    userRole: (state) => state.user?.rol || null
  },

  actions: {
    async login(email, password) {
      this.loading = true
      this.error = null
      try {
        const data = await apiLogin(email, password)
        this.token = data.token
        this.user = data.user
        localStorage.setItem('token', data.token)
        localStorage.setItem('userId', data.user.id)
        localStorage.setItem('userRole', data.user.rol)
        localStorage.setItem('currentUser', JSON.stringify(data.user))
        return data
      } catch (error) {
        this.error = error.message
        throw error
      } finally {
        this.loading = false
      }
    },

    async register(userData) {
      this.loading = true
      this.error = null
      try {
        const data = await apiRegister(userData)
        this.token = data.token
        this.user = data.user
        localStorage.setItem('token', data.token)
        localStorage.setItem('userId', data.user.id)
        localStorage.setItem('userRole', data.user.rol)
        localStorage.setItem('currentUser', JSON.stringify(data.user))
        return data
      } catch (error) {
        this.error = error.message
        throw error
      } finally {
        this.loading = false
      }
    },

    async fetchUser() {
      if (!this.token) return
      
      this.loading = true
      try {
        const user = await getCurrentUser()
        this.user = user
      } catch (error) {
        this.error = error.message
        this.logout()
      } finally {
        this.loading = false
      }
    },

    logout() {
      this.token = null
      this.user = null
      this.error = null
      localStorage.removeItem('token')
      localStorage.removeItem('userId')
      localStorage.removeItem('userRole')
      localStorage.removeItem('currentUser')
    }
  }
})
