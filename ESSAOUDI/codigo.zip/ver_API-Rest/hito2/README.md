# Proyecto Backend con PocketBase y Node.js

Este proyecto implementa el backend de nuestra plataforma rentEase usando **PocketBase** como base de datos y **Node.js** para la lógica de negocio.

## Autores
- Maha Essaoudi
- Sabrine Bentaleb Kheyar 

## Pruebas tests
Se realizaron tests para comprobar el correcto funcionamiento de todas las funciones de los servicios hechos.  

## Notas
- Las colecciones fueron creadas localmente y exportadas a través de `pb_migrations` para permitir reproducir la base de datos.
- Los roles de usuarios son: `admin`, `inquilino` y `propietario`.
