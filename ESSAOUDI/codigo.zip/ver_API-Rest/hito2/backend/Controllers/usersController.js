import express from 'express';
import userService from '../Services/userService.js';
import { pb } from '../config/pb.js';
const router = express.Router();

// GET /api/users? page, perPage, searchText, rol
router.get('/', async (req, res) => {
	try {
		const page = parseInt(req.query.page) || 1;
		const perPage = parseInt(req.query.perPage) || 20;

		// If an explicit id query param was provided, return that user as a single-item paginated result
		if (req.query.id) {
			try {
				const u = await userService.getUserById(req.query.id);
				return res.json({ items: [u], page: 1, perPage: 1, totalItems: 1, totalPages: 1 });
			} catch (e) {
				return res.status(404).json({ error: 'Usuario no encontrado' });
			}
		}

		const filters = {
			searchText: req.query.searchText || '',
			rol: req.query.rol || ''
		};

		const result = await userService.getAllUsers(page, perPage, filters);
		return res.json(result);
	} catch (err) {
		return res.status(500).json({ error: err.message || 'Error al obtener los usuarios' });
	}
});

// GET /api/users/:id
router.get('/:id', async (req, res) => {
	try {
		const user = await userService.getUserById(req.params.id);
		return res.json(user);
	} catch (err) {
		return res.status(404).json({ error: err.message || 'Usuario no encontrado' });
	}
});

// POST /api/users
router.post('/', async (req, res) => {
	try {
		const newUser = await userService.createUser(req.body);
		return res.status(201).json(newUser);
	} catch (err) {
		return res.status(400).json({ error: err.message || 'Error al crear el user' });
	}
});

// PUT /api/users/:id
router.put('/:id', async (req, res) => {
	try {
		const updated = await userService.updateUser(req.params.id, req.body);
		return res.json(updated);
	} catch (err) {
		return res.status(400).json({ error: err.message || 'Error al actualizar el user' });
	}
});

// DELETE /api/users/:id
router.delete('/:id', async (req, res) => {
	try {
		await userService.deleteUser(req.params.id);
		return res.status(204).end();
	} catch (err) {
		return res.status(400).json({ error: err.message || 'Error al eleminar el usuario' });
	}
});
// DELETE /api/users/me/delete-account - Eliminar la propia cuenta
router.delete('/me/delete-account', async (req, res) => {
    try {
        const currentUser = pb.authStore.record;
        
        if (!currentUser) {
            return res.status(401).json({ error: 'No autenticado' });
        }
        const result = await userService.deleteMyAccount(currentUser.id);
        
        return res.json(result);
    } catch (err) {
        return res.status(400).json({ error: err.message || 'Error al eliminar la cuenta' });
    }
});
// PUT /api/users/:id/perfil - Actualizar perfil propio
router.put('/:id/perfil', async (req, res) => {
    try {
        const currentUser = pb.authStore.record;
        
        if (!currentUser) {
            return res.status(401).json({ error: 'No autenticado' });
        }

        // Verificar que el usuario solo puede actualizar su propio perfil
        if (currentUser.id !== req.params.id) {
            return res.status(403).json({ error: 'No puedes actualizar otro perfil' });
        }

        const updated = await userService.updatePerfil(req.params.id, req.body);
        
        return res.json(updated);
    } catch (err) {
        return res.status(400).json({ error: err.message || 'Error al actualizar el perfil' });
    }
});
export default router;

