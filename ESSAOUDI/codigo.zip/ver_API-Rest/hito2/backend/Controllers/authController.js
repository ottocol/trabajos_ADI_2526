import express from 'express';
import authService from '../Services/authService.js';
import util from 'util';
import multer from 'multer';
import { Readable } from 'stream';
import FormData from 'form-data';
import axios from 'axios';
import { pb } from '../config/pb.js';

const router = express.Router();

// Use memory storage for user avatar uploads (no disk writes)
const storage = multer.memoryStorage();
const upload = multer({ storage, limits: { fileSize: 3 * 1024 * 1024 } });

// POST /api/auth/register (accept optional `image` file)
router.post('/register', upload.single('image'), async (req, res) => {
    try {
        const body = { ...req.body };
        const { username, email, password, passwordConfirm } = body;
        if (!username || !email || !password || !passwordConfirm) {
            return res.status(400).json({ error: 'username, email, password and passwordConfirm are required' });
        }

        if (body.password !== body.passwordConfirm) {
            return res.status(400).json({ error: 'password and passwordConfirm do not match' });
        }

        if (req.file) {
            try {
                // create the user in PB (without the file)
                const createPayload = {};
                Object.entries(body).forEach(([k, v]) => {
                    if (v !== undefined && v !== null) createPayload[k] = String(v);
                });
                if (createPayload.role && !createPayload.rol) createPayload.rol = createPayload.role;

                const created = await authService.register(createPayload);

                try {
                    await pb.collection('users').authWithPassword(createPayload.email, createPayload.password);
                    // create a Readable stream from the uploaded buffer
                    const stream = Readable.from(req.file.buffer);
                    const updateRes = await pb.collection('users').update(created.id, { image: [stream] });
                    const updated = await pb.collection('users').getOne(created.id);

                    if (!updated.image || (Array.isArray(updated.image) && updated.image.length === 0) || updated.image === '') {
                        try {
                            const filesForm = new FormData();
                            // Merge existing record's non-sensitive fields to avoid validation errors
                            let existingUser = null;
                            try {
                                existingUser = await pb.collection('users').getOne(created.id);
                            } catch (fetchErr) {
                                console.warn('Could not fetch existing user for fallback merge:', fetchErr?.message || fetchErr);
                            }

                            const sensitiveKeys = new Set(['password', 'passwordConfirm', 'oldPassword']);
                            const skipSystem = new Set(['id', 'created', 'updated', 'collectionId', 'collectionName']);

                            if (existingUser) {
                                Object.entries(existingUser).forEach(([k, v]) => {
                                    if (v === undefined || v === null) return;
                                    if (sensitiveKeys.has(k)) return;
                                    if (skipSystem.has(k)) return;
                                    if (k === 'image') return; // we'll append the file separately
                                    filesForm.append(k, String(v));
                                });
                            } else {
                                // As a fallback, append only safe createPayload fields (exclude passwords)
                                Object.keys(createPayload).forEach(k => {
                                    if (sensitiveKeys.has(k)) return;
                                    if (createPayload[k] !== undefined && createPayload[k] !== null) filesForm.append(k, String(createPayload[k]));
                                });
                            }

                            filesForm.append('image', req.file.buffer, { filename: req.file.originalname, contentType: req.file.mimetype });
                            const headers = filesForm.getHeaders();
                            if (pb.authStore && pb.authStore.token) headers['Authorization'] = `Bearer ${pb.authStore.token}`;
                            const uploadUrl = `${pb.baseUrl.replace(/\/$/, '')}/api/collections/users/records/${created.id}`;
                            const resp = await axios.patch(uploadUrl, filesForm, { headers, maxContentLength: Infinity, maxBodyLength: Infinity });
                            return res.status(201).json(resp.data);
                        } catch (e) {
                            console.error('User fallback attach failed:', e?.response?.data || e?.message || e);
                            return res.status(201).json(updated);
                        }
                    }

                    return res.status(201).json(updated);
                } catch (uploadErr) {
                    console.error('Attach avatar via SDK failed:', uploadErr?.message || uploadErr);
                    return res.status(201).json(created);
                }
            } catch (errCreate) {
                throw errCreate;
            }
        }

        const createPayload = {};
        Object.entries(body).forEach(([k, v]) => {
            if (v !== undefined && v !== null) createPayload[k] = String(v);
        });
        if (createPayload.role && !createPayload.rol) createPayload.rol = createPayload.role;

        const user = await authService.register(createPayload);
        return res.status(201).json(user);
    } catch (err) {
        // Log full error for debugging (pretty-print everything)
        console.error('Register error:', err?.message || err);
        try {
            console.error('Full error object:', util.inspect(err, { depth: null }));
            if (err && err.stack) console.error(err.stack);
        } catch (e) {
            // ignore inspect errors
        }
        const details = err && (err.data || err.response?.data || err.body) || null;
        if (details && Object.keys(details).length > 0) {
            console.error('PocketBase details:', util.inspect(details, { depth: null, colors: true }));
        }

        const message = err?.message || 'Error al registrar el usuario';
        return res.status(err?.status || 400).json({ error: message, details });
    }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
    try {
        console.log('Login request body:', req.body);
        const { email, password } = req.body;
        const auth = await authService.login(email, password);
        return res.status(200).json(auth);
    } catch (err) {
        return res.status(401).json({ error: err.message || 'Usuario o contraseña incorrectos' });
    }
});

// POST /api/auth/logout
router.post('/logout', async (req, res) => {
    try {
        await authService.logout();
        return res.status(204).end();
    } catch (err) {
        return res.status(500).json({ error: err.message || 'Error logging out' });
    }
});
// Middleware para verificar autenticación - lo añadimos aquí mismo
export const authenticateToken = async (req, res, next) => {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

        if (!token) {
            return res.status(401).json({ error: 'Token de autenticación requerido' });
        }

        // Importar pb aquí mismo para evitar problemas
        const { pb } = await import('../config/pb.js');
        
        // Verificar el token con PocketBase
        pb.authStore.save(token, null);
        
        // Verificar si el token es válido
        if (!pb.authStore.isValid) {
            return res.status(401).json({ error: 'Token inválido o expirado' });
        }

        // Obtener información actualizada del usuario
        await pb.collection('users').authRefresh();
        
        req.user = pb.authStore.model;
        next();
    } catch (error) {
        console.error('Error en autenticación:', error);
        return res.status(401).json({ error: 'Error de autenticación' });
    }
};

export default router;

