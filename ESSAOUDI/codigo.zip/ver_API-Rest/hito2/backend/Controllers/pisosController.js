import express from 'express';
import pisosService from '../Services/pisosService.js';
import { authenticateToken } from './authController.js'; // Importa desde authController
import multer from 'multer';
import { Readable } from 'stream';
import FormData from 'form-data';
import axios from 'axios';
import { pb } from '../config/pb.js';

// use memory storage to avoid writing files to disk during uploads
const storage = multer.memoryStorage();
const upload = multer({ storage, limits: { fileSize: 6 * 1024 * 1024 } });

const router = express.Router();

// GET /api/pisos
router.get('/', async (req, res) => {
	try {
		const page = parseInt(req.query.page) || 1;
		const perPage = parseInt(req.query.perPage) || 10;
		const filters = req.query || {};
		const result = await pisosService.listarPisos(page, perPage, filters);
		return res.json(result);
	} catch (err) {
		return res.status(500).json({ error: err.message || 'Error al obtener los pisos' });
	}
});

// GET /api/pisos/mis-anuncios - NUEVA RUTA PARA MIS ANUNCIOS
router.get('/mis-anuncios', authenticateToken, async (req, res) => {
	try {
		const page = parseInt(req.query.page) || 1;
		const perPage = parseInt(req.query.perPage) || 50;
		const userId = req.user.id;
		
		const result = await pisosService.obtenerMisPisos(userId, page, perPage);
		return res.json(result.items); // Devuelve directamente el array
	} catch (err) {
		console.error('Error en mis-anuncios:', err);
		return res.status(500).json({ error: err.message || 'Error al obtener mis anuncios' });
	}
});

// GET /api/pisos/admin
router.get('/admin', async (req, res) => {
	try {
		const page = parseInt(req.query.page) || 1;
		const perPage = parseInt(req.query.perPage) || 10;
		const filters = req.query || {};
		const result = await pisosService.listarPisosAdmin(page, perPage, filters);
		return res.json(result);
	} catch (err) {
		const status = err && err.status === 403 ? 403 : 500;
		return res.status(status).json({ error: err.message || 'Error al obtener los pisos (admin)' });
	}
});

// GET /api/pisos/:id
router.get('/:id', async (req, res) => {
	try {
		const piso = await pisosService.obtenerPisoPorId(req.params.id);
		return res.json(piso);
	} catch (err) {
		return res.status(404).json({ error: err.message || 'Piso no encontrado' });
	}
});

// POST /api/pisos - aceptar multipart/form-data (imagen opcional)
router.post('/', authenticateToken, upload.single('imagen'), async (req, res) => {
	try {
		// Añadir el propietario: si el usuario es admin se permite usar el propietario_id enviado en el body,
		const isAdmin = (req.user && (req.user.rol === 'admin' || req.user.role === 'admin'));

		// req.body will be populated by multer for multipart/form-data
		const pisoData = {
			...req.body,
			propietario_id: isAdmin && req.body && req.body.propietario_id ? req.body.propietario_id : req.user.id
		};

		if (req.file) {
			try {
				pisoData.imagen = [Readable.from(req.file.buffer)];
			} catch (e) {
				console.warn('Could not attach uploaded image buffer as stream:', e?.message || e);
			}
		}

		const created = await pisosService.crearPiso(pisoData);
		return res.status(201).json(created);
	} catch (err) {
		console.error('Error creating piso (POST):', err);
		return res.status(400).json({ error: err.message || 'Error: no se ha podido crear el piso' });
	}
});

// PUT /api/pisos/:id 
router.put('/:id', authenticateToken, upload.array('imagen', 5), async (req, res) => {
    try {
		const userId = req.user && req.user.id;
		const isAdmin = req.user && (req.user.rol === 'admin' || req.user.role === 'admin');
		const pisoData = { ...req.body };
			if (req.files && req.files.length > 0) {
				try {
					const existing = await pisosService.obtenerPisoPorId(req.params.id);
					if (existing) {
						console.log('Merging existing record fields into update payload to avoid validation errors');
						const required = ['titulo', 'ciudad', 'direccion', 'cp', 'descripcion', 'precio', 'num_habit', 'superficie', 'propietario_id'];
						required.forEach(k => {
							if ((pisoData[k] === undefined || pisoData[k] === '') && existing[k] !== undefined) {
								pisoData[k] = existing[k];
							}
						});
						
						if (pisoData.precio !== undefined && pisoData.precio !== '') pisoData.precio = Number(pisoData.precio);
						if (pisoData.num_habit !== undefined && pisoData.num_habit !== '') pisoData.num_habit = Number(pisoData.num_habit);
						if (pisoData.superficie !== undefined && pisoData.superficie !== '') pisoData.superficie = Number(pisoData.superficie);
					}
				} catch (e) {
					console.error('Could not merge existing piso fields:', e?.message || e);
				}
			}
		if (req.files && req.files.length > 0) {
			pisoData.imagen = req.files.map(f => Readable.from(f.buffer));
		}

        // Update directly through PocketBase SDK
		// Allow admins to bypass propietario ownership check when updating (e.g., to attach images)
		const updated = isAdmin
			? await pisosService.actualizarPiso(req.params.id, pisoData)
			: await pisosService.actualizarPiso(req.params.id, pisoData, userId);

        console.log("PB updated:", updated);

		// If SDK update didn't attach files (imagen empty) try multipart PATCH to PB record endpoint
		if (req.files && req.files.length > 0 && Array.isArray(updated?.imagen) && updated.imagen.length === 0) {
			console.log('SDK update returned empty imagen array — attempting multipart PATCH fallback to PocketBase');
			try {
				const filesForm = new FormData();
				Object.keys(pisoData).forEach(k => {
					if (k === 'imagen') return;
					if (pisoData[k] !== undefined && pisoData[k] !== null) filesForm.append(k, String(pisoData[k]));
				});
				req.files.forEach(f => filesForm.append('imagen', f.buffer, { filename: f.originalname, contentType: f.mimetype }));

				const uploadUrl = `${pb.baseUrl.replace(/\/$/, '')}/api/collections/pisos/records/${req.params.id}`;
				const headers = filesForm.getHeaders();
				const incomingAuth = req.headers && req.headers.authorization;
				if (incomingAuth) headers['Authorization'] = incomingAuth;
				else if (pb.authStore && pb.authStore.token) headers['Authorization'] = `Bearer ${pb.authStore.token}`;

				console.log('Fallback PATCH uploadUrl:', uploadUrl);
				console.log('Fallback PATCH headers keys:', Object.keys(headers));

				const resp = await axios.patch(uploadUrl, filesForm, { headers, maxContentLength: Infinity, maxBodyLength: Infinity });
				console.log('Fallback PATCH response status:', resp.status);
				console.log('Fallback PATCH response data:', resp.data);
				return res.json(resp.data);
			} catch (e) {
				console.error('Fallback PATCH failed:', e?.response?.status, e?.response?.data || e?.message || e);
			}
		}

		return res.json(updated);
    } catch (err) {
        console.error("Error updating piso:", err);
        return res.status(400).json({
            error: err?.response?.data || err.message || "Error updating piso"
        });
    }
});


// DELETE /api/pisos/:id
router.delete('/:id', authenticateToken, async (req, res) => {
	try {
		const userId = req.user.id;
		const isAdmin = (req.user && (req.user.rol === 'admin' || req.user.role === 'admin'));
		// If admin, call eliminarPiso without propietarioId so repository won't enforce owner check
		if (isAdmin) {
			await pisosService.eliminarPiso(req.params.id);
		} else {
			await pisosService.eliminarPiso(req.params.id, userId);
		}
		return res.status(204).end();
	} catch (err) {
		return res.status(400).json({ error: err.message || 'Error al eliminar el piso' });
	}
});

export default router;