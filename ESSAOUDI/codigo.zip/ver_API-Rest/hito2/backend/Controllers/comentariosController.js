import express from 'express';
import comentariosService from '../Services/comentariosService.js';
import { authenticateToken } from './authController.js'; // ⚠️ IMPORTA el middleware

const router = express.Router();

// GET /api/comentarios - Público (todos pueden ver comentarios)
// GET /api/comentarios
router.get('/', async (req, res) => {
	try {
		const page = parseInt(req.query.page) || 1;
		const perPage = parseInt(req.query.perPage) || 10;
		const filters = req.query || {};
		
		const result = await comentariosService.listarComentarios(page, perPage, {
			...filters,
			expand: 'usuario_id' 
		});
		
		return res.json(result);
	} catch (err) {
		return res.status(500).json({ error: err.message || 'Error al obtener los comentarios' });
	}
});
// GET /api/comentarios/:id - Público
router.get('/:id', async (req, res) => {
	try {
		const coment = await comentariosService.obtenerComentarioPorId(req.params.id);
		return res.json(coment);
	} catch (err) {
		return res.status(404).json({ error: err.message || 'Comentario no encontrado' });
	}
});

// POST /api/comentarios - Solo usuarios autenticados
router.post('/', authenticateToken, async (req, res) => { // ⚠️ AÑADE middleware
	try {
    // ⚠️ AÑADE: El usuario ya está autenticado por el middleware
    const usuarioId = req.user.id; // Obtenido del middleware
    
    // Asegurar que el comentario tenga el usuario_id correcto
    const comentarioData = {
      ...req.body,
      usuario_id: usuarioId // ⚠️ FORZAR el usuario_id del usuario autenticado
    };
    
		const created = await comentariosService.crearComentario(comentarioData);
		return res.status(201).json(created);
	} catch (err) {
		return res.status(400).json({ error: err.message || 'Error al crear el comentario' });
	}
});

// PUT /api/comentarios/:id - Solo usuarios autenticados y dueños
router.put('/:id', authenticateToken, async (req, res) => { // ⚠️ AÑADE middleware
	try {
    const usuarioId = req.user.id; // Obtenido del middleware
		const updated = await comentariosService.actualizarComentario(req.params.id, req.body, usuarioId);
		return res.json(updated);
	} catch (err) {
    if (err.message.includes('No autorizado') || err.message.includes('no tiene permisos')) {
      return res.status(403).json({ error: 'No tienes permisos para editar este comentario' });
    }
		return res.status(400).json({ error: err.message || 'Error al actualizar el comentario' });
	}
});

// DELETE /api/comentarios/:id - Solo usuarios autenticados y dueños  
router.delete('/:id', authenticateToken, async (req, res) => { // ⚠️ AÑADE middleware
	try {
    const usuarioId = req.user.id; // Obtenido del middleware
		await comentariosService.eliminarComentario(req.params.id, usuarioId);
		return res.status(204).end();
	} catch (err) {
    if (err.message.includes('No autorizado') || err.message.includes('no tiene permisos')) {
      return res.status(403).json({ error: 'No tienes permisos para eliminar este comentario' });
    }
		return res.status(400).json({ error: err.message || 'Error al eliminar el comentario' });
	}
});

export default router;