import express from 'express';
import { authenticateToken } from './authController.js';
import { pb } from '../config/pb.js';

const router = express.Router();

// GET /api/reservas - lista paginada de reservas (preview support)
router.get('/', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const perPage = parseInt(req.query.perPage) || (req.query.limit ? parseInt(req.query.limit) : 50);
        const resultList = await pb.collection('reservas').getList(page, perPage, {
            sort: '-created',
            expand: 'piso_id,inquilino_id'
        });

        // If caller asked for a small preview with `?limit=6` return plain array to match frontend usage
        if (req.query.limit) return res.json(resultList.items);

        return res.json({
            items: resultList.items,
            page: resultList.page,
            perPage: resultList.perPage,
            totalItems: resultList.totalItems,
            totalPages: resultList.totalPages
        });
    } catch (err) {
        console.error('Error listing reservas:', err);
        return res.status(500).json({ error: err.message || 'Error listing reservas' });
    }
});

// GET /api/reservas/mis-reservas - Obtener reservas del usuario autenticado (VERSIÓN MEJORADA)
router.get('/mis-reservas', authenticateToken, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const perPage = parseInt(req.query.perPage) || 50;
        const userId = req.user.id;
        
        const resultList = await pb.collection('reservas').getList(page, perPage, {
            filter: `inquilino_id = "${userId}"`,  
            sort: '-created',
            expand: 'piso_id'
        });
        
        // Procesar las reservas para incluir información del piso
        const reservasProcesadas = (resultList.items || []).map(reserva => {
            const piso = reserva.expand?.piso_id || {};
            
            // Obtener imagen del piso
            let imagenPiso = null;
            if (Array.isArray(piso.imagen) && piso.imagen.length > 0) {
                const filename = piso.imagen[0];
                imagenPiso = `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${piso.id}/${encodeURIComponent(filename)}`;
            }

            return {
                id: reserva.id,
                tituloPiso: piso.titulo || 'Piso sin título',
                direccion: piso.direccion || '',
                ciudad: piso.ciudad || '',
                fechaInicio: reserva.fecha_inicio || reserva.fecha_inc, // Manejar ambos nombres
                fechaFin: reserva.fecha_fin,
                precioTotal: reserva.precio_total || 0,
                estado: reserva.estado || 'pendiente',
                pisoId: reserva.piso_id,
                imagenPiso: imagenPiso,
                fechaCreacion: reserva.created
            };
        });

        return res.json(reservasProcesadas);
        
    } catch (err) {
        console.error('Error al obtener reservas:', err);
        return res.status(500).json({ error: err.message || 'Error al obtener mis reservas' });
    }
});

// POST /api/reservas/:id/cancelar - Cancelar reserva (VERSIÓN MEJORADA)
router.post('/:id/cancelar', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const reservaId = req.params.id;
        
        console.log(`Intentando cancelar reserva ${reservaId} para usuario ${userId}`);
        
        // Obtener la reserva existente
        const reservaExistente = await pb.collection('reservas').getOne(reservaId);
        
        // Verificar que la reserva pertenece al usuario
        if (reservaExistente.inquilino_id !== userId) {
            console.log(`Usuario ${userId} no es el propietario de la reserva ${reservaId}`);
            return res.status(403).json({ error: 'No tienes permisos para cancelar esta reserva' });
        }
        
        // Verificar que la reserva no esté ya cancelada o completada
        if (reservaExistente.estado === 'cancelada') {
            return res.status(400).json({ error: 'La reserva ya está cancelada' });
        }
        
        if (reservaExistente.estado === 'completada') {
            return res.status(400).json({ error: 'No se puede cancelar una reserva completada' });
        }
        
        // Actualizar el estado a cancelada
        const reservaActualizada = await pb.collection('reservas').update(reservaId, {
            estado: 'cancelada',
            fecha_cancelacion: new Date().toISOString()
        });
        
        console.log(`Reserva ${reservaId} cancelada exitosamente`);
        
        return res.json({ 
            success: true, 
            message: 'Reserva cancelada correctamente',
            reserva: reservaActualizada 
        });
        
    } catch (err) {
        console.error('Error al cancelar reserva:', err);
        
        if (err.status === 404) {
            return res.status(404).json({ error: 'Reserva no encontrada' });
        }
        
        return res.status(500).json({ 
            error: err.message || 'Error al cancelar la reserva' 
        });
    }
});

// POST /api/reservas/ - Crear nueva reserva (MANTENER ESTA ORIGINAL)
router.post('/', authenticateToken, async (req, res) => {
  try {
    console.log('Usuario autenticado:', req.user);
    console.log('Datos recibidos:', req.body);
    
    const reservaData = {
      ...req.body,
      inquilino_id: req.user.id,  
      estado: 'pendiente'
    };
    
    console.log('Datos a guardar:', reservaData);
    
    const reserva = await pb.collection('reservas').create(reservaData);
    
    console.log('Reserva creada:', reserva);
    return res.status(201).json(reserva);
    
  } catch (err) {
    console.error('Error completo al crear reserva:', err);
    return res.status(400).json({ 
      error: err.message || 'Error al crear la reserva',
      details: err.data || 'Sin detalles adicionales'
    });
  }
});

// GET /api/reservas/piso/:pisoId - Obtener reservas de un piso (VERSIÓN MEJORADA)
router.get('/piso/:pisoId', authenticateToken, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const perPage = parseInt(req.query.perPage) || 50;
        const pisoId = req.params.pisoId;
        const userId = req.user.id;
        
        // Verificar que el piso pertenece al usuario
        const pisoExistente = await pb.collection('pisos').getOne(pisoId);
        if (pisoExistente.propietario_id !== userId) {
            return res.status(403).json({ error: 'No tienes permisos para ver las reservas de este piso' });
        }
        
        const resultList = await pb.collection('reservas').getList(page, perPage, {
            filter: `piso_id = "${pisoId}"`,
            sort: '-created',
            expand: 'inquilino_id'  
        });
        
        // Procesar las reservas para incluir información del usuario
        const reservasProcesadas = (resultList.items || []).map(reserva => {
            const usuario = reserva.expand?.inquilino_id || {};  
            
            // CALCULAR PRECIO SI ES NECESARIO
            let precioTotal = reserva.precio_total;
            
            // Si el precio es 0 o no existe, calcularlo basado en las fechas
            if (!precioTotal || precioTotal === 0) {
                const fechaInicio = new Date(reserva.fecha_inc);
                const fechaFin = new Date(reserva.fecha_fin);
                const diffTime = fechaFin - fechaInicio;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                precioTotal = diffDays * (pisoExistente.precio || 0);
            }
            
            return {
                id: reserva.id,
                nombreUsuario: usuario.name || usuario.username || 'Usuario',
                emailUsuario: usuario.email,
                fechaInicio: reserva.fecha_inc, 
                fechaFin: reserva.fecha_fin,
                precioTotal: precioTotal, // USAR PRECIO CALCULADO
                estado: reserva.estado,
                fechaCreacion: reserva.created
            };
        });

        return res.json(reservasProcesadas);
        
    } catch (err) {
        return res.status(500).json({ error: err.message || 'Error al obtener las reservas del piso' });
    }
});

// GET /api/reservas/:id - obtener reserva por id (expand piso and inquilino)
router.get('/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const reserva = await pb.collection('reservas').getOne(id, { expand: 'piso_id,inquilino_id' });
        return res.json(reserva);
    } catch (err) {
        console.error('Error getting reserva by id:', err);
        if (err && err.status === 404) return res.status(404).json({ error: 'Reserva no encontrada' });
        return res.status(500).json({ error: err.message || 'Error obteniendo reserva' });
    }
});

// DELETE /api/reservas/:id - eliminar reserva (admin or owner)
router.delete('/:id', authenticateToken, async (req, res) => {
    try {
        const id = req.params.id;
        const user = req.user;
        const isAdmin = user && (user.rol === 'admin' || user.role === 'admin');

        const reserva = await pb.collection('reservas').getOne(id, { expand: 'inquilino_id' });
        if (!reserva) return res.status(404).json({ error: 'Reserva no encontrada' });

        const ownerId = reserva.inquilino_id || (reserva.expand && (reserva.expand.inquilino_id && reserva.expand.inquilino_id.id)) || null;
        if (!isAdmin && user.id !== ownerId) {
            return res.status(403).json({ error: 'No tienes permisos para eliminar esta reserva' });
        }

        await pb.collection('reservas').delete(id);
        return res.status(204).end();
    } catch (err) {
        console.error('Error deleting reserva:', err);
        return res.status(400).json({ error: err.message || 'Error eliminando reserva' });
    }
});

// PATCH /api/reservas/:id - Actualizar reserva (para propietarios)
router.patch('/:id', authenticateToken, async (req, res) => {
    try {
        const reservaId = req.params.id;
        const userId = req.user.id;
        const isAdmin = req.user && (req.user.rol === 'admin' || req.user.role === 'admin');
        const { estado, fecha_inc, fecha_fin } = req.body;

        // Obtener la reserva
        const reserva = await pb.collection('reservas').getOne(reservaId, {
            expand: 'piso_id'
        });

        // Verificar que el usuario es el propietario del piso OR admin
        if (!isAdmin && (!reserva.expand?.piso_id || reserva.expand.piso_id.propietario_id !== userId)) {
            return res.status(403).json({ error: 'No tienes permisos para modificar esta reserva' });
        }

        // Build update payload with allowed fields
        const updateData = {};
        if (estado !== undefined) updateData.estado = estado;
        if (fecha_inc !== undefined) updateData.fecha_inc = fecha_inc;
        if (fecha_fin !== undefined) updateData.fecha_fin = fecha_fin;
        if (Object.keys(updateData).length === 0) return res.status(400).json({ error: 'No hay campos para actualizar' });
        updateData.updated = new Date().toISOString();

        const reservaActualizada = await pb.collection('reservas').update(reservaId, updateData);
        return res.json(reservaActualizada);

    } catch (err) {
        console.error('Error actualizando reserva:', err);
        return res.status(400).json({ error: err.message || 'Error al actualizar la reserva' });
    }
});

export default router;