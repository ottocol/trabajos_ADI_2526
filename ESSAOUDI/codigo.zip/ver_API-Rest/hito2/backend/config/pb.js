import PocketBase from "pocketbase";

export const pb = new PocketBase("http://127.0.0.1:8090");

// If admin credentials are provided via environment variables, try to authenticate
// the backend as an admin so it can perform admin-only collection actions.
// Set PB_ADMIN_EMAIL and PB_ADMIN_PASS in your environment before starting the server.
const { PB_ADMIN_EMAIL, PB_ADMIN_PASS } = process.env;
if (PB_ADMIN_EMAIL && PB_ADMIN_PASS) {
	try {
		// top-level await is supported in ESM modules
		await pb.admins.authWithPassword(PB_ADMIN_EMAIL, PB_ADMIN_PASS);
		console.log('PocketBase: admin authenticated from environment');
	} catch (err) {
		console.warn('PocketBase: admin auth failed:', err.message || err);
	}
}
