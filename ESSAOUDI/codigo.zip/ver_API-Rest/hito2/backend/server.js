import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';

// Note: runtime file uploads are handled in-memory (no local image directory required)

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

async function loadController(path) {
	try {
		const mod = await import(path);
		return mod.default ?? mod;
	} catch (err) {
		try {
			const { createRequire } = await import('module');
			const require = createRequire(import.meta.url);
			return require(path);
		} catch (err2) {
			// If both methods fail, rethrow the original error for debugging.
			err.originalError = err2;
			throw err;
		}
	}
}

const rawAuth = await loadController('./Controllers/authController.js');
const rawUsers = await loadController('./Controllers/usersController.js');
const rawPisos = await loadController('./Controllers/pisosController.js');
const rawComentarios = await loadController('./Controllers/comentariosController.js');
const rawReservas = await loadController('./Controllers/reservasController.js');

function normalizeController(raw, name) {
	const mod = raw && raw.default ? raw.default : raw;
	// router in express is a function with .use and .handle properties, but the minimal check is that it's a function
	const isFunction = typeof mod === 'function';
	const hasUse = mod && typeof mod.use === 'function';
	if (!isFunction && !hasUse) {
		console.error(`Controller ${name} does not export a router/middleware. Export keys:`, Object.keys(mod || {}));
		throw new TypeError(`Controller ${name} did not export a valid Express router or middleware`);
	}
	return mod;
}

const authController = normalizeController(rawAuth, 'authController');
const usersController = normalizeController(rawUsers, 'usersController');
const pisosController = normalizeController(rawPisos, 'pisosController');
const comentariosController = normalizeController(rawComentarios, 'comentariosController');
const reservasController = normalizeController(rawReservas, 'reservasController');

app.use('/api/auth', authController);
app.use('/api/users', usersController);
app.use('/api/pisos', pisosController);
app.use('/api/comentarios', comentariosController);
app.use('/api/reservas', reservasController);

// Basic health
app.get('/api/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`API server listening on port ${PORT}`));
