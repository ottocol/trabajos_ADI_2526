import { pb } from '../config/pb.js';
import listaRepository from '../repositories/listaRepository.js';

// CREATE - Crear un nuevo piso ,lo har´el propietario solo
async function crearPiso(pisoData) {
    try {
        const piso = await listaRepository.createPiso(pisoData);
        console.log("Piso creado correctamente:", piso);
        return piso;
    } catch (err) {
        console.error("Error al crear piso:", err);
        throw err;
    }
}

// READ - Listar todos los pisos con paginacion (PÚBLICO/INQUILINO)
async function listarPisos(page = 1, perPage = 10, filters = {}) {
    try {
        // By default return a public summary suitable for the home page
        const result = await listaRepository.getAllPisos(page, perPage, filters);
        // Map to a lightweight summary for the frontend home page
        const summaryItems = (result.items || []).map(item => {
            // Attempt to pick the first image (assumes a `images` array or `foto` field)
            let firstImage = null;
            // PocketBase field may be named `imagen` and contain an array of filenames.
            if (Array.isArray(item.imagen) && item.imagen.length > 0) {
                const filename = item.imagen[0];
                // build file URL from PocketBase base URL and known collection name
                firstImage = `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${item.id}/${encodeURIComponent(filename)}`;
            } else if (typeof item.imagen === 'string' && item.imagen.length > 0) {
                const filename = item.imagen;
                firstImage = `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${item.id}/${encodeURIComponent(filename)}`;
            } else if (Array.isArray(item.images) && item.images.length > 0) firstImage = item.images[0];
            else if (item.foto) firstImage = item.foto;

            return {
                id: item.id || item._id || item.id,
                titulo: item.titulo || item.name || '',
                direccion: item.direccion || item.dirección || '',
                ciudad: item.ciudad || '',
                precio: item.precio || null,
                cp: item.cp || null,
                descripcion: item.descripcion || '',
                num_habit: item.num_habit || null,
                superficie: item.superficie || null,
                primeraImagen: firstImage,
                                propietario: (item.expand && item.expand.propietario_id && (item.expand.propietario_id.nombre || item.expand.propietario_id.name || item.expand.propietario_id.email))
                                    || (item.propietario && (item.propietario.nombre || item.propietario.name || item.propietario.email))
                                    || item.propietario_id || undefined
            };
        });

        console.log(`Página ${page} de pisos (summary) obtenida: ${summaryItems.length} pisos`);
        return { ...result, items: summaryItems };
    } catch (err) {
        console.error("Error al obtener lista de pisos:", err);
        throw err;
    }
}

// Admin listing: returns full piso records (owner expanded) — intended for admins
async function listarPisosAdmin(page = 1, perPage = 10, filters = {}) {
    try {
        const result = await listaRepository.getAllPisos(page, perPage, filters);
        console.log(`Página ${page} de pisos (admin) obtenida: ${result.items.length} pisos`);
        return result;
    } catch (err) {
        console.error("Error al obtener lista de pisos (admin):", err);
        throw err;
    }
}

// READ - Obtener pisos por propietario(el propietario podrá ver sus pisos)
async function obtenerPisosPorPropietario(propietarioId, page = 1, perPage = 10) {
    try {
        const result = await listaRepository.getPisosByPropietario(propietarioId, page, perPage);
        console.log(`Pisos del propietario ${propietarioId} obtenidos: ${result.items.length} pisos`);
        return result;
    } catch (err) {
        console.error("Error al obtener pisos del propietario:", err);
        throw err;
    }
}

// READ - Buscar pisos con filtros 
async function buscarPisos(filters = {}, page = 1, perPage = 10) {
    try {
        const result = await listaRepository.searchPisos(filters, page, perPage);
        console.log(`Búsqueda completada: ${result.items.length} pisos encontrados`);
        return result;
    } catch (err) {
        console.error("Error al buscar pisos:", err);
        throw err;
    }
}

// READ - Obtener piso por ID , publico
async function obtenerPisoPorId(id) {
    try {
        const piso = await listaRepository.getPisoById(id);
        console.log("Piso obtenido:", piso);
        return piso;
    } catch (err) {
        console.error("Error al obtener piso:", err);
        throw err;
    }
}

// UPDATE (PROPIETARIO - con validación)
async function actualizarPiso(id, pisoData, propietarioId = null) {
    try {
        const piso = await listaRepository.updatePiso(id, pisoData, propietarioId);
        console.log("Piso actualizado correctamente:", piso);
        return piso;
    } catch (err) {
        console.error("Error al actualizar piso:", err);
        throw err;
    }
}

// DELETE  (PROPIETARIO - con validación)
async function eliminarPiso(id, propietarioId = null) {
    try {
        const result = await listaRepository.deletePiso(id, propietarioId);
        console.log("Piso eliminado correctamente:", id);
        return result;
    } catch (err) {
        console.error("Error al eliminar piso:", err);
        throw err;
    }
}
// READ - Obtener pisos del usuario autenticado
async function obtenerMisPisos(propietarioId, page = 1, perPage = 10) {
    try {
        const result = await listaRepository.getPisosByPropietario(propietarioId, page, perPage);
        
        // Mapear los datos para el frontend
        const misPisos = (result.items || []).map(item => {
            let primeraImagen = null;
            if (Array.isArray(item.imagen) && item.imagen.length > 0) {
                const filename = item.imagen[0];
                primeraImagen = `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${item.id}/${encodeURIComponent(filename)}`;
            }

            return {
                id: item.id,
                titulo: item.titulo || '',
                direccion: item.direccion || '',
                codigoPostal: item.cp || item.codigo_postal || '',
                descripcion: item.descripcion || '',
                precio: item.precio || item.precio_noche || 0,
                habitaciones: item.num_habit || item.num_habitaciones || 0,
                superficie: item.superficie || 0,
                tipo: item.tipo_propiedad || 'apartamento',
                estado: item.estado || 'pendiente',
                imagenUrl: primeraImagen,
                imagenes: item.imagen || []
            };
        });

        console.log(`Pisos del usuario ${propietarioId} obtenidos: ${misPisos.length} pisos`);
        return { ...result, items: misPisos };
    } catch (err) {
        console.error("Error al obtener mis pisos:", err);
        throw err;
    }
}

// ==================== RESERVAS ====================

// Obtener reservas del usuario autenticado
async function obtenerMisReservas(usuarioId, page = 1, perPage = 50) {
    try {
        
        const result = await listaRepository.getReservasByUsuario(usuarioId, page, perPage);
        
        
        // Procesar las reservas para incluir información del piso
        const reservasProcesadas = (result.items || []).map(reserva => {
            const piso = reserva.expand?.piso_id || {};
            
            // Obtener imagen del piso
            let imagenPiso = null;
            if (Array.isArray(piso.imagen) && piso.imagen.length > 0) {
                const filename = piso.imagen[0];
                imagenPiso = `${pb.baseUrl.replace(/\/$/, '')}/api/files/pisos/${piso.id}/${encodeURIComponent(filename)}`;
            }

            return {
                id: reserva.id,
                tituloPiso: piso.titulo || 'Piso sin título',
                direccion: piso.direccion || '',
                ciudad: piso.ciudad || '',
                fechaInicio: reserva.fecha_inicio,
                fechaFin: reserva.fecha_fin,
                precioTotal: reserva.precio_total,
                estado: reserva.estado || 'pendiente',
                pisoId: reserva.piso_id,
                imagenPiso: imagenPiso,
                fechaCreacion: reserva.created
            };
        });

        return {
            items: reservasProcesadas,
            page: result.page,
            perPage: result.perPage,
            totalItems: result.totalItems,
            totalPages: result.totalPages
        };
    } catch (err) {
        throw err;
    }
}

// Crear nueva reserva
async function crearReserva(reservaData) {
    try {
        const reserva = await listaRepository.createReserva(reservaData);
        return reserva;
    } catch (err) {
        throw err;
    }
}

// Cancelar reserva
async function cancelarReserva(reservaId, usuarioId = null) {
    try {
        // Si se proporciona usuarioId, validar que la reserva le pertenece
        if (usuarioId) {
            const reservaExistente = await listaRepository.getReservaById(reservaId);
            if (reservaExistente.usuario_id !== usuarioId) {
                throw new Error('No tienes permisos para cancelar esta reserva');
            }
        }
        
        const reservaActualizada = await listaRepository.updateReserva(reservaId, {
            estado: 'cancelada'
        });
        
        return reservaActualizada;
    } catch (err) {
        throw err;
    }
}

// Obtener reservas de un piso (para propietarios)
async function obtenerReservasPorPiso(pisoId, propietarioId = null, page = 1, perPage = 50) {
    try {
        // Si se proporciona propietarioId, validar que el piso le pertenece
        if (propietarioId) {
            const pisoExistente = await listaRepository.getPisoById(pisoId);
            if (pisoExistente.propietario_id !== propietarioId) {
                throw new Error('No tienes permisos para ver las reservas de este piso');
            }
        }
        
        const result = await listaRepository.getReservasByPiso(pisoId, page, perPage);
        
        // Procesar las reservas para incluir información del usuario
        const reservasProcesadas = (result.items || []).map(reserva => {
            const usuario = reserva.expand?.usuario_id || {};
            
            return {
                id: reserva.id,
                nombreUsuario: usuario.name || usuario.username || 'Usuario',
                emailUsuario: usuario.email,
                fechaInicio: reserva.fecha_inicio,
                fechaFin: reserva.fecha_fin,
                precioTotal: reserva.precio_total,
                estado: reserva.estado,
                fechaCreacion: reserva.created
            };
        });

        return {
            items: reservasProcesadas,
            page: result.page,
            perPage: result.perPage,
            totalItems: result.totalItems,
            totalPages: result.totalPages
        };
    } catch (err) {
        throw err;
    }
}


export default {
    crearPiso,
    listarPisos,
    listarPisosAdmin,
    obtenerPisosPorPropietario,
    obtenerMisPisos,
    buscarPisos,
    obtenerPisoPorId,
    actualizarPiso,
    eliminarPiso,
    obtenerMisReservas,
    crearReserva,
    cancelarReserva,
    obtenerReservasPorPiso
};