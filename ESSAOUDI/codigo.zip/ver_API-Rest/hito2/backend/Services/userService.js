import { pb } from '../config/pb.js';
import userRepository from '../repositories/listaRepository.js';

// Función común para todos los usuarios - Obtener usuario por ID
async function getUserById(userId) {
    try {
        const user = await userRepository.getUserById(userId);
        console.log("Usuario obtenido:", user);
        return user;
    } catch (err) {
        console.error("Error al obtener usuario:", err);
        throw err;
    }
}

// Función SOLO para usuarios con rol admin
// Obtener todos los usuarios con paginación
// Si se pasan filtros (searchText/rol), delega en searchUsers del repositorio
async function getAllUsers(page = 1, perPage = 20, filters = {}) {
    try {
        const currentUser = pb.authStore.record;
        if (!currentUser || currentUser.rol !== 'admin') {
            throw new Error("Acceso denegado: Solo los administradores pueden ver todos los usuarios");
        }

        const { searchText = '', rol = '' } = filters || {};

        // Si hay filtros aplicados, usar búsqueda; si no, listado normal
        const resultList = (searchText?.trim() || rol?.trim())
            ? await userRepository.searchUsers(searchText, rol, page, perPage)
            : await userRepository.getAllUsers(page, perPage, { sort: '-created' });
        
        // Mensaje coherente tanto para listados como para búsquedas
        console.log(`Página ${page} de usuarios obtenida: ${resultList.items?.length ?? 0} usuarios`);
        return {
            items: resultList.items,          // Array de usuarios
            page: resultList.page,            // Página actual
            perPage: resultList.perPage,      // Usuarios por página
            totalItems: resultList.totalItems, // Total de usuarios
            totalPages: resultList.totalPages  // Total de páginas
        };
    } catch (err) {
        console.error("Error al obtener lista de usuarios:", err);
        throw err;
    }
}

// Función SOLO para ADMIN - Buscar usuarios por texto, rol o username
async function searchUsers(searchText = '', rol = '', page = 1, perPage = 20) {
    try {
        const currentUser = pb.authStore.record;
        if (!currentUser || currentUser.rol !== 'admin') {
            throw new Error("Acceso denegado: Solo los administradores pueden buscar usuarios");
        }

        const resultList = await userRepository.searchUsers(searchText, rol, page, perPage);
        
        // si no se encontraron usuarios con los filtros
        if (resultList.totalItems === 0) {
            console.log("No se encontraron usuarios con los filtros aplicados");
            return {
                items: [],
                page: page,
                perPage: perPage,
                totalItems: 0,
                totalPages: 0,
                message: "No se encontraron usuarios con los filtros aplicados"
            };
        }
        
        console.log(`Búsqueda completada: ${resultList.items.length} usuarios encontrados`);
        return {
            items: resultList.items,
            page: resultList.page,
            perPage: resultList.perPage,
            totalItems: resultList.totalItems,
            totalPages: resultList.totalPages
        };
    } catch (err) {
        console.error("Error al buscar usuarios:", err);
        throw err;
    }
}

// Función SOLO para ADMIN - Crear nuevo usuario
async function createUser(data) {
    try {
        // Verificar que el usuario actual es admin
        const currentUser = pb.authStore.record;
        if (!currentUser || currentUser.rol !== 'admin') {
            throw new Error("Acceso denegado: Solo los administradores pueden crear usuarios");
        }

        const newUser = await userRepository.createUser(data);
        console.log("Usuario creado correctamente por admin:", newUser);
        return newUser;
    } catch (err) {
        console.error("Error al crear usuario:", err);
        throw err;
    }
}

// Función SOLO para ADMIN - Actualizar cualquier usuario (puede cambiar rol a admin)
async function updateUser(userId, data) {
    try {
        const currentUser = pb.authStore.record;
        if (!currentUser || currentUser.rol !== 'admin') {
            throw new Error("Acceso denegado: Solo los administradores pueden actualizar usuarios");
        }

        const updatedUser = await userRepository.updateUser(userId, data);
        console.log("Usuario actualizado correctamente por admin:", updatedUser);
        return updatedUser;
    } catch (err) {
        console.error("Error al actualizar usuario:", err);
        throw err;
    }
}

// Función para usuarios inquilino/propietario - Actualizar su propio perfil
// Solo puede cambiar rol entre 'inquilino' y 'propietario', nunca a 'admin'
async function updatePerfil(userId, data) {
    try {
        //para validar que el rol no sea 'admin'
        if (data.rol && data.rol === 'admin') {
            throw new Error("No puedes asignarte el rol de administrador");
        }

        const updatedUser = await userRepository.updateUser(userId, data);
        console.log("Perfil actualizado correctamente:", updatedUser);
        return updatedUser;
    } catch (err) {
        console.error("Error al actualizar perfil:", err);
        throw err;
    }
}

// Función SOLO para ADMIN - Eliminar usuario
async function deleteUser(userId) {
    try {
        // Verificar que el usuario actual es admin
        const currentUser = pb.authStore.record;
        if (!currentUser || currentUser.rol !== 'admin') {
            throw new Error("Acceso denegado: Solo los administradores pueden eliminar usuarios");
        }

        await userRepository.deleteUser(userId);
        console.log("Usuario eliminado correctamente:", userId);
        return { success: true, message: "Usuario eliminado" };
    } catch (err) {
        console.error("Error al eliminar usuario:", err);
        throw err;
    }
}
// Función para que un usuario elimine su PROPIA cuenta
async function deleteMyAccount(userId) {
    try {
        const currentUser = pb.authStore.record;
        if (!currentUser) {
            throw new Error("No autenticado");
        }
        
        if (currentUser.id !== userId) {
            throw new Error("No puedes eliminar una cuenta que no es tuya");
        }

        console.log(`🗑️ Iniciando eliminación de cuenta para usuario: ${userId}`);
        console.log(`🔐 Usuario autenticado:`, currentUser.id, currentUser.email, currentUser.rol);

        // PRIMERO: Verificar que podemos acceder al usuario
        console.log('👤 Obteniendo datos del usuario...');
        const userData = await pb.collection('users').getOne(userId);
        console.log('✅ Datos del usuario obtenidos:', userData.id, userData.email);

        // SEGUNDO: Intentar eliminar reservas
        try {
            console.log('📋 Buscando reservas del usuario...');
            const reservas = await pb.collection('reservas').getFullList({
                filter: `inquilino_id = "${userId}"`
            });
            console.log(`📊 Encontradas ${reservas.length} reservas`);
            
            for (const reserva of reservas) {
                console.log(`🗑️ Eliminando reserva: ${reserva.id}`);
                await pb.collection('reservas').delete(reserva.id);
            }
            console.log(`✅ ${reservas.length} reservas eliminadas`);
        } catch (reservaError) {
            console.warn('⚠️ Error con reservas:', reservaError.message);
        }

        // TERCERO: Si es propietario, eliminar pisos
        if (userData.rol === 'propietario') {
            try {
                console.log('🏠 Buscando pisos del propietario...');
                const pisos = await pb.collection('pisos').getFullList({
                    filter: `propietario_id = "${userId}"`
                });
                console.log(`📊 Encontrados ${pisos.length} pisos`);
                
                for (const piso of pisos) {
                    console.log(`🗑️ Eliminando piso: ${piso.id}`);
                    
                    // Eliminar reservas del piso primero
                    const reservasPiso = await pb.collection('reservas').getFullList({
                        filter: `piso_id = "${piso.id}"`
                    });
                    console.log(`📊 Encontradas ${reservasPiso.length} reservas para el piso ${piso.id}`);
                    
                    for (const reserva of reservasPiso) {
                        await pb.collection('reservas').delete(reserva.id);
                    }
                    
                    // Eliminar piso
                    await pb.collection('pisos').delete(piso.id);
                }
                console.log(`✅ ${pisos.length} pisos eliminados`);
            } catch (pisoError) {
                console.warn('⚠️ Error con pisos:', pisoError.message);
            }
        }

        // FINALMENTE: Eliminar el usuario
        console.log('👤 INTENTANDO ELIMINAR USUARIO...');
        console.log('🔍 Antes de eliminar - userId:', userId);
        console.log('🔍 Auth store:', pb.authStore);
        
        // ⚠️ ESTA ES LA LÍNEA CRÍTICA - vamos a ver qué pasa aquí
        await pb.collection('users').delete(userId);
        
        console.log('✅ USUARIO ELIMINADO EXITOSAMENTE');
        
        // Cerrar sesión
        pb.authStore.clear();
        
        return { 
            success: true, 
            message: "Cuenta eliminada correctamente" 
        };
    } catch (err) {
        console.error("❌ ERROR COMPLETO en deleteMyAccount:", err);
        console.error("🔍 Detalles del error:", {
            message: err.message,
            stack: err.stack,
            userId: userId,
            authStore: pb.authStore
        });
        throw err;
    }
}
export default {
    getUserById,
    getAllUsers,
    searchUsers,
    createUser,
    updateUser,
    updatePerfil,
    deleteUser,
    deleteMyAccount
};