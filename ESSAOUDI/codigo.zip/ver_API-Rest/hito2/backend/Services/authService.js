import repo from '../repositories/listaRepository.js';

// Registrar usuario
async function register(data) {
    try {
        const user = await repo.registerUser(data);
        console.log("Usuario registrado correctamente:", user);
        return user;
    } catch (err) {
        console.error("Error al registrar usuario:", err);
        throw err;
    }
}

// Login usuario
async function login(email, password) {
    try {
        const authData = await repo.loginUser(email, password);
        console.log("Sesion iniciada correctamente:", authData);
        return authData;
    } catch (err) {
        console.error("Error al iniciar sesion:", err);
        throw err;
    }
}


// Logout usuario
async function logout() {
    try {
        repo.logoutUser();
        console.log("Sesion cerrada correctamente");
    } catch (err) {
        console.error("Error al cerrar sesion:", err);
        throw err;
    }
}

export default {
    register,
    login,
    logout,
};
