import { pb } from '../config/pb.js';
import listaRepository from '../repositories/listaRepository.js';

// Función privada para validar comentario
function validarComentario(coment) {
    if (coment === undefined || coment === null) {
        throw new Error('El comentario es obligatorio');
    }
    
    if (typeof coment !== 'string') {
        throw new Error('El comentario debe ser un texto');
    }
    
    const comentarioLimpio = coment.trim();
    
    if (comentarioLimpio.length === 0) {
        throw new Error('El comentario no puede estar vacío o contener solo espacios');
    }
    
    if (comentarioLimpio.length < 3) {
        throw new Error('El comentario debe tener al menos 3 caracteres');
    }
    
    return comentarioLimpio;
}

// CREATE - Crear un nuevo comentario
async function crearComentario(comentarioData) {
    try {
        // Validar que el comentario no esté vacío o solo contenga espacios
        validarComentario(comentarioData.coment);
        
        const comentario = await listaRepository.createComentario(comentarioData);
        console.log("Comentario creado correctamente:", comentario);
        return comentario;
    } catch (err) {
        console.error("Error al crear comentario:", err);
        throw err;
    }
}

// READ - Obtener comentario por ID
async function obtenerComentarioPorId(id) {
    try {
        const comentario = await listaRepository.getComentarioById(id);
        console.log("Comentario obtenido:", comentario);
        return comentario;
    } catch (err) {
        console.error("Error al obtener comentario:", err);
        throw err;
    }
}

// READ - Listar todos los comentarios con PAGINACIÓN
async function listarComentarios(page = 1, perPage = 10, filters = {}) {
    try {
        const resultList = await listaRepository.getAllComentarios(page, perPage, filters);
        
        console.log(`Página ${page} de comentarios obtenida: ${resultList.items.length} comentarios`);
        
        if (resultList.items.length > 0) {
            console.log('Primer comentario con expand:', resultList.items[0].expand);
        }
        
        return resultList;
    } catch (err) {
        console.error("Error al obtener lista de comentarios:", err);
        throw err;
    }
}

// READ - Obtener comentarios por PISO
async function obtenerComentariosPorPiso(pisoId, page = 1, perPage = 10) {
    try {
        const resultList = await listaRepository.getComentariosByPiso(pisoId, page, perPage);
        
        console.log(`Comentarios del piso ${pisoId} obtenidos: ${resultList.items.length} comentarios`);
        return resultList;
    } catch (err) {
        console.error("Error al obtener comentarios del piso:", err);
        throw err;
    }
}

// UPDATE - Actualizar comentario (solo el usuario propietario)
async function actualizarComentario(id, comentarioData, usuarioId = null) {
  try {
    if (!usuarioId) {
      throw new Error('Usuario no autenticado');
    }

    // Validar siempre que venga el campo "coment"
    if ('coment' in comentarioData) {
      validarComentario(comentarioData.coment);
    }

    const comentario = await listaRepository.updateComentario(id, comentarioData, usuarioId);
    console.log("Comentario actualizado correctamente:", comentario);
    return comentario;
  } catch (err) {
    console.error("Error al actualizar comentario:", err);
    throw err;
  }
}

// DELETE - Eliminar comentario (solo el usuario propietario)
async function eliminarComentario(id, usuarioId = null) {
    try {
        if (!usuarioId) {
            throw new Error('Usuario no autenticado');
        }

        const result = await listaRepository.deleteComentario(id, usuarioId);
        console.log("Comentario eliminado correctamente:", id);
        return result;
    } catch (err) {
        console.error("Error al eliminar comentario:", err);
        throw err;
    }
}

export default {
    crearComentario,
    obtenerComentarioPorId,
    listarComentarios,
    obtenerComentariosPorPiso,
    actualizarComentario,
    eliminarComentario,
    validarComentario 
};