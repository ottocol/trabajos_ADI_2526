const comentariosService = require('../Services/comentariosService.js');

// Mocks
jest.mock('../repositories/listaRepository.js', () => ({
  createComentario: jest.fn(), getComentarioById: jest.fn(), getAllComentarios: jest.fn(),
  getComentariosByPiso: jest.fn(), updateComentario: jest.fn(), deleteComentario: jest.fn(),
}));

jest.mock('../config/pb.js', () => ({ pb: { authStore: { record: null } } }));

const listaRepository = require('../repositories/listaRepository.js');

const mockComentario = {
  id: '1', usuario_id: 'user123', piso_id: 'piso456',
  coment: 'Excelente piso, muy bien ubicado', fecha: '2024-01-15 10:30:00'
};

const mockLista = { items: [mockComentario], page: 1, perPage: 10, totalItems: 1, totalPages: 1 };

describe('comentariosService', () => {
  beforeEach(() => {
    listaRepository.createComentario.mockResolvedValue(mockComentario);
    listaRepository.getComentarioById.mockResolvedValue(mockComentario);
    listaRepository.getAllComentarios.mockResolvedValue(mockLista);
    listaRepository.getComentariosByPiso.mockResolvedValue(mockLista);
    
    // Mock que permite que la validación del servicio funcione
    listaRepository.updateComentario.mockImplementation((id, data) => {
      // Simplemente resuelve con los datos - la validación la hace el servicio
      return Promise.resolve({ ...mockComentario, ...data, id });
    });
    
    listaRepository.deleteComentario.mockResolvedValue({ success: true, message: "Comentario eliminado" });
  });

  afterEach(() => jest.clearAllMocks());

  describe('Operaciones básicas', () => {
    const testCases = [
      ['crearComentario', () => comentariosService.crearComentario(mockComentario), 
        () => expect(listaRepository.createComentario).toHaveBeenCalledWith(mockComentario)
      ],
      ['obtenerComentarioPorId', () => comentariosService.obtenerComentarioPorId('1'),
        () => expect(listaRepository.getComentarioById).toHaveBeenCalledWith('1')
      ],
      ['listarComentarios', () => comentariosService.listarComentarios(1, 10),
        () => expect(listaRepository.getAllComentarios).toHaveBeenCalledWith(1, 10, {})
      ],
      ['obtenerComentariosPorPiso', () => comentariosService.obtenerComentariosPorPiso('piso456'),
        () => expect(listaRepository.getComentariosByPiso).toHaveBeenCalledWith('piso456', 1, 10)
      ],
      ['actualizarComentario', () => comentariosService.actualizarComentario('1', { coment: 'Actualizado' }),
        () => expect(listaRepository.updateComentario).toHaveBeenCalledWith('1', { coment: 'Actualizado' }, null)
      ],
      ['eliminarComentario', () => comentariosService.eliminarComentario('1'),
        () => expect(listaRepository.deleteComentario).toHaveBeenCalledWith('1', null)
      ]
    ];

    test.each(testCases)('%s funciona correctamente', async (_, action, check) => {
      const result = await action();
      expect(result).toBeDefined();
      check();
    });
  });

  describe('Validaciones', () => {
    const validationCases = [
      [{ coment: '' }, 'El comentario no puede estar vacío o contener solo espacios'],
      [{ coment: '   ' }, 'El comentario no puede estar vacío o contener solo espacios'],
      [{ coment: 'Ok' }, 'El comentario debe tener al menos 3 caracteres'],
      [{ coment: 123 }, 'El comentario debe ser un texto']
    ];

    test.each(validationCases)('debe fallar con datos inválidos %p', async (invalidData, error) => {
      await expect(comentariosService.crearComentario({ ...mockComentario, ...invalidData }))
        .rejects.toThrow(error);
    });

    it('debe fallar al actualizar con comentario vacío', async () => {
      await expect(comentariosService.actualizarComentario('1', { coment: '' }))
        .rejects.toThrow('El comentario no puede estar vacío o contener solo espacios');
    });

    it('debe fallar al actualizar con comentario muy corto', async () => {
      await expect(comentariosService.actualizarComentario('1', { coment: 'No' }))
        .rejects.toThrow('El comentario debe tener al menos 3 caracteres');
    });

    it('debe permitir actualizar con comentario válido', async () => {
      const result = await comentariosService.actualizarComentario('1', { coment: 'Comentario válido' });
      expect(result.coment).toEqual('Comentario válido');
    });
  });

  describe('Filtros', () => {
    const filterCases = [
      ['piso_id', { piso_id: 'piso456' }],
      ['fecha_desde', { fecha_desde: '2024-01-01' }],
      ['fecha_hasta', { fecha_hasta: '2024-01-31' }],
      ['combinación', { piso_id: 'piso456', fecha_desde: '2024-01-01', fecha_hasta: '2024-01-31' }]
    ];

    test.each(filterCases)('debe filtrar por %s', async (_, filters) => {
      const result = await comentariosService.listarComentarios(1, 10, filters);
      expect(result.items.length).toBe(1);
    });

    it('debe manejar búsqueda vacía', async () => {
      listaRepository.getAllComentarios.mockResolvedValueOnce({ ...mockLista, items: [], totalItems: 0 });
      const result = await comentariosService.listarComentarios(1, 10, { piso_id: 'pisoInexistente' });
      expect(result.items.length).toBe(0);
    });
  });

  describe('Manejo de errores', () => {
    it('debe manejar comentario no existente al obtener', async () => {
      listaRepository.getComentarioById.mockRejectedValueOnce(new Error('Record not found'));
      await expect(comentariosService.obtenerComentarioPorId('999'))
        .rejects.toThrow('Record not found');
    });

    it('debe manejar comentario no existente al actualizar', async () => {
      listaRepository.updateComentario.mockRejectedValueOnce(new Error('Record not found'));
      await expect(comentariosService.actualizarComentario('999', { coment: 'Actualizado' }))
        .rejects.toThrow('Record not found');
    });

    it('debe manejar comentario no existente al eliminar', async () => {
      listaRepository.deleteComentario.mockRejectedValueOnce(new Error('Record not found'));
      await expect(comentariosService.eliminarComentario('999'))
        .rejects.toThrow('Record not found');
    });

    it('debe manejar error en listado', async () => {
      listaRepository.getAllComentarios.mockRejectedValueOnce(new Error('Error de base de datos'));
      await expect(comentariosService.listarComentarios(1, 10))
        .rejects.toThrow('Error de base de datos');
    });
  });

  describe('Gestión de permisos', () => {
    it('debe permitir actualizar comentario propio', async () => {
      // Configurar el mock para que permita la actualización cuando el usuario es el propietario
      listaRepository.updateComentario.mockImplementationOnce((id, data, usuarioId) => {
        if (usuarioId === 'user123') {
          return Promise.resolve({ ...mockComentario, ...data, id });
        }
        return Promise.reject(new Error('No tienes permisos para actualizar este comentario'));
      });
      
      const result = await comentariosService.actualizarComentario('1', { coment: 'Test' }, 'user123');
      expect(result.coment).toEqual('Test');
      expect(listaRepository.updateComentario).toHaveBeenCalledWith('1', { coment: 'Test' }, 'user123');
    });

    it('debe permitir eliminar comentario propio', async () => {
      // Configurar el mock para que permita la eliminación cuando el usuario es el propietario
      listaRepository.deleteComentario.mockImplementationOnce((id, usuarioId) => {
        if (usuarioId === 'user123') {
          return Promise.resolve({ success: true, message: "Comentario eliminado" });
        }
        return Promise.reject(new Error('No tienes permisos para eliminar este comentario'));
      });
      
      const result = await comentariosService.eliminarComentario('1', 'user123');
      expect(result.success).toBe(true);
      expect(listaRepository.deleteComentario).toHaveBeenCalledWith('1', 'user123');
    });

    it('debe impedir actualizar comentario ajeno', async () => {
      // Configurar el mock para que rechace la actualización cuando el usuario no es el propietario
      listaRepository.updateComentario.mockRejectedValueOnce(new Error('No tienes permisos para actualizar este comentario'));
      await expect(comentariosService.actualizarComentario('1', { coment: 'Test' }, 'user456')) // usuario diferente
        .rejects.toThrow('No tienes permisos para actualizar este comentario');
    });

    it('debe impedir eliminar comentario ajeno', async () => {
      // Configurar el mock para que rechace la eliminación cuando el usuario no es el propietario
      listaRepository.deleteComentario.mockRejectedValueOnce(new Error('No tienes permisos para eliminar este comentario'));
      await expect(comentariosService.eliminarComentario('1', 'user456')) // usuario diferente
        .rejects.toThrow('No tienes permisos para eliminar este comentario');
    });

    it('debe funcionar sin validación de usuario (admin)', async () => {
      const result = await comentariosService.actualizarComentario('1', { coment: 'Actualizado sin usuario' });
      expect(result.coment).toEqual('Actualizado sin usuario');
      expect(listaRepository.updateComentario).toHaveBeenCalledWith('1', { coment: 'Actualizado sin usuario' }, null);
    });
  });
});