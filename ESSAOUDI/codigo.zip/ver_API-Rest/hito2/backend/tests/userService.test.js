const userService = require('../Services/userService.js');

// Mock the repository (data layer)
jest.mock('../repositories/listaRepository.js', () => ({
  getUserById: jest.fn(),
  getAllUsers: jest.fn(),
  searchUsers: jest.fn(),
  createUser: jest.fn(),
  updateUser: jest.fn(),
  deleteUser: jest.fn(),
}));

// Mock pb.authStore for RBAC checks
jest.mock('../config/pb.js', () => ({
  pb: {
    authStore: { record: { rol: 'admin', id: 'adminId' } },
  },
}));

const userRepository = require('../repositories/listaRepository.js');

describe('userService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('getUserById', () => {
    it('tiene que devolver datos de un usuario por su ID si existe', async () => {
      const mockUser = { id: '1', name: 'Test User' };
      userRepository.getUserById.mockResolvedValueOnce(mockUser);
      const result = await userService.getUserById('1');
      expect(result).toEqual(mockUser);
      expect(userRepository.getUserById).toHaveBeenCalledWith('1');
    });
  });

  describe('getAllUsers', () => {
    it('tiene que devolver usuarios para admin con paginacion', async () => {
      const mockList = { items: [{ id: '1' }], page: 1, perPage: 20, totalItems: 1, totalPages: 1 };
      userRepository.getAllUsers.mockResolvedValueOnce(mockList);
      const result = await userService.getAllUsers(1, 20);
      expect(result.items.length).toBe(1);
      expect(userRepository.getAllUsers).toHaveBeenCalledWith(1, 20, { sort: '-created' });
    });

    it('tiene que delegar a la funcion search cuando se proporciona filters.searchText', async () => {
      const mockList = { items: [{ id: '2' }], page: 1, perPage: 20, totalItems: 1, totalPages: 1 };
      userRepository.searchUsers.mockResolvedValueOnce(mockList);
      const result = await userService.getAllUsers(1, 20, { searchText: 'maria' });
      expect(result.items.length).toBe(1);
      expect(userRepository.searchUsers).toHaveBeenCalledWith('maria', '', 1, 20);
      expect(userRepository.getAllUsers).not.toHaveBeenCalled();
    });

    it('tiene que delegar a la funcion search cuando se proporciona filters.rol', async () => {
      const mockList = { items: [{ id: '3' }], page: 1, perPage: 20, totalItems: 1, totalPages: 1 };
      userRepository.searchUsers.mockResolvedValueOnce(mockList);
      const result = await userService.getAllUsers(1, 20, { rol: 'inquilino' });
      expect(result.items.length).toBe(1);
      expect(userRepository.searchUsers).toHaveBeenCalledWith('', 'inquilino', 1, 20);
      expect(userRepository.getAllUsers).not.toHaveBeenCalled();
    });
  });

  describe('createUser', () => {
    it('Tiene que crear un usuario para admin', async () => {
      const mockUser = { id: '2', name: 'New User' };
      userRepository.createUser.mockResolvedValueOnce(mockUser);
      const result = await userService.createUser({ name: 'New User' });
      expect(result).toEqual(mockUser);
      expect(userRepository.createUser).toHaveBeenCalledWith({ name: 'New User' });
    });
  });

  describe('updateUser', () => {
    it('tiene que actualizar un usuario para admin', async () => {
      const mockUser = { id: '1', name: 'Updated User' };
      userRepository.updateUser.mockResolvedValueOnce(mockUser);
      const result = await userService.updateUser('1', { name: 'Updated User' });
      expect(result).toEqual(mockUser);
      expect(userRepository.updateUser).toHaveBeenCalledWith('1', { name: 'Updated User' });
    });
  });

  describe('updatePerfil', () => {
    it('tiene que actualizar el perfil para los roles inquilino/propietario', async () => {
      const mockUser = { id: '3', name: 'Perfil User', rol: 'inquilino' };
      userRepository.updateUser.mockResolvedValueOnce(mockUser);
      const result = await userService.updatePerfil('3', { name: 'Perfil User', rol: 'inquilino' });
      expect(result).toEqual(mockUser);
      expect(userRepository.updateUser).toHaveBeenCalledWith('3', { name: 'Perfil User', rol: 'inquilino' });
    });

    it('No se puede asignar el rol de admin', async () => {
      await expect(userService.updatePerfil('3', { rol: 'admin' }))
        .rejects.toThrow('No puedes asignarte el rol de administrador');
    });
  });

  describe('deleteUser', () => {
    it('tiene que eliminar un usuario para admin', async () => {
      userRepository.deleteUser.mockResolvedValueOnce();
      const result = await userService.deleteUser('1');
      expect(result.success).toBe(true);
      expect(userRepository.deleteUser).toHaveBeenCalledWith('1');
    });
  });

  describe('searchUsers', () => {
    it('tiene que devolver usuarios que coincidan con la búsqueda', async () => {
      const mockList = { items: [{ id: '1', name: 'Test' }], page: 1, perPage: 20, totalItems: 1, totalPages: 1 };
      userRepository.searchUsers.mockResolvedValueOnce(mockList);
      const result = await userService.searchUsers('Test', '', 1, 20);
      expect(result.items[0].name).toBe('Test');
      expect(userRepository.searchUsers).toHaveBeenCalledWith('Test', '', 1, 20);
    });

    it('tiene que devolver un mensaje de error cuando no se encuentran usuarios', async () => {
      const emptyList = { items: [], page: 1, perPage: 20, totalItems: 0, totalPages: 0 };
      userRepository.searchUsers.mockResolvedValueOnce(emptyList);
      const result = await userService.searchUsers('NoMatch', '', 1, 20);
      expect(result.message).toBe('No se encontraron usuarios con los filtros aplicados');
    });
  });
});
