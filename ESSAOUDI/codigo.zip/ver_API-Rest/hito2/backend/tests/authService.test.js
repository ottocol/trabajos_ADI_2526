const authService = require('../Services/authService.js');

// Mock the repository (data layer)
jest.mock('../repositories/listaRepository.js', () => ({
  registerUser: jest.fn(),
  loginUser: jest.fn(),
  logoutUser: jest.fn(),
}));

const repo = require('../repositories/listaRepository.js');

describe('authService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('register', () => {
    it('debe registrar un usuario', async () => {
      const mockUser = { id: '1', email: 'test@example.com' };
      repo.registerUser.mockResolvedValueOnce(mockUser);
      const result = await authService.register({ email: 'test@example.com', password: '1234' });
      expect(result).toEqual(mockUser);
      expect(repo.registerUser).toHaveBeenCalledWith({ email: 'test@example.com', password: '1234' });
    });
    it('debe lanzar un error en caso de fallo de registro', async () => {
      repo.registerUser.mockRejectedValueOnce(new Error('fail'));
      await expect(authService.register({})).rejects.toThrow('fail');
    });
  });

  describe('login', () => {
    it('debe iniciar sesión de un usuario', async () => {
      const mockAuth = { token: 'abc', user: { id: '1' } };
      repo.loginUser.mockResolvedValueOnce(mockAuth);
      const result = await authService.login('test@example.com', '1234');
      expect(result).toEqual(mockAuth);
      expect(repo.loginUser).toHaveBeenCalledWith('test@example.com', '1234');
    });
    it('debe lanzar un error en caso de fallo de login', async () => {
      repo.loginUser.mockRejectedValueOnce(new Error('login fail'));
      await expect(authService.login('bad', 'bad')).rejects.toThrow('login fail');
    });
  });

  describe('logout', () => {
    it('tiene que llamar a logoutUser', async () => {
      await authService.logout();
      expect(repo.logoutUser).toHaveBeenCalled();
    });
    it('debería lanzar un error en caso de fallo de logout', async () => {
      repo.logoutUser.mockImplementationOnce(() => { throw new Error('logout fail'); });
      await expect(authService.logout()).rejects.toThrow('logout fail');
    });
  });
});
