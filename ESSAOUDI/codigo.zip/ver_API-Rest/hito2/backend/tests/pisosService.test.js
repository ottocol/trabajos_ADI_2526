const pisosService = require('../Services/pisosService.js');

// Mocks
jest.mock('../repositories/listaRepository.js', () => ({
  createPiso: jest.fn(), getAllPisos: jest.fn(), getPisosByPropietario: jest.fn(),
  searchPisos: jest.fn(), getPisoById: jest.fn(), updatePiso: jest.fn(), deletePiso: jest.fn(),
}));

jest.mock('../config/pb.js', () => ({ pb: { authStore: { record: null } } }));

const listaRepository = require('../repositories/listaRepository.js');

const mockPiso = {
  id: '1', ciudad: 'Madrid', direccion: 'Calle Gran Vía 123', cp: '28013',
  descripcion: 'Amplio piso', precio: 850, num_habit: 3, superficie: 90, propietario: 'user123'
};

const mockPisoBcn = {
  ...mockPiso, id: '2', ciudad: 'Barcelona', direccion: 'Avenida Diagonal 456',
  cp: '08028', precio: 750, num_habit: 2, superficie: 75
};

const mockLista = { items: [mockPiso], page: 1, perPage: 10, totalItems: 1, totalPages: 1 };

describe('pisosService', () => {
  beforeEach(() => {
    listaRepository.createPiso.mockResolvedValue(mockPiso);
    listaRepository.getAllPisos.mockResolvedValue(mockLista);
    listaRepository.getPisoById.mockResolvedValue(mockPisoBcn);
    listaRepository.updatePiso.mockImplementation((id, data) => Promise.resolve({ ...mockPiso, ...data, id }));
    listaRepository.deletePiso.mockResolvedValue({ success: true, message: "Piso eliminado" });
    listaRepository.getPisosByPropietario.mockResolvedValue(mockLista);
    listaRepository.searchPisos.mockResolvedValue(mockLista);
  });

  afterEach(() => jest.clearAllMocks());

  describe('Operaciones básicas', () => {
    const testCases = [
      ['crearPiso', () => pisosService.crearPiso(mockPiso), 
        (result) => {
          expect(result.id).toEqual('1');
          expect(listaRepository.createPiso).toHaveBeenCalledWith(mockPiso);
        }
      ],
      ['listarPisos', () => pisosService.listarPisos(1, 10),
        (result) => {
          expect(result.items.length).toBe(1);
          expect(listaRepository.getAllPisos).toHaveBeenCalledWith(1, 10, {});
        }
      ],
      ['obtenerPisoPorId', () => pisosService.obtenerPisoPorId('1'),
        (result) => {
          expect(result.ciudad).toEqual('Barcelona');
          expect(listaRepository.getPisoById).toHaveBeenCalledWith('1');
        }
      ],
      ['actualizarPiso', () => pisosService.actualizarPiso('1', { precio: 900 }),
        (result) => {
          expect(result.precio).toEqual(900);
          expect(listaRepository.updatePiso).toHaveBeenCalledWith('1', { precio: 900 }, null);
        }
      ],
      ['eliminarPiso', () => pisosService.eliminarPiso('1'),
        (result) => {
          expect(result.success).toBe(true);
          expect(listaRepository.deletePiso).toHaveBeenCalledWith('1', null);
        }
      ]
    ];

    test.each(testCases)('%s funciona correctamente', async (_, action, checks) => {
      const result = await action();
      checks(result);
    });
  });

  describe('Búsquedas', () => {
    const searchCases = [
      ['ciudad y precio', { ciudad: 'Madrid', precioMin: 500, precioMax: 1000 }],
      ['número de habitaciones', { num_habit: 2, superficieMin: 70 }],
      ['código postal', { cp: '28013' }]
    ];

    test.each(searchCases)('debe filtrar por %s', async (_, filters) => {
      const result = await pisosService.buscarPisos(filters);
      expect(result.items.length).toBe(1);
      expect(listaRepository.searchPisos).toHaveBeenCalledWith(filters, 1, 10);
    });
  });

  describe('Validaciones', () => {
    const requiredFields = ['ciudad', 'direccion', 'cp'];
    test.each(requiredFields)('debe fallar cuando falta %s', async (field) => {
      listaRepository.createPiso.mockRejectedValueOnce(new Error(`${field} is required`));
      const { [field]: _, ...incompletePiso } = mockPiso;
      await expect(pisosService.crearPiso(incompletePiso)).rejects.toThrow(`${field} is required`);
    });

    const validationCases = [
      [{ precio: 0 }, 'precio must be nonzero'],
      [{ num_habit: 'dos' }, 'num_habit must be a number'],
      [{ superficie: 'ochenta' }, 'superficie must be a number']
    ];
    test.each(validationCases)('debe fallar con datos inválidos %p', async (invalidData, error) => {
      listaRepository.createPiso.mockRejectedValueOnce(new Error(error));
      await expect(pisosService.crearPiso({ ...mockPiso, ...invalidData })).rejects.toThrow(error);
    });

    const updateCases = [[{ precio: 0 }, 'precio must be nonzero']];
    test.each(updateCases)('debe fallar al actualizar con %p', async (updateData, error) => {
      listaRepository.updatePiso.mockRejectedValueOnce(new Error(error));
      await expect(pisosService.actualizarPiso('1', updateData)).rejects.toThrow(error);
    });
  });

  describe('Manejo de errores', () => {
    it('debe manejar piso no existente', async () => {
      listaRepository.updatePiso.mockRejectedValueOnce(new Error('Record not found'));
      await expect(pisosService.actualizarPiso('999', { precio: 900 })).rejects.toThrow('Record not found');
    });

    it('debe manejar eliminación de piso no existente', async () => {
      listaRepository.deletePiso.mockRejectedValueOnce(new Error('Record not found'));
      await expect(pisosService.eliminarPiso('999')).rejects.toThrow('Record not found');
    });

    it('debe manejar búsqueda vacía', async () => {
      listaRepository.searchPisos.mockResolvedValueOnce({ ...mockLista, items: [], totalItems: 0 });
      const result = await pisosService.buscarPisos({ ciudad: 'CiudadInexistente' });
      expect(result.items.length).toBe(0);
    });
  });

  describe('Gestión de propietarios', () => {
    it('debe obtener pisos por propietario', async () => {
      const result = await pisosService.obtenerPisosPorPropietario('user123');
      expect(result.items.length).toBe(1);
      expect(listaRepository.getPisosByPropietario).toHaveBeenCalledWith('user123', 1, 10);
    });

    const setupPermisos = (propietario) => ({ ...mockPiso, propietario });
    
    it('debe permitir actualizar piso propio', async () => {
      listaRepository.getPisoById.mockResolvedValueOnce(setupPermisos('user123'));
      listaRepository.updatePiso.mockResolvedValueOnce({ ...mockPiso, precio: 950 });
      const result = await pisosService.actualizarPiso('1', { precio: 950 }, 'user123');
      expect(result.precio).toEqual(950);
    });

    it('debe impedir actualizar piso ajeno', async () => {
      listaRepository.getPisoById.mockResolvedValueOnce(setupPermisos('otroUsuario'));
      listaRepository.updatePiso.mockRejectedValueOnce(new Error('No tienes permisos'));
      await expect(pisosService.actualizarPiso('1', { precio: 950 }, 'user123'))
        .rejects.toThrow('No tienes permisos');
    });

    it('debe permitir eliminar piso propio', async () => {
      listaRepository.getPisoById.mockResolvedValueOnce(setupPermisos('user123'));
      const result = await pisosService.eliminarPiso('1', 'user123');
      expect(result.success).toBe(true);
    });

    it('debe impedir eliminar piso ajeno', async () => {
      listaRepository.getPisoById.mockResolvedValueOnce(setupPermisos('otroUsuario'));
      listaRepository.deletePiso.mockRejectedValueOnce(new Error('No tienes permisos'));
      await expect(pisosService.eliminarPiso('1', 'user123')).rejects.toThrow('No tienes permisos');
    });
  });
});