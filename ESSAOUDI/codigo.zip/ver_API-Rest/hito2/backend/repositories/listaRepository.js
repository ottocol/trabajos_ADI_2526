import { pb } from '../config/pb.js';


// ==================== Parte de Autenticación ====================
// Registrar usuario 
async function registerUser(data) {
    return await pb.collection('users').create(data);
}

// Login usuario (autenticación con email y password)
async function loginUser(email, password) {
    try {
        return await pb.collection('users').authWithPassword(email, password);
    } catch (err) {
        // Log detailed PocketBase error for debugging
        console.error('PocketBase authWithPassword failed for', email, 'error:', err?.message || err);
        try {
            if (err && err.response) console.error('PocketBase response data:', err.response.data || err.response);
            if (err && err.data) console.error('PocketBase error data:', err.data);
        } catch (e) {
            // ignore
        }
        throw err;
    }
}

// Logout usuario (limpia el authStore)
function logoutUser() {
    pb.authStore.clear();
}

// ==================== Parte de Ususarios ====================

// Obtener usuario por ID
async function getUserById(userId) {
    return await pb.collection('users').getOne(userId);
}

// Lista de usuarios con pagination and optional sort/filter 
async function getAllUsers(page = 1, perPage = 20, options = { sort: '-created', filter: '' }) {
    const { sort = '-created', filter = '' } = options || {};
    return await pb.collection('users').getList(page, perPage, { sort, filter });
}

// Search usuario con su nombre, username and/or role with pagination
async function searchUsers(searchText = '', rol = '', page = 1, perPage = 20) {
    const filters = [];
    if (searchText) {
        filters.push(`(name ~ "${searchText}" || email ~ "${searchText}" || username ~ "${searchText}")`);
    }
    if (rol) {
        filters.push(`rol = "${rol}"`);
    }
    const filterString = filters.length > 0 ? filters.join(' && ') : '';
    return await pb.collection('users').getList(page, perPage, { filter: filterString, sort: '-created' });
}

// Crear usuario
async function createUser(data) {
    return await pb.collection('users').create(data);
}

// Update a user
async function updateUser(userId, data) {
    return await pb.collection('users').update(userId, data);
}

// Delete a user
async function deleteUser(userId) {
    return await pb.collection('users').delete(userId);
}


//PISOS------------------------------------------------------------------------
// CREAR
async function createPiso(pisoData) {
    return await pb.collection('pisos').create(pisoData);
}

// READ - Listar todos los pisos con paginación
async function getAllPisos(page = 1, perPage = 10, filters = {}) {
    const filterString = buildPisoFilters(filters);
    try {
        const resultList = await pb.collection('pisos').getList(page, perPage, {
            filter: filterString,
            sort: '-created',
            expand: 'propietario_id'
        });

        return {
            items: resultList.items,
            page: resultList.page,
            perPage: resultList.perPage,
            totalItems: resultList.totalItems,
            totalPages: resultList.totalPages
        };
    } catch (err) {
        // If PocketBase denies access (collection requires admin), try a safe fallback:
        // - If you have a `public` boolean field on `pisos`, return only those records.
        // - Otherwise return a clear error so caller can handle it.
        const is403 = err && err.status === 403;
        if (is403) {
            // attempt fallback to public-only pisos
            const fallbackFilter = [filterString, 'public = true'].filter(Boolean).join(' && ');
            try {
                const resultList = await pb.collection('pisos').getList(page, perPage, {
                    filter: fallbackFilter,
                    sort: '-created',
                    expand: 'propietario_id'
                });

                return {
                    items: resultList.items,
                    page: resultList.page,
                    perPage: resultList.perPage,
                    totalItems: resultList.totalItems,
                    totalPages: resultList.totalPages,
                    warning: 'Restricted collection: returned only public pisos as fallback'
                };
            } catch (err2) {
                // Still failing: inform caller about admin-only restriction
                const e = new Error('PocketBase: collection access restricted to admins. Change collection rules or provide admin credentials.');
                e.cause = err2;
                e.status = 403;
                throw e;
            }
        }

        // rethrow other errors
        throw err;
    }
}

// READ - Obtener pisos por propietario - VERSIÓN CORREGIDA
async function getPisosByPropietario(propietarioId, page = 1, perPage = 10) {
    try {
        console.log(`🔍 Buscando pisos para propietario_id: ${propietarioId}`);
        
        const resultList = await pb.collection('pisos').getList(page, perPage, {
            // ✅ CAMBIAR "propietario" por "propietario_id"
            filter: `propietario_id = "${propietarioId}"`,
            sort: '-created'
        });
        
        console.log(`✅ Pisos encontrados: ${resultList.items.length}`);
        return {
            items: resultList.items,
            page: resultList.page,
            perPage: resultList.perPage,
            totalItems: resultList.totalItems,
            totalPages: resultList.totalPages
        };
    } catch (err) {
        console.error('❌ Error en getPisosByPropietario:', err);
        throw err;
    }
}
// READ - con filtros buscamos los pisos   
async function searchPisos(filters = {}, page = 1, perPage = 10) {
    const filterString = buildPisoFilters(filters);
    const resultList = await pb.collection('pisos').getList(page, perPage, {
        filter: filterString,
        sort: '-created',
        expand: 'propietario_id'
    });
    
    return {
        items: resultList.items,
        page: resultList.page,
        perPage: resultList.perPage,
        totalItems: resultList.totalItems,
        totalPages: resultList.totalPages
    };
}

// READ - Obtener piso por id
async function getPisoById(id) {
    return await pb.collection('pisos').getOne(id, {
        expand: 'propietario_id'
    });
}

// UPDATE - Actualizar piso (con validación de propietario) - VERSIÓN CORREGIDA
async function updatePiso(id, pisoData, propietarioId = null) {
    // Si se proporciona propietarioId, validar que el piso le pertenece
    if (propietarioId) {
        const pisoExistente = await pb.collection('pisos').getOne(id);
        // ✅ CORREGIDO: Cambiar "propietario" por "propietario_id"
        if (pisoExistente.propietario_id !== propietarioId) {
            throw new Error('No tienes permisos para actualizar este piso');
        }
    }
    
    return await pb.collection('pisos').update(id, pisoData);
}

// DELETE - Eliminar piso (con validación de propietario) - VERSIÓN CORREGIDA
async function deletePiso(id, propietarioId = null) {
    try {
        console.log(`🗑️ Intentando eliminar piso ${id} para propietario_id: ${propietarioId}`);
        
        // Si se proporciona propietarioId, validar que el piso le pertenece
        if (propietarioId) {
            const pisoExistente = await pb.collection('pisos').getOne(id);
            console.log(`📋 Piso existente - Propietario_id: ${pisoExistente.propietario_id}, Usuario: ${propietarioId}`);
            
            // ✅ CORREGIDO: Cambiar "propietario" por "propietario_id"
            if (pisoExistente.propietario_id !== propietarioId) {
                throw new Error('No tienes permisos para eliminar este piso');
            }
        }
        
        await pb.collection('pisos').delete(id);
        console.log(`✅ Piso ${id} eliminado correctamente`);
        return { success: true, message: "Piso eliminado" };
    } catch (err) {
        console.error(`❌ Error eliminando piso ${id}:`, err);
        throw err;
    }
}

// construir filtros de pisos
function buildPisoFilters(filters) {
    let filterConditions = [];
    
    if (filters.ciudad) {
        filterConditions.push(`ciudad ~ "${filters.ciudad}"`);
    }
    
    if (filters.precioMin) {
        filterConditions.push(`precio >= ${filters.precioMin}`);
    }
    
    if (filters.precioMax) {
        filterConditions.push(`precio <= ${filters.precioMax}`);
    }
    
    if (filters.num_habit) {
        filterConditions.push(`num_habit >= ${filters.num_habit}`);
    }
    
    if (filters.superficieMin) {
        filterConditions.push(`superficie >= ${filters.superficieMin}`);
    }
    
    return filterConditions.length > 0 ? filterConditions.join(' && ') : '';
}


//COMENTARIOS -------------------------------------------------------------------------------------------------------------------
// CREATE - Crear un nuevo comentario
async function createComentario(comentarioData) {
    return await pb.collection('comentarios').create(comentarioData);
}

// READ - Obtener comentario por ID
async function getComentarioById(id) {
    return await pb.collection('comentarios').getOne(id, {
        expand: 'usuario_id,piso_id' 
    });
}
// READ - Listar todos los comentarios con PAGINACIÓN
async function getAllComentarios(page = 1, perPage = 10, filters = {}) {
    const filterString = buildComentarioFilters(filters);
    const resultList = await pb.collection('comentarios').getList(page, perPage, {
        filter: filterString,
        sort: '-created',
        expand: 'usuario_id,piso_id' 
    });
    
    return {
        items: resultList.items,
        page: resultList.page,
        perPage: resultList.perPage,
        totalItems: resultList.totalItems,
        totalPages: resultList.totalPages
    };
}
// READ - Obtener comentarios por PISO
async function getComentariosByPiso(pisoId, page = 1, perPage = 10) {
    const resultList = await pb.collection('comentarios').getList(page, perPage, {
        filter: `piso_id = "${pisoId}"`,
        sort: '-created',
        expand: 'usuario_id,piso_id' 
    });
    
    return {
        items: resultList.items,
        page: resultList.page,
        perPage: resultList.perPage,
        totalItems: resultList.totalItems,
        totalPages: resultList.totalPages
    };
}
// UPDATE - Actualizar comentario (con validación de usuario)
async function updateComentario(id, comentarioData, usuarioId = null) {
    // Si se proporciona usuarioId, validar que el comentario le pertenece
    if (usuarioId) {
        const comentarioExistente = await pb.collection('comentarios').getOne(id);
        if (comentarioExistente.usuario_id !== usuarioId) {
            throw new Error('No tienes permisos para actualizar este comentario');
        }
    }
    
    return await pb.collection('comentarios').update(id, comentarioData);
}

// DELETE - Eliminar comentario (con validación de usuario)
async function deleteComentario(id, usuarioId = null) {
    // Si se proporciona usuarioId, validar que el comentario le pertenece
    if (usuarioId) {
        const comentarioExistente = await pb.collection('comentarios').getOne(id);
        if (comentarioExistente.usuario_id !== usuarioId) {
            throw new Error('No tienes permisos para eliminar este comentario');
        }
    }
    
    await pb.collection('comentarios').delete(id);
    return { success: true, message: "Comentario eliminado" };
}

// Validar que el comentario no esté vacío o solo espacios
function validateComentario(coment) {
    if (!coment || typeof coment !== 'string') {
        throw new Error('El comentario es obligatorio');
    }
    
    const comentarioLimpio = coment.trim();
    
    if (comentarioLimpio.length === 0) {
        throw new Error('El comentario no puede estar vacío o contener solo espacios');
    }
    
    if (comentarioLimpio.length < 3) {
        throw new Error('El comentario debe tener al menos 3 caracteres');
    }
    
    return comentarioLimpio;
}

// Función privada para construir filtros de comentarios
function buildComentarioFilters(filters) {
    let filterConditions = [];
    
    if (filters.piso_id) {
        filterConditions.push(`piso_id = "${filters.piso_id}"`);
    }
    
    // filter by usuario (author) id
    if (filters.usuario_id || filters.inquilino_id) {
        const uid = filters.usuario_id || filters.inquilino_id
        filterConditions.push(`usuario_id = "${uid}"`);
    }

    // filter by exact comentario id
    if (filters.id) {
        filterConditions.push(`id = "${filters.id}"`);
    }
    
    if (filters.fecha_desde) {
        // legacy param `fecha_desde` now maps to the record `created` timestamp
        filterConditions.push(`created >= "${filters.fecha_desde}"`);
    }
    
    if (filters.fecha_hasta) {
        filterConditions.push(`created <= "${filters.fecha_hasta}"`);
    }
    
    return filterConditions.length > 0 ? filterConditions.join(' && ') : '';
}


//RESERVAS ---------------------------------------------------------------------------------------------------

// CREATE - Crear nueva reserva
async function createReserva(reservaData) {
    return await pb.collection('reservas').create(reservaData);
}

// READ - Obtener reservas por usuario
async function getReservasByUsuario(usuarioId, page = 1, perPage = 50) {
    return await pb.collection('reservas').getList(page, perPage, {
        filter: `inquilino_id = "${usuarioId}"`,  
        sort: '-created',
        expand: 'piso_id'
    });
}

// READ - Obtener reserva por ID
async function getReservaById(id) {
    return await pb.collection('reservas').getOne(id, {
        expand: 'piso_id,inquilino_id' 
    });
}

// UPDATE - Actualizar reserva
async function updateReserva(id, reservaData) {
    return await pb.collection('reservas').update(id, reservaData);
}

// DELETE - Eliminar reserva
async function deleteReserva(id) {
    return await pb.collection('reservas').delete(id);
}

// READ - Obtener reservas por piso (para propietarios)
async function getReservasByPiso(pisoId, page = 1, perPage = 50) {
    return await pb.collection('reservas').getList(page, perPage, {
        filter: `piso_id = "${pisoId}"`,
        sort: '-created',
        expand: 'inquilino_id'  
    });
}
export default {
    registerUser,
    loginUser,
    logoutUser,

    getUserById,
    getAllUsers,
    searchUsers,
    createUser,
    updateUser,
    deleteUser,

    createPiso,
    getAllPisos,
    getPisosByPropietario,
    searchPisos,
    getPisoById,
    updatePiso,
    deletePiso,

    createComentario,
    getComentarioById,
    getAllComentarios,
    getComentariosByPiso,
    updateComentario,
    deleteComentario,
    validateComentario,

    createReserva,
    getReservasByUsuario,
    getReservaById,
    updateReserva,
    deleteReserva,
    getReservasByPiso
};
