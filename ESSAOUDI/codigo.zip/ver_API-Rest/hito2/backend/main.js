// backend/main.js
import readline from 'readline';
import { pb } from './config/pb.js';

async function menu() {
  console.clear();
  console.log(' Bienvenido al sistema de gestión de pisos');
  console.log('------------------------------------------');
  console.log('1. Ver pisos existentes');
  console.log('2. Crear un nuevo comentario');
  console.log('3. Ver comentarios');
  console.log('4. Salir');
  console.log('------------------------------------------');

  const opcion = await preguntar(' Elige una opción: ');

  switch (opcion.trim()) {
    case '1':
      await verPisos();
      break;
    case '2':
      await crearComentario();
      break;
    case '3':
      await verComentarios();
      break;
    case '4':
      console.log('\n ¡Hasta pronto!\n');
      process.exit(0);
      break;
    default:
      console.log('\n Opción no válida.\n');
      await esperar();
      await menu();
  }
}

async function verPisos() {
  console.clear();
  console.log(' Listado de pisos\n');
  try {
    const lista = await pb.collection('pisos').getList(1, 5);
    if (lista.items.length === 0) console.log('No hay pisos disponibles.');
    else {
      lista.items.forEach((p, i) =>
        console.log(`${i + 1}. ${p.titulo || '(Sin título)'} - ${p.direccion || 'Dirección desconocida'}`)
      );
    }
  } catch (err) {
    console.log(' Error al obtener pisos:', err.message);
  }
  await esperar();
  await menu();
}

async function crearComentario() {
  console.clear();
  console.log(' Crear nuevo comentario\n');
  try {
    const pisoId = await preguntar(' ID del piso: ');
    const usuario = await preguntar(' Nombre de usuario: ');
    const coment = await preguntar(' Comentario: ');

    const data = { piso: pisoId.trim(), usuario: usuario.trim(), coment: coment.trim() };
    const creado = await pb.collection('comentarios').create(data);

    console.log('\n Comentario creado correctamente:', creado.id);
  } catch (err) {
    console.log(' Error al crear comentario:', err.message);
  }
  await esperar();
  await menu();
}

async function verComentarios() {
  console.clear();
  console.log(' Comentarios recientes\n');
  try {
    const lista = await pb.collection('comentarios').getList(1, 5);
    if (lista.items.length === 0) console.log('No hay comentarios aún.');
    else {
      lista.items.forEach((c, i) =>
        console.log(`${i + 1}. [${c.usuario || 'Anónimo'}] → ${c.coment}`)
      );
    }
  } catch (err) {
    console.log(' Error al obtener comentarios:', err.message);
  }
  await esperar();
  await menu();
}

// Utilidades para entrada/salida
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function preguntar(pregunta) {
  return new Promise((resolve) => rl.question(pregunta, resolve));
}

function esperar() {
  return new Promise((resolve) => {
    rl.question('\nPresiona ENTER para continuar...', () => resolve());
  });
}

// Inicio del programa
(async () => {
  console.clear();
  console.log('Conectando con PocketBase...');
  try {
    await pb.health.check();
    console.log(' Conexión establecida.\n');
    await menu();
  } catch (err) {
    console.log(' No se pudo conectar a PocketBase:', err.message);
    rl.close();
  }
})();
