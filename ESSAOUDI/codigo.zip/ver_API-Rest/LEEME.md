## **MAHA ESSAOUDI Y SABRINE BENTALEB KHEYAR **

## el frontend esta en la carpeta vue-fontend y el backend en la carpeta hito2

en la base de datos tenemos datos ceados para :
    - cuenta admin: admin@adi.es            contraseña: adminadmin
    - cuenta inquilino: carmen@adi.com      contraseña: inquilino
    - cuenta propietario: hugo@adi.com      contraseña: hugohugo

- Edición de items: la tenemos implemantada en actualizar perfil , o actualizar un anuncio de piso, y tambien en la parte de admin el admin puede actualizar datos de una reserva por ejemplo 
- hacer click sobre la imagen del usuario en el header, redirigea el usuario a su perfil
- pra ver bien los comentarios , hemos añadido algunos en pisos , como el pisos con titulo 'piso en luceros' , o tambien en 'Vicienda de vacaciones '
- en la carpeta vur-frontend/src/images hemos dejado algunas fotos , por si usted quiere crear un piso , o usuarios 
## funcionalidades nuevas
- hemos implementado la busqueda y paginación de datos en la parte privada y pública del sitioweb, se puede encuentrar en la parte de Admin en (usuarios en admin por ejemplo), también en todos los admins Views se puede hacer búsqueda por texto y también filtrar( ejemplo:por role en la página usuarios de la parte admin)
- En cuanto al segundo punto pedido , el efecto "tiembla " está implementado también , por ejemplo , en la página de registrar , una vez que se introduzcan los datos de registrar y los campos se vayan validando , al final a la hora de darle al botón de registrar si el nombre de usuario con el que se van a registrar ya existe o el email ya existe "temblará" el botón registrar.
- hemos implementado un router para gestionar la navegacion de la app( se puede ver en index.js, y main.js).
- hemos implementado el listado incluyendo ver detalles (ver detalles de un piso en inquilinoPagina y propietarioPagina) y en muchos más casos, también en la parte de admin se puede ver los detalles de cualquier objeto, y tambien eleminar y editar ( en reservasAdmin por ejemplo).