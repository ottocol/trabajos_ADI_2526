<template>
  <footer class="site-footer">
    <p>&copy; 2025 rentEase. Todos los derechos reservados.</p>
    <p>Contacto | Política de privacidad</p>
  </footer>
</template>

<script setup>
/**
 * Footer reutilizable
 */
</script>

<style scoped>
.site-footer {
  background-color: #f1f1f1;
  color: #333;
  text-align: center;
  padding: 20px 0;
  font-size: 0.9rem;
  border-top: 1px solid #ccc;
}
</style>