<template>
  <header class="site-header">
    <div class="header-left">
      <slot name="left"><!-- default: empty --></slot>
    </div>

    <div class="header-center">
      <slot name="center">
        <router-link to="/" class="logo-link">
          <img :src="logoImg" alt="rentEase" class="logo-img" />
        </router-link>
      </slot>
    </div>

    <div class="header-right header-buttons">
      <slot name="right">
        <slot name="buttons">
          <!-- Botones por defecto -->
          <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
          <router-link to="/login" class="btn">Login</router-link>
          <router-link to="/registro" class="btn btn-primary">Registrar</router-link>
        </slot>
      </slot>
    </div>
  </header>
</template>

<script setup>
import logoImg from '@/images/rentEase_logo.jpg'
/**
 * Header reusable component. Accepts three named slots:
 *  - `left` : content to show on the left (e.g. user avatar)
 *  - `center`: content in the center (default is the logo)
 *  - `right`: right-side actions (falls back to `buttons` slot for compatibility)
 */
</script>

<style scoped>
.site-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.5rem 1rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
}

.header-left, .header-center, .header-right {
  display: flex;
  align-items: center;
}

.header-left { flex: 0 0 60px }
.header-center { flex: 1; justify-content: center }
.header-right { flex: 0 0 auto }

.user-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #eee;
}

/* small avatar variant for header (used by views) */
.user-avatar-small {
  width: 70px;
  height: 70px;
  border-radius: 50%;
  object-fit: cover;
  border: 1px solid #eee;
}

.logo-img { height: 56px; object-fit: contain }

.header-buttons .btn { margin-left: 0.75rem }

.header-buttons .btn {
  margin-left: 0.75rem;
  padding: 0.4rem 0.9rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover { background-color: #0056b3; color: white }

/* Danger button styling for header (logout) */
.header-buttons .btn-danger {
  background: #e53935;
  color: #fff;
  border: none;
}
.header-buttons .btn-danger:hover { background: #d32f2f; }
.header-buttons .btn-danger[disabled] { opacity: 0.6 }
</style>