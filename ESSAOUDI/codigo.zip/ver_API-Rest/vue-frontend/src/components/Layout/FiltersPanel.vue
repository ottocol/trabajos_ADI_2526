<template>
  <aside class="filters-panel">
    <h2>Filtros</h2>
    <form @submit.prevent="aplicarFiltros" class="filters-form">
      <div class="filter-group">
        <label for="ciudad">Ciudad</label>
        <input 
          v-model="filtrosLocales.ciudad" 
          type="text" 
          id="ciudad" 
          placeholder="Ej: Madrid"
        >
      </div>
      
      <div class="filter-group">
        <label for="precio-min">Precio mínimo (€)</label>
        <input 
          v-model="filtrosLocales.precioMin" 
          type="number" 
          id="precio-min" 
          placeholder="50"
        >
      </div>
      
      <div class="filter-group">
        <label for="precio-max">Precio máximo (€)</label>
        <input 
          v-model="filtrosLocales.precioMax" 
          type="number" 
          id="precio-max" 
          placeholder="500"
        >
      </div>
      
      <div class="filter-group">
        <label for="habitaciones">Mín. habitaciones</label>
        <input 
          v-model="filtrosLocales.habitaciones" 
          type="number" 
          id="habitaciones" 
          placeholder="1" 
          min="1"
        >
      </div>
      
      <div class="filter-buttons">
        <button type="submit" class="btn btn-primary">Buscar</button>
        <button type="button" @click="limpiarFiltros" class="btn btn-secondary">Limpiar Filtros</button>
      </div>
    </form>
  </aside>
</template>

<script setup>
import { inject, reactive } from 'vue'

const onFiltrosChange = inject('onFiltrosChange')

const filtrosLocales = reactive({
  ciudad: '',
  precioMin: '',
  precioMax: '',
  habitaciones: ''
})

// ⚠️ CORREGIDO: Solo aplica filtros al hacer submit
const aplicarFiltros = () => {
  console.log('🎯 Aplicando filtros (botón Buscar):', filtrosLocales)
  if (onFiltrosChange) {
    onFiltrosChange({ ...filtrosLocales })
  }
}

// ⚠️ CORREGIDO: Función para limpiar filtros
const limpiarFiltros = () => {
  Object.assign(filtrosLocales, {
    ciudad: '',
    precioMin: '',
    precioMax: '',
    habitaciones: ''
  })
  // Aplicar inmediatamente al limpiar
  if (onFiltrosChange) {
    onFiltrosChange({ ...filtrosLocales })
  }
}
</script>

<style scoped>
.filters-panel {
  background: white;
  border: 1px solid #ddd;
  border-radius: 12px;
  padding: 1.5rem;
  height: fit-content;
  box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
  position: sticky;
  top: 20px; /* Se queda fijo al hacer scroll */
}

.filters-panel h2 {
  margin-top: 0;
  margin-bottom: 1rem;
  font-size: 1.2rem;
  color: #333;
}

.filters-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.filter-group {
  display: flex;
  flex-direction: column;
}

.filter-group label {
  font-size: 0.85rem;
  margin-bottom: 0.3rem;
  color: #555;
  font-weight: 500;
}

.filter-group input,
.filter-group select {
  padding: 0.6rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 0.9rem;
  transition: border-color 0.3s;
}

.filter-group input:focus,
.filter-group select:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25);
}

.filter-buttons {
  display: flex;
  gap: 0.5rem;
  flex-direction: column;
  margin-top: 0.5rem;
}

.btn {
  padding: 0.7rem;
  border: none;
  border-radius: 6px;
  font-weight: bold;
  cursor: pointer;
  text-align: center;
  transition: all 0.3s;
  font-size: 0.9rem;
}

.btn-primary {
  background-color: #007bff;
  color: white;
}

.btn-secondary {
  background-color: #6c757d;
  color: white;
}

.btn:hover {
  opacity: 0.9;
  transform: translateY(-1px);
}

.btn:active {
  transform: translateY(0);
}
</style>