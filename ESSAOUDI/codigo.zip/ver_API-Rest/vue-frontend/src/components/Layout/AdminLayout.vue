<template>
  <div class="admin-view">
    <AppHeader>
      <template #left>
        <router-link to="/admin/perfil">
          <img :src="avatarSrc" alt="avatar" class="user-avatar-small" />
        </router-link>
      </template>

      <template #right>
        <router-link to="/admin/perfil" class="btn">Perfil</router-link>
        <button class="btn btn-danger" @click="handleLogout" :disabled="loggingOut">Desconectar</button>
      </template>
    </AppHeader>

    <div class="admin-layout">
      <aside class="admin-sidebar">
        <div class="brand">rentEase</div>
        <nav class="side-nav">
          <router-link to="/admin" class="nav-item" exact>Dashboard</router-link>
          <router-link to="/admin/users" class="nav-item">Usuarios</router-link>
          <router-link to="/admin/pisos" class="nav-item">Pisos</router-link>
          <router-link to="/admin/reservas" class="nav-item">Reservaciones</router-link>
          <router-link to="/admin/comentarios" class="nav-item">Comentarios</router-link>
        </nav>
      </aside>

      <main class="admin-main">
        <slot />
      </main>
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import randomAvatar from '@/images/users/random.png'

const loggingOut = ref(false)
const avatarSrc = ref(randomAvatar)

function loadAvatar() {
  try {
    const raw = localStorage.getItem('currentUser')
    if (!raw) return
    const u = JSON.parse(raw)
    if (u.avatarUrl) { avatarSrc.value = u.avatarUrl; return }
    if (u.image) {
      if (Array.isArray(u.image) && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image[0]}`
        return
      }
      if (typeof u.image === 'string' && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image}`
        return
      }
    }
    const userId = u.id || localStorage.getItem('userId')
    if (!userId) return
    fetch(`/api/perfil/${userId}`).then(r => r.json()).then(json => {
      if (json && json.image && Array.isArray(json.image) && json.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${json.id}/${json.image[0]}`
        try { localStorage.setItem('currentUser', JSON.stringify(json)) } catch (e) {}
      }
    }).catch(() => {})
  } catch (e) {}
}

const handleLogout = async () => {
  loggingOut.value = true
  try { await fetch('/api/auth/logout', { method: 'POST' }) } catch (e) { console.error('Logout failed', e) }
  try { localStorage.removeItem('currentUser') } catch (e) {}
  try { localStorage.removeItem('pb_token') } catch (e) {}
  try { localStorage.removeItem('userId') } catch (e) {}
  try { localStorage.removeItem('userRole') } catch (e) {}
  loggingOut.value = false
  // navigate to home
  window.location.href = '/'
}

onMounted(() => { loadAvatar(); window.addEventListener('storage', loadAvatar) })
</script>

<style scoped>
.admin-layout { display: flex; min-height: calc(100vh - 120px) }
.admin-sidebar { width: 220px; background: #0b57b7; color: white; padding: 18px 12px; box-sizing: border-box }
.admin-sidebar .brand { font-weight: 700; font-size: 1.2rem; margin-bottom: 18px }
.side-nav .nav-item { display:block; color: rgba(255,255,255,0.9); padding: 8px 10px; border-radius:4px; margin-bottom:6px }
.side-nav .nav-item.router-link-active { background: rgba(255,255,255,0.08) }
.admin-main { flex: 1; background: #f6f8fb; padding: 22px }
.user-avatar-small { width: 50px !important; height: 50px !important; border-radius: 50%; object-fit: cover }
</style>
