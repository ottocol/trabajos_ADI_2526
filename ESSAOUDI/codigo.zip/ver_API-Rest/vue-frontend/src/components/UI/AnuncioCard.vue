<!-- Para los anuncios-->
<template>
  <div class="anuncio-card">
    <img :src="piso.imagen" :alt="piso.titulo" class="anuncio-img">
    <div class="anuncio-info">
      <h3>{{ piso.titulo }}</h3>
      <p><strong>Tipo:</strong> {{ piso.tipo }}</p>
      <p><strong>Dirección:</strong> {{ piso.direccion }}</p>
      <p class="precio">{{ piso.precio }} € / noche</p>
      <router-link :to="`/piso-detalle/${piso.id}`" class="btn-ver-detalle">Ver Detalles</router-link>
    </div>
  </div>
</template>

<script setup>
defineProps({
  piso: {
    type: Object,
    required: true
  }
})
</script>

<style scoped>
.anuncio-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
}

.anuncio-img {
  width: 100%;
  height: 180px;
  object-fit: cover;
}

.anuncio-info {
  padding: 1rem;
}

.anuncio-info h3 {
  margin: 0 0 0.5rem;
  color: #333;
}

.precio {
  color: #e63946;
  font-weight: bold;
  margin: 0.5rem 0;
}

.btn-ver-detalle {
  display: block;
  padding: 0.6rem;
  background: #007bff;
  color: white;
  text-decoration: none;
  border-radius: 8px;
  text-align: center;
  margin-top: 0.8rem;
}
</style>