<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script setup>
// Este componente es el contenedor principal de la aplicación
// Router-view renderiza las vistas según la ruta actual
</script>

<style>
/* Estilos globales */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: Arial, sans-serif;
  background-color: #f8f9fa;
  line-height: 1.6;
}

#app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}
</style>