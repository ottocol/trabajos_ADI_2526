<template>
  <div class="login-view">
    <AppHeader>
      <template #buttons>
        <router-link to="/mis-reservas" class="btn btn-primary">Mis Reservas</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <router-link to="/registro" class="btn">Registrar</router-link>
      </template>
    </AppHeader>

    <div class="login-container">
      <h2 class="login-title">Iniciar sesión</h2>
      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label for="email">Correo electrónico</label>
          <input v-model="form.email" type="email" id="email" placeholder="tuemail@ejemplo.com" required>
        </div>

        <div class="form-group">
          <label for="password">Contraseña</label>
          <input v-model="form.password" type="password" id="password" placeholder="********" required>
        </div>

        <button type="submit" class="login-button" :disabled="loading">{{ loading ? 'Entrando...' : 'Entrar' }}</button>
      </form>
      <div v-if="error" class="error">{{ error }}</div>

      <div class="login-footer">
        <p>¿No tienes cuenta? <router-link to="/registro">Regístrate aquí</router-link></p>
      </div>
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const form = reactive({
  email: '',
  password: ''
})

const loading = ref(false)
const error = ref(null)

const handleLogin = async () => {
  error.value = null
  loading.value = true
  console.log('handleLogin called', form.email)
  try {
    // Llamada al backend
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: form.email, password: form.password })
    })

    // Obtener body de la respuesta
    const body = await res.json().catch(() => null)
    console.log('login response status', res.status, body)
    if (!res.ok) {
      error.value = (body && (body.error || body.message)) || 'Error al iniciar sesión'
      return
    }

    // Login successful. Determine role, token and redirect accordingly.
    const user = (body && (body.record || body.model || body.user || body.data)) || body || null;
    // PocketBase typically returns a token alongside the record. Try to extract it from various shapes.
    const token = body && (body.token || body?.data?.token || body?.auth?.token || body?.record?.token || body?.accessToken || body?.access_token) || null;
    const role = (user && (user.rol || user.role)) ? String(user.rol || user.role).toLowerCase() : null;

    // persist token and user info for other views that need authentication
    try {
      if (token) localStorage.setItem('pb_token', token)
    } catch (e) {}
    try { localStorage.setItem('currentUser', JSON.stringify(user)) } catch (e) {}
    try { if (user && user.id) localStorage.setItem('userId', user.id) } catch (e) {}
    try { if (user && (user.rol || user.role)) localStorage.setItem('userRole', String(user.rol || user.role)) } catch (e) {}

    if (role === 'propietario') {
      router.push({ name: 'propietario' })
    } else if (role === 'inquilino') {
      router.push({ name: 'inquilino' })
    } else if (role === 'admin') {
      router.push({ name: 'admin' })
    } else {
      // default
      router.push({ name: 'home' })
    }
  } catch (err) {
    console.error('Login failed', err)
    error.value = err.message || 'Error de red'
  } finally {
    loading.value = false
  }
}

</script>

<style scoped>
.error { color: #b00020; margin-top: 0.75rem }
.login-button[disabled] { opacity: 0.7 }
</style>