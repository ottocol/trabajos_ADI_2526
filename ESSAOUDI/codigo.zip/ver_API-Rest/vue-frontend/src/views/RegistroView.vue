<template>
  <div class="registro-view">
    <AppHeader>
      <template #buttons>
        <router-link to="/mis-reservas" class="btn btn-primary">Mis Reservas</router-link>
        <router-link to="/login" class="btn">Login</router-link>
        <router-link to="/registro" class="btn">Registrar</router-link>
      </template>
    </AppHeader>

    <div class="login-container">
      <h2 class="login-title">Crea tu cuenta</h2>
      
      <form 
        @submit.prevent="handleRegistro" 
        class="registro-form"
        :class="{ 'shake': showShake }"
      >
        <div class="form-group">
          <label for="nombre">Nombre</label>
          <input 
            v-model="form.nombre" 
            type="text" 
            id="nombre" 
            placeholder="Ej: María" 
            required
            @blur="validarCampo('nombre')"
            :class="{ 'error-input': errores.nombre }"
          >
          <transition name="fade">
            <span v-if="errores.nombre" class="error-message">{{ errores.nombre }}</span>
          </transition>
          <small class="help-text">Solo letras y espacios (2-50 caracteres)</small>
        </div>

        <div class="form-group">
          <label for="username">Nombre de usuario</label>
          <input 
            v-model="form.username" 
            type="text" 
            id="username" 
            placeholder="Ej: maria123" 
            required
            @blur="validarCampo('username')"
            :class="{ 'error-input': errores.username }"
          >
          <transition name="fade">
            <span v-if="errores.username" class="error-message">{{ errores.username }}</span>
          </transition>
          <small class="help-text">Letras, números y _ (3-20 caracteres)</small>
        </div>

        <div class="form-group">
          <label for="apellidos">Apellidos</label>
          <input 
            v-model="form.apellidos" 
            type="text" 
            id="apellidos" 
            placeholder="Ej: García López" 
            required
            @blur="validarCampo('apellidos')"
            :class="{ 'error-input': errores.apellidos }"
          >
          <transition name="fade">
            <span v-if="errores.apellidos" class="error-message">{{ errores.apellidos }}</span>
          </transition>
          <small class="help-text">Solo letras y espacios (2-100 caracteres)</small>
        </div>

        <div class="form-group">
          <label for="email">Correo electrónico</label>
          <input 
            v-model="form.email" 
            type="email" 
            id="email" 
            placeholder="Ej: maria@ejemplo.com" 
            required
            @blur="validarCampo('email')"
            :class="{ 'error-input': errores.email }"
          >
          <transition name="fade">
            <span v-if="errores.email" class="error-message">{{ errores.email }}</span>
          </transition>
          <small class="help-text">Debe ser un email válido</small>
        </div>

        <div class="form-group">
          <label for="password">Contraseña</label>
          <input 
            v-model="form.password" 
            type="password" 
            id="password" 
            placeholder="Mínimo 6 caracteres" 
            required
            @blur="validarCampo('password')"
            :class="{ 'error-input': errores.password }"
          >
          <transition name="fade">
            <span v-if="errores.password" class="error-message">{{ errores.password }}</span>
          </transition>
          <small class="help-text">Mínimo 8 caracteres</small>
        </div>

        <div class="form-group">
          <label for="confirm-password">Confirmar contraseña</label>
          <input 
            v-model="form.confirmPassword" 
            type="password" 
            id="confirm-password" 
            placeholder="Repite tu contraseña" 
            required
            @blur="validarConfirmPassword()"
            :class="{ 'error-input': errores.confirmPassword }"
          >
          <transition name="fade">
            <span v-if="errores.confirmPassword" class="error-message">{{ errores.confirmPassword }}</span>
          </transition>
        </div>

        <div class="form-group">
          <label for="tel">Teléfono</label>
          <input 
            v-model="form.tel" 
            type="tel" 
            id="tel" 
            placeholder="Ej: +34 612345678"
            @blur="validarCampo('tel')"
            :class="{ 'error-input': errores.tel }"
          >
          <transition name="fade">
            <span v-if="errores.tel" class="error-message">{{ errores.tel }}</span>
          </transition>
          <small class="help-text">Opcional - Formato internacional</small>
        </div>

        <div class="form-group">
          <label for="rol">Registrarme como</label>
          <select 
            v-model="form.rol" 
            id="rol" 
            required
            @blur="validarCampo('rol')"
            :class="{ 'error-input': errores.rol }"
          >
            <option value="">-- Selecciona una opcion --</option>
            <option value="inquilino">Inquilino</option>
            <option value="propietario">Propietario</option>
          </select>
          <transition name="fade">
            <span v-if="errores.rol" class="error-message">{{ errores.rol }}</span>
          </transition>
        </div>

        <div class="form-group">
          <label for="image">Foto de perfil (opcional)</label>
          <input 
            id="image" 
            type="file" 
            accept="image/*" 
            @change="onFileChange"
            :class="{ 'error-input': errores.image }"
          >
          <transition name="fade">
            <span v-if="errores.image" class="error-message">{{ errores.image }}</span>
          </transition>
          <small class="help-text">Formatos: JPG, PNG, GIF. Máximo 3MB</small>
        </div>

        <button 
          type="submit" 
          class="login-button"
          :class="{ 'pulse': formValido && !submitting, 'loading': submitting }"
          :disabled="submitting || !formValido"
        >
          <transition name="fade" mode="out-in">
            <span :key="submitting">
              {{ submitting ? 'Creando cuenta...' : 'Registrarse' }}
            </span>
          </transition>
        </button>
      </form>

      <transition name="slide-fade">
        <div v-if="error" class="login-footer error-container">
          <div class="error-message global-error">
            <strong>❌ Error al registrarse</strong>
            <p>{{ error }}</p>
          </div>
          
          <transition-group name="fade-list" tag="div" v-if="fieldErrors.length > 0">
            <div key="field-errors" class="field-errors">
              <strong>Problemas encontrados:</strong>
              <ul>
                <li v-for="fieldError in fieldErrors" :key="fieldError.field">
                  <strong>{{ fieldError.label }}:</strong> {{ fieldError.message }}
                </li>
              </ul>
            </div>
          </transition-group>
        </div>
      </transition>

      <div class="login-footer" v-if="!error">
        <p>¿Ya tienes cuenta? <router-link to="/login">Inicia sesión aquí</router-link></p>
      </div>
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import { reactive, ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'

const router = useRouter()

const form = reactive({
  username: '',
  nombre: '',
  apellidos: '',
  email: '',
  password: '',
  confirmPassword: '',
  tel: '',
  rol: ''
})

const errores = reactive({
  nombre: '',
  username: '',
  apellidos: '',
  email: '',
  password: '',
  confirmPassword: '',
  tel: '',
  rol: '',
  image: ''
})

const submitting = ref(false)
const error = ref('')
const details = ref(null)
const imageFile = ref(null)
const showShake = ref(false)

// Configuración de validaciones
const validaciones = {
  nombre: {
    regex: /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{2,50}$/,
    mensaje: 'Solo letras y espacios (2-50 caracteres)',
    requerido: true
  },
  username: {
    regex: /^[a-zA-Z0-9_]{3,20}$/,
    mensaje: 'Solo letras, números y _ (3-20 caracteres)',
    requerido: true
  },
  apellidos: {
    regex: /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{2,100}$/,
    mensaje: 'Solo letras y espacios (2-100 caracteres)',
    requerido: true
  },
  email: {
    regex: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    mensaje: 'Formato de email inválido',
    requerido: true
  },
  password: {
    min: 6,
    mensaje: 'Mínimo 6 caracteres',
    requerido: true
  },
  tel: {
    regex: /^[\+]?[0-9\s\-\(\)]{0,20}$/,
    mensaje: 'Formato de teléfono inválido',
    requerido: false
  },
  rol: {
    regex: /^(inquilino|propietario)$/,
    mensaje: 'Selecciona un tipo de usuario',
    requerido: true
  }
}

// Computed properties
const formValido = computed(() => {
  return Object.keys(validaciones).every(field => 
    !validaciones[field].requerido || (form[field] && !errores[field])
  ) && !errores.confirmPassword
})

const fieldErrors = computed(() => {
  if (!details.value) return []
  
  const errors = []
  const fieldLabels = {
    username: 'Nombre de usuario',
    email: 'Correo electrónico',
    password: 'Contraseña',
    passwordConfirm: 'Confirmar contraseña',
    nombre: 'Nombre',
    apellidos: 'Apellidos',
    tel: 'Teléfono',
    rol: 'Tipo de usuario',
    role: 'Tipo de usuario'
  }
  
  for (const [field, errorData] of Object.entries(details.value)) {
    if (Array.isArray(errorData)) {
      errorData.forEach(message => {
        errors.push({
          field,
          label: fieldLabels[field] || field,
          message: traducirError(field, message)
        })
      })
    }
  }
  
  return errors
})

// Animación shake
const triggerShake = () => {
  showShake.value = true
  setTimeout(() => {
    showShake.value = false
  }, 500)
}

// Validaciones
const validarCampo = (campo) => {
  const valor = form[campo]
  const config = validaciones[campo]
  
  if (config.requerido && !valor) {
    errores[campo] = 'Este campo es obligatorio'
    return false
  }
  
  if (!config.requerido && !valor) {
    errores[campo] = ''
    return true
  }
  
  if (config.regex && !config.regex.test(valor)) {
    errores[campo] = config.mensaje
    return false
  }
  
  if (config.min && valor.length < config.min) {
    errores[campo] = config.mensaje
    return false
  }
  
  errores[campo] = ''
  return true
}

const validarConfirmPassword = () => {
  if (!form.confirmPassword) {
    errores.confirmPassword = 'Confirma tu contraseña'
    return false
  }
  
  if (form.password !== form.confirmPassword) {
    errores.confirmPassword = 'Las contraseñas no coinciden'
    return false
  }
  
  errores.confirmPassword = ''
  return true
}

// Traducción de errores de PocketBase
const traducirError = (field, message) => {
  const lowerMessage = message.toLowerCase()
  
  // Errores de formato
  if (lowerMessage.includes('format') || lowerMessage.includes('formato')) {
    return validaciones[field]?.mensaje || 'Formato incorrecto'
  }
  
  // Errores de longitud
  if (lowerMessage.includes('short') || lowerMessage.includes('corto')) {
    return validaciones[field]?.mensaje || 'Muy corto'
  }
  
  if (lowerMessage.includes('long') || lowerMessage.includes('largo')) {
    return validaciones[field]?.mensaje || 'Muy largo'
  }
  
  // Errores de unicidad
  if (lowerMessage.includes('unique') || lowerMessage.includes('duplicado')) {
    if (field === 'email') return 'Este email ya está registrado'
    if (field === 'username') return 'Este usuario ya existe'
    return 'Este valor ya está en uso'
  }
  
  // Errores de requerido
  if (lowerMessage.includes('required') || lowerMessage.includes('faltante')) {
    return 'Este campo es obligatorio'
  }
  
  return message
}

function onFileChange(e) {
  const f = e.target.files && e.target.files[0]
  if (f) {
    if (!f.type.startsWith('image/')) {
      errores.image = 'Solo se permiten imágenes (JPG, PNG, GIF)'
      imageFile.value = null
      e.target.value = ''
      return
    }
    if (f.size > 3 * 1024 * 1024) {
      errores.image = 'La imagen no puede superar 3MB'
      imageFile.value = null
      e.target.value = ''
      return
    }
    errores.image = ''
  }
  imageFile.value = f || null
}

async function handleRegistro() {
  error.value = ''
  details.value = null

  // Validar todos los campos
  const camposValidos = Object.keys(validaciones).every(validarCampo)
  const confirmacionValida = validarConfirmPassword()
  
  if (!camposValidos || !confirmacionValida) {
    error.value = 'Por favor, corrige los errores en el formulario'
    triggerShake()
    return
  }

  submitting.value = true
  try {
    let res, data

    if (imageFile.value) {
      const formData = new FormData()
      formData.append('username', form.username)
      formData.append('email', form.email)
      formData.append('password', form.password)
      formData.append('passwordConfirm', form.confirmPassword)
      formData.append('nombre', form.nombre)
      formData.append('apellidos', form.apellidos)
      formData.append('tel', form.tel)
      formData.append('role', form.rol)
      formData.append('image', imageFile.value)

      res = await fetch('/api/auth/register', {
        method: 'POST',
        body: formData
      })
    } else {
      const payload = {
        username: form.username,
        email: form.email,
        password: form.password,
        passwordConfirm: form.confirmPassword,
        nombre: form.nombre,
        apellidos: form.apellidos,
        tel: form.tel,
        role: form.rol
      }
      res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
    }

    data = await res.json()
    
    if (!res.ok) {
      error.value = 'Error al crear la cuenta. Verifica los datos.'
      details.value = normalizeDetails(data?.details || data)
      triggerShake()
      return
    }

    // Registro exitoso
    router.push({ 
      name: 'login', 
      query: { registro: 'exitoso' } 
    })
    
  } catch (err) {
    console.error('Registro error', err)
    error.value = 'Error de conexión. Intenta nuevamente.'
    triggerShake()
  } finally {
    submitting.value = false
  }
}

function normalizeDetails(raw) {
  if (!raw) return null
  
  let d = raw
  for (let i = 0; i < 3; i++) {
    if (d && d.data && (typeof d.data === 'object')) {
      d = d.data
      continue
    }
    if (d && d.details && (typeof d.details === 'object')) {
      d = d.details
      continue
    }
    break
  }
  
  if (typeof d !== 'object') return { general: [String(d)] }

  const out = {}
  for (const [key, val] of Object.entries(d)) {
    if (Array.isArray(val)) {
      out[key] = val.map(v => String(v))
    } else if (val && typeof val === 'object') {
      if (val.message) {
        out[key] = [val.message]
      } else {
        const sub = Object.values(val).map(v => String(v)).filter(Boolean)
        out[key] = sub.length ? sub : ['Error de validación']
      }
    } else {
      out[key] = [String(val)]
    }
  }
  return out
}
</script>

<style scoped>
/* Animaciones CSS */
.registro-form {
  transition: all 0.3s ease;
}

.shake {
  animation: shake 0.5s ease-in-out;
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
  20%, 40%, 60%, 80% { transform: translateX(5px); }
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.slide-fade-enter-active {
  transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
  transition: all 0.3s cubic-bezier(1, 0.5, 0.8, 1);
}

.slide-fade-enter-from {
  transform: translateY(-10px);
  opacity: 0;
}

.slide-fade-leave-to {
  transform: translateY(10px);
  opacity: 0;
}

.fade-list-enter-active,
.fade-list-leave-active {
  transition: all 0.3s ease;
}

.fade-list-enter-from,
.fade-list-leave-to {
  opacity: 0;
  transform: translateX(-10px);
}

.pulse {
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0% {
    box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.4);
  }
  70% {
    box-shadow: 0 0 0 10px rgba(0, 123, 255, 0);
  }
  100% {
    box-shadow: 0 0 0 0 rgba(0, 123, 255, 0);
  }
}

/* Estilos mejorados */
.login-button.loading {
  background-color: #6c757d;
  cursor: wait;
  transform: scale(0.98);
}

.login-button {
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.login-button:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
}

.login-button:disabled {
  cursor: not-allowed;
  transform: none;
}

/* Estilos de formulario */
.form-group {
  margin-bottom: 1.5rem;
  position: relative;
}

label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: bold;
  color: #333;
}

input, select {
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #ddd;
  border-radius: 4px;
  transition: all 0.3s ease;
  font-size: 1rem;
}

input:focus, select:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.1);
}

.error-input {
  border-color: #dc3545 !important;
  background-color: #f8d7da;
}

.help-text {
  display: block;
  margin-top: 0.25rem;
  font-size: 0.875rem;
  color: #666;
}

.error-message {
  display: block;
  margin-top: 0.25rem;
  color: #dc3545;
  font-size: 0.875rem;
  font-weight: 500;
}

/* Mensajes de error globales */
.global-error {
  background: #ffeaea;
  border: 1px solid #f5c6cb;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
  text-align: left;
}

.global-error strong {
  color: #b00020;
}

.field-errors {
  background: #fff3cd;
  border: 1px solid #ffeaa7;
  border-radius: 8px;
  padding: 1rem;
  margin: 1rem 0;
  text-align: left;
}

.field-errors ul {
  margin: 0.5rem 0 0 0;
  padding-left: 1.5rem;
}

.field-errors li {
  margin-bottom: 0.5rem;
  color: #856404;
}

/* Estilos base */
.login-container {
  max-width: 500px;
  margin: 2rem auto;
  padding: 2rem;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.login-title {
  text-align: center;
  margin-bottom: 2rem;
  color: #333;
  font-size: 2rem;
}

.login-button {
  width: 100%;
  padding: 0.75rem;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
}

.login-footer {
  text-align: center;
  margin-top: 2rem;
}
</style>