<template>
  <div class="perfil-view">
    <!-- Header integrado -->
    <header class="site-header">
      <div class="logo">
        <img :src="logoImg" alt="Logo rentEase">
      </div>
      <div class="header-buttons">
        <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <div class="profile-container">
      <h2 class="profile-title">Mi Perfil</h2>

      <!-- User Avatar -->
      <div class="profile-avatar-container">
        <img :src="avatarSrc" alt="Avatar del usuario" class="profile-avatar" />
      </div>

      <!-- Estados de carga - IGUAL QUE HOME -->
      <div v-if="loading" class="loading-state">
        <p>Cargando datos del perfil...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
      </div>

      <!-- Datos del perfil - DINÁMICOS -->
      <template v-else>
        <div class="profile-group">
          <span class="profile-label">Nombre</span>
          <div class="profile-value">{{ perfil.nombre || 'No especificado' }}</div>
        </div>
        
        <div class="profile-group">
          <span class="profile-label">Apellidos</span>
          <div class="profile-value">{{ perfil.apellidos || 'No especificado' }}</div>
        </div>
        
        <div class="profile-group">
          <span class="profile-label">Email</span>
          <div class="profile-value">{{ perfil.email || 'No especificado' }}</div>
        </div>
        
        <div class="profile-group">
          <span class="profile-label">Teléfono</span>
          <div class="profile-value">{{ perfil.telefono || 'No especificado' }}</div>
        </div>
        
        <div class="profile-group">
          <span class="profile-label">Rol</span>
          <div class="profile-value">{{ getRolTexto(perfil.rol) }}</div>
        </div>

        <!-- Información adicional si está disponible -->
        <div class="profile-group" v-if="perfil.fechaRegistro">
          <span class="profile-label">Fecha de registro</span>
          <div class="profile-value">{{ formatFecha(perfil.fechaRegistro) }}</div>
        </div>

        <div class="profile-actions">
          <router-link to="/editar-perfil" class="btn-edit">Editar Perfil</router-link>
          <router-link :to="getRutaInicio()" class="btn-back">Volver al Inicio</router-link>
        </div>

        <div class="danger-zone">
          <p class="danger-warning">Esta acción no se puede deshacer. Se eliminará tu cuenta y todos tus datos permanentemente.</p>
          <button @click="confirmarEliminarCuenta" class="btn-danger" :disabled="eliminando">
            {{ eliminando ? 'Eliminando...' : 'Eliminar Mi Cuenta' }}
          </button>
        </div>
      </template>
    </div>

    <!-- Footer integrado -->
    <footer class="site-footer">
      <p>&copy; 2025 rentEase. Todos los derechos reservados.</p>
      <p>Contacto | Política de privacidad</p>
    </footer>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import logoImg from '@/images/rentEase_logo.jpg'
import randomAvatar from '@/images/users/random.png'

const router = useRouter()
const perfil = reactive({})
const loading = ref(false)
const error = ref('')
const avatarSrc = ref(randomAvatar)

// Formatear fecha
const formatFecha = (fecha) => {
  if (!fecha) return ''
  return new Date(fecha).toLocaleDateString('es-ES')
}

// Obtener texto del rol
const getRolTexto = (rol) => {
  const roles = {
    'inquilino': 'Inquilino',
    'propietario': 'Propietario',
    'admin': 'Administrador'
  }
  return roles[rol] || rol || 'No especificado'
}
// Obtener la ruta de inicio según el rol (prioriza localStorage.userRole)
const getRutaInicio = () => {
  try {
    let rol = (localStorage.getItem('userRole') || '').toString().toLowerCase()
    if (!rol) {
      const raw = localStorage.getItem('currentUser')
      if (raw) {
        const u = JSON.parse(raw)
        rol = (u.rol || u.role || '').toString().toLowerCase()
      }
    }

    // fallback to loaded perfil.rol
    if (!rol && perfil && perfil.rol) rol = String(perfil.rol).toLowerCase()

    if (rol === 'inquilino' || rol === 'tenant') return { name: 'inquilino' }
    if (rol === 'propietario' || rol === 'owner') return { name: 'propietario' }
    if (rol === 'admin' || rol === 'administrator') return { name: 'admin' }
  } catch (e) {
    // ignore and fallback
  }

  return { name: 'home' }
}


const eliminando = ref(false)

// Función para eliminar la cuenta
const eliminarCuenta = async () => {
  eliminando.value = true
  try {
    const userId = localStorage.getItem('userId')
    const token = localStorage.getItem('pb_token')
    
    if (!userId || !token) {
      throw new Error('No autenticado')
    }

    console.log(' Eliminando cuenta...', userId)

    const res = await fetch('http://localhost:3000/api/users/me/delete-account', {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token
      }
    })

    if (!res.ok) {
      const errorData = await res.json().catch(() => null)
      throw new Error(errorData?.error || `Error ${res.status}`)
    }

    const result = await res.json()
    console.log('✅ Cuenta eliminada:', result)

    // Limpiar localStorage y redirigir
    localStorage.removeItem('userId')
    localStorage.removeItem('currentUser')
    localStorage.removeItem('userRole')
    localStorage.removeItem('pb_token')
    
    router.push('/')
    
  } catch (err) {
    console.error('❌ Error eliminando cuenta:', err)
    error.value = 'Error al eliminar la cuenta: ' + err.message
  } finally {
    eliminando.value = false
  }
}

// Función de confirmación
const confirmarEliminarCuenta = () => {
  if (confirm('¿Estás SEGURO de que quieres eliminar tu cuenta? Esta acción es permanente y no se puede deshacer. Todos tus datos se perderán.')) {
    if (confirm(' ÚLTIMA OPORTUNIDAD: ¿Realmente quieres eliminar tu cuenta permanentemente?')) {
      eliminarCuenta()
    }
  }
}


// Cargar perfil - MISMA ESTRUCTURA QUE HOME
const cargarPerfil = async () => {
  loading.value = true
  try {
    let userId = localStorage.getItem('userId')
    
    // Si no está en userId, buscar en currentUser
    if (!userId) {
      const currentUser = localStorage.getItem('currentUser')
      if (currentUser) {
        const userData = JSON.parse(currentUser)
        userId = userData.id
        console.log('👤 UserId obtenido de currentUser:', userId)
      }
    }

    if (!userId) {
      throw new Error('Usuario no identificado - Inicia sesión nuevamente')
    }

    const res = await fetch(`http://localhost:3000/api/users/${userId}`)
    
    if (!res.ok) {
      throw new Error(`Error ${res.status}: ${res.statusText}`)
    }

    const userData = await res.json()

    Object.assign(perfil, {
      id: userData.id,
      nombre: userData.nombre || 'No especificado',
      apellidos: userData.apellidos || 'No especificado',
      email: userData.email || 'No especificado',
      telefono: userData.tel || 'No especificado', 
      rol: userData.rol || 'inquilino',
      fechaRegistro: userData.created, 
      username: userData.username || '',
      image: userData.image || ''
    })

    
  } catch (err) {
    error.value = 'Error al cargar los datos del perfil. Intenta nuevamente.'
    
    try {
      const currentUser = localStorage.getItem('currentUser')
      if (currentUser) {
        const userData = JSON.parse(currentUser)
        
        Object.assign(perfil, {
          nombre: userData.nombre || 'Usuario',
          apellidos: userData.apellidos || 'Apellidos',
          email: userData.email || 'usuario@ejemplo.com',
          telefono: userData.tel || '+34 600 000 000',
          rol: userData.rol || 'inquilino',
          fechaRegistro: userData.created || new Date().toISOString()
        })
        error.value = '' // Limpiar error si conseguimos datos
      } else {
        throw new Error('No hay datos de usuario disponibles')
      }
    } catch (fallbackError) {
      // Mantener el error original
    }
  }
  loading.value = false
}

// Load user avatar
function loadAvatar() {
  try {
    const raw = localStorage.getItem('currentUser')
    if (!raw) return
    const u = JSON.parse(raw)
    if (u.avatarUrl) {
      avatarSrc.value = u.avatarUrl
      return
    }

    if (u.image) {
      if (Array.isArray(u.image) && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image[0]}`
        return
      }
      if (typeof u.image === 'string' && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image}`
        return
      }
    }

    try {
      const userId = u.id || localStorage.getItem('userId')
      if (!userId) return
      fetch(`/api/perfil/${userId}`).then(r => r.json()).then(json => {
        if (json && json.image && Array.isArray(json.image) && json.image.length > 0) {
          avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${json.id}/${json.image[0]}`
          try { localStorage.setItem('currentUser', JSON.stringify(json)) } catch (e) {}
        }
      }).catch(() => {})
    } catch (e) {}
  } catch (e) {}
}

// Desconectar
// Desconectar
const desconectar = () => {
  localStorage.removeItem('userId')
  localStorage.removeItem('currentUser')
  localStorage.removeItem('userRole')
  localStorage.removeItem('pb_token')
  router.push('/')
}
// Cargar al montar - EXACTAMENTE IGUAL QUE HOME
onMounted(() => {
  cargarPerfil()
  loadAvatar()
})
</script>

<style scoped>
.perfil-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
}

/* Header styles */
.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
  position: static;
  top: 0;
}

.logo img {
  height: 60px;
}

.header-buttons .btn {
  margin-left: 1rem;
  padding: 0.5rem 1rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  background: none;
  cursor: pointer;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover {
  background-color: #0056b3;
  color: white;
}

/* Contenedor principal */
.profile-container { 
  background: white; 
  padding: 2rem; 
  border-radius: 12px; 
  box-shadow: 0 4px 12px rgba(0,0,0,0.1); 
  width: 70%; 
  max-width: 600px; 
  margin: 2rem auto; 
}

.profile-title { 
  text-align: center; 
  margin-bottom: 1.5rem; 
  color: #333; 
}

/* Avatar styling */
.profile-avatar-container {
  display: flex;
  justify-content: center;
  margin-bottom: 2rem;
}

.profile-avatar {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #007bff;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.profile-group { 
  margin-bottom: 1rem; 
}

.profile-label { 
  display: block; 
  margin-bottom: 0.3rem; 
  color: #555; 
  font-weight: bold; 
}

.profile-value { 
  width: 100%; 
  padding: 0.7rem; 
  border: 1px solid #ccc; 
  border-radius: 8px; 
  background: #f8f9fa; 
  color: #333;
}

.profile-actions { 
  display: flex; 
  gap: 1rem; 
  margin-top: 1.5rem; 
}

.btn-edit, .btn-back { 
  flex: 1; 
  padding: 0.8rem; 
  color: white; 
  text-decoration: none; 
  text-align: center; 
  border-radius: 8px; 
}

.btn-edit { 
  background: #007bff; 
}

.btn-back { 
  background: #6c757d; 
}

.btn-edit:hover { 
  background: #0056b3; 
}

.btn-back:hover { 
  background: #545b62; 
}

/* Footer */
.site-footer {
  background-color: #f1f1f1; 
  color: #333; 
  text-align: center; 
  padding: 20px 0; 
  font-size: 0.9rem; 
  border-top: 1px solid #ccc; 
}

.site-footer a {
  color: #007bff; 
  text-decoration: none;
  margin: 0 5px; 
}

.site-footer a:hover {
  text-decoration: underline; 
}

/* Estados de carga - IGUAL QUE HOME */
.loading-state,
.error-state {
  text-align: center;
  padding: 2rem;
  color: #666;
  font-size: 1.1rem;
}

.error-state {
  color: #dc3545;
  background: #f8d7da;
  border-radius: 8px;
  margin-bottom: 1rem;
}

/* Responsive */
@media (max-width: 768px) {
  .profile-container {
    width: 90%;
    padding: 1.5rem;
  }
  
  .header-buttons {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .header-buttons .btn {
    margin-left: 0;
  }
}

@media (max-width: 480px) { 
  .profile-container { 
    width: 90%; 
    padding: 1.5rem; 
  } 
  
  .profile-actions { 
    flex-direction: column; 
  } 
}


.danger-zone {
  margin-top: 2rem;
  padding: 1.5rem;
  border: 2px solid #dc3545;
  border-radius: 8px;
  background: #f8d7da;
}

.danger-title {
  color: #dc3545;
  margin-bottom: 0.5rem;
}

.danger-warning {
  color: #721c24;
  margin-bottom: 1rem;
  font-size: 0.9rem;
}

.btn-danger {
  background: #dc3545;
  color: white;
  border: none;
  padding: 0.8rem 1.5rem;
  border-radius: 6px;
  cursor: pointer;
  font-weight: bold;
}

.btn-danger:hover:not(:disabled) {
  background: #c82333;
}

.btn-danger:disabled {
  background: #6c757d;
  cursor: not-allowed;
}
</style>