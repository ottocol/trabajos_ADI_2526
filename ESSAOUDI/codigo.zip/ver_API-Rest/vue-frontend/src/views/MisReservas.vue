<template>
  <div class="mis-reservas-view">
    <!-- Header -->
    <header class="site-header">
      <div class="logo">
          <img :src="logoImg" alt="Logo rentEase">
        </div>
      <div class="header-buttons">
        <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <!-- Contenido Principal -->
    <div class="reservas-container">
      <h2 class="reservas-title">Mis Reservas</h2>

      <div v-if="loading" class="loading-state">
        <p>Cargando reservas...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
      </div>

      <div v-else-if="reservas.length === 0" class="empty-state">
        <p>No tienes reservas realizadas.</p>
        <router-link to="/inquilino" class="btn btn-primary">Explorar pisos disponibles</router-link>
      </div>

      <div v-else class="reservas-list">
        <div v-for="reserva in reservas" :key="reserva.id" class="reserva-card" :class="reserva.estado">
          <div class="reserva-img">
            <img 
              :src="getReservaImage(reserva)" 
              :alt="reserva.tituloPiso"
              @error="handleImageError"
            >
          </div>

          <div class="reserva-info">
            <div class="info-group">
              <span class="info-label">Piso</span>
              <div class="info-value">{{ reserva.tituloPiso }}</div>
            </div>

            <div class="info-group">
              <span class="info-label">Dirección</span>
              <div class="info-value">{{ reserva.direccion }}</div>
            </div>

            <div class="info-group">
              <span class="info-label">Fechas</span>
              <div class="info-value">
                {{ formatFecha(reserva.fechaInicio) }} - {{ formatFecha(reserva.fechaFin) }} 
                ({{ calcularNoches(reserva.fechaInicio, reserva.fechaFin) }} noches)
              </div>
            </div>

            

            <div class="info-group">
              <span class="info-label">Estado</span>
              <div class="info-value">
                <span :class="['estado-badge', getEstadoClass(reserva.estado)]">
                  {{ getEstadoText(reserva.estado) }}
                </span>
              </div>
            </div>

            <div class="reserva-actions">
              <router-link 
                :to="{ name: 'PisoDetalle', params: { id: reserva.pisoId }}" 
                class="btn btn-primary"
              >
                Ver Detalles
              </router-link>
              
              <button 
                v-if="reserva.estado === 'pendiente'" 
                @click="cancelarReserva(reserva)" 
                class="btn btn-danger"
              >
                Cancelar
              </button>
              
              
              
              <router-link 
                v-else-if="reserva.estado === 'completada'" 
                :to="{ name: 'PisoDetalle', params: { id: reserva.pisoId }, hash: '#comentarios' }" 
                class="btn btn-outline"
              >
                Dejar Reseña
              </router-link>
            </div>
          </div>
        </div>
      </div>

      <router-link to="/inquilino" class="volver-link">← Volver a la Pagina Principal</router-link>
    </div>

    <!-- Footer -->
    <footer class="site-footer">
      <p>&copy; 2025 rentEase. Todos los derechos reservados.</p>
      <p>Contacto | Política de privacidad</p>
    </footer>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import logoImg from '@/images/rentEase_logo.jpg'
import pisoEjemplo from '@/images/piso-ejemplo.jpeg'
import villa1 from '@/images/villa1.jpg'
import house1 from '@/images/house1.jpg'

const router = useRouter()
const reservas = ref([])
const loading = ref(false)
const error = ref(null)
const cancelando = ref(false) // Para manejar estado de carga en cancelación

// Formatear precio
const formatPrecio = (precio) => {
  return precio ? `${precio} €` : '0 €'
}

// Formatear fecha
const formatFecha = (fecha) => {
  if (!fecha) return ''
  return new Date(fecha).toLocaleDateString('es-ES')
}

// Calcular número de noches
const calcularNoches = (fechaInicio, fechaFin) => {
  if (!fechaInicio || !fechaFin) return 0
  const inicio = new Date(fechaInicio)
  const fin = new Date(fechaFin)
  const diff = fin.getTime() - inicio.getTime()
  return Math.ceil(diff / (1000 * 3600 * 24))
}

const getReservaImage = (reserva) => {
  if (reserva.imagenPiso) return reserva.imagenPiso
  
  const defaultImages = [
    pisoEjemplo,
    villa1,
    house1
  ]
  const index = reservas.value.indexOf(reserva) % defaultImages.length
  return defaultImages[index]
}

// Manejar error de imagen
const handleImageError = (event) => {
  event.target.src = pisoEjemplo
}

// Obtener clase CSS del estado
const getEstadoClass = (estado) => {
  const clases = {
    'pendiente': 'estado-pendiente',
    'confirmada': 'estado-confirmada', 
    'cancelada': 'estado-cancelada',
    'completada': 'estado-completada'
  }
  return clases[estado] || 'estado-pendiente'
}

// Obtener texto del estado
const getEstadoText = (estado) => {
  const textos = {
    'pendiente': 'Pendiente',
    'confirmada': 'Confirmada',
    'cancelada': 'Cancelada',
    'completada': 'Completada'
  }
  return textos[estado] || estado
}

// Cargar mis reservas
const cargarMisReservas = async () => {
  loading.value = true
  error.value = null
  
  try {
    const token = localStorage.getItem('pb_token') || localStorage.getItem('authToken')
    
    if (!token) {
      throw new Error('No hay token de autenticación. Vuelve a iniciar sesión.')
    }

    const res = await fetch('/api/reservas/mis-reservas', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    
    if (!res.ok) {
      if (res.status === 401) {
        localStorage.removeItem('pb_token')
        localStorage.removeItem('authToken')
        throw new Error('Sesión expirada. Vuelve a iniciar sesión.')
      } else if (res.status === 500) {
        throw new Error('Error del servidor. Intenta más tarde.')
      } else {
        const errorText = await res.text()
        throw new Error(`Error ${res.status}: ${errorText}`)
      }
    }
    
    const data = await res.json()
    reservas.value = data
    
  } catch (err) {
    error.value = err.message || 'Error al cargar tus reservas. Intenta nuevamente.'
    
    // Datos de ejemplo solo para desarrollo
    if (process.env.NODE_ENV === 'development') {
      console.log('Modo desarrollo: usando datos de ejemplo')
      reservas.value = [
        {
          id: '1',
          tituloPiso: 'Apartamento en Madrid Centro',
          direccion: 'Calle Mayor 123, Madrid',
          fechaInicio: '2024-12-15',
          fechaFin: '2024-12-20',
          estado: 'confirmada',
          pisoId: '1',
          imagenPiso: '/images/piso-ejemplo.jpeg'
        },
        {
          id: '2', 
          tituloPiso: 'Villa en Palma de Mallorca',
          direccion: 'Carrer de la Mar 45, Palma',
          fechaInicio: '2025-01-05',
          fechaFin: '2025-01-12',
          estado: 'pendiente',
          pisoId: '2',
          imagenPiso: '/images/villa1.jpg'
        }
      ]
      error.value = null
    } else {
      reservas.value = []
    }
  }
  
  loading.value = false
}

// Cancelar reserva - función principal
const cancelarReserva = async (reserva) => {
  if (!reserva.id) {
    alert('Error: ID de reserva no válido')
    return
  }

  if (!confirm(`¿Estás seguro de que quieres cancelar la reserva de "${reserva.tituloPiso}"?`)) {
    return
  }

  await cancelarReservaBackend(reserva.id)
}

// Cancelar reserva en el backend
const cancelarReservaBackend = async (reservaId) => {
  cancelando.value = true
  
  try {
    const token = localStorage.getItem('pb_token') || localStorage.getItem('authToken')
    
    if (!token) {
      throw new Error('No hay token de autenticación')
    }

    const response = await fetch(`/api/reservas/${reservaId}/cancelar`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    })

    const data = await response.json()

    if (response.ok) {
      // Actualizar el estado local de la reserva
      const reservaIndex = reservas.value.findIndex(r => r.id === reservaId)
      if (reservaIndex !== -1) {
        reservas.value[reservaIndex].estado = 'cancelada'
      }
      
      alert('Reserva cancelada correctamente')
    } else {
      throw new Error(data.error || 'Error al cancelar la reserva')
    }
  } catch (err) {
    console.error('Error cancelando reserva:', err)
    alert(`Error al cancelar la reserva: ${err.message}`)
  } finally {
    cancelando.value = false
  }
}

// Contactar propietario
const contactarPropietario = (reserva) => {
  alert(`Contactando al propietario de: ${reserva.tituloPiso}`)
}

// Desconectar
const desconectar = () => {
  localStorage.removeItem('userId')
  localStorage.removeItem('authToken')
  localStorage.removeItem('pb_token')
  router.push('/')
}

onMounted(() => {
  cargarMisReservas()
})
</script>

<style scoped>



.mis-reservas-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
}

.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
  position: static;
  top: 0;
}

.logo img {
  height: 60px;
}

.header-buttons .btn {
  margin-left: 1rem;
  padding: 0.5rem 1rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  background: none;
  cursor: pointer;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover {
  background-color: #0056b3;
  color: white;
}

.reservas-container { 
  background: white;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  width: 75%;
  max-width: 1000px;
  margin: 2rem auto;
}

.reservas-title { 
  text-align: center; 
  margin-bottom: 1.5rem; 
  color: #333; 
}

.reserva-card {
  display: flex;
  gap: 1rem;
  align-items: flex-start;
  background: #f8f9fa;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  border-left: 4px solid #007bff;
}

.reserva-card.pendiente { border-left-color: #ffc107; }
.reserva-card.confirmada { border-left-color: #28a745; }
.reserva-card.cancelada { border-left-color: #dc3545; }

.reserva-img {
  flex-shrink: 0;
  width: 150px;
  height: 150px;
}

.reserva-img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 6px;
}

.reserva-info { 
  flex: 1; 
}

.info-group { 
  margin-bottom: 0.5rem; 
}

.info-label { 
  display: block; 
  margin-bottom: 0.2rem; 
  color: #555; 
  font-weight: bold; 
}

.info-value { 
  color: #333; 
}

.estado-badge { 
  display: inline-block; 
  padding: 0.2rem 0.6rem; 
  border-radius: 12px; 
  font-size: 0.8rem; 
  font-weight: bold; 
  margin-top: 0.5rem; 
}

.estado-pendiente { 
  background: #fff3cd; 
  color: #856404; 
}

.estado-confirmada { 
  background: #d4edda; 
  color: #155724; 
}

.estado-cancelada { 
  background: #f8d7da; 
  color: #721c24; 
}

.reserva-actions { 
  display: flex; 
  gap: 0.5rem; 
  margin-top: 1rem; 
}

.btn { 
  flex: 1; 
  padding: 0.5rem; 
  color: white; 
  text-decoration: none; 
  text-align: center; 
  border-radius: 6px; 
  font-size: 0.9rem; 
  border: none;
  cursor: pointer;
  display: inline-block;
}

.btn-primary { 
  background: #007bff; 
}

.btn-danger { 
  background: #dc3545; 
}

.btn-outline { 
  background: transparent; 
  border: 1px solid #6c757d; 
  color: #6c757d; 
}

.btn:hover { 
  opacity: 0.9; 
}

.volver-link { 
  text-align: center; 
  margin-top: 1.5rem; 
  display: block; 
  color: #007bff; 
  text-decoration: none; 
}

.volver-link:hover { 
  text-decoration: underline; 
}

.site-footer {
  background-color: #f1f1f1; 
  color: #333; 
  text-align: center; 
  padding: 20px 0; 
  font-size: 0.9rem; 
  border-top: 1px solid #ccc; 
}

.site-footer a {
  color: #007bff; 
  text-decoration: none;
  margin: 0 5px; 
}

.site-footer a:hover {
  text-decoration: underline; 
}

.loading-state,
.error-state,
.empty-state {
  text-align: center;
  padding: 3rem;
  color: #666;
}

.error-state {
  color: #dc3545;
}

.empty-state {
  background: #f8f9fa;
  border-radius: 8px;
}

/* Responsive */
@media (max-width: 768px) {
  .reservas-container {
    width: 90%;
    padding: 1rem;
  }
  
  .reserva-card {
    flex-direction: column;
  }
  
  .reserva-img {
    width: 100%;
    height: 200px;
  }
}

@media (max-width: 480px) { 
  .reserva-actions { 
    flex-direction: column; 
  }
  
  .header-buttons {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .header-buttons .btn {
    margin-left: 0;
  }
}

/* Agregar al final de tu CSS existente */
.estado-completada {
  border-left-color: #6c757d !important;
}

.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.cancelando {
  position: relative;
  pointer-events: none;
}

.cancelando::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 20px;
  height: 20px;
  margin: -10px 0 0 -10px;
  border: 2px solid #f3f3f3;
  border-top: 2px solid #dc3545;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>