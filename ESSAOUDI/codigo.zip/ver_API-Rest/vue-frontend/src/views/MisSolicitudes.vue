<template>
  <div class="mis-solicitudes-view">
    <!-- Header -->
    <header class="site-header">
      <div class="logo">
        <img :src="logoImg" alt="Logo rentEase">
      </div>
      <div class="header-buttons">
        <router-link to="/mis-anuncios" class="btn">Mis Anuncios</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <div class="solicitudes-container">
      <h2 class="solicitudes-title"> Mis Solicitudes</h2>

      <!-- Estados de carga y error -->
      <div v-if="loading" class="loading-state">
        <p>Cargando solicitudes...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
        <button @click="cargarSolicitudes" class="btn btn-primary">Reintentar</button>
      </div>

      <div v-else-if="solicitudes.length === 0" class="empty-state">
        <p>No hay solicitudes pendientes</p>
      </div>

      <!-- Lista de solicitudes -->
      <div v-else class="solicitudes-list">
        <div 
          v-for="solicitud in solicitudes" 
          :key="solicitud.id" 
          class="solicitud-card" 
          :class="solicitud.estado"
        >
          <!-- Información de la solicitud -->
          <div class="solicitud-header">
            <div class="solicitud-info">
              <h3 class="piso-titulo">{{ solicitud.tituloPiso }}</h3>
              <div class="solicitud-meta">
                <span class="user-info">👤 {{ solicitud.nombreUsuario }} • {{ solicitud.emailUsuario }}</span>
                <span class="fechas">
                  📅 {{ formatFecha(solicitud.fechaInicio) }} → {{ formatFecha(solicitud.fechaFin) }} 
                  ({{ calcularNoches(solicitud.fechaInicio, solicitud.fechaFin) }} noches)
                </span>
                <span class="precio">💰 {{ formatPrecio(solicitud.precioTotal) }}</span>
              </div>
            </div>
            
            <!-- Estado y fecha -->
            <div class="solicitud-status">
              <span :class="['estado-badge', getEstadoClass(solicitud.estado)]">
                {{ getEstadoText(solicitud.estado) }}
              </span>
              <div class="fecha-solicitud">
                Solicitado: {{ formatFechaCorta(solicitud.fechaCreacion) }}
              </div>
            </div>
          </div>

          <!-- Acciones según el estado -->
          <div class="solicitud-actions" v-if="solicitud.estado === 'pendiente'">
            <button 
              @click="aprobarSolicitud(solicitud.id)" 
              class="btn btn-success"
              :disabled="procesando === solicitud.id"
            >
               Aprobar
            </button>
            <button 
              @click="rechazarSolicitud(solicitud.id)" 
              class="btn btn-danger"
              :disabled="procesando === solicitud.id"
            >
               Rechazar
            </button>
            <router-link 
              :to="{ name: 'PisoDetalle', params: { id: solicitud.pisoId }}" 
              class="btn btn-outline"
            >
              📋 Ver Anuncio
            </router-link>
          </div>

          <div class="solicitud-actions" v-else-if="solicitud.estado === 'confirmada'">
            <span class="status-text confirmed"> Confirmada</span>
            <button 
              @click="cancelarReserva(solicitud.id)" 
              class="btn btn-warning"
              :disabled="procesando === solicitud.id"
            >
              🗑️ Cancelar
            </button>
          </div>

          <div class="solicitud-actions" v-else-if="solicitud.estado === 'cancelada'">
            <span class="status-text cancelled"> Cancelada</span>
          </div>
        </div>
      </div>

      <router-link to="/propietario" class="volver-link">← Volver al Inicio</router-link>
    </div>

    <!-- Footer -->
    <footer class="site-footer">
      <p>&copy; 2025 rentEase</p>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import logoImg from '@/images/rentEase_logo.jpg'

const router = useRouter()

// Variables reactivas
const solicitudes = ref([])
const loading = ref(false)
const error = ref(null)
const procesando = ref(null)

// Funciones de formato
// Funciones de formato - MEJORADA
const formatPrecio = (precio) => {
  const precioNum = Number(precio)
  if (isNaN(precioNum) || precioNum === 0) {
    return 'Precio no disponible'
  }
  return `${precioNum.toFixed(2)} €`
}

const formatFecha = (fecha) => {
  if (!fecha) return ''
  return new Date(fecha).toLocaleDateString('es-ES')
}

const formatFechaCorta = (fecha) => {
  if (!fecha) return ''
  return new Date(fecha).toLocaleDateString('es-ES', { 
    day: '2-digit', 
    month: '2-digit' 
  })
}

// Calcular número de noches
// Calcular número de noches - MEJORADA
const calcularNoches = (fechaInicio, fechaFin) => {
  if (!fechaInicio || !fechaFin) return 0
  
  try {
    const inicio = new Date(fechaInicio)
    const fin = new Date(fechaFin)
    
    // Validar que las fechas sean válidas
    if (isNaN(inicio.getTime()) || isNaN(fin.getTime())) {
      console.error('Fechas inválidas:', fechaInicio, fechaFin)
      return 0
    }
    
    // Asegurarse de que fin sea después de inicio
    if (fin <= inicio) return 0
    
    const diff = fin.getTime() - inicio.getTime()
    const noches = Math.ceil(diff / (1000 * 3600 * 24))
    
    return noches > 0 ? noches : 0
  } catch (error) {
    console.error('Error calculando noches:', error)
    return 0
  }
}

// Funciones para estados
const getEstadoClass = (estado) => {
  const clases = {
    'pendiente': 'estado-pendiente',
    'confirmada': 'estado-confirmada', 
    'cancelada': 'estado-cancelada'
  }
  return clases[estado] || 'estado-pendiente'
}

const getEstadoText = (estado) => {
  const textos = {
    'pendiente': 'Pendiente',
    'confirmada': 'Confirmada',
    'cancelada': 'Cancelada'
  }
  return textos[estado] || estado
}

// Cargar solicitudes del propietario
// Cargar solicitudes del propietario - VERSIÓN CORREGIDA
const cargarSolicitudes = async () => {
  loading.value = true
  error.value = null
  
  try {
    const token = localStorage.getItem('pb_token') || localStorage.getItem('authToken')
    
    if (!token) {
      throw new Error('No hay token de autenticación. Vuelve a iniciar sesión.')
    }

    // Obtener los pisos del propietario
    const resPisos = await fetch('/api/pisos/mis-anuncios', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    
    if (!resPisos.ok) {
      throw new Error('Error al obtener mis anuncios')
    }

    const misPisos = await resPisos.json()
    
    if (!misPisos || misPisos.length === 0) {
      solicitudes.value = []
      return
    }

    // Obtener todas las reservas de los pisos del propietario
    const todasSolicitudes = []
    
    for (const piso of misPisos) {
      try {
        const resReservas = await fetch(`/api/reservas/piso/${piso.id}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        
        if (resReservas.ok) {
          const reservasPiso = await resReservas.json()
          reservasPiso.forEach(reserva => {
            // CALCULAR PRECIO SI ES 0 - CORREGIDO
            let precioFinal = reserva.precioTotal
            
            if (!precioFinal || precioFinal === 0) {
              const noches = calcularNoches(reserva.fechaInicio, reserva.fechaFin)
              precioFinal = noches * (piso.precio || 0)
            }
            
            todasSolicitudes.push({
              ...reserva,
              tituloPiso: piso.titulo,
              pisoId: piso.id,
              precioTotal: precioFinal // USAR PRECIO CALCULADO
            })
          })
        }
      } catch (err) {
        console.error(`Error cargando reservas del piso ${piso.id}:`, err)
      }
    }

    // Ordenar por fecha de creación (más reciente primero)
    solicitudes.value = todasSolicitudes.sort((a, b) => 
      new Date(b.fechaCreacion) - new Date(a.fechaCreacion)
    )
    
  } catch (err) {
    console.error('Error cargando solicitudes:', err)
    error.value = err.message || 'Error al cargar las solicitudes. Intenta nuevamente.'
    
    // Datos de ejemplo para desarrollo
    if (process.env.NODE_ENV === 'development') {
      console.log('Modo desarrollo: usando datos de ejemplo')
      solicitudes.value = [
        {
          id: '1',
          tituloPiso: 'Apartamento en Madrid Centro',
          nombreUsuario: 'Juan Pérez',
          emailUsuario: 'juan@example.com',
          fechaInicio: '2024-12-15',
          fechaFin: '2024-12-20',
          precioTotal: 600, // PRECIO CORRECTO
          estado: 'pendiente',
          pisoId: '1',
          fechaCreacion: '2024-01-10T10:00:00.000Z'
        }
      ]
      error.value = null
    }
  }
  
  loading.value = false
}

// Acciones sobre las solicitudes
const aprobarSolicitud = async (solicitudId) => {
  if (!confirm('¿Estás seguro de que quieres aprobar esta solicitud?')) {
    return
  }

  await actualizarEstadoSolicitud(solicitudId, 'confirmada', 'Solicitud aprobada correctamente')
}

const rechazarSolicitud = async (solicitudId) => {
  if (!confirm('¿Estás seguro de que quieres rechazar esta solicitud?')) {
    return
  }

  await actualizarEstadoSolicitud(solicitudId, 'cancelada', 'Solicitud rechazada correctamente')
}

const cancelarReserva = async (solicitudId) => {
  if (!confirm('¿Estás seguro de que quieres cancelar esta reserva confirmada?')) {
    return
  }

  await actualizarEstadoSolicitud(solicitudId, 'cancelada', 'Reserva cancelada correctamente')
}

// Función genérica para actualizar estado
const actualizarEstadoSolicitud = async (solicitudId, nuevoEstado, mensajeExito) => {
  procesando.value = solicitudId
  
  try {
    const token = localStorage.getItem('pb_token') || localStorage.getItem('authToken')
    
    const response = await fetch(`/api/reservas/${solicitudId}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        estado: nuevoEstado
      })
    })

    if (response.ok) {
      // Actualizar el estado local de la solicitud
      const solicitudIndex = solicitudes.value.findIndex(s => s.id === solicitudId)
      if (solicitudIndex !== -1) {
        solicitudes.value[solicitudIndex].estado = nuevoEstado
      }
      
      alert(mensajeExito)
    } else {
      throw new Error('Error al actualizar la solicitud')
    }
  } catch (err) {
    console.error('Error actualizando solicitud:', err)
    alert(`Error: ${err.message}`)
  } finally {
    procesando.value = null
  }
}

// Desconectar
const desconectar = () => {
  localStorage.removeItem('userId')
  localStorage.removeItem('authToken')
  localStorage.removeItem('pb_token')
  router.push('/')
}

// Cargar solicitudes al montar el componente
onMounted(() => {
  cargarSolicitudes()
})
</script>

<style scoped>
.mis-solicitudes-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
}

/* Header */
.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
}

.logo img {
  height: 50px;
}

.header-buttons {
  display: flex;
  gap: 0.8rem;
}

.header-buttons .btn {
  padding: 0.5rem 1rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  background: none;
  cursor: pointer;
}

.header-buttons .btn-active {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover {
  background-color: #0056b3;
  color: white;
}

/* Contenedor principal */
.solicitudes-container {
  background: white;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  width: 90%;
  max-width: 900px;
  margin: 1.5rem auto;
}

.solicitudes-title {
  text-align: center;
  margin-bottom: 1.5rem;
  color: #333;
  font-size: 1.5rem;
}

/* Tarjetas de solicitud */
.solicitud-card {
  background: white;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  border: 1px solid #e0e0e0;
  border-left: 4px solid #007bff;
}

.solicitud-card.pendiente {
  border-left-color: #ffc107;
}

.solicitud-card.confirmada {
  border-left-color: #28a745;
}

.solicitud-card.cancelada {
  border-left-color: #dc3545;
}

/* Header de la solicitud */
.solicitud-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.8rem;
}

.solicitud-info {
  flex: 1;
}

.piso-titulo {
  margin: 0 0 0.5rem 0;
  color: #333;
  font-size: 1.1rem;
  font-weight: bold;
}

.solicitud-meta {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
  font-size: 0.85rem;
  color: #666;
}

.user-info, .fechas, .precio {
  display: block;
}

.precio {
  color: #28a745;
  font-weight: bold;
}

/* Estado de la solicitud */
.solicitud-status {
  text-align: right;
  min-width: 120px;
}

.estado-badge {
  padding: 0.3rem 0.8rem;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: bold;
  text-transform: uppercase;
  display: inline-block;
  margin-bottom: 0.3rem;
}

.estado-pendiente {
  background: #fff3cd;
  color: #856404;
}

.estado-confirmada {
  background: #d4edda;
  color: #155724;
}

.estado-cancelada {
  background: #f8d7da;
  color: #721c24;
}

.fecha-solicitud {
  font-size: 0.75rem;
  color: #999;
}

/* Acciones */
.solicitud-actions {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.btn {
  padding: 0.4rem 0.8rem;
  border: none;
  border-radius: 4px;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  font-size: 0.8rem;
}

.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.btn-success {
  background: #28a745;
  color: white;
}

.btn-danger {
  background: #dc3545;
  color: white;
}

.btn-warning {
  background: #ffc107;
  color: #212529;
}

.btn-outline {
  background: transparent;
  border: 1px solid #6c757d;
  color: #6c757d;
}

.btn-primary {
  background: #007bff;
  color: white;
}

/* Estados de texto */
.status-text {
  font-weight: bold;
  padding: 0.4rem 0.8rem;
  border-radius: 4px;
  font-size: 0.8rem;
}

.confirmed {
  background: #d4edda;
  color: #155724;
}

.cancelled {
  background: #f8d7da;
  color: #721c24;
}

/* Enlace volver */
.volver-link {
  text-align: center;
  margin-top: 1.5rem;
  display: block;
  color: #007bff;
  text-decoration: none;
  font-weight: bold;
}

.volver-link:hover {
  text-decoration: underline;
}

/* Footer */
.site-footer {
  background: #f1f1f1;
  color: #333;
  text-align: center;
  padding: 1rem;
  font-size: 0.8rem;
  margin-top: 2rem;
}

/* Estados de la página */
.loading-state,
.error-state,
.empty-state {
  text-align: center;
  padding: 2rem;
  color: #666;
}

.error-state {
  color: #dc3545;
}

.empty-state {
  color: #666;
}

/* Responsive */
@media (max-width: 768px) {
  .solicitudes-container {
    width: 95%;
    padding: 1rem;
  }
  
  .solicitud-header {
    flex-direction: column;
    gap: 0.8rem;
  }
  
  .solicitud-status {
    text-align: left;
  }
  
  .solicitud-actions {
    flex-direction: column;
  }
  
  .header-buttons {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .site-header {
    padding: 1rem;
    flex-direction: column;
    gap: 1rem;
  }
}
</style>