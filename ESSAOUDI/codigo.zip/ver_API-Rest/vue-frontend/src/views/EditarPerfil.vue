<template>
  <div class="editar-perfil-view">
    <header class="site-header">
      <div class="logo">
        <img :src="logoImg" alt="Logo rentEase">
      </div>
      <div class="header-buttons">
        <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <div class="edit-container">
      <h2 class="edit-title">Editar Perfil</h2>

      <div v-if="loading" class="loading-state">
        <p>Cargando datos del perfil...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
      </div>

      <div v-else-if="success" class="success-state">
        <p>¡Perfil actualizado correctamente!</p>
      </div>

      <form v-else @submit.prevent="guardarCambios">
        <div class="form-group">
          <label for="nombre">Nombre</label>
          <input v-model="form.nombre" type="text" id="nombre" required>
        </div>
        
        <div class="form-group">
          <label for="apellidos">Apellidos</label>
          <input v-model="form.apellidos" type="text" id="apellidos" required>
        </div>
        
        <div class="form-group">
          <label for="email">Email</label>
          <input v-model="form.email" type="email" id="email" required disabled>
          <small class="form-help">El email no se puede modificar</small>
        </div>
        
        <div class="form-group">
          <label for="tel">Teléfono</label>
          <input v-model="form.tel" type="tel" id="tel" placeholder="+34 612 345 678">
        </div>
        
        <div class="form-group">
          <label for="rol">Rol</label>
          <select v-model="form.rol" id="rol" required>
            <option value="inquilino">Inquilino</option>
            <option value="propietario">Propietario</option>
          </select>
        </div>
        
        <div class="form-group">
          <label for="username">Nombre de usuario</label>
          <input v-model="form.username" type="text" id="username" required>
        </div>
        
       <div class="form-group">
          <label for="oldPassword">Contraseña Actual *</label>
          <input v-model="form.oldPassword" type="password" id="oldPassword" placeholder="********" required>
          <small class="form-help">Requerida para cambiar la contraseña</small>
        </div>

        <div class="form-group">
          <label for="password">Nueva Contraseña</label>
          <input v-model="form.password" type="password" id="password" placeholder="********">
        </div>

        <div class="form-group">
          <label for="confirmPassword">Confirmar Nueva Contraseña</label>
          <input v-model="form.confirmPassword" type="password" id="confirmPassword" placeholder="********">
        </div>
        
        <div class="form-actions">
          <button type="submit" class="btn-save" :disabled="guardando">
            {{ guardando ? 'Guardando...' : 'Guardar Cambios' }}
          </button>
          <router-link to="/perfil" class="btn-cancel">Cancelar</router-link>
        </div>
      </form>
    </div>

    <footer class="site-footer">
      <p>&copy; 2025 rentEase. Todos los derechos reservados.</p>
    </footer>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import logoImg from '@/images/rentEase_logo.jpg'

const router = useRouter()
const loading = ref(false)
const guardando = ref(false)
const error = ref('')
const success = ref(false)

const form = reactive({
  nombre: '',
  apellidos: '',
  email: '',
  tel: '', 
  rol: 'inquilino',
  oldPassword: '',
  username: '', 
  password: '',
  confirmPassword: ''
})

const cargarPerfil = async () => {
  loading.value = true
  error.value = ''
  
  try {
    const userId = localStorage.getItem('userId')
    const token = localStorage.getItem('pb_token') 
    
    if (!userId || !token) {
      throw new Error('No autenticado')
    }

    const res = await fetch(`http://localhost:3000/api/users/${userId}`, {
      headers: {
        'Authorization': `Bearer ${token}` 
      }
    })

    if (!res.ok) {
      throw new Error(`Error ${res.status}: ${res.statusText}`)
    }

    const userData = await res.json()
    
    form.nombre = userData.nombre || ''
    form.apellidos = userData.apellidos || ''
    form.email = userData.email || ''
    form.tel = userData.tel || '' 
    form.rol = userData.rol || 'inquilino'
    form.username = userData.username || '' 
    
  } catch (err) {
    error.value = 'Error al cargar los datos del perfil: ' + err.message
  } finally {
    loading.value = false
  }
}

// Validar formulario
const validarFormulario = () => {
  // Si se quiere cambiar la contraseña, validar todos los campos
  if (form.password) {
    if (!form.oldPassword) {
      error.value = 'Debes ingresar tu contraseña actual para cambiarla'
      return false
    }
    
    if (form.password !== form.confirmPassword) {
      error.value = 'Las nuevas contraseñas no coinciden'
      return false
    }
    
    if (form.password.length < 6) {
      error.value = 'La nueva contraseña debe tener al menos 6 caracteres'
      return false
    }
  }
  
  // Validar username según reglas de PocketBase
  if (!form.username || form.username.length < 3) {
    error.value = 'El nombre de usuario debe tener al menos 3 caracteres'
    return false
  }
  
  const usernameRegex = /^[a-zA-Z0-9_]+([a-zA-Z0-9_.]*[a-zA-Z0-9_])?$/
  if (!usernameRegex.test(form.username)) {
    error.value = 'El nombre de usuario solo puede contener letras, números, _ y .'
    return false
  }
  
  error.value = ''
  return true
}
const guardarCambios = async () => {
  if (!validarFormulario()) return
  
  guardando.value = true
  error.value = ''
  success.value = false
  
  try {
    const userId = localStorage.getItem('userId')
    const token = localStorage.getItem('pb_token')
    
    if (!userId || !token) {
      throw new Error('No autenticado')
    }

    const datosActualizacion = {
      nombre: form.nombre,
      apellidos: form.apellidos,
      tel: form.tel, 
      rol: form.rol,
      username: form.username 
    }
    
    // ⚠️ MODIFICA ESTA PARTE - Solo incluir password si se proporcionó
    if (form.password) {
      if (!form.oldPassword) {
        throw new Error('Debes ingresar tu contraseña actual para cambiarla')
      }
      
      datosActualizacion.oldPassword = form.oldPassword // ⚠️ AÑADE ESTO
      datosActualizacion.password = form.password
      datosActualizacion.passwordConfirm = form.password 
    }

    console.log('📤 Enviando actualización:', datosActualizacion)

    const res = await fetch(`http://localhost:3000/api/users/${userId}/perfil`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(datosActualizacion)
    })

    if (!res.ok) {
      const errorData = await res.json().catch(() => null)
      
      // ⚠️ AÑADE ESTO PARA MANEJAR ERROR DE CONTRASEÑA
      if (errorData?.data?.oldPassword) {
        throw new Error('La contraseña actual es incorrecta')
      }
      
      throw new Error(errorData?.error || `Error ${res.status}`)
    }

    const result = await res.json()
    console.log('✅ Perfil actualizado:', result)
    
    success.value = true
    
    // Limpiar campos de contraseña después de éxito
    form.oldPassword = ''
    form.password = ''
    form.confirmPassword = ''
    
    // Actualizar localStorage
    localStorage.setItem('currentUser', JSON.stringify({
      id: userId,
      nombre: form.nombre,
      email: form.email,
      rol: form.rol,
      tel: form.tel,
      username: form.username
    }))
    localStorage.setItem('userRole', form.rol)
    
    // Redirigir después de éxito
    setTimeout(() => {
      router.push('/perfil')
    }, 2000)
    
  } catch (err) {
    console.error('❌ Error actualizando perfil:', err)
    error.value = 'Error al guardar los cambios: ' + err.message
  } finally {
    guardando.value = false
  }
}

// Desconectar - CORREGIDO
const desconectar = () => {
  localStorage.removeItem('userId')
  localStorage.removeItem('currentUser')
  localStorage.removeItem('userRole')
  localStorage.removeItem('pb_token') 
  router.push('/')
}

// Cargar al montar
onMounted(() => {
  cargarPerfil()
})
</script>

<style scoped>
.form-help {
  display: block;
  margin-top: 0.25rem;
  font-size: 0.8rem;
  color: #666;
}

.editar-perfil-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
}

.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
}

.logo img {
  height: 60px;
}

.header-buttons .btn {
  margin-left: 1rem;
  padding: 0.5rem 1rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  background: none;
  cursor: pointer;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover {
  background-color: #0056b3;
  color: white;
}

.edit-container { 
  background: white;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  width: 75%;
  margin: 2rem auto; 
  max-width: 600px;
}

.edit-title { 
  text-align: center; 
  margin-bottom: 1.5rem; 
  color: #333; 
}

.form-group { 
  margin-bottom: 1rem; 
}

label { 
  display: block; 
  margin-bottom: 0.3rem; 
  color: #555; 
  font-size: 0.9rem; 
  font-weight: bold; 
}

input, select { 
  width: 100%; 
  padding: 0.7rem; 
  border: 1px solid #ccc; 
  border-radius: 8px; 
  font-size: 1rem; 
  box-sizing: border-box; 
}

input:focus, select:focus { 
  border-color: #007bff; 
  outline: none; 
}

input:disabled {
  background-color: #f8f9fa;
  color: #666;
}

.form-actions { 
  display: flex; 
  gap: 1rem; 
  margin-top: 1.5rem; 
}

.btn-save, .btn-cancel { 
  flex: 1; 
  padding: 0.8rem; 
  color: white; 
  text-decoration: none; 
  text-align: center; 
  border-radius: 8px; 
  border: none; 
  cursor: pointer; 
  font-size: 1rem; 
}

.btn-save { 
  background: #28a745; 
}

.btn-save:disabled {
  background: #6c757d;
  cursor: not-allowed;
}

.btn-cancel { 
  background: #6c757d; 
}

.btn-save:hover:not(:disabled) { 
  background: #218838; 
}

.btn-cancel:hover { 
  background: #545b62; 
}

.site-footer {
  background-color: #f1f1f1; 
  color: #333; 
  text-align: center; 
  padding: 20px 0; 
  font-size: 0.9rem; 
  border-top: 1px solid #ccc; 
}

.loading-state,
.error-state,
.success-state {
  text-align: center;
  padding: 2rem;
  font-size: 1.1rem;
}

.error-state {
  color: #dc3545;
  background: #f8d7da;
  border-radius: 8px;
}

.success-state {
  color: #155724;
  background: #d4edda;
  border-radius: 8px;
}

@media (max-width: 768px) {
  .edit-container {
    width: 90%;
    padding: 1.5rem;
  }
  
  .form-actions { 
    flex-direction: column; 
  }
  
  .header-buttons {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .header-buttons .btn {
    margin-left: 0;
  }
}
</style>