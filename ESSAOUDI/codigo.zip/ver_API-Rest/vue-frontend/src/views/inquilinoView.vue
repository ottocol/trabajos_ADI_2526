<template>
  <div class="home-view">
    <AppHeader>
      <template #left>
        <router-link to="/perfil">
          <img :src="avatarSrc" alt="avatar" class="user-avatar-small" />
        </router-link>
      </template>

      <template #right>
        <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
        <router-link to="/perfil" class="btn">Perfil</router-link>
        <button class="btn btn-danger" @click="handleLogout" :disabled="loggingOut">Desconectar</button>
      </template>
    </AppHeader>

    <div class="main-layout">
      <main class="anuncios-container">

        <!-- Debug temporal -->
        <div class="debug-box" v-if="debug">
          <p><strong>Debug:</strong> items count = {{ items.length }}</p>
          <pre>{{ JSON.stringify(items, null, 2) }}</pre>
        </div>

        <template v-if="loading">
          <p>Cargando pisos...</p>
        </template>

        <template v-else-if="items.length === 0">
          <p>No hay pisos disponibles.</p>
        </template>

        <!-- Tarjetas -->
        <template v-else>
          <div class="cards-grid">
            <div v-for="(item, idx) in items" :key="item.id" class="anuncio-card">
              
              <img :src="getImage(item, idx)"
                   :alt="item.titulo"
                   class="anuncio-img">

              <div class="anuncio-info">
                <h3 class="titulo">{{ item.titulo }}</h3>

                <p class="descripcion" v-if="item.descripcion">
                  {{ item.descripcion }}
                </p>

                <p><strong>Dirección:</strong> {{ item.direccion }}</p>

                <p class="precio">
                  {{ formatPrice(item.precio) }}
                </p>

                <router-link 
                  :to="{ name: 'PisoDetalle', params: { id: item.id }}"
                  class="btn-ver-detalle">
                  Ver Detalles
                </router-link>
              </div>

            </div>
          </div>
        </template>

        <!-- Pagination controls -->
        <div v-if="!loading && items.length" style="display:flex; gap:8px; align-items:center; justify-content:center; margin:18px 0">
          <button class="btn" :disabled="page <= 1" @click="goPrev">Anterior</button>
          <div> Página {{ page }} de {{ totalPages }} — {{ totalItems }} pisos </div>
          <button class="btn" :disabled="page >= totalPages" @click="goNext">Siguiente</button>
        </div>

      </main>

      <FiltersPanel />
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref, onMounted, provide } from 'vue' 
import randomAvatar from '@/images/users/random.png'
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import FiltersPanel from '@/components/Layout/FiltersPanel.vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const loggingOut = ref(false)
const avatarSrc = ref(randomAvatar)

const items = ref([])
const loading = ref(false)
const page = ref(1)
const perPage = ref(9)
const totalPages = ref(1)
const totalItems = ref(0)
const filtros = ref({})
provide('filtros', filtros)

function loadAvatar() {
  try {
    const raw = localStorage.getItem('currentUser')
    if (!raw) return
    const u = JSON.parse(raw)
    if (u.avatarUrl) {
      avatarSrc.value = u.avatarUrl
      return
    }

    if (u.image) {
      if (Array.isArray(u.image) && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image[0]}`
        return
      }
      if (typeof u.image === 'string' && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image}`
        return
      }
    }

    try {
      const userId = u.id || localStorage.getItem('userId')
      if (!userId) return
      fetch(`/api/perfil/${userId}`).then(r => r.json()).then(json => {
        if (json && json.image && Array.isArray(json.image) && json.image.length > 0) {
          avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${json.id}/${json.image[0]}`
          try { localStorage.setItem('currentUser', JSON.stringify(json)) } catch (e) {}
        }
      }).catch(() => {})
    } catch (e) {}
  } catch (e) {}
}

const handleLogout = async () => {
  loggingOut.value = true
  try {
    await fetch('/api/auth/logout', { method: 'POST' })
  } catch (e) {
    console.error('Logout request failed', e)
  } finally {
    try { localStorage.removeItem('currentUser') } catch (e) {}
    loggingOut.value = false
    router.push({ name: 'home' })
  }
}

function formatPrice(p) {
  return p ? `${p} € / noche` : ''
}

function getImage(item, idx = 0) {
  if (item.primeraImagen) return item.primeraImagen

  const localImages = [
    '/images/house1.jpg',
    '/images/villa1.jpg',
    '/images/piso-ejemplo.jpeg',
    '/images/3.jpg'
  ]
  return localImages[idx % localImages.length]
}

const cargarPisos = async (filtrosAplicados = {}) => {
  loading.value = true
  try {
    const params = new URLSearchParams()
    if (filtrosAplicados.ciudad) params.append('ciudad', filtrosAplicados.ciudad)
    if (filtrosAplicados.precioMin) params.append('precioMin', filtrosAplicados.precioMin)
    if (filtrosAplicados.precioMax) params.append('precioMax', filtrosAplicados.precioMax)
    if (filtrosAplicados.habitaciones) params.append('num_habit', filtrosAplicados.habitaciones)
    
    // include pagination params
    params.set('page', String(page.value))
    params.set('perPage', String(perPage.value))
    const url = params.toString() ? `/api/pisos?${params.toString()}` : '/api/pisos'

    const res = await fetch(url)
    const json = await res.json()

    if (Array.isArray(json)) {
      items.value = json
      totalItems.value = json.length
      totalPages.value = 1
      page.value = 1
      perPage.value = json.length
    } else if (json && json.items) {
      items.value = json.items || []
      page.value = json.page || page.value
      perPage.value = json.perPage || perPage.value
      totalItems.value = json.totalItems || totalItems.value
      totalPages.value = json.totalPages || totalPages.value
    }
  } catch (err) {
    console.error('Error cargando pisos', err)
  }
  loading.value = false
}

const manejarCambioFiltros = (nuevosFiltros) => {
  filtros.value = nuevosFiltros
  page.value = 1
  cargarPisos(nuevosFiltros)
}

provide('onFiltrosChange', manejarCambioFiltros)

onMounted(() => {
  loadAvatar()
  window.addEventListener('storage', loadAvatar)
  cargarPisos() 
})

function goPrev() { if (page.value > 1) { page.value -= 1; cargarPisos(filtros.value) } }
function goNext() { if (page.value < totalPages.value) { page.value += 1; cargarPisos(filtros.value) } }


</script>

<script>
export default {
  data() {
    return { debug: false }
  }
}
</script>

<style scoped>
.main-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 300px; /* left flexible, right fixed sidebar */
  gap: 1.5rem;
  align-items: start;
}


.cards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 18px;
  padding: 8px 8px;
  box-sizing: border-box;
  width: 100%;
}

.anuncios-container {
  display: block;
  width: 100%;
  padding: 0;
  box-sizing: border-box;
}

/* Card */
.anuncio-card {
  background: #ffffff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0px 4px 14px rgba(0,0,0,0.1);
  transition: .25s;
}

.anuncio-card:hover {
  transform: translateY(-4px);
  box-shadow: 0px 6px 18px rgba(0,0,0,0.15);
}

/* Image */
.anuncio-img {
  width: 100%;
  height: 170px;
  object-fit: cover;
  display: block;
}

/* Content */
.anuncio-info {
  padding: 12px;
}

.titulo {
  margin: 0 0 8px;
  font-size: 1.15em;
}

.descripcion {
  color: #555;
  margin-bottom: 10px;
}

.precio {
  font-weight: bold;
  color: #2185d0;
  font-size: 1.05em;
  margin: 10px 0;
}

.btn-ver-detalle {
  display: inline-block;
  padding: 8px 12px;
  background: #2185d0;
  color: white;
  border-radius: 6px;
  text-decoration: none;
}

.btn-ver-detalle:hover {
  background: #1678c2;
}

/* Responsive: stack sidebar under listings on narrow viewports */
@media (max-width: 800px) {
  .main-layout {
    grid-template-columns: 1fr; /* sidebar stacks under listings */
  }
  .cards-grid {
    grid-template-columns: 1fr;
  }
}

/* Force 3 columns on wide screens to use available space */
@media (min-width: 1100px) {
  .cards-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
</style>

/* Small helper for danger buttons used in views */
.btn-danger {
  background: #e53935;
  color: #fff;
  border: none;
}
.btn-danger:hover {
  background: #d32f2f;
}
.btn-danger[disabled] {
  opacity: 0.6;
}