<template>
  <div class="admin-view">
    <AppHeader>
      <template #left>
        <router-link to="/perfil">
          <img :src="avatarSrc" alt="avatar" class="user-avatar-small" />
        </router-link>
      </template>

      <template #right>
        <router-link to="/perfil" class="btn">Perfil</router-link>
        <button class="btn btn-danger" @click="handleLogout" :disabled="loggingOut">Desconectar</button>
      </template>
    </AppHeader>

    <div class="admin-layout">
      <aside class="admin-sidebar">
        <div class="brand">rentEase</div>
        <nav class="side-nav">
          <router-link to="/admin" class="nav-item" exact>Dashboard</router-link>
          <router-link to="/admin/users" class="nav-item">Usuarios</router-link>
          <router-link to="/admin/pisos" class="nav-item">Pisos</router-link>
          <router-link to="/admin/reservas" class="nav-item">Reservas</router-link>
          <router-link to="/admin/comentarios" class="nav-item">Comentarios</router-link>
        </nav>
      </aside>

      <main class="admin-main">
      <h1 class="page-title">Panel de Administración</h1>

      <p class="lead">Bienvenido, administra las entidades del sistema desde aquí.</p>

      <div class="admin-grid">
        <div class="admin-card users-card">
          <div class="card-head">
            <div class="head-left">
              <h3>Usuarios</h3>
              <span class="badge">{{ counts.users }}</span>
            </div>
          </div>
          <div class="card-body">
            <table class="preview-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Apellidos</th>
                  <th>Rol</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="u in previews.users" :key="u.id">
                  <td>{{ u.id || (u.record && u.record.id) || '-' }}</td>
                  <td>{{ u.nombre || u.name || (u.record && (u.record.nombre || u.record.name)) || '-' }}</td>
                  <td>{{ u.apellidos || u.lastName || (u.record && u.record.apellidos) || '-' }}</td>
                  <td>{{ u.rol || u.role || u.userRole || (u.record && u.record.rol) || '-' }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="card-actions">
            <button class="btn" @click="goTo('AdminUsers')">Ver más usuarios</button>
            <button class="btn" @click="openUserCreateModal">Crear</button>
          </div>
        </div>

        <div class="admin-card pisos-card">
          <div class="card-head">
            <div class="head-left">
              <h3>Pisos</h3>
              <span class="badge">{{ counts.pisos }}</span>
            </div>
          </div>
          <div class="card-body">
            <table class="preview-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Título</th>
                  <th>Ciudad</th>
                  <th>Propietario</th>
                  <th>Precio</th>
                  <th>Habit.</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="p in previews.pisos" :key="p.id">
                  <td>{{ p.id }}</td>
                  <td>{{ p.titulo || '-' }}</td>
                  <td>{{ p.ciudad || '-' }}</td>
                  <td>
                    {{
                      (p.expand && p.expand.propietario_id && (p.expand.propietario_id.nombre || p.expand.propietario_id.name || p.expand.propietario_id.email))
                      || (p.expand && p.expand.propietario && (p.expand.propietario.nombre || p.expand.propietario.name || p.expand.propietario.email))
                      || p.propietario /* may be a string id or already-mapped name */
                      || p.propietario_id
                      || p.ownerId
                      || p.owner
                      || '-'
                    }}
                  </td>
                  <td>{{ p.precio !== undefined ? p.precio : '-' }}</td>
                  <td>{{ p.num_habit || '-' }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="card-actions">
            <button class="btn" @click="goTo('AdminPisos')">Ver todos los pisos</button>
          </div>
        </div>

        <div class="admin-card reservas-card">
          <div class="card-head">
            <h3>Reservas</h3>
            <p class="count">{{ counts.reservas }}</p>
          </div>
          <div class="card-body">
            <table class="preview-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Piso</th>
                  <th>Inquilino</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="r in previews.reservas" :key="r.id">
                  <td>{{ r.id }}</td>
                  <td>{{ r.piso_id || r.piso || r.pisoId || '-' }}</td>
                  <td>{{ r.usuario_id || r.inquilino_id || r.user || '-' }}</td>
                  <td>{{ r.estado || r.status || '-' }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="card-actions">
            <button class="btn" @click="goTo('AdminReservas')">Ver todas las reservas</button>
            <button class="btn" @click="goTo('AdminReservas')">Crear</button>
          </div>
        </div>

        <div class="admin-card comentarios-card">
          <div class="card-head">
            <h3>Comentarios</h3>
            <p class="count">{{ counts.comentarios }}</p>
          </div>
          <div class="card-body">
            <table class="preview-table">
              <thead>
                <tr>
                  <th>Usuario</th>
                  <th>Piso</th>
                  <th>Comentario</th>
                  <th>Valoración</th>
                  <th>Creado</th>
                  <th>—</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="c in previews.comentarios" :key="c.id || (c.record && c.record.id)">
                  <td>{{ c.usuario_id || c.user || c.userId || (c.record && (c.record.usuario_id || c.record.user)) || '-' }}</td>
                  <td>{{ c.piso_id || c.piso || c.pisoId || (c.record && (c.record.piso_id || c.record.piso)) || '-' }}</td>
                  <td class="muted">{{ c.coment || c.contenido || c.text || '-' }}</td>
                  <td>{{ c.rating || c.valoracion || '-' }}</td>
                  <td>{{ c.created || c.createdAt || '-' }}</td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="card-actions">
            <button class="btn" @click="goTo('AdminComentarios')">Ver los comentarios</button>
          </div>
        </div>
      </div>
    </main>

    </div>

    <!-- User Create Modal (dashboard) -->
    <div v-if="showUserCreate" class="modal-backdrop" @click.self="closeUserCreateModal">
      <div class="modal">
        <h3>Crear Usuario</h3>
        <button class="close" @click="closeUserCreateModal">×</button>
        <div class="modal-body">
          <form @submit.prevent="submitCreateUser">
            <div class="form-row">
              <label>Nombre</label>
              <input v-model="userForm.nombre" required />
            </div>
            <div class="form-row">
              <label>Apellidos</label>
              <input v-model="userForm.apellidos" />
            </div>
            <div class="form-row">
              <label>Username</label>
              <input v-model="userForm.username" required />
            </div>
            <div class="form-row">
              <label>Email</label>
              <input v-model="userForm.email" type="email" required />
            </div>
            <div class="form-row">
              <label>Password</label>
              <input v-model="userForm.password" type="password" required />
            </div>
            <div class="form-row">
              <label>Confirmar Password</label>
              <input v-model="userForm.passwordConfirm" type="password" required />
            </div>
            <div class="form-row">
              <label>Rol</label>
              <select v-model="userForm.rol" required>
                <option value="inquilino">inquilino</option>
                <option value="propietario">propietario</option>
                <option value="admin">admin</option>
              </select>
            </div>
            <div class="form-row">
              <label>Tel</label>
              <input v-model="userForm.tel" />
            </div>
            <div class="form-row">
              <label>Foto</label>
              <input type="file" @change="onUserImageChange" accept="image/*" />
            </div>

            <div style="margin-top:12px; display:flex; gap:8px; align-items:center">
              <button class="btn btn-primary" type="submit" :disabled="creatingUser">Crear</button>
              <button class="btn" type="button" @click="closeUserCreateModal">Cancelar</button>
              <div v-if="createError" class="muted" style="color:#a00">{{ createError }}</div>
            </div>
          </form>
        </div>
      </div>

        <!-- Piso Create Modal (dashboard) -->
        <div v-if="showPisoCreate" class="modal-backdrop" @click.self="closePisoCreateModal">
          <div class="modal">
            <h3>Crear Piso</h3>
            <button class="close" @click="closePisoCreateModal">×</button>
            <div class="modal-body">
              <form @submit.prevent="submitCreatePiso">
                <div class="form-row"><label>Título</label><input v-model="pisoForm.titulo" required /></div>
                <div class="form-row"><label>Dirección</label><input v-model="pisoForm.direccion" /></div>
                <div class="form-row"><label>Ciudad</label><input v-model="pisoForm.ciudad" /></div>
                <div class="form-row"><label>CP</label><input v-model="pisoForm.cp" /></div>
                <div class="form-row"><label>Precio</label><input v-model.number="pisoForm.precio" type="number" /></div>
                <div class="form-row"><label>Habitaciones</label><input v-model.number="pisoForm.num_habit" type="number" /></div>
                <div class="form-row"><label>Superficie</label><input v-model.number="pisoForm.superficie" type="number" /></div>
                <div class="form-row"><label>Descripción</label><textarea v-model="pisoForm.descripcion"></textarea></div>
                <div class="form-row"><label>Propietario</label>
                  <select v-model="pisoForm.propietario_id">
                    <option value="">-- seleccionar propietario --</option>
                    <option v-for="u in propietarios" :key="u.id" :value="u.id">{{ u.username || u.nombre || u.email || u.id }}</option>
                  </select>
                </div>
                <div class="form-row"><label>Foto principal</label><input type="file" accept="image/*" @change="onPisoImageChange" /></div>

                <div style="margin-top:12px; display:flex; gap:8px; align-items:center">
                  <button class="btn btn-primary" type="submit" :disabled="creatingPiso">Crear</button>
                  <button class="btn" type="button" @click="closePisoCreateModal">Cancelar</button>
                  <div v-if="createPisoError" class="muted" style="color:#a00">{{ createPisoError }}</div>
                </div>
              </form>
            </div>
          </div>
        </div>
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import randomAvatar from '@/images/users/random.png'
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const loggingOut = ref(false)
const avatarSrc = ref(randomAvatar)

function loadAvatar() {
  try {
    const raw = localStorage.getItem('currentUser')
    if (!raw) return
    const u = JSON.parse(raw)
    if (u.avatarUrl) { avatarSrc.value = u.avatarUrl; return }
    if (u.image) {
      if (Array.isArray(u.image) && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image[0]}`
        return
      }
      if (typeof u.image === 'string' && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image}`
        return
      }
    }
    // try to fetch fresh profile if needed
    const userId = u.id || localStorage.getItem('userId')
    if (!userId) return
    fetch(`/api/perfil/${userId}`).then(r => r.json()).then(json => {
      if (json && json.image && Array.isArray(json.image) && json.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${json.id}/${json.image[0]}`
        try { localStorage.setItem('currentUser', JSON.stringify(json)) } catch (e) {}
      }
    }).catch(() => {})
  } catch (e) {}
}

const handleLogout = async () => {
  loggingOut.value = true
  try { await fetch('/api/auth/logout', { method: 'POST' }) } catch (e) { console.error('Logout failed', e) }
  try { localStorage.removeItem('currentUser') } catch (e) {}
  try { localStorage.removeItem('pb_token') } catch (e) {}
  try { localStorage.removeItem('userId') } catch (e) {}
  try { localStorage.removeItem('userRole') } catch (e) {}
  loggingOut.value = false
  router.push({ name: 'home' })
}

onMounted(() => { loadAvatar(); window.addEventListener('storage', loadAvatar) })

const counts = ref({ users: 0, pisos: 0, comentarios: 0, reservas: 0 })
const loading = ref(false)
const previews = ref({ users: [], pisos: [], reservas: [], comentarios: [] })

// Piso create modal state
const showPisoCreate = ref(false)
const creatingPiso = ref(false)
const createPisoError = ref('')
const pisoImageFile = ref(null)
const pisoForm = ref({ titulo:'', direccion:'', ciudad:'', cp:'', precio:0, num_habit:1, superficie:0, descripcion:'', propietario_id: '' })
const propietarios = ref([])

// --- User create modal state ---
const showUserCreate = ref(false)
const creatingUser = ref(false)
const createError = ref('')
const imageFile = ref(null)
const userForm = ref({
  nombre: '',
  apellidos: '',
  username: '',
  email: '',
  password: '',
  passwordConfirm: '',
  rol: 'inquilino',
  tel: ''
})

function openUserCreateModal() {
  createError.value = ''
  imageFile.value = null
  userForm.value = { nombre:'', apellidos:'', username:'', email:'', password:'', passwordConfirm:'', rol:'inquilino', tel: '' }
  showUserCreate.value = true
}

function openPisoCreateModal() {
  createPisoError.value = ''
  pisoImageFile.value = null
  pisoForm.value = { titulo:'', direccion:'', ciudad:'', cp:'', precio:0, num_habit:1, superficie:0, descripcion:'', propietario_id: '' }
  // fetch propietarios list
  const token = localStorage.getItem('pb_token')
  const headers = token ? { 'Authorization': `Bearer ${token}` } : {}
  fetch('/api/users?limit=1000', { headers }).then(r => r.json()).then(j => {
    const items = Array.isArray(j) ? j : (j.items || [])
    propietarios.value = items.filter(u => (u.rol === 'propietario' || u.role === 'propietario' || u.userRole === 'propietario'))
  }).catch(() => { propietarios.value = [] })
  showPisoCreate.value = true
}

function closePisoCreateModal() { showPisoCreate.value = false }

function onPisoImageChange(e) {
  const f = e.target && e.target.files && e.target.files[0]
  if (f) pisoImageFile.value = f
}

async function submitCreatePiso() {
  try {
    createPisoError.value = ''
    if (!pisoForm.value.titulo) { createPisoError.value = 'Título requerido'; return }
    creatingPiso.value = true
    const fd = new FormData()
    Object.entries(pisoForm.value).forEach(([k,v]) => { if (v !== undefined && v !== null && String(v) !== '') fd.append(k, String(v)) })
    if (pisoImageFile.value) fd.append('imagen', pisoImageFile.value, pisoImageFile.value.name)
    const token = localStorage.getItem('pb_token')
    const opts = { method: 'POST', body: fd }
    if (token) opts.headers = { 'Authorization': `Bearer ${token}` }
    const resp = await fetch('/api/pisos', opts)
    if (resp.ok) {
      try { await fetchPreviews() } catch (e) {}
      try { await fetchCounts() } catch (e) {}
      closePisoCreateModal()
      // navigate to admin pisos list so admin sees the created piso in full list
      try { router.push({ name: 'AdminPisos' }).catch(() => {}) } catch (e) {}
    } else {
      let txt = await resp.text()
      try { const j = JSON.parse(txt); createPisoError.value = j.error || j.message || JSON.stringify(j) } catch { createPisoError.value = txt || 'Error creando piso' }
    }
  } catch (err) { createPisoError.value = err?.message || String(err) }
  finally { creatingPiso.value = false }
}

function closeUserCreateModal() {
  showUserCreate.value = false
}

function onUserImageChange(e) {
  const f = e.target && e.target.files && e.target.files[0]
  if (f) imageFile.value = f
}

async function submitCreateUser() {
  try {
    createError.value = ''
    if (!userForm.value.username || !userForm.value.email || !userForm.value.password) {
      createError.value = 'Completa los campos obligatorios'
      return
    }
    if (userForm.value.password !== userForm.value.passwordConfirm) {
      createError.value = 'Las contraseñas no coinciden'
      return
    }

    creatingUser.value = true
    const fd = new FormData()
    // append all fields as strings
    Object.entries(userForm.value).forEach(([k, v]) => {
      if (v !== undefined && v !== null) fd.append(k, String(v))
    })
    if (imageFile.value) {
      fd.append('image', imageFile.value, imageFile.value.name)
    }

    const resp = await fetch('/api/auth/register', { method: 'POST', body: fd })
    if (resp.ok) {
      // success — refresh previews and counts
      try { await fetchPreviews() } catch (e) {}
      try { await fetchCounts() } catch (e) {}
      closeUserCreateModal()
    } else {
      // try read json
      let txt = await resp.text()
      try {
        const j = JSON.parse(txt)
        createError.value = j.error || j.message || JSON.stringify(j)
      } catch (e) {
        createError.value = txt || 'Error creando usuario'
      }
    }
  } catch (err) {
    createError.value = err?.message || String(err)
  } finally {
    creatingUser.value = false
  }
}

async function fetchPreviews() {
  try {
    const token = localStorage.getItem('pb_token')
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {}
    const [uRes, pRes, rRes, cRes] = await Promise.all([
      fetch('/api/users?limit=6', { headers }).catch(() => null),
      fetch('/api/pisos?limit=6', { headers }).catch(() => null),
      fetch('/api/reservas?limit=6', { headers }).catch(() => null),
      fetch('/api/comentarios?limit=6', { headers }).catch(() => null)
    ])

    if (uRes && uRes.ok) {
      const u = await uRes.json()
      console.debug('adminView: /api/users preview response:', u)
      previews.value.users = Array.isArray(u) ? u.slice(0,6) : (u.items ? u.items.slice(0,6) : [])
    }
    if (pRes && pRes.ok) {
      const p = await pRes.json()
      console.debug('adminView: /api/pisos preview response:', p)
      previews.value.pisos = Array.isArray(p) ? p.slice(0,6) : (p.items ? p.items.slice(0,6) : [])
    }
    if (rRes && rRes.ok) {
      const r = await rRes.json()
      previews.value.reservas = Array.isArray(r) ? r.slice(0,6) : (r.items ? r.items.slice(0,6) : [])
    }
    if (cRes && cRes.ok) {
      const c = await cRes.json()
      previews.value.comentarios = Array.isArray(c) ? c.slice(0,6) : (c.items ? c.items.slice(0,6) : [])
    }
  } catch (e) {
    console.error('Error fetching previews', e)
  }
}

async function fetchCounts() {
  loading.value = true
  try {
    // try to fetch counts from likely endpoints; these are minimal and tolerant to errors
    const [usersRes, pisosRes, reservasRes, comenRes] = await Promise.all([
      fetch('/api/users').catch(() => ({ ok: false })),
      fetch('/api/pisos').catch(() => ({ ok: false })),
      fetch('/api/reservas').catch(() => ({ ok: false })),
      fetch('/api/comentarios').catch(() => ({ ok: false }))
    ])

    function extractCount(obj) {
      if (!obj) return 0
      if (Array.isArray(obj)) return obj.length
      if (typeof obj === 'object') {
        if (typeof obj.total === 'number') return obj.total
        if (typeof obj.totalItems === 'number') return obj.totalItems
        if (obj.items && Array.isArray(obj.items)) return obj.items.length
        if (obj.data && Array.isArray(obj.data)) return obj.data.length
        if (obj.meta && typeof obj.meta.total === 'number') return obj.meta.total
      }
      return 0
    }

    if (usersRes && usersRes.ok) {
      const u = await usersRes.json()
      console.debug('adminView: users count response', u)
      counts.value.users = extractCount(u)
    }
    if (pisosRes && pisosRes.ok) {
      const p = await pisosRes.json()
      console.debug('adminView: pisos count response', p)
      counts.value.pisos = extractCount(p)
    }
    if (reservasRes && reservasRes.ok) {
      const r = await reservasRes.json()
      counts.value.reservas = extractCount(r)
    }
    if (comenRes && comenRes.ok) {
      const c = await comenRes.json()
      counts.value.comentarios = extractCount(c)
    }
  } catch (e) {
    console.error('Error fetching admin counts', e)
  }
  loading.value = false
}

function goTo(routeName) {
  // navigation is optimistic; routes may not exist yet
  router.push({ name: routeName }).catch(() => {})
}

function refreshCounts() { fetchCounts() }

onMounted(fetchCounts)
onMounted(fetchPreviews)
</script>

<style scoped>
.admin-main {
  max-width: 1100px;
  margin: 24px auto;
  padding: 16px;
}
.page-title { margin: 0 0 8px; font-size: 1.6rem }
.lead { margin: 0 0 18px; color: #555 }
.admin-grid {
  display: grid;
  grid-template-columns: 45% 55%;
  grid-template-rows: auto auto;
  gap: 18px;
  align-items: start;
}
.admin-card {
  background: #fff;
  border-radius: 10px;
  padding: 16px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.06);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.users-card { grid-column: 1 / 2; }
.pisos-card { grid-column: 2 / 3; }
.reservas-card { grid-column: 1 / 2; }
.comentarios-card { grid-column: 2 / 3; }

/* Tables in cards should scroll horizontally if too wide */
.card-body { overflow: auto; max-height: 260px }
.preview-table { width: 100%; border-collapse: collapse }
.preview-table th, .preview-table td { padding: 6px 8px; border-bottom: 1px solid #eee; font-size: 0.95rem }
.preview-table thead th { background: transparent; text-align: left; font-weight: 600 }
.admin-card h3 { margin: 0 0 8px }
.count { font-size: 1.8rem; color: #222; margin: 0 0 12px }
  .card-actions { display:flex; gap:8px }

.user-avatar-small { width: 50px !important; height: 50px !important; border-radius: 50%; object-fit: cover }

/* Sidebar */
.admin-layout { display: flex; min-height: calc(100vh - 120px) }
.admin-sidebar {
  width: 220px; background: #0b57b7; color: white; padding: 18px 12px; box-sizing: border-box;
}
.admin-sidebar .brand { font-weight: 700; font-size: 1.2rem; margin-bottom: 18px }
.side-nav .nav-item { display:block; color: rgba(255,255,255,0.9); padding: 8px 10px; border-radius:4px; margin-bottom:6px }
.side-nav .nav-item.router-link-active { background: rgba(255,255,255,0.08) }
.admin-main { flex: 1; background: #f6f8fb; padding: 22px }

/* Card header badge */
.card-head { display:flex; justify-content:space-between; align-items:center }
.head-left { display:flex; align-items:center; gap:12px }
.badge { background: #1070d3; color: white; padding: 6px 10px; border-radius: 20px; font-weight:600 }

/* preview table */
.preview-table { width:100%; border-collapse: collapse }
.preview-table th, .preview-table td { padding: 8px 10px; border-bottom: 1px solid rgba(0,0,0,0.06) }
.preview-table thead th { font-weight:600; font-size: 0.95rem }

@media (max-width: 900px) {
  .admin-layout { flex-direction: column }
  .admin-sidebar { width: 100%; }
  .admin-main { padding: 12px }
}

@media (max-width: 900px) {
  .admin-grid { grid-template-columns: 1fr; }
  .users-card, .pisos-card, .reservas-card, .comentarios-card { grid-column: auto }
  .card-body { max-height: 220px }
}

/* Modal (create user) styles */
.modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.4); display:flex; align-items:center; justify-content:center; z-index:50 }
.modal { background: white; border-radius:8px; padding:16px; width:720px; max-width:95%; position:relative }
.modal h3 { margin:0 0 12px }
.modal .close { position:absolute; right:8px; top:8px; background:transparent; border:0; font-size:20px }
.modal .modal-body { max-height:70vh; overflow:auto }
.form-row { display:flex; flex-direction:column; margin-bottom:8px }
.form-row label { font-size:0.9rem; margin-bottom:6px }
.form-row input, .form-row select { padding:8px; border:1px solid #ddd; border-radius:6px }
</style>
