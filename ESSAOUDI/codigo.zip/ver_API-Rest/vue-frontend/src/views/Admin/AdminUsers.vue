<template>
  <AdminLayout>
    <template #default>
      <div class="admin-users">
        <h1>Usuarios — Gestión</h1>
        <p>Lista completa de todos los usuarios. Puedes cambiar rol, ver mas detalles, actualizar o eliminar usuarios desde aquí.</p>

        <div class="actions">
          <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap">
            <input v-model="searchId" placeholder="Buscar por ID" style="padding:6px; width:220px;" />
            <select v-model="filterRole" style="padding:6px; width:180px">
              <option value="">Todos los roles</option>
              <option value="admin">admin</option>
              <option value="propietario">propietario</option>
              <option value="inquilino">inquilino</option>
            </select>
            <button class="btn" @click="applyFilters">Buscar</button>
            <button class="btn" @click="clearFilters">Limpiar</button>
            <button class="btn" @click="loadUsers">Refrescar</button>
          </div>
        </div>

        <table class="users-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Apellidos</th>
              <th>Username</th>
              <th>Rol</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="u in users" :key="u.id">
              <td>{{ u.id || (u.record && u.record.id) || '-' }}</td>
              <td>{{ u.nombre || u.name || (u.record && (u.record.nombre || u.record.name)) || '-' }}</td>
              <td>{{ u.apellidos || u.lastName || (u.record && u.record.apellidos) || '-' }}</td>
              <td>{{ u.username || u.user || (u.record && u.record.username) || '-' }}</td>
              <td>{{ u.rol || u.role || u.userRole || (u.record && u.record.rol) || '-' }}</td>
              <td>
                <button class="btn" @click="showDetails(u)">Detalles</button>
                <button class="btn" @click="promote(u)">Hacer admin</button>
                <button class="btn btn-danger" @click="removeUser(u)">Eliminar</button>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- Pagination controls -->
        <div class="pagination" style="display:flex; gap:8px; align-items:center; margin-top:12px">
          <button class="btn" :disabled="page <= 1" @click="goPrev">Anterior</button>
          <div> Página {{ page }} de {{ totalPages }} — {{ totalItems }} usuarios </div>
          <button class="btn" :disabled="page >= totalPages" @click="goNext">Siguiente</button>
        </div>

        <!-- Details modal -->
        <div v-if="selectedUser" class="modal-backdrop" @click.self="selectedUser = null">
          <div class="modal">
            <h3>Usuario — {{ selectedUser.id || selectedUser.username || '-' }}</h3>
            <button class="close" @click="selectedUser = null">×</button>
            <div class="modal-body">
              <table class="details-table">
                <tbody>
                  <tr v-for="(val, key) in userDetails" :key="key">
                    <th>{{ key }}</th>
                    <td>{{ formatValue(val) }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </template>
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import AdminLayout from '@/components/Layout/AdminLayout.vue'
const users = ref([])
const loading = ref(false)
const selectedUser = ref(null)
const searchId = ref('')
const filterRole = ref('')
const page = ref(1)
const perPage = ref(10)
const totalPages = ref(1)
const totalItems = ref(0)
// edit modal removed — no edit state required

const userDetails = computed(() => {
  const u = selectedUser.value || {};
  // flatten .record wrapper if present
  const src = u.record ? { ...u.record, ...u } : u;
  // keys to exclude from detailed view
  const exclude = new Set(['email', 'password', 'passwordConfirm', 'pass', 'pwd']);
  return Object.keys(src)
    .filter(k => !exclude.has(k))
    .reduce((acc, k) => {
      acc[k] = src[k];
      return acc;
    }, {});
})

function formatValue(v) {
  if (v === null || v === undefined) return '-'
  if (typeof v === 'object') return JSON.stringify(v)
  return String(v)
}

async function loadUsers() {
  loading.value = true
  try {
    const params = new URLSearchParams()
    const idVal = (searchId.value || '').toString().trim()
    const roleVal = (filterRole.value || '').toString().trim()
    if (idVal) params.set('id', idVal)
    if (roleVal) params.set('rol', roleVal)
    params.set('page', String(page.value))
    params.set('perPage', String(perPage.value))
    const url = '/api/users' + (params.toString() ? ('?' + params.toString()) : '')
    const res = await fetch(url)
    const json = await res.json()
    if (Array.isArray(json)) {
      users.value = json
      totalItems.value = json.length
      totalPages.value = 1
      page.value = 1
      perPage.value = json.length
    } else {
      users.value = json.items || []
      page.value = json.page || page.value
      perPage.value = json.perPage || perPage.value
      totalItems.value = json.totalItems || totalItems.value
      totalPages.value = json.totalPages || totalPages.value
    }
  } catch (e) {
    console.error('Error loading users', e)
    users.value = []
  }
  loading.value = false
}

function applyFilters() {
  page.value = 1
  loadUsers()
}

function clearFilters() {
  searchId.value = ''
  filterRole.value = ''
  loadUsers()
}

function goPrev() {
  if (page.value > 1) { page.value -= 1; loadUsers() }
}

function goNext() {
  if (page.value < totalPages.value) { page.value += 1; loadUsers() }
}

async function promote(user) {
  if (!confirm(`Promover ${user.email || user.username || user.id} a admin?`)) return
  try {
    // PocketBase schema uses `rol` (spanish) for role — send `rol: 'admin'`
    const res = await fetch(`/api/users/${user.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rol: 'admin' })
    })
    if (res.ok) {
      alert('Usuario promovido a admin')
      await loadUsers()
    } else {
      const err = await res.text()
      alert('Error promocionando: ' + err)
    }
  } catch (e) {
    console.error(e)
    alert('Error promocionando usuario')
  }
}

async function removeUser(user) {
  if (!confirm(`Eliminar usuario ${user.email || user.username || user.id}?`)) return
  try {
    const res = await fetch(`/api/users/${user.id}`, { method: 'DELETE' })
    if (res.ok) {
      alert('Usuario eliminado')
      await loadUsers()
    } else {
      const err = await res.text()
      alert('Error eliminando: ' + err)
    }
  } catch (e) {
    console.error(e)
    alert('Error eliminando usuario')
  }
}

onMounted(loadUsers)

function showDetails(user) {
  selectedUser.value = user
}

// edit handlers removed per user request
</script>

<style scoped>
.admin-users { max-width: 1100px; margin: 18px auto; }
.users-table { width: 100%; border-collapse: collapse }
.users-table th, .users-table td { padding: 8px 10px; border-bottom: 1px solid #eee }
.actions { margin-bottom: 12px }

/* Modal styles */
.modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.4); display:flex; align-items:center; justify-content:center; z-index:50 }
.modal { background: white; border-radius:8px; padding:16px; width:720px; max-width:95%; position:relative }
.modal h3 { margin:0 0 12px }
.modal .close { position:absolute; right:8px; top:8px; background:transparent; border:0; font-size:20px }
.details-table { width:100%; border-collapse:collapse }
.details-table th { text-align:left; padding:6px 8px; width:160px; vertical-align:top }
.details-table td { padding:6px 8px }

/* Add spacing between action buttons in table rows */
.users-table td > .btn { margin-right: 8px }
</style>
