<template>
  <AdminLayout>
    <template #default>
      <div class="pisos-admin">
        <h2>Gestión de Pisos</h2>
        <p>Placeholder para la gestión de pisos (crear, editar, eliminar).</p>
        <div class="top-actions">
          <button class="btn" @click="refresh">Refrescar</button>
          <button class="btn" @click="openCreatePisoModal">Crear anuncio</button>
        </div>
        <!-- Details modal (popup emergente) -->
        <div v-if="selectedPiso" class="modal-backdrop" @click.self="closeDetails">
          <div class="modal">
            <button class="close" @click="closeDetails" aria-label="Cerrar">×</button>
            <div class="modal-header">
              <h3>Piso — {{ selectedPiso.id || '-' }}</h3>
              <div class="meta">{{ selectedPiso.titulo || selectedPiso.nombre || '' }}</div>
            </div>
            <div class="modal-body">
              <div class="modal-grid">
                <div class="modal-image" v-if="imageUrl">
                  <img :src="imageUrl" alt="Imagen del piso" />
                </div>
                <div class="modal-info">
                  <table class="details-table">
                    <tbody>
                      <tr v-for="(val, key) in pisoDetails" :key="key">
                        <th>{{ key }}</th>
                        <td>{{ formatValue(val) }}</td>
                      </tr>
                    </tbody>
                  </table>
                    
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Create Piso Modal -->
        <div v-if="showCreate" class="modal-backdrop" @click.self="closeCreatePisoModal">
          <div class="modal">
            <button class="close" @click="closeCreatePisoModal" aria-label="Cerrar">×</button>
            <h3>Crear Piso</h3>
            <div class="modal-body">
              <form @submit.prevent="submitCreatePisoModal">
                <div class="form-row"><label>Título</label><input v-model="pisoFormModal.titulo" required /></div>
                <div class="form-row"><label>Dirección</label><input v-model="pisoFormModal.direccion" /></div>
                <div class="form-row"><label>Ciudad</label><input v-model="pisoFormModal.ciudad" /></div>
                <div class="form-row"><label>CP</label><input v-model="pisoFormModal.cp" /></div>
                <div class="form-row"><label>Precio</label><input v-model.number="pisoFormModal.precio" type="number" /></div>
                <div class="form-row"><label>Habitaciones</label><input v-model.number="pisoFormModal.num_habit" type="number" /></div>
                <div class="form-row"><label>Superficie</label><input v-model.number="pisoFormModal.superficie" type="number" /></div>
                <div class="form-row"><label>Descripción</label><textarea v-model="pisoFormModal.descripcion"></textarea></div>
                <div class="form-row"><label>Propietario</label>
                  <select v-model="pisoFormModal.propietario_id">
                    <option value="">-- seleccionar propietario --</option>
                    <option v-for="u in propietarios" :key="u.id" :value="u.id">{{ u.username || u.nombre || u.email || u.id }}</option>
                  </select>
                </div>
                <div class="form-row"><label>Imágenes (máx. 5)</label>
                  <input type="file" accept="image/*" multiple @change="onCreateImagesChange" />
                  <div class="image-previews" v-if="pisoImageFiles && pisoImageFiles.length">
                    <div class="preview" v-for="(p, idx) in pisoImageFiles" :key="idx">
                      <img :src="p.preview" alt="preview" />
                      <button type="button" class="btn btn-small" @click="removeImage(idx)">Eliminar</button>
                    </div>
                  </div>
                </div>

                <div style="margin-top:12px; display:flex; gap:8px; align-items:center">
                  <button class="btn btn-primary" type="submit" :disabled="creating">{{ creating ? 'Creando...' : 'Crear' }}</button>
                  <button class="btn" type="button" @click="closeCreatePisoModal">Cancelar</button>
                  <div v-if="createError" class="muted" style="color:#a00">{{ createError }}</div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div v-if="loading">Cargando pisos...</div>
        <div v-else>
          <table class="users-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Dirección</th>
                <th>Ciudad</th>
                <th>Propietario</th>
                <th>Precio</th>
                <th>Habit.</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="p in pisos" :key="p.id">
                <td>{{ p.id }}</td>
                <td>{{ p.titulo || '-' }}</td>
                <td>{{ p.direccion || '-' }}</td>
                <td>{{ p.ciudad || '-' }}</td>
                <td>
                  {{ (p.expand && p.expand.propietario_id && (p.expand.propietario_id.username || p.expand.propietario_id.nombre))
                    || (p.expand && p.expand.propietario && (p.expand.propietario.username || p.expand.propietario.nombre))
                    || p.propietario_name || p.propietario || p.propietario_id || '-'
                  }}
                </td>
                <td>{{ p.precio !== undefined ? p.precio : '-' }}</td>
                <td>{{ p.num_habit || '-' }}</td>
                <td>
                  <button class="btn" @click="showDetails(p)">Detalles</button>
                  <button class="btn btn-danger" @click="removePiso(p)">Eliminar</button>
                </td>
              </tr>
            </tbody>
          </table>
          <!-- Pagination controls -->
          <div class="pagination" style="display:flex; gap:8px; align-items:center; margin-top:12px">
            <button class="btn" :disabled="page <= 1" @click="goPrev">Anterior</button>
            <div> Página {{ page }} de {{ totalPages }} — {{ totalItems }} pisos </div>
            <button class="btn" :disabled="page >= totalPages" @click="goNext">Siguiente</button>
          </div>
        </div>
      </div>
    </template>
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, computed } from 'vue'
import AdminLayout from '@/components/Layout/AdminLayout.vue'
const pisos = ref([])
const loading = ref(false)
const page = ref(1)
const perPage = ref(10)
const totalPages = ref(1)
const totalItems = ref(0)
// edit modal removed - no local edit state

async function loadPisos() {
  loading.value = true
  try {
    const token = localStorage.getItem('pb_token')
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {}
    const params = new URLSearchParams()
    params.set('page', String(page.value))
    params.set('perPage', String(perPage.value))
    const url = '/api/pisos' + (params.toString() ? ('?' + params.toString()) : '')
    const res = await fetch(url, { headers })
    const json = await res.json()
    if (Array.isArray(json)) {
      pisos.value = json
      totalItems.value = json.length
      totalPages.value = 1
      page.value = 1
      perPage.value = json.length
    } else {
      pisos.value = json.items || []
      page.value = json.page || page.value
      perPage.value = json.perPage || perPage.value
      totalItems.value = json.totalItems || totalItems.value
      totalPages.value = json.totalPages || totalPages.value
    }
  } catch (e) {
    console.error('Error loading pisos', e)
    pisos.value = []
  }
  loading.value = false
}

function refresh() { loadPisos() }
onMounted(loadPisos)

function goPrev() { if (page.value > 1) { page.value -= 1; loadPisos() } }
function goNext() { if (page.value < totalPages.value) { page.value += 1; loadPisos() } }

const selectedPiso = ref(null)

// Create piso modal state
const showCreate = ref(false)
const creating = ref(false)
const createError = ref('')
const pisoFormModal = ref({ titulo:'', direccion:'', ciudad:'', cp:'', precio:0, num_habit:1, superficie:0, descripcion:'', propietario_id: '' })
const pisoImageFiles = ref([]) // array of { file, preview }
const propietarios = ref([])

function openCreatePisoModal() {
  createError.value = ''
    // clear selected files and previews
    pisoImageFiles.value.forEach(p => { try { URL.revokeObjectURL(p.preview) } catch {} })
    pisoImageFiles.value = []
  pisoFormModal.value = { titulo:'', direccion:'', ciudad:'', cp:'', precio:0, num_habit:1, superficie:0, descripcion:'', propietario_id: '' }
  // fetch propietarios
  const token = localStorage.getItem('pb_token')
  const headers = token ? { 'Authorization': `Bearer ${token}` } : {}
  fetch('/api/users?limit=1000', { headers }).then(r => r.json()).then(j => {
    const items = Array.isArray(j) ? j : (j.items || [])
    propietarios.value = items.filter(u => (u.rol === 'propietario' || u.role === 'propietario' || u.userRole === 'propietario'))
  }).catch(() => { propietarios.value = [] })
  showCreate.value = true
}

function closeCreatePisoModal() { showCreate.value = false }

function onCreateImagesChange(e) {
  const fl = e.target && e.target.files ? Array.from(e.target.files) : []
  if (!fl.length) return
  // limit to 5 images
  const max = 5
  const existing = pisoImageFiles.value.length
  const allowed = Math.max(0, max - existing)
  const take = fl.slice(0, allowed)
  take.forEach(f => {
    const preview = URL.createObjectURL(f)
    pisoImageFiles.value.push({ file: f, preview })
  })
}

function removeImage(idx) {
  const it = pisoImageFiles.value[idx]
  if (it && it.preview) try { URL.revokeObjectURL(it.preview) } catch {}
  pisoImageFiles.value.splice(idx, 1)
}

async function submitCreatePisoModal() {
  try {
    createError.value = ''
    if (!pisoFormModal.value.titulo) { createError.value = 'Título requerido'; return }
    creating.value = true

    const token = localStorage.getItem('pb_token')

    // First: create the piso without images (JSON). Backend will set propietario_id when appropriate.
    const datos = {}
    Object.entries(pisoFormModal.value).forEach(([k,v]) => { if (v !== undefined && v !== null && String(v) !== '') datos[k] = (k === 'precio' || k === 'num_habit' || k === 'superficie') ? Number(v) : v })

    const createResp = await fetch('/api/pisos', {
      method: 'POST',
      headers: token ? { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos)
    })

    if (!createResp.ok) {
      const txt = await createResp.text()
      try { const j = JSON.parse(txt); createError.value = j.error || j.message || JSON.stringify(j) } catch { createError.value = txt || 'Error creando piso' }
      return
    }

    const created = await createResp.json()

    // If there are images, upload them via PUT to the created record using multipart/form-data
    if (pisoImageFiles.value && pisoImageFiles.value.length) {
      const fd = new FormData()
      pisoImageFiles.value.forEach((p, i) => {
        // append multiple 'imagen' fields — backend should accept array
        fd.append('imagen', p.file, p.file.name)
      })
      const putResp = await fetch(`/api/pisos/${created.id}`, {
        method: 'PUT',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
        body: fd
      })

      if (!putResp.ok) {
        console.warn('Imágenes no subidas, pero el piso fue creado')
        try { const t = await putResp.text(); createError.value = t || createError.value } catch(e) {}
      }
      // cleanup previews
      pisoImageFiles.value.forEach(p => { try { URL.revokeObjectURL(p.preview) } catch {} })
      pisoImageFiles.value = []
    }

    // refresh list and close
    await loadPisos()
    closeCreatePisoModal()
  } catch (err) {
    createError.value = err?.message || String(err)
  } finally {
    creating.value = false
  }
}

function closeDetails() { selectedPiso.value = null }

// Close modal on Escape
function onKeydown(e) { if (e.key === 'Escape' && selectedPiso.value) closeDetails() }
onMounted(() => window.addEventListener('keydown', onKeydown))
onBeforeUnmount(() => window.removeEventListener('keydown', onKeydown))

function formatValue(v) {
  if (v === null || v === undefined) return '-'
  if (typeof v === 'object') return JSON.stringify(v)
  return String(v)
}

const pisoDetails = computed(() => {
  const p = selectedPiso.value || {}
  const src = p.record ? { ...p.record, ...p } : p
  const exclude = new Set(['expand', 'collectionId', 'collection_name', 'collectionName', 'imagen'])
  return Object.keys(src)
    .filter(k => !exclude.has(k))
    .reduce((acc, k) => { acc[k] = src[k]; return acc }, {})
})

// Show first image from `imagen` field (common PocketBase shape: array of filenames)
const imageUrl = computed(() => {
  const p = selectedPiso.value || {}
  // prefer p.record.imagen -> p.imagen
  const arr = (p.record && p.record.imagen) || p.imagen || null
  if (!arr) return null
  const first = Array.isArray(arr) ? arr[0] : (typeof arr === 'string' ? arr : null)
  if (!first) return null
  // if it's already a full URL, return it
  if (typeof first === 'string' && (first.startsWith('http://') || first.startsWith('https://') || first.startsWith('/')))
    return first

  // If it's a filename only, build a full PocketBase files URL.
  // Use the PocketBase base URL configured in the backend (default 127.0.0.1:8090)
  const PB_BASE = 'http://127.0.0.1:8090'
  const collection = p.collectionName || p.collection || p.collection_name || 'pisos'
  const recordId = p.id || (p.record && p.record.id) || ''
  if (!recordId) return null
  return `${PB_BASE.replace(/\/$/, '')}/api/files/${collection}/${recordId}/${encodeURIComponent(first)}`
})

async function showDetails(p) {
  try {
    const token = localStorage.getItem('pb_token')
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {}
    const res = await fetch(`/api/pisos/${p.id}`, { headers })
    if (res.ok) {
      const j = await res.json()
      selectedPiso.value = j
    } else {
      const t = await res.text()
      alert('Error cargando detalles: ' + t)
    }
  } catch (e) {
    console.error(e); alert('Error cargando detalles')
  }
}

async function removePiso(p) {
  if (!confirm(`Eliminar piso ${p.titulo || p.id}?`)) return
  try {
    const token = localStorage.getItem('pb_token')
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {}
    const res = await fetch(`/api/pisos/${p.id}`, { method: 'DELETE', headers })
    if (res.ok) { alert('Piso eliminado'); await loadPisos() }
    else { const t = await res.text(); alert('Error eliminando piso: ' + t) }
  } catch (e) { console.error(e); alert('Error eliminando piso') }
}

// edit handlers removed per user request
</script>

<style scoped>
.pisos-admin { max-width: 1000px; margin: 18px auto; }

.users-table { width:100%; border-collapse: collapse }
.users-table th, .users-table td { padding: 8px 10px; border-bottom: 1px solid #eee }
.users-table th { text-align:left }

.details-table { width:100%; border-collapse: collapse }
.details-table th { text-align:left; padding:6px 8px; width:160px; vertical-align:top }
.details-table td { padding:6px 8px }

/* edit modal styles removed */
/* Modal popup styles */
.modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1100;
  padding: 20px;
}
.modal {
  background: #fff;
  border-radius: 8px;
  max-width: 900px;
  width: 100%;
  max-height: 90vh;
  overflow: auto;
  box-shadow: 0 10px 30px rgba(0,0,0,0.3);
  position: relative;
  padding: 18px;
}
.modal-header { display:flex; align-items:baseline; justify-content:space-between; gap:12px }
.modal-header h3 { margin:0 }
.modal .meta { color:#666; font-size:0.95rem }
.modal-grid { display:flex; gap:16px; align-items:flex-start }
.modal-image { flex:0 0 320px }
.modal-image img { width:100%; height:auto; border-radius:6px; object-fit:cover }
.modal-info { flex:1 1 auto }
.close { position:absolute; top:10px; right:12px; background:transparent; border:none; font-size:22px; cursor:pointer }

@media (max-width:720px) {
  .modal-grid { flex-direction:column }
  .modal-image { flex: none; width:100% }
}

.users-table td > .btn { margin-right: 8px }
.pisos-admin > div > .btn { margin-right: 8px }
/* Generic card-actions spacing (in case used) */
.card-actions .btn { margin-right: 8px }

.image-previews { display:flex; gap:8px; margin-top:8px; flex-wrap:wrap }
.image-previews .preview { position:relative; width:100px; height:80px; border:1px solid #eee; border-radius:6px; overflow:hidden; display:flex; align-items:center; justify-content:center }
.image-previews .preview img { width:100%; height:100%; object-fit:cover }
.btn-small { padding:4px 6px; font-size:12px; position:absolute; right:6px; top:6px; background:rgba(0,0,0,0.6); color:#fff; border:none; border-radius:4px; cursor:pointer }
</style>
