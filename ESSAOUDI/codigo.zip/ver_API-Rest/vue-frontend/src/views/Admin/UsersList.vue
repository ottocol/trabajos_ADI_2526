<template>
  <div class="users-admin">
    <h2>Gestión de Usuarios</h2>
    <p>Listado y acciones sobre los usuarios. Esta es una vista placeholder; implementar CRUD aquí.</p>
    <div>
      <button class="btn" @click="refresh">Refrescar</button>
    </div>
    <div v-if="loading">Cargando usuarios...</div>
    <ul v-else>
      <li v-for="u in users" :key="u.id">{{ u.email || u.username || u.id }} - <strong>{{ u.role || u.userRole || '—' }}</strong></li>
    </ul>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
const users = ref([])
const loading = ref(false)

async function loadUsers() {
  loading.value = true
  try {
    const res = await fetch('/api/users')
    const json = await res.json()
    users.value = Array.isArray(json) ? json : (json.items || [])
  } catch (e) {
    console.error('Error loading users', e)
    users.value = []
  }
  loading.value = false
}

function refresh() { loadUsers() }
onMounted(loadUsers)
</script>

<style scoped>
.users-admin { max-width: 900px; margin: 18px auto; }
</style>
