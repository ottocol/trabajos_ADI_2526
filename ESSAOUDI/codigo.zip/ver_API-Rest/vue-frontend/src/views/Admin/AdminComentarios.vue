<template>
  <AdminLayout>
    <template #default>
      <div class="admin-comentarios">
        <h1>Comentarios — Gestión</h1>
        <p>Lista de comentarios.</p>
        <div class="actions">
          <div style="display:flex; gap:10px; align-items:center; flex-wrap:nowrap;">
            <input v-model="searchId" placeholder="Buscar por ID de comentario" style="padding:6px; width:220px;" />
            <input v-model="filterPiso" placeholder="Filtrar por piso_id" style="padding:6px; width:220px;" />
            <input v-model="filterInquilino" placeholder="Filtrar por inquilino_id" style="padding:6px; width:220px;" />
            <button class="btn" @click="applyFilters">Buscar</button>
            <button class="btn" @click="clearFilters">Limpiar</button>
            <button class="btn" @click="load">Refrescar</button>
          </div>
        </div>

        <table class="c-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Usuario</th>
              <th>Piso</th>
              <th>Contenido</th>
              <th>Valoración</th>
              <th>Creado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="c in comentarios" :key="c.id || (c.record && c.record.id)">
              <td>{{ c.id || c._id || (c.record && c.record.id) || '-' }}</td>
              <td>
                {{
                  c.usuario_id || c.usuario || c.user || c.userId ||
                  (c.record && (c.record.usuario_id || c.record.user || c.record.userId)) ||
                  (c.expand && c.expand.usuario_id && (c.expand.usuario_id.username || c.expand.usuario_id.nombre)) ||
                  '-'
                }}
              </td>
              <td>
                {{
                  c.piso_id || c.piso || c.pisoId ||
                  (c.record && (c.record.piso_id || c.record.piso || c.record.pisoId)) ||
                  (c.expand && c.expand.piso_id && (c.expand.piso_id.titulo || c.expand.piso_id.nombre)) ||
                  '-'
                }}
              </td>
              <td class="muted">{{ c.coment || c.contenido || c.text || '-' }}</td>
              <td>
                {{
                  (typeof (c.valoracion || c.rating || (c.record && c.record.valoracion)) === 'number')
                    ? (String(c.valoracion ?? c.rating ?? (c.record && c.record.valoracion)) + '/5')
                    : ( (c.valoracion || c.rating) ? (c.valoracion || c.rating) + '/5' : '-' )
                }}
              </td>
              <td>{{ formatDate(c.created || c.createdAt || (c.record && c.record.created)) }}</td>
              <td>
                <button class="btn btn-danger" @click="remove(c)">Eliminar</button>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- Pagination controls -->
        <div class="pagination" style="display:flex; gap:8px; align-items:center; margin-top:12px">
          <button class="btn" :disabled="page <= 1" @click="goPrev">Anterior</button>
          <div> Página {{ page }} de {{ totalPages }} — {{ totalItems }} comentarios </div>
          <button class="btn" :disabled="page >= totalPages" @click="goNext">Siguiente</button>
        </div>
      </div>
    </template>
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import AdminLayout from '@/components/Layout/AdminLayout.vue'
const comentarios = ref([])
const loading = ref(false)
const searchId = ref('')
const filterPiso = ref('')
const filterInquilino = ref('')
const page = ref(1)
const perPage = ref(10)
const totalPages = ref(1)
const totalItems = ref(0)

function formatDate(v) {
  if (!v) return '-'
  try {
    const d = new Date(v)
    if (isNaN(d.getTime())) return String(v)
    return d.toLocaleString()
  } catch (e) { return String(v) }
}

async function load() {
  loading.value = true
  try {
    // build query params from filters
    const params = new URLSearchParams()
    if (searchId.value) params.set('id', searchId.value)
    if (filterPiso.value) params.set('piso_id', filterPiso.value)
    if (filterInquilino.value) params.set('inquilino_id', filterInquilino.value)
    params.set('page', String(page.value))
    params.set('perPage', String(perPage.value))
    const url = '/api/comentarios' + (params.toString() ? ('?' + params.toString()) : '')
    const res = await fetch(url)
    const json = await res.json()
    if (Array.isArray(json)) {
      comentarios.value = json
      totalItems.value = json.length
      totalPages.value = 1
      page.value = 1
      perPage.value = json.length
    } else {
      comentarios.value = json.items || []
      page.value = json.page || page.value
      perPage.value = json.perPage || perPage.value
      totalItems.value = json.totalItems || totalItems.value
      totalPages.value = json.totalPages || totalPages.value
    }
  } catch (e) {
    console.error('Error loading comentarios', e)
    comentarios.value = []
  }
  loading.value = false
}

function applyFilters() {
  page.value = 1
  load()
}

function clearFilters() {
  searchId.value = ''
  filterPiso.value = ''
  filterInquilino.value = ''
  page.value = 1
  load()
}

function goPrev() {
  if (page.value > 1) { page.value -= 1; load() }
}

function goNext() {
  if (page.value < totalPages.value) { page.value += 1; load() }
}

async function remove(c) {
  if (!confirm('Eliminar comentario ' + c.id + '?')) return
  try {
    const res = await fetch(`/api/comentarios/${c.id}`, { method: 'DELETE' })
    if (res.ok) await load()
    else alert('Error eliminando')
  } catch (e) { console.error(e); alert('Error eliminando') }
}

onMounted(load)
</script>

<style scoped>
.admin-comentarios { max-width: 1100px; margin: 18px auto }
.c-table th, .c-table td { padding: 8px 10px; border-bottom: 1px solid #eee }
</style>
