<template>
  <div class="home-view">
    <AppHeader>
      <template #buttons>
        <button @click="handleMisReservas" class="btn">Mis Reservas</button>
        <router-link to="/login" class="btn">Login</router-link>
        <router-link to="/registro" class="btn btn-primary">Registrar</router-link>
      </template>
    </AppHeader>

    <div class="main-layout">
      <main class="anuncios-container">

        <!-- Debug temporal -->
        <div class="debug-box" v-if="debug">
          <p><strong>Debug:</strong> items count = {{ items.length }}</p>
          <pre>{{ JSON.stringify(items, null, 2) }}</pre>
        </div>

        <template v-if="loading">
          <p>Cargando pisos...</p>
        </template>

        <template v-else-if="items.length === 0">
          <p>No hay pisos disponibles.</p>
        </template>

        <!-- Tarjetas -->
        <template v-else>
          <div class="cards-grid">
            <div v-for="(item, idx) in items" :key="item.id" class="anuncio-card">
              
              <img :src="getImage(item, idx)"
                   :alt="item.titulo"
                   class="anuncio-img">

              <div class="anuncio-info">
                <h3 class="titulo">{{ item.titulo }}</h3>

                <p class="descripcion" v-if="item.descripcion">
                  {{ item.descripcion }}
                </p>

                <p><strong>Dirección:</strong> {{ item.direccion }}</p>

                <p class="precio">
                  {{ formatPrice(item.precio) }}
                </p>

                <router-link 
                  :to="{ name: 'PisoDetalle', params: { id: item.id }}"
                  class="btn-ver-detalle">
                  Ver Detalles
                </router-link>
              </div>

            </div>
          </div>
        </template>

        <!-- Pagination controls -->
        <div v-if="!loading && items.length" style="display:flex; gap:8px; align-items:center; justify-content:center; margin:18px 0">
          <button class="btn" :disabled="page <= 1" @click="goPrev">Anterior</button>
          <div> Página {{ page }} de {{ totalPages }} — {{ totalItems }} pisos </div>
          <button class="btn" :disabled="page >= totalPages" @click="goNext">Siguiente</button>
        </div>

      </main>

      <FiltersPanel />
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref, onMounted, provide } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import FiltersPanel from '@/components/Layout/FiltersPanel.vue'

const router = useRouter()
const authStore = useAuthStore()

const items = ref([])
const loading = ref(false)
const debug = ref(false)
const page = ref(1)
const perPage = ref(9)
const totalPages = ref(1)
const totalItems = ref(0)

const filtros = ref({})

// PROPORCIONA los filtros al FiltersPanel
provide('filtros', filtros)

function formatPrice(p) {
  return p ? `${p} € / noche` : ''
}

function getImage(item, idx = 0) {
  if (item.primeraImagen) return item.primeraImagen

  const localImages = [
    '/images/house1.jpg',
    '/images/villa1.jpg',
    '/images/piso-ejemplo.jpeg',
    '/images/3.jpg'
  ]
  return localImages[idx % localImages.length]
}


const cargarPisos = async (filtrosAplicados = {}) => {
  loading.value = true
  try {
    // Construir query string con filtros
    const params = new URLSearchParams()
    
    // Añadir filtros a los parámetros
    if (filtrosAplicados.ciudad) params.append('ciudad', filtrosAplicados.ciudad)
    if (filtrosAplicados.precioMin) params.append('precioMin', filtrosAplicados.precioMin)
    if (filtrosAplicados.precioMax) params.append('precioMax', filtrosAplicados.precioMax)
    if (filtrosAplicados.habitaciones) params.append('num_habit', filtrosAplicados.habitaciones)
    if (filtrosAplicados.tipo) params.append('tipo_propiedad', filtrosAplicados.tipo)
    
    const queryString = params.toString()
    // include pagination params
    params.set('page', String(page.value))
    params.set('perPage', String(perPage.value))
    const url = params.toString() ? `/api/pisos?${params.toString()}` : '/api/pisos'

    const res = await fetch(url)
    const json = await res.json()

    if (Array.isArray(json)) {
      items.value = json
      totalItems.value = json.length
      totalPages.value = 1
      page.value = 1
      perPage.value = json.length
    } else if (json && json.items) {
      items.value = json.items || []
      page.value = json.page || page.value
      perPage.value = json.perPage || perPage.value
      totalItems.value = json.totalItems || totalItems.value
      totalPages.value = json.totalPages || totalPages.value
    }
  } catch (err) {
    console.error('Error cargando pisos', err)
  }
  loading.value = false
}

const manejarCambioFiltros = (nuevosFiltros) => {
  filtros.value = nuevosFiltros
  page.value = 1
  cargarPisos(nuevosFiltros)
}

// PROPORCIONA la función al FiltersPanel
provide('onFiltrosChange', manejarCambioFiltros)

// Handle Mis Reservas button click
const handleMisReservas = () => {
  if (authStore.isAuthenticated) {
    router.push('/mis-reservas')
  } else {
    router.push('/login')
  }
}

onMounted(() => {
  cargarPisos() // Cargar sin filtros inicialmente
})

// pagination helpers
function goPrev() { if (page.value > 1) { page.value -= 1; cargarPisos(filtros.value) } }
function goNext() { if (page.value < totalPages.value) { page.value += 1; cargarPisos(filtros.value) } }

</script>

<script>
export default {
  data() {
    return { debug: false }
  }
}
</script>

<style scoped>
/* Main layout: flexible left listings and fixed right sidebar */
.main-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 300px; /* left flexible, right fixed sidebar */
  gap: 1.5rem;
  align-items: start;
}

/* Cards grid: responsive auto-fit so cards occupy 2–3 columns when possible.
   Use a smaller min width so medium screens can fit 3 narrow cards; adjust gap for tighter layout. */
.cards-grid {
  display: grid;
  /* prefer larger cards so they are not too small; auto-fit will reduce columns as needed */
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 18px;
  padding: 8px 8px;
  box-sizing: border-box;
  width: 100%;
}

.anuncios-container {
  /* Force this to be a simple block wrapper (legacy/global CSS made it a grid).
     The inner `.cards-grid` should manage the cards layout. */
  display: block;
  width: 100%;
  padding: 0;
  box-sizing: border-box;
}

/* Card */
.anuncio-card {
  background: #ffffff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0px 4px 14px rgba(0,0,0,0.1);
  transition: .25s;
}

.anuncio-card:hover {
  transform: translateY(-4px);
  box-shadow: 0px 6px 18px rgba(0,0,0,0.15);
}

/* Image */
.anuncio-img {
  width: 100%;
  height: 170px;
  object-fit: cover;
  display: block;
}

/* Content */
.anuncio-info {
  padding: 12px;
}

.titulo {
  margin: 0 0 8px;
  font-size: 1.15em;
}

.descripcion {
  color: #555;
  margin-bottom: 10px;
}

.precio {
  font-weight: bold;
  color: #2185d0;
  font-size: 1.05em;
  margin: 10px 0;
}

.btn-ver-detalle {
  display: inline-block;
  padding: 8px 12px;
  background: #2185d0;
  color: white;
  border-radius: 6px;
  text-decoration: none;
}

.btn-ver-detalle:hover {
  background: #1678c2;
}

/* Responsive: stack sidebar under listings on narrow viewports */
@media (max-width: 800px) {
  .main-layout {
    grid-template-columns: 1fr; /* sidebar stacks under listings */
  }
  .cards-grid {
    grid-template-columns: 1fr;
  }
}

/* Force 3 columns on wide screens to use available space */
@media (min-width: 1100px) {
  .cards-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
</style>