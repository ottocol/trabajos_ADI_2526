<template>
  <div class="actualizar-anuncio-view">
    <!-- Header integrado -->
    <header class="site-header">
      <div class="logo">
        <img :src="logoImg" alt="Logo rentEase">
      </div>
      <div class="header-buttons">
        <router-link to="/mis-reservas" class="btn">Mis Reservas</router-link>
        <router-link to="/mis-anuncios" class="btn">Mis Anuncios</router-link>
        <router-link to="/perfil" class="btn">Mi Perfil</router-link>
        <button @click="desconectar" class="btn btn-primary">Desconectar</button>
      </div>
    </header>

    <div class="form-container">
      <h2 class="form-title">Actualizar anuncio</h2>

      <!-- Estados - IGUAL QUE CREAR ANUNCIO -->
      <div v-if="loading" class="loading-state">
        <p>Cargando datos del anuncio...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
        <button @click="volverAMisAnuncios" class="btn btn-primary">Volver a Mis Anuncios</button>
      </div>

      <div v-else-if="success" class="success-state">
        <p>¡Anuncio actualizado exitosamente! Redirigiendo...</p>
      </div>

      <form v-else @submit.prevent="actualizarAnuncio">
        <div class="form-group">
          <label for="titulo">Título del anuncio</label>
          <input v-model="form.titulo" type="text" id="titulo" required>
        </div>

        <div class="form-group">
          <label for="direccion">Dirección</label>
          <input v-model="form.direccion" type="text" id="direccion" required>
        </div>

        <div class="form-group">
          <label for="ciudad">Ciudad</label>
          <input v-model="form.ciudad" type="text" id="ciudad" required>
        </div>

        <div class="form-group">
          <label for="codigoPostal">Código Postal</label>
          <input v-model="form.codigoPostal" type="text" id="codigoPostal" required>
        </div>

        <div class="form-group">
          <label for="descripcion">Descripción</label>
          <textarea v-model="form.descripcion" id="descripcion" rows="4" required></textarea>
        </div>

        <div class="form-group">
          <label for="precio">Precio por noche (€)</label>
          <input v-model="form.precio" type="number" id="precio" min="1" required>
        </div>

        <div class="form-group">
          <label for="habitaciones">Número de habitaciones</label>
          <input v-model="form.habitaciones" type="number" id="habitaciones" min="1" required>
        </div>

        <div class="form-group">
          <label for="superficie">Superficie (m²)</label>
          <input v-model="form.superficie" type="number" id="superficie" min="1" required>
        </div>      

        <div class="form-actions">
          <button type="submit" class="btn-primary" :disabled="actualizando">
            {{ actualizando ? 'Actualizando...' : 'Actualizar anuncio' }}
          </button>
          <router-link to="/mis-anuncios" class="btn-cancelar">Cancelar</router-link>
        </div>
      </form>
    </div>

    <!-- Footer integrado -->
    <footer class="site-footer">
      <p>&copy; 2025 rentEase. Todos los derechos reservados.</p>
      <p>Contacto | Política de privacidad</p>
    </footer>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import logoImg from '@/images/rentEase_logo.jpg'

const router = useRouter()
const route = useRoute()
const anuncioId = route.params.id


const loading = ref(true)
const actualizando = ref(false)
const error = ref('')
const success = ref(false)

const form = reactive({
  titulo: '',
  direccion: '',
  ciudad: '',
  codigoPostal: '',
  descripcion: '',
  precio: '',
  habitaciones: '',
  superficie: '',
  tipo: '',
  servicios: '',
  estado: 'pendiente'
})

// Cargar datos del anuncio - VERSIÓN CON DEBUG
const cargarAnuncio = async () => {
  loading.value = true
  error.value = ''
  
  try {
    const token = localStorage.getItem('pb_token')
    
    if (!token) {
      error.value = 'No estás autenticado. Por favor, inicia sesión nuevamente.'
      loading.value = false
      return
    }

    // Verificar que tenemos ID
    if (!anuncioId) {
      throw new Error('No se proporcionó ID del anuncio')
    }

    const url = `/api/pisos/${anuncioId}`

    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    })


    if (response.status === 404) {
      throw new Error('Anuncio no encontrado')
    }
    
    if (response.status === 403) {
      throw new Error('No tienes permisos para ver este anuncio')
    }
    
    if (!response.ok) {
      throw new Error(`Error del servidor: ${response.status} - ${response.statusText}`)
    }

    const anuncio = await response.json()
    
    // Mapear datos del backend al formulario - CAMPOS CORRECTOS
    form.titulo = anuncio.titulo || ''
    form.direccion = anuncio.direccion || ''
    form.ciudad = anuncio.ciudad || ''
    form.codigoPostal = anuncio.cp || ''
    form.descripcion = anuncio.descripcion || ''
    form.precio = anuncio.precio || ''
    form.habitaciones = anuncio.num_habit || ''
    form.superficie = anuncio.superficie || ''
    form.tipo = anuncio.tipo_propiedad || 'apartamento'
    form.servicios = anuncio.servicios || ''
    form.estado = anuncio.estado || 'pendiente'


  } catch (err) {
    error.value = 'Error al cargar el anuncio: ' + err.message
  } finally {
    loading.value = false
  }
}

// Validar formulario - IGUAL QUE CREAR ANUNCIO
const validarFormulario = () => {
  if (!form.titulo.trim()) {
    error.value = 'El título es obligatorio'
    return false
  }
  
  if (!form.direccion.trim()) {
    error.value = 'La dirección es obligatoria'
    return false
  }
  
  if (!form.ciudad.trim()) {
    error.value = 'La ciudad es obligatoria'
    return false
  }
  
  if (!form.precio || form.precio < 1) {
    error.value = 'El precio debe ser mayor a 0'
    return false
  }
  
  if (!form.habitaciones || form.habitaciones < 1) {
    error.value = 'El número de habitaciones debe ser mayor a 0'
    return false
  }
  
  if (!form.superficie || form.superficie < 1) {
    error.value = 'La superficie debe ser mayor a 0'
    return false
  }
  
  if (!form.tipo) {
    error.value = 'Debes seleccionar un tipo de propiedad'
    return false
  }
  
  error.value = ''
  return true
}

// Actualizar anuncio - VERSIÓN CON DEBUG
const actualizarAnuncio = async () => {
  if (!validarFormulario()) return
  
  actualizando.value = true
  error.value = ''
  success.value = false
  
  try {
    const token = localStorage.getItem('pb_token')
    
    if (!token) {
      throw new Error('No estás autenticado')
    }

    // Preparar datos para el backend - CAMPOS CORRECTOS
    const datosActualizados = {
      titulo: form.titulo,
      direccion: form.direccion,
      ciudad: form.ciudad,
      cp: form.codigoPostal,
      descripcion: form.descripcion,
      precio: Number(form.precio),
      num_habit: Number(form.habitaciones),
      superficie: Number(form.superficie),
      tipo_propiedad: form.tipo,
      servicios: form.servicios,
      estado: form.estado
    }


    const response = await fetch(`/api/pisos/${anuncioId}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(datosActualizados)
    })

    console.log('📡 FRONTEND - Respuesta de actualización:', response.status, response.statusText)

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(errorData.error || `Error ${response.status}: ${response.statusText}`)
    }

    const resultado = await response.json()

    success.value = true
    
    // Redirigir después de éxito
    setTimeout(() => {
      router.push('/mis-anuncios')
    }, 2000)
    
  } catch (err) {
    error.value = err.message || 'Error al actualizar el anuncio. Intenta nuevamente.'
  } finally {
    actualizando.value = false
  }
}

// Navegación
const volverAMisAnuncios = () => {
  router.push('/mis-anuncios')
}

// Desconectar - IGUAL QUE CREAR ANUNCIO
const desconectar = () => {
  localStorage.removeItem('pb_token')
  localStorage.removeItem('userId')
  localStorage.removeItem('authToken')
  router.push('/')
}

onMounted(() => {
  cargarAnuncio()
})
</script>

<style scoped>
.actualizar-anuncio-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
}

.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border-bottom: 1px solid #ddd;
  position: static;
  top: 0;
}

.logo img {
  height: 60px;
}

.header-buttons .btn {
  margin-left: 1rem;
  padding: 0.5rem 1rem;
  border: 1px solid #007bff;
  border-radius: 6px;
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  background: none;
  cursor: pointer;
}

.header-buttons .btn-primary {
  background-color: #007bff;
  color: white;
}

.header-buttons .btn:hover {
  background-color: #0056b3;
  color: white;
}

.form-container {
  background: white;
  padding: 2rem 2.5rem;
  border-radius: 12px;
  box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
  width: 80%;
  max-width: 600px;
  margin: 2rem auto;
}

.form-title {
  text-align: center;
  margin-bottom: 1.5rem;
  font-size: 1.6rem;
  color: #333;
}

.form-group {
  margin-bottom: 1rem;
}

label {
  display: block;
  margin-bottom: 0.3rem;
  color: #555;
  font-size: 0.9rem;
  font-weight: bold;
}

input, select, textarea {
  width: 100%;
  padding: 0.7rem;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 1rem;
  box-sizing: border-box;
}

textarea {
  resize: vertical;
}

input:focus, select:focus, textarea:focus {
  border-color: #007bff;
  outline: none;
}

.form-actions {
  margin-top: 1.5rem;
  display: flex;
  justify-content: space-between;
  gap: 1rem;
}

.btn-primary {
  padding: 0.7rem 1rem;
  border: none;
  border-radius: 6px;
  background-color: #007bff;
  color: white;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  text-align: center;
}

.btn-primary:hover:not(:disabled) {
  background-color: #0056b3;
}

.btn-primary:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
}

.btn-cancelar {
  padding: 0.7rem 1rem;
  border: none;
  border-radius: 6px;
  background-color: #dc3545;
  color: white;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  text-align: center;
}

.btn-cancelar:hover {
  background-color: #a71d2a;
}

.site-footer {
  background-color: #f1f1f1;
  color: #333;
  text-align: center;
  padding: 20px 0;
  font-size: 0.9rem;
  border-top: 1px solid #ccc;
}

.site-footer a {
  color: #007bff;
  text-decoration: none;
  margin: 0 5px;
}

.site-footer a:hover {
  text-decoration: underline;
}

.loading-state,
.error-state,
.success-state {
  text-align: center;
  padding: 2rem;
  color: #666;
  font-size: 1.1rem;
}

.error-state {
  color: #dc3545;
  background: #f8d7da;
  border-radius: 8px;
  margin-bottom: 1rem;
}

.success-state {
  color: #155724;
  background: #d4edda;
  border-radius: 8px;
  margin-bottom: 1rem;
}

@media (max-width: 768px) {
  .form-container {
    width: 90%;
    padding: 1.5rem;
  }
  
  .form-actions {
    flex-direction: column;
  }
  
  .header-buttons {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .header-buttons .btn {
    margin-left: 0;
  }
}

@media (max-width: 480px) {
  .form-container {
    padding: 1rem;
  }
}
</style>