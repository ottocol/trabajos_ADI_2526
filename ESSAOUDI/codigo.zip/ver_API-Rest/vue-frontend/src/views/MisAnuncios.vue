<template>
  <div class="mis-anuncios-view">
    <AppHeader>
      <template #left>
        <router-link to="/perfil">
          <img :src="avatarSrc" alt="avatar" class="user-avatar-small" />
        </router-link>
      </template>

      <template #right>
        <router-link to="/mis-anuncios" class="btn">Mis Anuncios</router-link>
        <router-link to="/mis-solicitudes" class="btn">Mis Solicitudes</router-link>
        <router-link to="/perfil" class="btn">Perfil</router-link>
        <button @click="desconectar" class="btn btn-danger">Desconectar</button>
      </template>
    </AppHeader>

    <div class="anuncios-container">
      <h2 class="anuncios-title">Mis anuncios</h2>
      
      <div class="crear-anuncio-container">
        <router-link to="/crear-anuncio" class="btn btn-primary">+ Crear un anuncio</router-link>
      </div>

      <!-- Estados de carga -->
      <div v-if="loading" class="loading-state">
        <p>Cargando anuncios...</p>
      </div>

      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
      </div>

      <div v-else-if="anuncios.length === 0" class="empty-state">
        <p>No tienes anuncios creados.</p>
        <router-link to="/crear-anuncio" class="btn btn-primary">Crear mi primer anuncio</router-link>
      </div>

      <!-- Lista de anuncios - ESTRUCTURA EN COLUMNAS HORIZONTALES -->
      <div v-else class="anuncios-list">
        <div v-for="anuncio in anuncios" :key="anuncio.id" class="anuncio-card" :class="anuncio.estado">
          <div class="anuncio-img">
            <img 
              :src="getAnuncioImage(anuncio)" 
              :alt="anuncio.titulo"
              @error="handleImageError"
            >
          </div>
          
          <!-- Contenedor para las columnas de información -->
          <div class="anuncio-columns">
            <!-- Columna 1 -->
            <div class="info-column">
              <div class="info-item">
                <span class="info-label">Piso:</span>
                <span class="info-value">{{ anuncio.titulo }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Dirección:</span>
                <span class="info-value">{{ anuncio.direccion }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">codigo postal:</span>
                <span class="info-value">{{ anuncio.codigoPostal }}</span>
              </div>
            </div>
            
            <!-- Columna 2 -->
            <div class="info-column">
              <div class="info-item">
                <span class="info-label">Descripcion:</span>
                <span class="info-value">{{ anuncio.descripcion }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Precio Por noche:</span>
                <span class="info-value">{{ formatPrice(anuncio.precio) }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Número de Habitaciones:</span>
                <span class="info-value">{{ anuncio.habitaciones }}</span>
              </div>
            </div>
            
            <!-- Columna 3 -->
            <div class="info-column">
              <div class="info-item">
                <span class="info-label">Superficie:</span>
                <span class="info-value">{{ anuncio.superficie }} m²</span>
              </div>
              <div class="info-item action-item">
                <router-link 
                  :to="{ name: 'ActualizarAnuncio', params: { id: anuncio.id } }" 
                  class="btn btn-primary"
                >
                  Actualizar el Anuncio
                </router-link>
              </div>
              <div class="info-item action-item">
                <button 
                  @click="confirmarEliminar(anuncio)" 
                  class="btn btn-danger"
                >
                  suprimir el anuncio
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <router-link :to="{ name: 'propietario' }" class="volver-link">
        Volver a la pagina de inicio
      </router-link>
    </div>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import AppHeader from '@/components/Layout/AppHeader.vue'
import AppFooter from '@/components/Layout/AppFooter.vue'
import logoImg from '@/images/rentEase_logo.jpg'
import pisoEjemplo from '@/images/piso-ejemplo.jpeg'
import villa1 from '@/images/villa1.jpg'
import house1 from '@/images/house1.jpg'
import randomAvatar from '@/images/users/random.png'

const router = useRouter()
const anuncios = ref([])
const loading = ref(false)
const error = ref(null)
const avatarSrc = ref(randomAvatar)

function loadAvatar() {
  try {
    const raw = localStorage.getItem('currentUser')
    if (!raw) return
    const u = JSON.parse(raw)
    if (u.avatarUrl) { avatarSrc.value = u.avatarUrl; return }
    if (u.image) {
      if (Array.isArray(u.image) && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image[0]}`
        return
      }
      if (typeof u.image === 'string' && u.image.length > 0) {
        avatarSrc.value = `http://127.0.0.1:8090/api/files/users/${u.id}/${u.image}`
        return
      }
    }
  } catch (e) {}
}

// Formatear precio
const formatPrice = (precio) => {
  return precio ? `${precio} €` : '0 €'
}

// Obtener imagen del anuncio
const getAnuncioImage = (anuncio) => {
  if (anuncio.imagenUrl) return anuncio.imagenUrl
  const defaultImages = {
    'apartamento': pisoEjemplo,
    'villa': villa1,
    'casa': house1
  }
  return defaultImages[anuncio.tipo] || pisoEjemplo
}

// Manejar error de imagen
const handleImageError = (event) => {
  event.target.src = pisoEjemplo
}

const cargarMisAnuncios = async () => {
  loading.value = true
  error.value = null
  try {
    const token = localStorage.getItem('pb_token')
    console.log('FRONTEND - Token encontrado:', token ? 'SI' : 'NO')
    
    if (!token) {
      error.value = 'No estás autenticado'
      loading.value = false
      return
    }

    const url = '/api/pisos/mis-anuncios'
    console.log('FRONTEND - Haciendo fetch a:', url)
    
    const res = await fetch(url, {
      headers: { 
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    })

    console.log('FRONTEND - Respuesta recibida:', res.status, res.statusText)
    
    if (!res.ok) {
      throw new Error(`Error ${res.status}: ${res.statusText}`)
    }

    const json = await res.json()
    console.log('FRONTEND - Datos recibidos:', json)
    
    anuncios.value = Array.isArray(json) ? json : json.items || []
    console.log('FRONTEND - Anuncios procesados:', anuncios.value.length)

  } catch (err) {
    console.error('FRONTEND - Error:', err)
    error.value = 'Error al cargar anuncios: ' + err.message
  } finally {
    loading.value = false
    console.log('FRONTEND - Carga completada')
  }
}

// Eliminar anuncio
const confirmarEliminar = (anuncio) => {
  if (confirm(`¿Estás seguro de que quieres eliminar el anuncio "${anuncio.titulo}"?`)) {
    eliminarAnuncio(anuncio.id)
  }
}

const eliminarAnuncio = async (anuncioId) => {
  try {
    const token = localStorage.getItem('pb_token')
    const response = await fetch(`/api/pisos/${anuncioId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    })

    if (response.ok) {
      anuncios.value = anuncios.value.filter(a => a.id !== anuncioId)
      alert('Anuncio eliminado correctamente')
    } else {
      alert('Error al eliminar el anuncio')
    }
  } catch (err) {
    console.error('Error eliminando anuncio:', err)
    alert('Error al eliminar el anuncio')
  }
}

// Desconectar
const desconectar = () => {
  localStorage.removeItem('pb_token')
  localStorage.removeItem('userId')
  localStorage.removeItem('authToken')
  router.push('/')
}

onMounted(() => {
  console.log('🎯 FRONTEND - Componente MisAnuncios MONTADO')
  loadAvatar()
  window.addEventListener('storage', loadAvatar)
  cargarMisAnuncios()
})
</script>

<style scoped>
.mis-anuncios-view {
  min-height: 100vh;
  background-color: #f8f9fa;
  margin: 0;
  font-family: Arial, sans-serif;
  display: flex;
  flex-direction: column;
}

/* Header styles igual al HTML */
.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.logo img {
  height: 50px;
}

.header-buttons {
  display: flex;
  gap: 1rem;
  align-items: center;
}

/* Contenedor general - TODO CENTRADO */
.anuncios-container {
  width: 100%;
  max-width: 1200px;
  margin: 2rem auto;
  padding: 1rem;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.anuncios-title {
  text-align: center;
  margin-bottom: 2rem;
  color: #333;
  font-size: 2rem;
}

.crear-anuncio-container {
  text-align: center;
  margin-bottom: 2rem;
}

/* Tarjeta de anuncio - ESTRUCTURA HORIZONTAL CON COLUMNAS */
.anuncio-card {
  display: flex;
  align-items: flex-start;
  gap: 1.5rem;
  width: 100%;
  max-width: 950px;
  padding: 1.5rem;
  border-radius: 8px;
  margin-bottom: 1.5rem;
  border-left: 4px solid #007bff;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  background: #fff;
  min-height: 200px;
}

.anuncio-card.pendiente { border-left-color: #ffc107; }
.anuncio-card.activo { border-left-color: #28a745; }
.anuncio-card.inactivo { border-left-color: #dc3545; }

/* Imagen más compacta */
.anuncio-img {
  flex-shrink: 0;
  width: 180px;
  height: 150px;
}

.anuncio-img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 6px;
}

/* Contenedor de columnas */
.anuncio-columns {
  flex: 1;
  display: flex;
  gap: 1.5rem;
  justify-content: space-between;
  height: 100%;
}

/* Columnas de información */
.info-column {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  min-width: 0; /* Para que el texto no rompa el layout */
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.info-label {
  color: #555;
  font-weight: bold;
  font-size: 0.85rem;
  white-space: nowrap;
}

.info-value {
  color: #333;
  font-size: 0.9rem;
  font-weight: normal;
  word-wrap: break-word;
  line-height: 1.3;
}

/* Columna de acciones */
.action-item {
  margin-top: auto;
  display: flex;
  justify-content: center;
}

/* Button styles limited to the anuncios area so header buttons keep AppHeader styles */
.anuncios-list .btn,
.crear-anuncio-container .btn,
.action-item .btn {
  padding: 0.6rem 1.2rem;
  color: white;
  text-decoration: none;
  text-align: center;
  border-radius: 6px;
  font-size: 0.85rem;
  border: none;
  cursor: pointer;
  transition: opacity 0.2s ease;
  min-width: 140px;
}

.anuncios-list .btn:hover,
.crear-anuncio-container .btn:hover,
.action-item .btn:hover {
  opacity: 0.9;
}

.anuncios-list .btn-primary,
.crear-anuncio-container .btn-primary,
.action-item .btn-primary {
  background: #007bff;
}

.anuncios-list .btn-danger,
.crear-anuncio-container .btn-danger,
.action-item .btn-danger {
  background: #dc3545;
}

/* Estados centrados */
.loading-state,
.error-state,
.empty-state {
  text-align: center;
  padding: 3rem;
  color: #666;
  background: white;
  border-radius: 8px;
  margin: 2rem 0;
  width: 100%;
  max-width: 600px;
}

.error-state {
  color: #dc3545;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
}

/* Enlace volver centrado */
.volver-link {
  text-align: center;
  margin-top: 2rem;
  display: block;
  color: #007bff;
  text-decoration: none;
  font-weight: 500;
}

.volver-link:hover {
  text-decoration: underline;
}

/* Footer styles igual al HTML */
.site-footer {
  background-color: #333;
  color: white;
  text-align: center;
  padding: 2rem;
  margin-top: auto;
}

.site-footer p {
  margin: 0.5rem 0;
}

/* Responsive */
@media (max-width: 900px) {
  .anuncio-card {
    max-width: 90%;
  }
  
  .anuncio-columns {
    gap: 1rem;
  }
}

@media (max-width: 768px) {
  .anuncio-card {
    flex-direction: column;
    gap: 1.5rem;
    max-width: 95%;
  }

  .anuncio-img {
    width: 100%;
    max-width: 100%;
    height: 200px;
  }

  .anuncio-columns {
    flex-direction: column;
    gap: 1rem;
  }

  .info-column {
    gap: 1rem;
  }

  .site-header {
    flex-direction: column;
    gap: 1rem;
    padding: 1rem;
  }

  .header-buttons {
    flex-wrap: wrap;
    justify-content: center;
  }

  .action-item {
    margin-top: 1rem;
    justify-content: center;
  }
}

@media (max-width: 480px) {
  .anuncios-container {
    padding: 0.5rem;
  }

  .anuncio-card {
    padding: 1rem;
  }

  .anuncios-title {
    font-size: 1.5rem;
  }

  .btn {
    min-width: auto;
    padding: 0.6rem 1rem;
    width: 100%;
  }
}
</style>