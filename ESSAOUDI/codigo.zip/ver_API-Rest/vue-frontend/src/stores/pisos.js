import { defineStore } from 'pinia'
import { api } from '@/services/api'

export const usePisosStore = defineStore('pisos', {
  state: () => ({
    pisos: [],
    currentPiso: null,
    searchQuery: '',
    loading: false
  }),

  getters: {
    filteredPisos: (state) => {
      if (!state.searchQuery) return state.pisos
      return state.pisos.filter(piso =>
        piso.titulo?.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
        piso.descripcion?.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
        piso.ubicacion?.toLowerCase().includes(state.searchQuery.toLowerCase())
      )
    }
  },

  actions: {
    async fetchPisos(filters = {}) {
      this.loading = true
      try {
        const response = await api.get('/pisos', { params: filters })
        this.pisos = response.data.items || response.data
      } catch (error) {
        console.error('Error fetching pisos:', error)
        throw error
      } finally {
        this.loading = false
      }
    },

    async deletePiso(id) {
      try {
        await api.delete(`/pisos/${id}`)
        this.pisos = this.pisos.filter(p => p.id !== id)
      } catch (error) {
        console.error('Error deleting piso:', error)
        throw error
      }
    }
  }
})