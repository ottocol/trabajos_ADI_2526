import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => import('@/views/HomeView.vue')
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/LoginView.vue')
    },
    {
      path: '/propietario',
      name: 'propietario',
      component: () => import('@/views/propietarioView.vue')
    },
    {
      path: '/inquilino',
      name: 'inquilino',
      component: () => import('@/views/inquilinoView.vue')
    },
    {
      path: '/admin',
      name: 'admin',
      component: () => import('@/views/adminView.vue')
    },
    {
      path: '/admin/users',
      name: 'AdminUsers',
      component: () => import('@/views/Admin/AdminUsers.vue')
    },
    {
      path: '/admin/pisos',
      name: 'AdminPisos',
      component: () => import('@/views/Admin/PisosAdmin.vue')
    },
    {
      path: '/admin/reservas',
      name: 'AdminReservas',
      component: () => import('@/views/Admin/AdminReservas.vue')
    },
    {
      path: '/admin/comentarios',
      name: 'AdminComentarios',
      component: () => import('@/views/Admin/AdminComentarios.vue')
    },
    {
      path: '/admin/users/create',
      name: 'UserCreate',
      component: () => import('@/views/RegistroView.vue')
    },
    {
      path: '/registro',
      name: 'registro', 
      component: () => import('@/views/RegistroView.vue')
    },
    {
      path: '/piso-detalle/:id',
      name: 'PisoDetalle',
      component: () => import('@/views/PisoDetalleView.vue'),
      props: true
    },
    {
      path: '/mis-anuncios',
      name: 'MisAnuncios', 
      component: () => import('@/views/MisAnuncios.vue') // ← IMPORT DINÁMICO
    },
    {
      path: '/mis-reservas',
      name: 'MisReservas',
      component: () => import('@/views/MisReservas.vue')
    },
    {
      path: '/editar-perfil',
      name: 'EditarPerfil', 
      component: () => import('@/views/EditarPerfil.vue')
    },
    {
      path: '/crear-anuncio',
      name: 'CrearAnuncio', 
      component: () => import('@/views/CrearAnuncio.vue')
    },
    {
      path: '/perfil',
      name: 'Perfil', 
      component: () => import('@/views/Perfil.vue')
    },
    {
      path: '/admin/perfil',
      name: 'AdminPerfil',
      component: () => import('@/views/Admin/AdminPerfil.vue'),
      meta: { requiresAuth: true, roles: ['admin'] }
    },
    {
      path: '/reservar/:id',
      name: 'Reservar', 
      component: () => import('@/views/Reservar.vue')
    },
    {
      path: '/mis-solicitudes',
      name: 'MisSolicitudes',
      component: () => import('@/views/MisSolicitudes.vue')
    },
    {
      path: '/actualizar-anuncio/:id',
      name: 'ActualizarAnuncio', 
      component: () => import('@/views/ActualizarAnuncio.vue'),
      props: true
    }
  ]
})

// Redirect admins who open the public Perfil page to the AdminPerfil route
router.beforeEach((to, from, next) => {
  try {
    const targetIsPerfil = to && (to.name === 'Perfil' || to.path === '/perfil')
    if (!targetIsPerfil) return next()

    // get stored role
    let role = null
    try {
      role = (localStorage.getItem('userRole') || '').toLowerCase()
      if (!role) {
        const raw = localStorage.getItem('currentUser')
        if (raw) role = (JSON.parse(raw).rol || JSON.parse(raw).role || '').toLowerCase()
      }
    } catch (e) {
      role = null
    }

    if (role === 'admin' || role === 'administrator') {
      return next({ name: 'AdminPerfil' })
    }

    // otherwise allow the public Perfil view
    return next()
  } catch (err) {
    return next()
  }
})

export default router