## integrantes del equipo:
- Maha Essaoudi
- sabrine Bentaleb Kheyar
- salma Benmoussa
- Adnan moughlia Benghachoua
- Nada Benaissa

## enlace al video: 
https://drive.google.com/drive/folders/1nTq9x69vkqVvpcmy68Z7428WWqwrxfQ3?usp=sharing

## Instalación

```bash
npm install
```
## Ejecutar en backend y frontend

```bash
# Modo desarrollo
npm run dev
```

El servidor estará disponible en:
- GraphQL Playground: http://localhost:4000/graphql
- Health check: http://localhost:4000/health

## Requisitos

- PocketBase corriendo en http://127.0.0.1:8090
- Node.js 18+

## Ejemplos si quereis hacer pruebas en graphQL

### Listar pisos con filtros
```graphql
query {
  pisos(page: 1, perPage: 10, ciudad: "Alicante") {
    items {
      id
      titulo
      precio
      direccion
      ciudad
      primeraImagen
    }
    totalItems
    totalPages
  }
}
```
### Listar reservas
query {
  reservas(page: 1, perPage: 5) {
    items {
      id
      fecha_inc
      fecha_fin
      estado
      piso {
        titulo
      }
    }
  }
}
