/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("1vjj0oe6fsjt6gy")

  collection.name = "comentario"

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "ipsqytrf",
    "name": "usuario_id",
    "type": "relation",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {
      "collectionId": "rxep3cc04vzsyuk",
      "cascadeDelete": false,
      "minSelect": null,
      "maxSelect": 1,
      "displayFields": null
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("1vjj0oe6fsjt6gy")

  collection.name = "comenatrio"

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "ipsqytrf",
    "name": "usuaio_id",
    "type": "relation",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {
      "collectionId": "rxep3cc04vzsyuk",
      "cascadeDelete": false,
      "minSelect": null,
      "maxSelect": 1,
      "displayFields": null
    }
  }))

  return dao.saveCollection(collection)
})
