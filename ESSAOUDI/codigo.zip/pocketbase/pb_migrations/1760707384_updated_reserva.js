/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("0phf7woc2hsgjud")

  collection.name = "reservas"

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("0phf7woc2hsgjud")

  collection.name = "reserva"

  return dao.saveCollection(collection)
})
