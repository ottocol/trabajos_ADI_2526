/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("rxep3cc04vzsyuk")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "39gd1m7u",
    "name": "image",
    "type": "file",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {
      "mimeTypes": [],
      "thumbs": [],
      "maxSelect": 1,
      "maxSize": 5242880,
      "protected": false
    }
  }))

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "xgd8piiq",
    "name": "rol",
    "type": "select",
    "required": true,
    "presentable": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "values": [
        "admin",
        "inquilino",
        "propietario"
      ]
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("rxep3cc04vzsyuk")

  // remove
  collection.schema.removeField("39gd1m7u")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "xgd8piiq",
    "name": "rol",
    "type": "select",
    "required": true,
    "presentable": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "values": [
        "admin",
        "inlquilino",
        "propietario"
      ]
    }
  }))

  return dao.saveCollection(collection)
})
