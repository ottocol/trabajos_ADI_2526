# Trabajo ADI (Grupal) — Parte teorica
**Tema:** APIs GraphQL como alternativa a REST (comparacion y portado del backend)  
**Proyecto de referencia:** RentEase (PocketBase + Vue) con ambas versiones: REST (Express) y GraphQL (Apollo Server)


## Indice
1. [Objetivo y alcance](#1-objetivo-y-alcance)  
2. [Contexto del proyecto y motivacion](#2-contexto-del-proyecto-y-motivacion)  
   2.1. [Dominio funcional](#21-dominio-funcional-que-resuelve-la-app)  
   2.2. [Por que comparar REST y GraphQL](#22-por-que-comparar-rest-y-graphql-aqui)  
   2.3. [Arquitectura general y flujo de datos](#23-arquitectura-general-y-flujo-de-datos)  
3. [REST: fundamentos, fortalezas y limites](#3-rest-fundamentos-fortalezas-y-limites)  
4. [GraphQL: fundamentos, schema y ejecucion](#4-graphql-fundamentos-schema-y-ejecucion)  
5. [Comparacion REST vs GraphQL (criterios tecnicos)](#5-comparacion-rest-vs-graphql-criterios-tecnicos)  
   5.1. [Modelo mental](#51-modelo-mental-recursos-vs-grafo-de-datos)  
   5.2. [Over-fetching y under-fetching](#52-over-fetching-y-under-fetching)  
   5.3. [Cache](#53-cache-ventaja-natural-de-rest-vs-cache-a-nivel-cliente-en-graphql)  
   5.4. [Rendimiento y N+1](#54-rendimiento-en-servidor-riesgo-n1-en-graphql)  
   5.5. [Seguridad](#55-seguridad-controles-mas-finos-en-graphql)  
   5.6. [Errores](#56-errores-semantica-http-vs-errors)  
   5.7. [Subida de archivos](#57-subida-de-archivos-imagenes-mas-sencilla-en-rest)  
   5.8. [Mantenibilidad del stack](#58-mantenibilidad-del-stack-caso-apollo-server)  
   5.9. [Paginacion y filtrado](#59-paginacion-y-filtrado-rest-vs-graphql)  
6. [Analisis aplicado a RentEase (nuestro caso)](#6-analisis-aplicado-a-rentease-nuestro-caso)  
   6.1. [Por que GraphQL puede ser mejor](#61-por-que-graphql-puede-ser-mejor-en-este-proyecto)  
   6.2. [Por que GraphQL puede ser peor](#62-por-que-graphql-puede-ser-peor-o-mas-complejo-aqui)  
   6.3. [Que significa portar el backend](#63-que-significa-portar-el-backend-en-rentease)  
   6.4. [Equivalencia de operaciones REST y GraphQL](#64-equivalencia-de-operaciones-rest-y-graphql)  
7. [Aspectos clave mas alla de clase](#7-aspectos-clave-mas-alla-de-clase)  
8. [Conclusiones y recomendaciones](#8-conclusiones-y-recomendaciones)  
9. [Referencias](#9-referencias)  


## 1. Objetivo y alcance

El objetivo de nuestro trabajo es ir mas alla de lo visto en la asignatura y explorar **GraphQL** como alternativa real a una API **REST** tradicional, evaluando el impacto sobre un proyecto existente.

Para evitar una comparacion puramente teorica, nos planteamos una pregunta concreta:

**¿Como cambiaria nuestro proyecto RentEase si el backend expusiera GraphQL en lugar de REST?**

Nuestro enfoque es practico:
- Hemos implementado dos variantes de API para el mismo dominio (pisos, reservas, comentarios y usuarios): una REST y otra GraphQL.
- Analizamos ventajas y desventajas basandonos en criterios tecnicos y en su efecto directo sobre el desarrollo del frontend.

En este documento explicamos:
- Que es REST y que es GraphQL, y en que difieren conceptualmente.
- Que implica “portar” una API de REST a GraphQL (contrato, operaciones, control de acceso, rendimiento, etc.).
- Una comparacion tecnica argumentada para decidir cuando tiene sentido usar GraphQL y cuando REST sigue siendo la opcion mas adecuada.

## 2. Contexto del proyecto y motivacion

### 2.1. Dominio funcional (que resuelve la app)

RentEase es una aplicacion de alquiler/gestion de pisos con entidades tipicas:
- **Pisos**: titulo, ciudad, direccion, precio, imagenes, propietario.
- **Reservas**: piso, inquilino, fechas, estado (pendiente/confirmada/cancelada/pagada).
- **Comentarios/valoraciones**: comentario, valoracion, usuario, piso.
- **Usuarios**: con roles (admin, propietario, inquilino).

La persistencia se implementa con **PocketBase**, que proporciona base de datos, autenticacion y reglas API.

### 2.2. Por que comparar REST y GraphQL aqui

En aplicaciones modernas tipo SPA (Vue) con pantallas ricas (home con tarjetas, detalle con informacion relacionada, dashboards por rol), el frontend necesita datos **relacionados**. Con REST es comun:
- hacer varias llamadas para completar una vista (under-fetching),
- crear endpoints “a medida” para cada pantalla,
- o recibir respuestas con campos innecesarios (over-fetching).

GraphQL surge como propuesta para que el cliente solicite **exactamente** los campos que necesita, reduciendo estos problemas [1][2].

### 2.3. Arquitectura general y flujo de datos

Nuestra arquitectura tiene tres capas principales:

1) **Frontend (Vue)**  
   - Renderiza vistas: home, detalle de piso, paneles por rol (inquilino/propietario/admin).
   - Consume datos mediante dos opciones:
     - **REST** usando peticiones HTTP (axios).
     - **GraphQL** mediante un cliente GraphQL (peticiones al endpoint GraphQL).
   - En ambos casos, adjunta el token en `Authorization: Bearer <token>` cuando corresponde.

2) **Capa API (dos variantes)**
   - **REST (Express):** multiples endpoints por recurso (`/api/pisos`, `/api/reservas`, etc.).
   - **GraphQL (Apollo Server):** un unico endpoint que expone `Query` y `Mutation` tipadas.
   - Ambas variantes actuan como adaptador hacia PocketBase: validan entradas, aplican reglas y construyen respuestas con el formato que consume el frontend.

3) **Persistencia (PocketBase)**
   - Almacena colecciones y relaciones.
   - Permite expansion de relaciones (`expand`) para traer datos relacionados en una sola respuesta, si las reglas de visibilidad lo permiten [21].

**Flujo tipico (detalle de piso):**
- Vue solicita datos:
  - REST: varias rutas (piso, comentarios, propietario…).
  - GraphQL: una query con seleccion de campos (piso + propietario + comentarios).
- La capa API consulta PocketBase (posiblemente usando `expand`).
- Se devuelve al cliente lo necesario para pintar la vista.


## 3. REST: fundamentos, fortalezas y limites

REST (Representational State Transfer) es un **estilo arquitectonico** definido por Roy Fielding [6]. Describe restricciones para sistemas distribuidos orientados a escalabilidad y evolucion independiente.

### 3.1. Restricciones REST (vision “formal”)

Las restricciones mas conocidas son [6]:
- **Client-Server**: separacion de responsabilidades entre cliente y servidor.
- **Stateless**: cada request contiene la informacion necesaria; el servidor no mantiene estado de sesion.
- **Cacheable**: las respuestas deben definir si son cacheables.
- **Uniform Interface**: interfaz uniforme (principio clave) que simplifica la comunicacion.
- **Layered System**: arquitectura por capas (proxies, gateways…).
- **Code on demand (opcional)**: ejecucion de codigo descargado (rara en APIs modernas).

### 3.2. Recursos, URIs y representaciones

En REST, el servidor expone **recursos** identificados por URIs (por ejemplo, `/pisos`, `/reservas`).  
El cliente obtiene **representaciones** (usualmente JSON) y manipula recursos con metodos HTTP (GET/POST/PATCH/DELETE).

### 3.3. Ventajas principales de REST

1. **Simplicidad y familiaridad**  
   Patron muy extendido: endpoints, metodos HTTP, JSON y codigos de estado.

2. **Integracion natural con infraestructura web**  
   Herramientas, proxies, CDNs y observabilidad suelen organizarse bien “por endpoint”.

3. **Cache HTTP nativo**  
   REST (especialmente GET) encaja con mecanismos estandar como:
   - `Cache-Control`,
   - validadores `ETag` y `Last-Modified`,
   - requests condicionales (`If-None-Match`, `If-Modified-Since`),
   con respuestas como `304 Not Modified` cuando procede [7][8][9].

### 3.4. Limitaciones tipicas de REST en SPAs y UIs ricas

1. **Over-fetching**  
   El endpoint devuelve mas datos de los que necesita una vista.

2. **Under-fetching**  
   La vista necesita datos que no vienen en una respuesta y obliga a hacer varias llamadas.

3. **Crecimiento de endpoints por pantalla**  
   Para evitar under-fetching, se crean endpoints agregados que aumentan a medida que crece la UI.


## 4. GraphQL: fundamentos, schema y ejecucion

GraphQL es un lenguaje de consultas para APIs y un runtime que ejecuta esas consultas contra un **schema tipado** [1].

### 4.1. Operaciones principales

- **Query**: lectura de datos.
- **Mutation**: escritura/modificacion de datos.
- **Subscription (opcional)**: actualizaciones en tiempo real.

La idea central es que el cliente pide **exactamente** los campos que necesita [1].

### 4.2. Schema: contrato tipado y documentacion viva

El schema define:
- tipos (`User`, `Piso`, `Reserva`, `Comentario`),
- campos disponibles,
- y operaciones (`Query`/`Mutation`) [2].

Beneficios:
- validacion temprana de consultas,
- autodocumentacion (GraphiQL/Apollo Sandbox),
- mejor alineacion frontend-backend.

### 4.3. Introspeccion y tooling

GraphQL permite consultar el schema mediante introspeccion, lo que habilita:
- autocompletado,
- documentacion automatica,
- exploracion interactiva del API [3].

### 4.4. Evolucion del API y deprecacion

En GraphQL, es comun evolucionar añadiendo campos sin versionar endpoints.  
Los campos antiguos pueden marcarse como obsoletos (`@deprecated`) para migraciones graduales (practica habitual en schemas).

### 4.5. Respuesta y manejo de errores

Una respuesta GraphQL suele incluir:
- `data` con el resultado,
- `errors` con detalles del error (incluso con `data` parcial).

Esto cambia la forma de manejar errores respecto a REST (donde dominan los codigos HTTP).

## 5. Comparacion REST vs GraphQL (criterios tecnicos)

### 5.1. Modelo mental: recursos vs grafo de datos

- **REST**: recursos + endpoints; el servidor define la forma de la respuesta.
- **GraphQL**: grafo de tipos; el cliente define la forma mediante seleccion de campos.

**En RentEase** hay relaciones fuertes (piso↔propietario, reservas↔inquilino↔piso, comentarios↔usuario↔piso), por lo que el modelo en grafo es natural.

### 5.2. Over-fetching y under-fetching

**REST**
- Over/under-fetching depende del diseño del endpoint.
- Se corrige con endpoints agregados o multiples requests.

**GraphQL**
- Reduce over/under-fetching porque el cliente define los campos [1].
- Una sola query puede servir una vista completa.

Ejemplo conceptual (detalle de piso):
- REST: 2–4 llamadas (piso, propietario, comentarios, reservas…).
- GraphQL: 1 query con seleccion de campos.

### 5.3. Cache: ventaja natural de REST vs cache a nivel cliente en GraphQL

**REST**
- Cache HTTP por URL/metodo es directo.
- Soporta `ETag`/`Last-Modified` y `304 Not Modified` [7][8][9].

**GraphQL**
- Un solo endpoint y queries dinamicas complican el cache “por URL”.
- Se suele compensar con cache en el cliente. Apollo Client usa una cache **normalizada** en memoria (InMemoryCache), reutilizando objetos por ID [13][14].

### 5.4. Rendimiento en servidor: riesgo N+1 en GraphQL

GraphQL puede sufrir N+1 si los resolvers consultan datos relacionados de forma repetitiva (una consulta por elemento).
Mitigaciones habituales:
- **DataLoader** (batching + memoization por request) [17].
- Diseñar resolvers para aprovechar capacidades del backend (en PocketBase, `expand`) y reducir roundtrips [21].

Recomendacion practica: instanciar DataLoader **por request** para evitar mezclar cache entre usuarios [17].

### 5.5. Seguridad: controles mas finos en GraphQL

En REST, es comun proteger por endpoint (middlewares por ruta).
En GraphQL, con un unico endpoint, la seguridad debe aplicarse:
- por resolver (operacion),
- y en algunos casos por campo.

Riesgos conocidos (segun OWASP):
- queries profundas o costosas (DoS logico),
- ausencia de limites de profundidad/complexidad,
- batching abusivo,
- errores demasiado descriptivos,
- introspeccion/herramientas de desarrollo expuestas en produccion [10][11][12].

Buenas practicas recomendadas (resumen OWASP):
- **depth limiting** y **query cost analysis**,
- paginacion obligatoria,
- timeouts razonables,
- rate limiting por IP/usuario,
- mensajes de error genericos en produccion [10][11][12].

### 5.6. Errores: semantica HTTP vs `errors[]`

**REST**
- Codigos HTTP (400, 401, 403, 404, 409…) marcan el tipo de error.

**GraphQL**
- Es habitual recibir 200 OK con `errors[]`, y el cliente debe interpretarlos.
- En Apollo, los errores pueden incluir `extensions.code` para clasificar errores (por ejemplo autenticacion/autorizacion).

Implicacion: el frontend necesita una estrategia clara de manejo de errores (y de “data parcial”).

### 5.7. Subida de archivos (imagenes): mas sencilla en REST

**REST**
- `multipart/form-data` + middleware (por ejemplo `multer`) es estandar y directo.

**GraphQL**
- Lo habitual es usar el **GraphQL multipart request spec** y el scalar `Upload` [19].
- En Node, librerias como `graphql-upload` añaden middleware y el scalar `Upload` para soportar ese spec [20].

Consideracion adicional: la subida de ficheros introduce requisitos de seguridad (validacion, limites de tamaño, control de tipo MIME, etc.) y puede requerir protecciones adicionales.

### 5.8. Mantenibilidad del stack: caso Apollo Server

La eleccion de framework afecta a la mantenibilidad (seguridad, compatibilidad y soporte).
Dato relevante para nuestra entrega: **Apollo Server 4 esta deprecated y pasa a end-of-life el 26/01/2026**, por lo que se recomienda migrar a Apollo Server 5 [15][16].

Esto es un ejemplo claro de una preocupacion profesional: no basta con que “funcione hoy”; el stack debe mantenerse actualizado.

### 5.9. Paginacion y filtrado (REST vs GraphQL)

**REST**
- Paginacion tipica con query params: `page`, `perPage`, `limit`, `offset`.
- Filtrado con query params (`ciudad`, `precioMin`, `precioMax`, etc.).
- Ventaja: en algunos casos se puede beneficiar del cache por URL si las respuestas son estables.

**GraphQL**
- Paginacion modelada en el schema con argumentos (ej. `pisos(page:, perPage:)`) o con cursor-based pagination.
- Filtrado con argumentos tipados o inputs.
- Ventaja: contrato mas explicito y consistente; el cliente combina filtros y seleccion de campos en una sola operacion.

Conclusion:
- REST suele ser mas inmediato de exponer.
- GraphQL requiere diseñar el contrato de paginacion/filtros, pero aporta tipado y coherencia.

## 6. Analisis aplicado a RentEase (nuestro caso)

### 6.1. Por que GraphQL puede ser mejor en este proyecto

1. **Pantallas con composicion de datos**
   - Detalle de piso: piso + propietario + comentarios + (posible) disponibilidad/reservas.
   - Dashboard propietario: mis anuncios + reservas recibidas.
   - Dashboard inquilino: mis reservas + estados + cancelacion.

   GraphQL puede servir estas vistas con una sola query bien diseñada.

2. **Contrato tipado y mejor integracion con el frontend**
   - El schema sirve como documentacion viva.
   - Disminuye errores de integracion al validar tipos/campos (especialmente util al crecer el proyecto).

3. **Posible mejora de UX con cache en cliente**
   - Apollo Client cachea resultados en una cache normalizada y puede responder rapidamente a consultas repetidas [13][14].

### 6.2. Por que GraphQL puede ser peor (o mas complejo) aqui

1. **Uploads de imagenes**
   - RentEase depende de imagenes (pisos, avatar).
   - En REST es directo; en GraphQL requiere multipart spec + middleware + mas configuracion [19][20].

2. **Autorizacion fina: mas facil olvidar checks**
   - En GraphQL la autorizacion debe aplicarse en cada resolver sensible.
   - Esto exige disciplina para evitar que una mutation quede sin validacion de rol/propiedad.

3. **Riesgo N+1 si no se optimiza**
   - Requiere diseñar resolvers con batching/expand o DataLoader [17][21].

4. **Coste operacional en seguridad**
   - GraphQL necesita limites (depth/complexity) y medidas OWASP especificas [10][11][12].

### 6.3. Que significa portar el backend en RentEase

Portar el backend consiste en:
- mantener el mismo modelo de datos (PocketBase),
- mantener reglas de negocio (roles, estados de reserva),
- y exponer una API alternativa (GraphQL) consumible por el frontend.

En practico:
- REST: endpoints `/api/pisos`, `/api/reservas`, etc.
- GraphQL: schema con `Query`/`Mutation` equivalentes (`pisos`, `createReserva`, etc.).

### 6.4. Equivalencia de operaciones REST y GraphQL

| Caso de uso | REST (ejemplo) | GraphQL (ejemplo) |
|---|---|---|
| Listar pisos (con filtros) | `GET /api/pisos?ciudad=X&precioMin=...` | `query { pisos(ciudad:"X", precioMin:...) { items { id titulo ciudad precio } } }` |
| Detalle de piso (composicion) | `GET /api/pisos/:id` + `GET /api/comentarios?piso_id=id` | `query { piso(id:"..."){ titulo ciudad propietario{ nombre } comentarios{ coment valoracion } } }` |
| Crear reserva | `POST /api/reservas` | `mutation { createReserva(input:{...}) { id estado } }` |
| Login | `POST /api/auth/login` | `mutation { login(input:{ email:"", password:"" }) { token user { id email rol } } }` |
| Crear comentario | `POST /api/comentarios` | `mutation { createComentario(input:{...}) { id valoracion } }` |

## 7. Aspectos clave mas alla de clase

En esta seccion recogemos conceptos que normalmente no se profundizan en una introduccion basica, pero que son relevantes al usar GraphQL de forma correcta.

### 7.1. Introspeccion y documentacion automatica

La introspeccion permite explorar el schema y alimentar tooling (autocompletado, docs, etc.) [3].  
En un entorno academico y de equipo, esto mejora productividad y reduce friccion al consumir la API.

### 7.2. Limites de complejidad y profundidad (seguridad real)

Sin limites, GraphQL permite queries con nesting profundo o con gran volumen de datos, aumentando riesgo de DoS logico. OWASP recomienda:
- limite de profundidad,
- coste maximo por query,
- paginacion,
- rate limiting,
- timeouts [10][11][12].

### 7.3. N+1 y DataLoader

GraphQL no garantiza eficiencia automaticamente: una implementacion ingenua genera N+1.  
DataLoader soluciona esto agrupando cargas (batch) y cacheando por request [17].

### 7.4. PocketBase `expand` como “join” pragmatico

PocketBase permite expandir relaciones con el parametro `expand` y asi reducir llamadas adicionales [21].  
Importante: solo se expanden relaciones que el cliente tenga permiso de ver segun las reglas API [21].  
Esto conecta directamente con seguridad y diseño de permisos.

### 7.5. Ciclo de vida de dependencias (Apollo Server 4)

Apollo Server 4 esta deprecated y pasa a end-of-life el **26/01/2026** [15][16].  
Como la entrega es el **18/01/2026**, este punto demuestra una preocupacion realista: planificar migraciones y evitar depender de software sin soporte.


## 8. Conclusiones y recomendaciones

### 8.1. Conclusion general

- **GraphQL** es una excelente opcion cuando el frontend necesita datos relacionales “a medida”, y cuando interesa un contrato tipado con tooling potente [1][2][3].
- **REST** sigue siendo muy robusto por simplicidad, cache HTTP nativo y manejo directo de uploads [7][8][9].

### 8.2. Recomendacion concreta para RentEase

- Usar GraphQL tiene sentido para **consultas y composicion de datos** (listas/detalles/dashboards).
- Para **uploads**, REST es mas directo, o bien GraphQL con soporte Upload bien implementado (multipart spec + middleware) [19][20].

En un proyecto academico, una estrategia defendible es:
- GraphQL para queries/mutations de negocio,
- y subida de ficheros con REST (o GraphQL si se implementa correctamente la parte de uploads).

## 9. Referencias

> Todas las referencias son fuentes online (documentacion oficial y guias tecnicas) usadas para sustentar los conceptos tratados.

### GraphQL (fundamentos, schema, introspeccion)
[1] GraphQL.org — *What is GraphQL?*  
https://graphql.org/  

[2] GraphQL.org — *Schemas and Types*  
https://graphql.org/learn/schema/  

[3] GraphQL.org — *Introspection*  
https://graphql.org/learn/introspection/  

### REST (base teorica)
[6] Roy Fielding — *Representational State Transfer (REST)* (Dissertation, Chapter 5)  
https://roy.gbiv.com/pubs/dissertation/rest_arch_style.htm  

### Cache HTTP (REST y web)
[7] MDN — *HTTP caching*  
https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Caching  

[8] MDN — *Last-Modified header*  
https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Last-Modified  

[9] MDN — *304 Not Modified*  
https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status/304  

### Seguridad GraphQL (OWASP)
[10] OWASP Cheat Sheet — *GraphQL Cheat Sheet*  
https://cheatsheetseries.owasp.org/cheatsheets/GraphQL_Cheat_Sheet.html  

[11] OWASP WSTG — *Testing GraphQL*  
https://owasp.org/www-project-web-security-testing-guide/v42/4-Web_Application_Security_Testing/12-API_Testing/01-Testing_GraphQL  

[12] OWASP WSTG — recomendaciones de mitigacion (complejidad, throttling, errores)  
https://owasp.org/www-project-web-security-testing-guide/v42/4-Web_Application_Security_Testing/12-API_Testing/01-Testing_GraphQL  

### Apollo Client / Apollo Server (cache y mantenimiento)
[13] Apollo Client — *Caching in Apollo Client (overview)*  
https://www.apollographql.com/docs/react/caching/overview  

[14] Apollo Client — *InMemoryCache (API)*  
https://www.apollographql.com/docs/react/api/cache/InMemoryCache  

[15] Apollo Server — *Previous versions (estado de AS4)*  
https://www.apollographql.com/docs/apollo-server/previous-versions  

[16] Apollo Server — *Migrating from Apollo Server 4 (EOL 26 Jan 2026)*  
https://www.apollographql.com/docs/apollo-server/migration  

### N+1 y DataLoader
[17] DataLoader (batching + per-request caching)  
https://github.com/graphql/dataloader  

### Uploads en GraphQL (multipart spec)
[19] GraphQL multipart request specification  
https://github.com/jaydenseric/graphql-multipart-request-spec  

[20] graphql-upload (middleware + Upload scalar)  
https://github.com/jaydenseric/graphql-upload  

### PocketBase (relaciones y expand)
[21] PocketBase — *Working with relations (expand)*  
https://pocketbase.io/docs/working-with-relations/  
