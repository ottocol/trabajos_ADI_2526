
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Filter, SortAsc, LayoutGrid, List as ListIcon, Calendar as CalendarIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';
import { itemsService } from '@/services/itemsService';
import ItemCard from '@/components/items/ItemCard';
import ItemModal from '@/components/items/ItemModal';
import { useLanguage } from '@/contexts/LanguageContext';
import { Badge } from '@/components/ui/badge';
import { isSameDay, isSameWeek } from 'date-fns';

const ItemsPage = () => {
  const { t } = useLanguage();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  
  // Filtering & Sorting State
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('all'); // all, active, favorite, today, week
  const [sortBy, setSortBy] = useState('newest'); // newest, priority, due_date
  
  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    setLoading(true);
    const { data, error } = await itemsService.getAll();
    if (!error && data) {
      setItems(data);
    }
    setLoading(false);
  };

  const handleCreate = async (itemData) => {
    const { data, error } = await itemsService.create(itemData);
    if (!error && data) {
      setItems([data, ...items]);
      toast({ title: t('common.success'), description: "Item created successfully." });
      setModalOpen(false);
    }
  };

  const handleUpdate = async (id, itemData) => {
    const { data, error } = await itemsService.update(id, itemData);
    if (!error && data) {
      setItems(items.map(item => item.id === id ? data : item));
      toast({ title: t('common.success'), description: "Item updated successfully." });
      setModalOpen(false);
      setEditingItem(null);
    }
  };

  const handleDelete = async (id) => {
    const { error } = await itemsService.delete(id);
    if (!error) {
      setItems(items.filter(item => item.id !== id));
      toast({ title: t('common.success'), description: "Item deleted successfully." });
    }
  };

  const handleToggleFavorite = async (item) => {
    const updated = { ...item, is_favorite: !item.is_favorite };
    // Optimistic update
    setItems(items.map(i => i.id === item.id ? updated : i));
    
    // API call
    const { error } = await itemsService.update(item.id, { is_favorite: !item.is_favorite });
    if (error) {
      // Revert if error
      setItems(items.map(i => i.id === item.id ? item : i));
      toast({ title: t('common.error'), variant: "destructive" });
    }
  };
  
  const handleToggleArchive = async (item) => {
    const updated = { ...item, archived: !item.archived };
    setItems(items.map(i => i.id === item.id ? updated : i));
    const { error } = await itemsService.update(item.id, { archived: !item.archived });
    if (error) toast({ title: t('common.error'), variant: "destructive" });
  };

  // Filter & Sort Logic
  const filteredAndSortedItems = useMemo(() => {
    let result = items;

    // Search
    if (searchTerm) {
      result = result.filter(item => 
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.tags?.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Filters
    const now = new Date();
    switch (activeFilter) {
      case 'active':
        result = result.filter(item => item.status === 'active' && !item.archived);
        break;
      case 'favorite':
        result = result.filter(item => item.is_favorite && !item.archived);
        break;
      case 'today':
        result = result.filter(item => item.due_date && isSameDay(new Date(item.due_date), now));
        break;
      case 'week':
        result = result.filter(item => item.due_date && isSameWeek(new Date(item.due_date), now));
        break;
      case 'archived':
        result = result.filter(item => item.archived);
        break;
      default: // all
        result = result.filter(item => !item.archived);
    }

    // Sorting
    result.sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.created_at) - new Date(a.created_at);
      if (sortBy === 'priority') {
        const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
        return (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
      }
      if (sortBy === 'due_date') {
        if (!a.due_date) return 1;
        if (!b.due_date) return -1;
        return new Date(a.due_date) - new Date(b.due_date);
      }
      return 0;
    });

    return result;
  }, [items, searchTerm, activeFilter, sortBy]);

  return (
    <div className="space-y-6 w-full max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-text dark:text-white mb-2">
            {t('items.title')}
          </h1>
          <p className="text-secondary dark:text-gray-400">
            {t('items.subtitle')}
          </p>
        </div>
        <Button
          onClick={() => { setEditingItem(null); setModalOpen(true); }}
          className="bg-primary hover:bg-blue-700 text-white w-full md:w-auto"
        >
          <Plus className="w-4 h-4 mr-2" />
          {t('items.add')}
        </Button>
      </div>

      <div className="flex flex-col lg:flex-row gap-4 items-center bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="relative w-full lg:w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input 
            placeholder={t('items.search')} 
            className="pl-9 w-full" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2 w-full lg:w-auto overflow-x-auto pb-2 lg:pb-0 scrollbar-hide">
          <FilterButton active={activeFilter === 'all'} onClick={() => setActiveFilter('all')} label={t('common.all')} />
          <FilterButton active={activeFilter === 'active'} onClick={() => setActiveFilter('active')} label="Active" />
          <FilterButton active={activeFilter === 'favorite'} onClick={() => setActiveFilter('favorite')} label={t('items.favorite')} />
          <FilterButton active={activeFilter === 'today'} onClick={() => setActiveFilter('today')} label={t('common.today')} />
          <FilterButton active={activeFilter === 'week'} onClick={() => setActiveFilter('week')} label={t('common.thisWeek')} />
          <FilterButton active={activeFilter === 'archived'} onClick={() => setActiveFilter('archived')} label={t('items.archived')} />
        </div>

        <div className="flex-1" />

        <div className="flex items-center gap-2 w-full lg:w-auto justify-end">
          <span className="text-sm text-secondary dark:text-gray-400 hidden lg:inline">{t('items.sort')}:</span>
          <select 
            className="h-10 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 px-3 py-2 text-sm text-text dark:text-white focus:outline-none"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="newest">Newest</option>
            <option value="priority">Priority</option>
            <option value="due_date">Due Date</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : filteredAndSortedItems.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg border border-dashed border-gray-300 dark:border-gray-700">
          <p className="text-secondary dark:text-gray-400 mb-4">{t('items.noItems')}</p>
          <Button onClick={() => setModalOpen(true)} variant="outline">
            {t('items.createFirst')}
          </Button>
        </div>
      ) : (
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence>
            {filteredAndSortedItems.map((item) => (
              <ItemCard
                key={item.id}
                item={item}
                onEdit={() => { setEditingItem(item); setModalOpen(true); }}
                onDelete={() => handleDelete(item.id)}
                onToggleFavorite={() => handleToggleFavorite(item)}
                onToggleArchive={() => handleToggleArchive(item)}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      )}

      <ItemModal
        isOpen={modalOpen}
        onClose={() => {
          setModalOpen(false);
          setEditingItem(null);
        }}
        onSubmit={editingItem ? (data) => handleUpdate(editingItem.id, data) : handleCreate}
        item={editingItem}
      />
    </div>
  );
};

const FilterButton = ({ active, onClick, label }) => (
  <button
    onClick={onClick}
    className={`px-3 py-1.5 text-sm font-medium rounded-full transition-colors whitespace-nowrap ${
      active 
        ? 'bg-primary text-white shadow-sm' 
        : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
    }`}
  >
    {label}
  </button>
);

export default ItemsPage;
