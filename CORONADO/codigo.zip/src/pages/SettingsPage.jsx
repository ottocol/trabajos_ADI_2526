
import React from 'react';
import { motion } from 'framer-motion';
import { Moon, Sun, Bell, Shield, Database, Globe } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const SettingsPage = () => {
  const { isDark, toggleTheme } = useTheme();
  const { language, setLanguage, t } = useLanguage();

  const handleNotificationToggle = () => {
    toast({
      title: "🚧 Feature Pending",
      description: "Notification settings are coming soon!"
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-text dark:text-white mb-2">
          {t('settings.title')}
        </h1>
        <p className="text-secondary dark:text-gray-400">
          {t('settings.subtitle')}
        </p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-4"
      >
        {/* Language Setting */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <Globe className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-text dark:text-white">
                  {t('settings.language')}
                </h3>
                <p className="text-sm text-secondary dark:text-gray-400">
                  Select your preferred language
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant={language === 'en' ? 'default' : 'outline'}
                onClick={() => setLanguage('en')}
                size="sm"
              >
                English
              </Button>
              <Button
                variant={language === 'es' ? 'default' : 'outline'}
                onClick={() => setLanguage('es')}
                size="sm"
              >
                Español
              </Button>
            </div>
          </div>
        </div>

        {/* Theme Setting */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                {isDark ? <Moon className="w-6 h-6 text-purple-600" /> : <Sun className="w-6 h-6 text-purple-600" />}
              </div>
              <div>
                <h3 className="font-semibold text-text dark:text-white">
                  {t('settings.theme')}
                </h3>
                <p className="text-sm text-secondary dark:text-gray-400">
                  {isDark ? 'Dark mode enabled' : 'Light mode enabled'}
                </p>
              </div>
            </div>
            <Button
              onClick={toggleTheme}
              variant="outline"
              className="border-primary text-primary hover:bg-blue-50 dark:hover:bg-gray-700"
            >
              Toggle
            </Button>
          </div>
        </div>

        {/* Notifications Setting */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <Bell className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <h3 className="font-semibold text-text dark:text-white">
                  {t('settings.notifications')}
                </h3>
                <p className="text-sm text-secondary dark:text-gray-400">
                  Manage your notification preferences
                </p>
              </div>
            </div>
            <Button
              onClick={handleNotificationToggle}
              variant="outline"
            >
              Configure
            </Button>
          </div>
        </div>

        {/* Database Info */}
        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-6">
          <div className="flex items-start gap-4">
            <Database className="w-6 h-6 text-success mt-1" />
            <div className="flex-1">
              <h3 className="font-semibold text-text dark:text-white mb-2">
                {t('settings.database')}: {t('settings.active')}
              </h3>
              <p className="text-sm text-secondary dark:text-gray-400 mb-3">
                Your application is successfully connected to Supabase.
              </p>
              <ul className="text-sm text-secondary dark:text-gray-400 space-y-1 list-disc list-inside">
                <li>Real-time authentication enabled</li>
                <li>Items database table connected</li>
                <li>Row Level Security (RLS) policies active</li>
              </ul>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default SettingsPage;
