
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, CheckCircle, Package, Clock } from 'lucide-react';
import StatsCard from '@/components/dashboard/StatsCard';
import DashboardCalendar from '@/components/dashboard/DashboardCalendar';
import { dashboardService } from '@/services/dashboardService';

const DashboardHome = () => {
  const [stats, setStats] = useState({
    totalItems: 0,
    activeItems: 0,
    completedItems: 0,
    completionRate: 0
  });
  const [calendarEvents, setCalendarEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadDashboardData = async () => {
      setLoading(true);
      
      const [statsData, eventsData] = await Promise.all([
        dashboardService.getStats(),
        dashboardService.getCalendarEvents()
      ]);

      if (statsData) setStats(statsData);
      if (eventsData) setCalendarEvents(eventsData);
      
      setLoading(false);
    };

    loadDashboardData();
  }, []);

  const statCards = [
    {
      title: 'Total Items',
      value: loading ? '...' : stats.totalItems,
      change: 'All time',
      icon: <Package className="w-6 h-6" />,
      trend: 'neutral'
    },
    {
      title: 'Active Items',
      value: loading ? '...' : stats.activeItems,
      change: 'In progress',
      icon: <Clock className="w-6 h-6" />,
      trend: 'neutral'
    },
    {
      title: 'Completed',
      value: loading ? '...' : stats.completedItems,
      change: 'Finished',
      icon: <CheckCircle className="w-6 h-6" />,
      trend: 'up'
    },
    {
      title: 'Completion Rate',
      value: loading ? '...' : `${stats.completionRate}%`,
      change: 'Efficiency',
      icon: <TrendingUp className="w-6 h-6" />,
      trend: 'up'
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-text dark:text-white mb-2">
          Dashboard Overview
        </h1>
        <p className="text-secondary dark:text-gray-400">
          Welcome back! Here's what's happening with your items and schedule.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <StatsCard {...stat} />
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6">
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.4 }}
        >
          <DashboardCalendar events={calendarEvents} />
        </motion.div>
      </div>
    </div>
  );
};

export default DashboardHome;
