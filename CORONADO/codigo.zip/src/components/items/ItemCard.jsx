
import React from 'react';
import { motion } from 'framer-motion';
import { Edit, Trash2, Calendar, Star, Archive, BarChart2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const ItemCard = ({ item, onEdit, onDelete, onToggleFavorite, onToggleArchive }) => {
  const priorityColors = {
    low: "text-blue-500 bg-blue-100 dark:bg-blue-900/30",
    medium: "text-yellow-600 bg-yellow-100 dark:bg-yellow-900/30",
    high: "text-orange-600 bg-orange-100 dark:bg-orange-900/30",
    urgent: "text-red-600 bg-red-100 dark:bg-red-900/30"
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -4 }}
      className={cn(
        "bg-white dark:bg-gray-800 rounded-lg p-5 shadow-sm border transition-all relative overflow-hidden",
        item.is_favorite ? "border-primary/50 ring-1 ring-primary/20" : "border-gray-200 dark:border-gray-700",
        item.archived && "opacity-75 grayscale-[0.5]"
      )}
    >
      {/* Progress Bar Background */}
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gray-100 dark:bg-gray-700">
        <div 
          className="h-full bg-primary transition-all duration-500"
          style={{ width: `${item.progress || 0}%` }}
        />
      </div>

      <div className="flex items-start justify-between mb-3">
        <div className="flex-1 pr-4">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="text-lg font-semibold text-text dark:text-white truncate">
              {item.name || 'Untitled Item'}
            </h3>
            {item.is_favorite && (
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            )}
          </div>
          <p className="text-sm text-secondary dark:text-gray-400 line-clamp-2 h-10">
            {item.description || 'No description provided'}
          </p>
        </div>
        <div className="flex flex-col gap-2 items-end">
          {item.status && (
            <Badge variant={item.status === 'active' ? 'success' : 'secondary'}>
              {item.status}
            </Badge>
          )}
          {item.priority && (
            <span className={cn("text-xs px-2 py-0.5 rounded-full font-medium", priorityColors[item.priority] || priorityColors.medium)}>
              {item.priority}
            </span>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-1 mb-4 h-6 overflow-hidden">
        {item.tags && item.tags.map((tag, idx) => (
          <span key={idx} className="text-xs px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-md">
            #{tag}
          </span>
        ))}
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-gray-200 dark:border-gray-700">
        <div className="flex items-center gap-3 text-xs text-secondary dark:text-gray-400">
          {item.due_date && (
            <div className="flex items-center gap-1" title="Due Date">
              <Calendar className="w-3.5 h-3.5" />
              <span>{format(new Date(item.due_date), 'MMM d')}</span>
            </div>
          )}
          {item.progress !== undefined && (
            <div className="flex items-center gap-1" title="Progress">
              <BarChart2 className="w-3.5 h-3.5" />
              <span>{item.progress}%</span>
            </div>
          )}
        </div>
        
        <div className="flex gap-1">
          <Button
            onClick={onToggleFavorite}
            size="icon"
            variant="ghost"
            className={cn("h-8 w-8 hover:bg-yellow-50 dark:hover:bg-yellow-900/20", item.is_favorite ? "text-yellow-500" : "text-gray-400")}
            title="Toggle Favorite"
          >
            <Star className={cn("w-4 h-4", item.is_favorite && "fill-current")} />
          </Button>
          <Button
            onClick={onToggleArchive}
            size="icon"
            variant="ghost"
            className={cn("h-8 w-8 hover:bg-purple-50 dark:hover:bg-purple-900/20", item.archived ? "text-purple-500" : "text-gray-400")}
            title="Toggle Archive"
          >
            <Archive className="w-4 h-4" />
          </Button>
          <Button
            onClick={onEdit}
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-primary hover:bg-primary/10"
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button
            onClick={onDelete}
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-error hover:bg-red-50 dark:hover:bg-red-900/20"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default ItemCard;
