
import React, { useState } from 'react';
import { DayPicker } from 'react-day-picker';
import { format, parseISO } from 'date-fns';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { buttonVariants } from '@/components/ui/button';

const DashboardCalendar = ({ events = [] }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());

  // Create a map for quick lookup: "yyyy-MM-dd" -> event object
  const eventsMap = events.reduce((acc, event) => {
    // Ensure date is string yyyy-MM-dd
    const dateKey = typeof event.date === 'string' ? event.date : format(event.date, 'yyyy-MM-dd');
    acc[dateKey] = event;
    return acc;
  }, {});

  const modifiers = {
    hasEvent: (date) => {
      const key = format(date, 'yyyy-MM-dd');
      return !!eventsMap[key];
    }
  };

  const modifiersStyles = {
    hasEvent: {
      fontWeight: 'bold'
    }
  };

  // Custom Day Component to render dots
  const renderDay = (day) => {
    const dateKey = format(day, 'yyyy-MM-dd');
    const event = eventsMap[dateKey];
    
    return (
      <div className="relative w-full h-full flex items-center justify-center">
        {day.getDate()}
        {event && (
          <div className="absolute bottom-1 flex gap-0.5 justify-center">
             <div className={cn("w-1.5 h-1.5 rounded-full", event.color || "bg-primary")} />
          </div>
        )}
      </div>
    );
  };

  const selectedEvent = eventsMap[format(selectedDate, 'yyyy-MM-dd')];

  return (
    <div className="flex flex-col md:flex-row gap-6 bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
      <div className="flex-1">
        <h3 className="text-lg font-semibold text-text dark:text-white mb-4">Calendar</h3>
        <DayPicker
          mode="single"
          selected={selectedDate}
          onSelect={setSelectedDate}
          showOutsideDays
          modifiers={modifiers}
          modifiersStyles={modifiersStyles}
          components={{
            DayContent: ({ date }) => renderDay(date),
            IconLeft: ({ ...props }) => <ChevronLeft className="h-4 w-4" />,
            IconRight: ({ ...props }) => <ChevronRight className="h-4 w-4" />,
          }}
          className="p-0"
          classNames={{
            months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
            month: "space-y-4 w-full",
            caption: "flex justify-between pt-1 relative items-center px-1",
            caption_label: "text-sm font-medium text-text dark:text-white",
            nav: "space-x-1 flex items-center",
            nav_button: cn(
              buttonVariants({ variant: "outline" }),
              "h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100"
            ),
            table: "w-full border-collapse space-y-1",
            head_row: "flex w-full justify-between",
            head_cell: "text-muted-foreground rounded-md w-9 font-normal text-[0.8rem]",
            row: "flex w-full mt-2 justify-between",
            cell: "h-9 w-9 text-center text-sm p-0 relative [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
            day: cn(
              buttonVariants({ variant: "ghost" }),
              "h-9 w-9 p-0 font-normal aria-selected:opacity-100 text-text dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
            ),
            day_selected:
              "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground",
            day_today: "bg-accent text-accent-foreground font-bold",
          }}
        />
      </div>
      
      <div className="w-full md:w-64 border-t md:border-t-0 md:border-l border-gray-200 dark:border-gray-700 pt-6 md:pt-0 md:pl-6">
        <h4 className="font-medium text-text dark:text-white mb-4">
          {format(selectedDate, 'MMMM d, yyyy')}
        </h4>
        
        {selectedEvent ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className={cn("w-3 h-3 rounded-full", selectedEvent.color || "bg-primary")} />
              <span className="font-semibold text-text dark:text-white">
                {selectedEvent.item_count} Items Due
              </span>
            </div>
            <p className="text-sm text-secondary dark:text-gray-400">
              You have {selectedEvent.item_count} items scheduled for this day.
            </p>
          </motion.div>
        ) : (
          <div className="text-sm text-secondary dark:text-gray-400 italic">
            No items due on this date.
          </div>
        )}

        <div className="mt-6">
          <h5 className="text-xs font-semibold text-secondary dark:text-gray-400 uppercase tracking-wider mb-3">Legend</h5>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-red-500" />
              <span className="text-text dark:text-white">Urgent Priority</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-orange-500" />
              <span className="text-text dark:text-white">High Priority</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-yellow-500" />
              <span className="text-text dark:text-white">Medium Priority</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardCalendar;
