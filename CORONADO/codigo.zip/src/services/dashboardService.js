
import { supabase } from './supabase';
import { format } from 'date-fns';

export const dashboardService = {
  getStats: async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // Get real item counts
      const { count: totalItems, error: totalError } = await supabase
        .from('items')
        .select('*', { count: 'exact', head: true });

      if (totalError) throw totalError;

      const { count: activeItems, error: activeError } = await supabase
        .from('items')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      if (activeError) throw activeError;

      const { count: completedItems, error: completedError } = await supabase
        .from('items')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'completed');

      if (completedError) throw completedError;

      // Calculate simple growth/trends based on created_at (mock logic for demo purposes since we don't have historical snapshots)
      // In a real app, you'd query historical data or a separate analytics table.
      
      return {
        totalItems: totalItems || 0,
        activeItems: activeItems || 0,
        completedItems: completedItems || 0,
        completionRate: totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0
      };
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      return null;
    }
  },

  getCalendarEvents: async () => {
    try {
      // First, let's sync calendar_events based on items due_dates
      // In a production app, this would be better handled by a Database Trigger or Edge Function
      await syncCalendarEvents();

      const { data, error } = await supabase
        .from('calendar_events')
        .select('*');

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching calendar events:', error);
      return [];
    }
  }
};

// Helper function to sync items due_dates to calendar_events
// This is a client-side simulation of what should ideally be a backend trigger
async function syncCalendarEvents() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  // 1. Get all items with due dates
  const { data: items } = await supabase
    .from('items')
    .select('due_date, priority')
    .not('due_date', 'is', null);

  if (!items) return;

  // 2. Group by date
  const eventsByDate = {};
  items.forEach(item => {
    const dateStr = format(new Date(item.due_date), 'yyyy-MM-dd');
    if (!eventsByDate[dateStr]) {
      eventsByDate[dateStr] = { count: 0, priorityScore: 0 };
    }
    eventsByDate[dateStr].count++;
    
    // Assign score to determine color
    const score = item.priority === 'urgent' ? 3 : item.priority === 'high' ? 2 : 1;
    eventsByDate[dateStr].priorityScore = Math.max(eventsByDate[dateStr].priorityScore, score);
  });

  // 3. Prepare upsert data
  const upsertData = Object.entries(eventsByDate).map(([date, data]) => {
    let color = 'bg-blue-500'; // Default low priority
    if (data.priorityScore === 3) color = 'bg-red-500';
    else if (data.priorityScore === 2) color = 'bg-orange-500';
    else if (data.priorityScore === 1) color = 'bg-yellow-500';

    return {
      user_id: user.id,
      date: date,
      item_count: data.count,
      color: color
    };
  });

  // 4. Upsert into calendar_events (requires unique constraint on user_id + date ideally, 
  // but for now we'll delete old ones for this user to keep it simple and clean)
  
  // Clean slate for simplicity in this demo environment
  await supabase.from('calendar_events').delete().eq('user_id', user.id);
  
  if (upsertData.length > 0) {
    await supabase.from('calendar_events').insert(upsertData);
  }
}
