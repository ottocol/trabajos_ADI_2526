
import { supabase } from './supabase';

export const itemsService = {
  getAll: async () => {
    try {
      const { data, error } = await supabase
        .from('items')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error fetching items:', error.message);
      return { data: null, error };
    }
  },

  create: async (item) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('items')
        .insert([{ 
          ...item, 
          user_id: user.id,
          // Ensure defaults if missing
          tags: item.tags || [],
          progress: item.progress || 0,
          is_favorite: item.is_favorite || false,
          archived: item.archived || false,
          priority: item.priority || 'medium'
        }])
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error creating item:', error.message);
      return { data: null, error };
    }
  },

  update: async (id, updates) => {
    try {
      // Don't update user_id or created_at
      const { user_id, created_at, ...safeUpdates } = updates;

      const { data, error } = await supabase
        .from('items')
        .update({ ...safeUpdates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error updating item:', error.message);
      return { data: null, error };
    }
  },

  delete: async (id) => {
    try {
      const { error } = await supabase
        .from('items')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { data: true, error: null };
    } catch (error) {
      console.error('Error deleting item:', error.message);
      return { data: null, error };
    }
  }
};
