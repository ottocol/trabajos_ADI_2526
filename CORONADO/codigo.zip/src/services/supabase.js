
import { supabase } from '@/lib/customSupabaseClient';

export { supabase };
