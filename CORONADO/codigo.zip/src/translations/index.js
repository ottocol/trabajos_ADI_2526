
export const translations = {
  en: {
    dashboard: {
      title: "Dashboard Overview",
      subtitle: "Welcome back! Here's what's happening with your business.",
      revenue: "Total Revenue",
      users: "Active Users",
      orders: "Total Orders",
      growth: "Growth Rate",
      menu: "Dashboard"
    },
    items: {
      title: "Items Management",
      subtitle: "Manage your items and inventory",
      add: "Add Item",
      edit: "Edit Item",
      create: "Create New Item",
      noItems: "No items yet",
      createFirst: "Create Your First Item",
      search: "Search items...",
      filter: "Filter",
      sort: "Sort",
      menu: "Items",
      status: "Status",
      priority: "Priority",
      tags: "Tags",
      dueDate: "Due Date",
      progress: "Progress",
      favorite: "Favorite",
      archived: "Archived"
    },
    profile: {
      title: "Profile Settings",
      subtitle: "Manage your account information",
      save: "Save Changes",
      saving: "Saving...",
      name: "Full Name",
      email: "Email",
      memberSince: "Member Since",
      menu: "Profile"
    },
    settings: {
      title: "Settings",
      subtitle: "Customize your application preferences",
      theme: "Theme",
      language: "Language",
      notifications: "Notifications",
      security: "Security",
      database: "Database Status",
      active: "Active",
      menu: "Settings"
    },
    common: {
      cancel: "Cancel",
      delete: "Delete",
      save: "Save",
      update: "Update",
      create: "Create",
      success: "Success!",
      error: "Error",
      today: "Today",
      thisWeek: "This Week",
      all: "All",
      low: "Low",
      medium: "Medium",
      high: "High",
      urgent: "Urgent"
    }
  },
  es: {
    dashboard: {
      title: "Resumen del Panel",
      subtitle: "¡Bienvenido! Esto es lo que está pasando con tu negocio.",
      revenue: "Ingresos Totales",
      users: "Usuarios Activos",
      orders: "Pedidos Totales",
      growth: "Tasa de Crecimiento",
      menu: "Panel"
    },
    items: {
      title: "Gestión de Artículos",
      subtitle: "Administra tus artículos e inventario",
      add: "Añadir Artículo",
      edit: "Editar Artículo",
      create: "Crear Nuevo Artículo",
      noItems: "No hay artículos aún",
      createFirst: "Crea Tu Primer Artículo",
      search: "Buscar artículos...",
      filter: "Filtrar",
      sort: "Ordenar",
      menu: "Artículos",
      status: "Estado",
      priority: "Prioridad",
      tags: "Etiquetas",
      dueDate: "Fecha de Vencimiento",
      progress: "Progreso",
      favorite: "Favorito",
      archived: "Archivado"
    },
    profile: {
      title: "Configuración de Perfil",
      subtitle: "Administra la información de tu cuenta",
      save: "Guardar Cambios",
      saving: "Guardando...",
      name: "Nombre Completo",
      email: "Correo Electrónico",
      memberSince: "Miembro Desde",
      menu: "Perfil"
    },
    settings: {
      title: "Configuración",
      subtitle: "Personaliza las preferencias de tu aplicación",
      theme: "Tema",
      language: "Idioma",
      notifications: "Notificaciones",
      security: "Seguridad",
      database: "Estado de Base de Datos",
      active: "Activo",
      menu: "Configuración"
    },
    common: {
      cancel: "Cancelar",
      delete: "Eliminar",
      save: "Guardar",
      update: "Actualizar",
      create: "Crear",
      success: "¡Éxito!",
      error: "Error",
      today: "Hoy",
      thisWeek: "Esta Semana",
      all: "Todos",
      low: "Baja",
      medium: "Media",
      high: "Alta",
      urgent: "Urgente"
    }
  }
};
