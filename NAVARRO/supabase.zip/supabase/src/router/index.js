import { createRouter, createWebHistory } from 'vue-router';
import LoginForm from '@/components/LoginForm.vue';
import ListaCompra from '@/components/ListaCompra.vue';
import About from '@/components/About.vue';
// 1. Importamos supabase en lugar de pb
import { supabase } from '@/backend/config/supabase';

const routes = [
  {
    path: '/',
    redirect: { name: "Lista" }
  },
  {
    path: '/lista',
    name: 'Lista',
    component: ListaCompra,
    meta: { requiresAuth: true },
  },
  {
    path: '/login',
    name: 'Login',
    component: LoginForm,
  },
  {
    path: '/about',
    name: 'About',
    component: About
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

// Guard de navegación actualizado para Supabase
// Hacemos la función 'async' porque supabase.auth.getSession es asíncrono
router.beforeEach(async (to, from) => {
  
  // Verificamos si la ruta requiere autenticación
  if (to.meta.requiresAuth) {
    // 2. Pedimos la sesión actual a Supabase
    const { data } = await supabase.auth.getSession();
    
    // 3. Si no hay sesión (session es null), mandamos al Login
    if (!data.session) {
      return { name: 'Login' };
    }
  }
  
});

export default router;