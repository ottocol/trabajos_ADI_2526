import { supabase } from '../config/supabase'

async function getItems() {
    // PB: getFullList() -> Supabase: select('*')
    const { data, error } = await supabase
        .from("lista")
        .select('*')
        .order('created_at', { ascending: false }) // Ordenamos para que salgan los nuevos primero

    if (error) throw error
    return data
}

async function getItem(id) {
    const { data, error } = await supabase
        .from("lista")
        .select('*')
        .eq('id', id)
        .single() 

    if (error) throw error
    return data
}

async function addItem(nombre) {
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) throw new Error("No hay usuario logueado")

    const { data, error } = await supabase
        .from("lista")
        .insert({
            nombre: nombre,
            comprado: false, 
            usuario: user.id 
        })
        .select()
        .single() // Devolvemos el objeto creado para el frontend

    if (error) throw error
    return data
}

async function updateComprado(id, comprado) {
    const { data, error } = await supabase
        .from("lista")
        .update({ comprado: comprado })
        .eq('id', id)
        .select()
        .single()

    if (error) throw error
    return data
}

async function updateItem(id, nombre) {
    const { data, error } = await supabase
        .from("lista")
        .update({ nombre: nombre })
        .eq('id', id)
        .select()
        .single()

    if (error) throw error
    return data
}

async function deleteItem(id) {
    const { error } = await supabase
        .from("lista")
        .delete()
        .eq('id', id)

    if (error) throw error
}

export { getItems, getItem, addItem, updateItem, updateComprado, deleteItem }