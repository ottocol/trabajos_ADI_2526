import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://metkfuuhehxqoqfcqbap.supabase.co'
const supabaseKey = 'sb_publishable_fGYU0B2Q8qhIyIIxl26mhQ_PX8-f6ew'

export const supabase = createClient(supabaseUrl, supabaseKey)