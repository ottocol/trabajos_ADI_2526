import { supabase } from '../config/supabase.js';

const login = async function(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: email,
    password: password
  })

  if (error) throw error;
  return data.user;
}

const logout = async () => {
  const { error } = await supabase.auth.signOut()
  if (error) throw error;
};

const getCurrentUser = async () => {
  const { data } = await supabase.auth.getUser();
  return data.user;
}

export { login, logout, getCurrentUser };