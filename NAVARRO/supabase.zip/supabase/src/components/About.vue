<script setup>
    import { RouterLink } from 'vue-router';
</script>

<template>
   <p> App de ejemplo para Aplicaciones Distribuidas en Internet </p>
   <RouterLink to="/">Volver</RouterLink>
</template>


