<script setup>
    import { reactive } from 'vue'
    import { useRouter } from 'vue-router'
    import { login } from '@/backend/services/authService';
    import { RouterLink } from 'vue-router';

    const router = useRouter()
    let usuario = reactive({email:"", password:""})

    async function doLogin() {
        try {
            await login(usuario.email, usuario.password)
            router.push('/') 
        }
        catch(error) {
            alert("Usuario y/o contraseña incorrectos o error de conexión")
            console.error("Error Login Supabase:", error)
        }
    }

</script>

<template>
    <form @submit.prevent="doLogin">
        <h2>Iniciar sesión</h2>
        <label for="email">Correo electrónico:</label>
        <input type="email" name="email" required v-model="usuario.email" placeholder="ejemplo@email.com">
        
        <label for="password">Contraseña:</label>
        <input type="password" name="password" required v-model="usuario.password">
        
        <button type="submit">Iniciar sesión</button>
        
        <RouterLink to="/about" class="about-link">
            Acerca de la app
        </RouterLink>  
    </form>
</template>

<style scoped>
/* Tus estilos originales se mantienen igual, solo añadí un pequeño margen al enlace */

form {
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    max-width: 400px; /* Limitamos el ancho para que quede mejor centrado */
    margin: 0 auto;   /* Centramos el formulario */
}

form h2 {
    margin-top: 0;
    margin-bottom: 20px;
    text-align: center;
}

form label {
    display: block;
    margin-bottom: 5px;
    color: #333;
    font-weight: bold;
}

form button {
    width: 100%;
    margin-top: 20px;
    padding: 10px;
    background-color: #3ecf8e; /* Color verde corporativo de Supabase (guiño para el trabajo) */
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

form button:hover {
    background-color: #34b379;
}

input[type="text"],
input[type="password"],
input[type="email"] {
    width: 100%;      /* Asegura que ocupen todo el ancho */
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin-bottom: 10px;
    box-sizing: border-box; /* Evita que el padding rompa el ancho */
}

.about-link {
    display: block;
    text-align: center;
    margin-top: 15px;
    color: #666;
    text-decoration: none;
    font-size: 0.9em;
}

.about-link:hover {
    text-decoration: underline;
}

</style>