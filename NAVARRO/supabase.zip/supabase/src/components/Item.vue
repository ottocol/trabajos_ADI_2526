<script setup>
    defineProps(['id', 'nombre', 'comprado'])
    // Añadimos 'delete_item' a los eventos que este componente puede emitir
    defineEmits(["toggle_item", "delete_item"])
</script>

<template>
    <li> 
        <div :class="{tachado:comprado}" @click="$emit('toggle_item', id)">
            {{ nombre }}
        </div>
        
        <button class="delete-btn" @click="$emit('delete_item', id)">
            Eliminar
        </button>
    </li>
</template>

<style scoped>
li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    background-color: white;
    border-bottom: 1px solid #ddd;
    font-size: 20px;
}

li:last-child {
    border-bottom: none;
}

.tachado {
    text-decoration: line-through;
    color: lightgrey;
}

/* Cursor pointer para que se note que el texto es clickable */
.tachado, div:first-child {
    cursor: pointer; 
}

.delete-btn {
    background-color: #f44336;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
    margin-left: 10px; /* Un poco de separación */
}

.delete-btn:hover {
    background-color: #d32f2f;
}
</style>