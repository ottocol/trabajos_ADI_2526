<script setup>
    import { ref } from 'vue'

    // Emitimos un evento específico
    defineEmits(["buscar_receta"])
    
    let texto = ref("")
</script>

<template>
    <div class="buscador">
        <input 
            type="text" 
            v-model="texto" 
            @keyup.enter="$emit('buscar_receta', texto)" 
            placeholder="Buscar recetas (ej: pollo, pasta...)"
        > 
        <button @click="$emit('buscar_receta', texto)">Buscar</button>
    </div>
</template>

<style scoped>
.buscador { margin-bottom: 20px; display: flex; gap: 10px; }
input { padding: 8px; flex-grow: 1; }
</style>