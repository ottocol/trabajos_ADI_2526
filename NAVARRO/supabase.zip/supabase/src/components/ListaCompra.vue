<script setup>
    // 1. Añadimos deleteItem a los imports
    import { getItems, addItem, updateComprado, deleteItem } from '@/backend/repositories/listaRepository';
    import { logout } from '@/backend/services/authService'
    import { onMounted, reactive } from 'vue';
    import Item from './Item.vue';
    import AddItemForm from './AddItemForm.vue';

    let estado = reactive({items:[]})

    async function doLogout() {
        try {
            await logout()
        } catch (error) {
            console.error("Error al salir:", error)
        }
    }

    onMounted(async function() {
        try {
            estado.items = await getItems()
        } catch (error) {
            console.error("Error cargando items:", error)
        }
    }) 

    async function doAddItem(nuevoNombre) {
        if (!nuevoNombre.trim()) return;
        try {
            let nuevoItem = await addItem(nuevoNombre) 
            estado.items.push(nuevoItem) 
        } catch (error) {
            console.error("Error añadiendo:", error)
        }
    }
        
    async function doToggleItem(id) {
        let item = estado.items.find((item) => item.id == id)
        if (item) {
            let valorAntiguo = item.comprado
            item.comprado = !item.comprado
            
            try {
                await updateComprado(id, item.comprado)
            } catch(error) {
                item.comprado = valorAntiguo
                alert("Error al actualizar")
            }
        } 
    }

    async function doDeleteItem(id) {
        if(!confirm("¿Seguro que quieres borrarlo?")) return;

        try {
            await deleteItem(id)
            estado.items = estado.items.filter(item => item.id !== id)
        } catch (error) {
            console.error("Error borrando:", error)
            alert("No se pudo borrar el elemento")
        }
    }
    
</script>

<template>
    <h2>Lista de la compra</h2>
    
    <add-item-form @add_item="doAddItem"/>
    
    <ul>
       <item 
            v-for="i in estado.items" 
            :key="i.id"
            v-bind="i" 
            @toggle_item="doToggleItem"
            @delete_item="doDeleteItem" 
       />
    </ul>
    
    <button class="logout-btn" @click="doLogout">Salir</button>
</template>

<style scoped>
ul {
    list-style-type: none;
    padding: 0;
    border: 2px solid #ddd;
    border-radius: 4px;
    overflow: hidden;
    margin-bottom: 20px;
}

h2 {
    text-align: center;
    color: #333;
}

.logout-btn {
    background-color: #666;
    margin-top: 20px;
    width: 100%;
}
.logout-btn:hover {
    background-color: #444;
}
</style>