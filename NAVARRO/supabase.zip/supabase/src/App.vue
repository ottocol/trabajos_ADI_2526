<script setup>
  import { ref, onMounted } from 'vue'
  import { useRouter } from 'vue-router'
  // 1. IMPORTANTE: Importamos 'supabase', ya no existe 'pb'
  import { supabase } from './backend/config/supabase' 
  
  const router = useRouter()
  const hay_usuario = ref(false)

  onMounted(() => {
    // 2. Al cargar la app, preguntamos si ya hay sesión guardada
    supabase.auth.getSession().then(({ data }) => {
      hay_usuario.value = !!data.session
      
      // Si no hay usuario, mandamos al login, si hay, a la home
      if (!data.session) {
        router.push('/login')
      } else {
        router.push('/')
      }
    })

    // 3. Escuchador de eventos (Equivalente a pb.authStore.onChange)
    // Esto se dispara automáticamente cuando haces login o logout
    supabase.auth.onAuthStateChange((_, session) => {
      console.log("Cambio de estado Auth:", session)
      
      if (session) {
        hay_usuario.value = true
        router.push('/') // Si entra usuario -> Lista
      } else {
        hay_usuario.value = false
        router.push('/login') // Si sale usuario -> Login
      }
    })
  })
</script>

<template>
  <router-view/>
</template>

<style>
/* Estilos generales (Los he dejado igual) */
body {
    font-family: Arial, sans-serif;
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    background-color: white;
}

h1, h2 {
    text-align: center;
    color: #333;
}

button {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #45a049;
}
</style>