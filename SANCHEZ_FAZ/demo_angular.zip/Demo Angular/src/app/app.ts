import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Tarea {
  texto: string;
  completada: boolean;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  titulo = 'Lista de Tareas en Angular';
  nuevaTarea = '';

  tareas: Tarea[] = [
    { texto: 'Aprender Angular', completada: true },
    { texto: 'Hacer la presentación', completada: false },
    { texto: 'Aprobar ADI', completada: false },
  ];

  agregarTarea() {
    if (this.nuevaTarea.trim() !== '') {
      this.tareas.push({ texto: this.nuevaTarea, completada: false });
      this.nuevaTarea = '';
    }
  }

  eliminarTarea(index: number) {
    this.tareas.splice(index, 1);
  }
}
