import 'dotenv/config'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY)

const { error: loginErr } = await supabase.auth.signInWithPassword({
  email: process.env.SUPA_EMAIL,
  password: process.env.SUPA_PASSWORD,
})

if (loginErr) {
  console.error("Login error:", loginErr.message)
  process.exit(1)
}

const { data: ins, error: insErr } = await supabase
  .from('productos')
  .insert({ nombre: 'Zapa demo', precio: 49.99 })
  .select()

if (insErr) console.error("Insert error:", insErr.message)
else console.log("Insert OK:", ins)

const { data: rows, error: selErr } = await supabase
  .from('productos')
  .select('id,nombre,precio,created_at')
  .order('created_at', { ascending: false })
  .limit(5)

if (selErr) console.error("Select error:", selErr.message)
else console.table(rows)
