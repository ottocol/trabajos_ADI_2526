<template>
  <div>
    <NuxtPage />
  </div>
</template>

<script setup>
// App principal de Nuxt
</script>
